# Tumai Pay POS

![Logo](assets/images/logo.png)
