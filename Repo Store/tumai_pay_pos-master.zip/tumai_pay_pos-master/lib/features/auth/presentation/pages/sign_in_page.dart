import 'dart:ui';

import 'package:dartz/dartz.dart' as dartz;
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:handy_extensions/handy_extensions.dart';
import 'package:localregex/localregex.dart';
import 'package:provider/provider.dart';
import 'package:relative_scale/relative_scale.dart';
import 'package:tumaipay/configs/configs.dart';
import 'package:tumaipay/core/models/failure.dart';
import 'package:tumaipay/features/auth/data/repositories/impl/auth_provider.dart';
import 'package:tumaipay/features/home/presentation/pages/tumai_pay_home_page.dart';

class SignInPage extends StatefulWidget {
  const SignInPage({Key? key}) : super(key: key);

  @override
  State<SignInPage> createState() => _SignInPageState();
}

class _SignInPageState extends State<SignInPage> {
  // Keys
  final _formKey = GlobalKey<FormState>();

  // Editing Controllers
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  // Values
  bool _hidePassword = true;

  // Functions
  void _togglePasswordVisibility() {
    setState(() {
      _hidePassword = !_hidePassword;
    });
  }

  void _signIn() async {
    if (_formKey.currentState!.validate()) {
      AuthProvider provider = Provider.of<AuthProvider>(context, listen: false);
      dartz.Either<Failure, bool> response = await provider.signIn(
          _emailController.text, _passwordController.text);
      response.fold((Failure fail) {
        EasyLoading.showError("Failed to authenticate");
      }, (bool success) {
        if (success) {
          EasyLoading.showSuccess("Authenticated Successfully!");
          context.goToRefresh(
            page: const TumaiPayHomePage(),
          );
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return RelativeBuilder(builder: (context, height, width, sx, sy) {
      return Scaffold(
        backgroundColor: AppColors.scaffoldColor,
        body: SafeArea(
          child: SingleChildScrollView(
            child: SizedBox(
              height: context.height,
              width: context.width,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    height: context.height,
                    width: context.width * 0.5,
                    decoration: const BoxDecoration(
                      image: DecorationImage(
                        image: AssetImage("assets/images/unsplash_1.jpg"),
                        fit: BoxFit.cover,
                      ),
                    ),
                    child: BackdropFilter(
                      filter: ImageFilter.blur(sigmaX: 1, sigmaY: 1),
                      child: Center(
                        child: SizedBox(
                          width: sx(190),
                          child: const Image(
                            image: AssetImage("assets/images/logo.png"),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    height: context.height,
                    width: context.width * 0.5,
                    padding: EdgeInsets.symmetric(
                      horizontal: sx(20),
                    ),
                    child: Form(
                      key: _formKey,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Center(
                            child: Text(
                              "Welcome Back",
                              style: TextStyle(
                                color: Colors.black,
                                fontWeight: FontWeight.w900,
                                fontSize: sy(30),
                              ),
                              textAlign: TextAlign.center,
                            ),
                          ),
                          const Divider(),
                          SizedBox(
                            height: sy(20),
                          ),
                          Text(
                            "Email",
                            style: TextStyle(
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                              fontSize: sy(10),
                            ),
                          ),
                          TextFormField(
                            controller: _emailController,
                            decoration: InputDecoration(
                              hintText: "name@domain.com",
                              hintStyle: TextStyle(
                                color: Colors.black54,
                                fontWeight: FontWeight.normal,
                                fontSize: sy(8),
                              ),
                            ),
                            keyboardType: TextInputType.emailAddress,
                            autovalidateMode:
                                AutovalidateMode.onUserInteraction,
                            validator: (String? email) {
                              if (email!.isEmpty) {
                                return "Type your email!";
                              }

                              if (!LocalRegex.isEmail(email)) {
                                return "Invalid email!";
                              }

                              return null;
                            },
                          ),
                          SizedBox(
                            height: sy(10),
                          ),
                          Text(
                            "Password",
                            style: TextStyle(
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                              fontSize: sy(10),
                            ),
                          ),
                          TextFormField(
                            controller: _passwordController,
                            decoration: InputDecoration(
                              hintText: "*********",
                              hintStyle: TextStyle(
                                color: Colors.black54,
                                fontWeight: FontWeight.normal,
                                fontSize: sy(8),
                              ),
                              suffixIcon: InkWell(
                                onTap: _togglePasswordVisibility,
                                child: Icon(
                                  _hidePassword
                                      ? CupertinoIcons.eye_slash
                                      : CupertinoIcons.eye,
                                  size: sy(13),
                                ),
                              ),
                            ),
                            keyboardType: TextInputType.text,
                            obscureText: _hidePassword,
                            autovalidateMode:
                                AutovalidateMode.onUserInteraction,
                            validator: (String? password) {
                              if (password!.isEmpty) {
                                return "Type your password!";
                              }

                              return null;
                            },
                          ),
                          SizedBox(
                            height: sy(20),
                          ),
                          GestureDetector(
                            onTap: _signIn,
                            child: Container(
                              alignment: Alignment.center,
                              width: context.width,
                              padding: EdgeInsets.symmetric(
                                vertical: sy(10),
                              ),
                              decoration: BoxDecoration(
                                color: AppColors.darkAltBg,
                                borderRadius: BorderRadius.circular(13),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withOpacity(0.3),
                                    blurRadius: 10.0,
                                    spreadRadius: 1.0,
                                    offset: const Offset(3.0, 3.0),
                                  )
                                ],
                              ),
                              child: Text(
                                "Continue",
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: sy(10),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    });
  }
}
