import 'package:equatable/equatable.dart';
import 'package:json_annotation/json_annotation.dart';

part 'sign_in_response.g.dart';

@JsonSerializable()
class SignInResponse extends Equatable {
  @JsonKey(name: "refresh")
  String refreshToken;
  @JsonKey(name: "access")
  String accessToken;
  String username;
  @JsonKey(name: 'is_admin')
  bool isAdmin;
  @JsonKey(name: 'merchant_id')
  String merchantId;
  @JsonKey(name: 'merchant_name')
  String merchantName;
  @JsonKey(name: 'merchant_code')
  String merchantCode;
  @JsonKey(name: 'operator_name')
  String operatorName;
  @JsonKey(name: 'has_changed_default_password')
  bool hasChangedDefaultPassword;
  @JsonKey(name: 'user_id')
  String userId;
  @JsonKey(name: 'outlet_id')
  int outletId;

  SignInResponse({
    required this.refreshToken,
    required this.accessToken,
    required this.username,
    required this.isAdmin,
    required this.merchantId,
    required this.merchantName,
    required this.merchantCode,
    required this.operatorName,
    required this.hasChangedDefaultPassword,
    required this.userId,
    required this.outletId,
  });

  factory SignInResponse.fromJson(Map<String, dynamic> json) =>
      _$SignInResponseFromJson(json);
  Map<String, dynamic> toJson() => _$SignInResponseToJson(this);

  @override
  List<Object?> get props => [
        refreshToken,
        accessToken,
        username,
        isAdmin,
        merchantId,
        merchantName,
        merchantCode,
        operatorName,
        hasChangedDefaultPassword,
        userId
      ];
}
