// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'sign_in_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

SignInResponse _$SignInResponseFromJson(Map<String, dynamic> json) =>
    SignInResponse(
      refreshToken: json['refresh'] as String,
      accessToken: json['access'] as String,
      username: json['username'] as String,
      isAdmin: json['is_admin'] as bool,
      merchantId: json['merchant_id'] as String,
      merchantName: json['merchant_name'] as String,
      merchantCode: json['merchant_code'] as String,
      operatorName: json['operator_name'] as String,
      hasChangedDefaultPassword: json['has_changed_default_password'] as bool,
      userId: json['user_id'] as String,
      outletId: json['outlet_id'] as int,
    );

Map<String, dynamic> _$SignInResponseToJson(SignInResponse instance) =>
    <String, dynamic>{
      'refresh': instance.refreshToken,
      'access': instance.accessToken,
      'username': instance.username,
      'is_admin': instance.isAdmin,
      'merchant_id': instance.merchantId,
      'merchant_name': instance.merchantName,
      'merchant_code': instance.merchantCode,
      'operator_name': instance.operatorName,
      'has_changed_default_password': instance.hasChangedDefaultPassword,
      'user_id': instance.userId,
      'outlet_id': instance.outletId,
    };
