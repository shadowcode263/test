import 'package:dio/dio.dart';
import 'package:tumaipay/configs/configs.dart';
import 'package:tumaipay/core/models/log_level.dart';
import 'package:tumaipay/features/auth/models/sign_in_response.dart';
import 'package:tumaipay/services/logging.dart';
import 'package:tumaipay/services/services.dart';

class AuthNetwork {
  static final Dio _dio = Dio()
    ..interceptors.add(
      LogInterceptor(
        responseBody: true,
        error: true,
        requestHeader: true,
        responseHeader: true,
        requestBody: true,
      ),
    );

  static final LoggingService _loggingService = locator<LoggingService>();

  static Future<SignInResponse?> signIn({
    required String email,
    required String password,
  }) async {
    try {
      Response response = await _dio.post(
        "${NetworkApi.baseURl}/auth/authenticate/",
        data: {
          "email": email,
          "password": password,
        },
      );

      if (response.statusCode == 200) {
        return SignInResponse.fromJson(response.data);
      } else {
        _loggingService.log(LogLevel.ERROR, "Failed to sign in");
        return null;
      }
    } catch (exception, stacktrace) {
      _loggingService.log(
        LogLevel.ERROR,
        exception.toString(),
        stacktrace: stacktrace.toString(),
      );
      rethrow;
    }
  }

  static Future<bool> updatePassword({
    required String oldPassword,
    required String newPassword,
    required String newPasswordConfirmation,
  }) async {
    try {
      Response response = await _dio.post(
        "${NetworkApi.baseURl}/change/password/",
        data: {
          "old_password": oldPassword,
          "password1": newPassword,
          "password2": newPasswordConfirmation,
        },
      );

      if (response.statusCode == 200) {
        return true;
      }
      return false;
    } catch (exception, stacktrace) {
      _loggingService.log(
        LogLevel.ERROR,
        exception.toString(),
        stacktrace: stacktrace.toString(),
      );
      rethrow;
    }
  }
}
