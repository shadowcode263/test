import 'package:dartz/dartz.dart';

import '../../../../../core/models/failure.dart';

abstract class Auth {
  Future<Either<Failure, bool>> signIn(String email, String password);
  Either<Failure, bool> signOut();
}
