import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:tumaipay/core/models/failure.dart';
import 'package:tumaipay/features/auth/data/networking/authentication.dart';
import 'package:tumaipay/features/auth/data/repositories/abstract/auth.dart';
import 'package:tumaipay/features/auth/models/sign_in_response.dart';

class AuthProvider extends ChangeNotifier implements Auth {
  SignInResponse? _authentication;

  @override
  Future<Either<Failure, bool>> signIn(String email, String password) async {
    try {
      EasyLoading.show(status: "Authenticating");
      SignInResponse? response =
          await AuthNetwork.signIn(email: email, password: password);
      EasyLoading.dismiss();
      if (response != null) {
        _authentication = response;
        return const Right(true);
      } else {
        // Failure
        return Left(Failure("Failed to sign in!"));
      }
    } catch (exception) {
      EasyLoading.dismiss();
      if (exception is DioError) {
        return Left(Failure(exception.message));
      } else {
        return Left(Failure(exception.toString()));
      }
    }
  }

  @override
  Either<Failure, bool> signOut() {
    // TODO: implement signOut
    throw UnimplementedError();
  }

  Stream<bool> get isAuthenticatedStream =>
      _authentication != null ? Stream.value(true) : Stream.value(false);
  bool get isAuthenticated => _authentication != null;
  SignInResponse? get authenticatedUser => _authentication;
}
