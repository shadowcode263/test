import 'package:flutter/material.dart';
import 'package:tumaipay/features/receipt_management/models/receipt.dart';

class PrintReceiptPage extends StatefulWidget {
  const PrintReceiptPage({Key? key, required this.receipt}) : super(key: key);

  final Receipt receipt;

  @override
  State<PrintReceiptPage> createState() => _PrintReceiptPageState();
}

class _PrintReceiptPageState extends State<PrintReceiptPage> {
  void print() {}

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
