import 'package:equatable/equatable.dart';
import 'package:json_annotation/json_annotation.dart';

part 'receipt_item.g.dart';

@JsonSerializable()
class ReceiptItem extends Equatable {
  int quantity;
  String name;
  double cost;

  ReceiptItem({
    required this.quantity,
    required this.name,
    required this.cost,
  });

  factory ReceiptItem.fromJson(Map<String, dynamic> json) =>
      _$ReceiptItemFromJson(json);
  Map<String, dynamic> toJson() => _$ReceiptItemToJson(this);

  @override
  List<Object?> get props => [quantity, name, cost];
}
