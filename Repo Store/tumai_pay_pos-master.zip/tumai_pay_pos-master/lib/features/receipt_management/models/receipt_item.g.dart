// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'receipt_item.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ReceiptItem _$ReceiptItemFromJson(Map<String, dynamic> json) => ReceiptItem(
      quantity: json['quantity'] as int,
      name: json['name'] as String,
      cost: (json['cost'] as num).toDouble(),
    );

Map<String, dynamic> _$ReceiptItemToJson(ReceiptItem instance) =>
    <String, dynamic>{
      'quantity': instance.quantity,
      'name': instance.name,
      'cost': instance.cost,
    };
