// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'receipt.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Receipt _$ReceiptFromJson(Map<String, dynamic> json) => Receipt(
      receiptNumber: json['receipt_number'] as int,
      billName: json['bill_name'] as String,
      merchantName: json['merchant_name'] as String,
      merchantAddress: json['merchant_address'] as String,
      merchantVat: json['merchant_vat'] as String,
      merchantBp: json['merchant_bp'] as String,
      description: json['description'] as String,
      taxInvoiceNumber: json['tax_invoice_number'] as String,
      operator: json['operator'] as String,
      items: (json['items'] as List<dynamic>)
          .map((e) => ReceiptItem.fromJson(e as Map<String, dynamic>))
          .toList(),
      amount: json['total'] as String,
    );

Map<String, dynamic> _$ReceiptToJson(Receipt instance) => <String, dynamic>{
      'receipt_number': instance.receiptNumber,
      'bill_name': instance.billName,
      'merchant_name': instance.merchantName,
      'merchant_address': instance.merchantAddress,
      'merchant_vat': instance.merchantVat,
      'merchant_bp': instance.merchantBp,
      'description': instance.description,
      'tax_invoice_number': instance.taxInvoiceNumber,
      'operator': instance.operator,
      'items': instance.items,
      'total': instance.amount,
    };
