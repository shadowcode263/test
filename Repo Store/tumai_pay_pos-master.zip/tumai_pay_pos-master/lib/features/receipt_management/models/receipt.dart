import 'package:equatable/equatable.dart';
import 'package:json_annotation/json_annotation.dart';
import 'package:tumaipay/features/receipt_management/models/receipt_item.dart';

part 'receipt.g.dart';

@JsonSerializable()
class Receipt extends Equatable {
  @JsonKey(name: 'receipt_number')
  int receiptNumber;
  @JsonKey(name: 'bill_name')
  String billName;
  @JsonKey(name: 'merchant_name')
  String merchantName;
  @JsonKey(name: 'merchant_address')
  String merchantAddress;
  @JsonKey(name: 'merchant_vat')
  String merchantVat;
  @JsonKey(name: 'merchant_bp')
  String merchantBp;
  String description;
  @JsonKey(name: 'tax_invoice_number')
  String taxInvoiceNumber;
  String operator;
  List<ReceiptItem> items;
  @JsonKey(name: 'total')
  String amount;

  Receipt({
    required this.receiptNumber,
    required this.billName,
    required this.merchantName,
    required this.merchantAddress,
    required this.merchantVat,
    required this.merchantBp,
    required this.description,
    required this.taxInvoiceNumber,
    required this.operator,
    required this.items,
    required this.amount,
  });

  factory Receipt.fromJson(Map<String, dynamic> json) =>
      _$ReceiptFromJson(json);
  Map<String, dynamic> toJson() => _$ReceiptToJson(this);

  double get total => double.parse(amount);

  double get subtotal => total * 85.5;

  double get taxAmount => total * 14.5;

  double get tax => 14.5;

  @override
  List<Object?> get props => [
        receiptNumber,
        billName,
        merchantName,
        merchantAddress,
        merchantVat,
        merchantBp,
        description,
        taxInvoiceNumber,
        operator,
        items,
        amount,
      ];
}
