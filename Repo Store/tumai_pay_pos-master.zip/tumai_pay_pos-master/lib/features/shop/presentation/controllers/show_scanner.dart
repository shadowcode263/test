import 'package:flutter/material.dart';
import 'package:handy_extensions/handy_extensions.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:provider/provider.dart';
import 'package:relative_scale/relative_scale.dart';
import 'package:tumaipay/features/shop/data/repositories/impl/cart_provider.dart';

Future<void> showScanner(BuildContext context) async {
  await showDialog(
    context: context,
    builder: (context) {
      return RelativeBuilder(builder: (context, height, width, sx, sy) {
        return Dialog(
          child: SingleChildScrollView(
            child: Consumer<CartProvider>(builder: (context, provider, _) {
              return SizedBox(
                height: sy(200),
                width: sx(300),
                child: RotatedBox(
                  quarterTurns: 3,
                  child: MobileScanner(
                    allowDuplicates: false,
                    onDetect: (Barcode barcode, MobileScannerArguments? args) {
                      debugPrint("Scanned Data: ${barcode.rawValue}");
                      provider.scanToCart(context, "${barcode.rawValue}");
                      context.goBack();
                    },
                  ),
                ),
              );
            }),
          ),
        );
      });
    },
  );
}
