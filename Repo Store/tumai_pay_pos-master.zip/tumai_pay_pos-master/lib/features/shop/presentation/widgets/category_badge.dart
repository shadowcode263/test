import 'package:flutter/material.dart';
import 'package:relative_scale/relative_scale.dart';
import 'package:tumaipay/configs/colors.dart';

class CategoryBadge extends StatelessWidget {
  const CategoryBadge({
    Key? key,
    required this.category,
  }) : super(key: key);

  final String category;

  @override
  Widget build(BuildContext context) {
    return RelativeBuilder(builder: (context, height, width, sx, sy) {
      return Container(
        padding: EdgeInsets.symmetric(
          horizontal: sx(5),
          vertical: sy(1),
        ),
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: AppColors.primaryColorDark,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Text(
          category,
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.normal,
            fontSize: sy(6),
          ),
        ),
      );
    });
  }
}
