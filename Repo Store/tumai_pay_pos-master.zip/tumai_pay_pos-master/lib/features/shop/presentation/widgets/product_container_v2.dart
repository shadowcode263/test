import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:handy_extensions/handy_extensions.dart';
import 'package:relative_scale/relative_scale.dart';
import 'package:tumaipay/configs/colors.dart';
import 'package:tumaipay/features/shop/models/product.dart';
import 'package:tumaipay/features/shop/presentation/widgets/category_badge.dart';

class ProductContainerV2 extends StatelessWidget {
  const ProductContainerV2({
    Key? key,
    required this.product,
  }) : super(key: key);

  final Product product;

  @override
  Widget build(BuildContext context) {
    return RelativeBuilder(builder: (context, height, width, sx, sy) {
      return Container(
        decoration: BoxDecoration(
          color: AppColors.darkAltBg,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.3),
              blurRadius: 3.0,
              spreadRadius: 1.0,
              offset: const Offset(1.0, 1.0),
            )
          ],
        ),
        child: Column(
          children: [
            Stack(
              children: [
                Container(
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      image: CachedNetworkImageProvider(
                        product.picture,
                      ),
                      fit: BoxFit.cover,
                    ),
                  ),
                  height: sy(100),
                ),
                Positioned(
                  top: sy(2),
                  left: sx(5),
                  child: CategoryBadge(category: product.category),
                ),
              ],
            ),
            SizedBox(
              height: sy(2),
            ),
            Padding(
              padding: EdgeInsets.symmetric(
                horizontal: sx(5),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Text(
                      product.name,
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.normal,
                        fontSize: sy(7),
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  Text(
                    product.price.money.symbolOnLeft,
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w900,
                      fontSize: sy(8),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    });
  }
}
