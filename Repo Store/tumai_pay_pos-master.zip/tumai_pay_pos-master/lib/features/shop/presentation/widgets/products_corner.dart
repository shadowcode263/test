import 'package:dartz/dartz.dart' as dartz;
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:handy_extensions/handy_extensions.dart';
import 'package:provider/provider.dart';
import 'package:relative_scale/relative_scale.dart';
import 'package:tumaipay/configs/configs.dart';
import 'package:tumaipay/core/models/failure.dart';
import 'package:tumaipay/features/shop/data/repositories/impl/cart_provider.dart';
import 'package:tumaipay/features/shop/data/repositories/impl/products_provider.dart';
import 'package:tumaipay/features/shop/models/product.dart';
import 'package:tumaipay/features/shop/presentation/controllers/show_scanner.dart';
import 'package:tumaipay/features/shop/presentation/widgets/product_container.dart';

class ProductsCorner extends StatefulWidget {
  const ProductsCorner({
    Key? key,
  }) : super(key: key);

  @override
  State<ProductsCorner> createState() => _ProductsCornerState();
}

class _ProductsCornerState extends State<ProductsCorner> {
  Future<dartz.Either<Failure, List<Product>>>? _future;

  @override
  void initState() {
    _future =
        Provider.of<ProductsProvider>(context, listen: false).getProducts();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return RelativeBuilder(builder: (context, height, width, sx, sy) {
      return Expanded(
        child: Container(
          margin: EdgeInsets.only(
            right: sx(10),
          ),
          child: Column(
            children: [
              Container(
                width: context.width,
                padding: EdgeInsets.symmetric(
                  vertical: sy(2),
                  horizontal: sx(10),
                ),
                decoration: BoxDecoration(
                  color: AppColors.darkAltBg.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(7),
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: Consumer<ProductsProvider>(
                          builder: (context, provider, _) {
                        return TextFormField(
                          decoration: InputDecoration(
                            border: InputBorder.none,
                            hintText: "Search ...",
                            hintStyle: TextStyle(
                              color: AppColors.darkAltBg,
                              fontWeight: FontWeight.bold,
                              fontSize: sy(7),
                            ),
                            prefixIcon: const Icon(
                              CupertinoIcons.search,
                              color: AppColors.darkAltBg,
                            ),
                          ),
                          onChanged: (String? value) {
                            provider.updateQuery("$value");
                          },
                        );
                      }),
                    ),
                    SizedBox(
                      width: sx(10),
                    ),
                    Consumer<CartProvider>(builder: (context, provider, _) {
                      return InkWell(
                        onTap: () async {
                          provider.toggleBarcodeState();
                          await showScanner(context);
                          provider.toggleBarcodeState();
                        },
                        child: Icon(
                          provider.barcodeIsScanning
                              ? CupertinoIcons.barcode_viewfinder
                              : CupertinoIcons.barcode,
                          color: provider.barcodeIsScanning
                              ? AppColors.darkAltBg
                              : AppColors.darkAltBg.withOpacity(0.7),
                          size: sy(15),
                        ),
                      );
                    }),
                  ],
                ),
              ),
              SizedBox(
                height: sy(10),
              ),
              Expanded(
                child: FutureBuilder(
                  future: _future,
                  builder: (BuildContext context,
                      AsyncSnapshot<dartz.Either<Failure, List<Product>>>
                          snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return Center(
                        child: Text(
                          "Loading ...",
                          style: TextStyle(
                            color: AppColors.darkAltBg,
                            fontWeight: FontWeight.normal,
                            fontSize: sy(8),
                          ),
                        ),
                      );
                    }

                    return snapshot.data!.fold(
                      (l) => Center(
                        child: Text(
                          "Failed to load products.",
                          style: TextStyle(
                            color: AppColors.darkAltBg,
                            fontWeight: FontWeight.normal,
                            fontSize: sy(8),
                          ),
                        ),
                      ),
                      (r) {
                        List<Product> products = r;

                        return Consumer<ProductsProvider>(
                            builder: (context, provider, _) {
                          return GridView.count(
                            crossAxisCount: 4,
                            crossAxisSpacing: sx(10),
                            childAspectRatio: 0.9,
                            children: products
                                .where((product) => (product.name
                                        .toLowerCase()
                                        .contains(provider.query) ||
                                    product.category
                                        .toLowerCase()
                                        .contains(provider.query) ||
                                    product.barcode
                                        .toLowerCase()
                                        .contains(provider.query)))
                                .map((Product product) {
                              return ProductContainer(product: product);
                            }).toList(),
                          );
                        });
                      },
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      );
    });
  }
}
