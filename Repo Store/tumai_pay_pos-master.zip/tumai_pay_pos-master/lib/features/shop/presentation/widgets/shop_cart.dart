import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:handy_extensions/handy_extensions.dart';
import 'package:provider/provider.dart';
import 'package:relative_scale/relative_scale.dart';
import 'package:tumaipay/configs/colors.dart';
import 'package:tumaipay/features/shop/data/repositories/impl/cart_provider.dart';
import 'package:tumaipay/features/shop/models/cart_item.dart';
import 'package:tumaipay/features/shop/presentation/pages/tumai_pay_payment_methods_page.dart';

class ShopCart extends StatelessWidget {
  const ShopCart({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return RelativeBuilder(builder: (context, height, width, sx, sy) {
      return Container(
        height: context.height,
        width: sx(300),
        margin: EdgeInsets.only(
          left: sx(10),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child:
                      Consumer<CartProvider>(builder: (context, provider, _) {
                    return GestureDetector(
                      onTap: () => provider.clearCart(),
                      child: Container(
                        alignment: Alignment.center,
                        padding: EdgeInsets.symmetric(
                          vertical: sy(7),
                        ),
                        decoration: BoxDecoration(
                          color: AppColors.darkRed,
                          borderRadius: BorderRadius.circular(7),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.3),
                              blurRadius: 10.0,
                              spreadRadius: 1.0,
                              offset: const Offset(1.0, 1.0),
                            )
                          ],
                        ),
                        child: Text(
                          "Clear Cart",
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.normal,
                            fontSize: sy(8),
                          ),
                        ),
                      ),
                    );
                  }),
                ),
                SizedBox(
                  width: sx(10),
                ),
                Expanded(
                  child:
                      Consumer<CartProvider>(builder: (context, provider, _) {
                    return GestureDetector(
                      onTap: () => provider.saveCartAsTab(),
                      child: Container(
                        alignment: Alignment.center,
                        padding: EdgeInsets.symmetric(
                          vertical: sy(7),
                        ),
                        decoration: BoxDecoration(
                          color: AppColors.darkAltBg,
                          borderRadius: BorderRadius.circular(7),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.3),
                              blurRadius: 10.0,
                              spreadRadius: 1.0,
                              offset: const Offset(1.0, 1.0),
                            )
                          ],
                        ),
                        child: Text(
                          "Save Tab",
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.normal,
                            fontSize: sy(8),
                          ),
                        ),
                      ),
                    );
                  }),
                ),
              ],
            ),
            SizedBox(
              height: sy(7),
            ),
            Text(
              "TXN #1145",
              style: TextStyle(
                color: Colors.black,
                fontWeight: FontWeight.bold,
                fontSize: sy(8),
              ),
            ),
            const Divider(),
            Expanded(
              child: Consumer<CartProvider>(builder: (context, provider, _) {
                return ListView(
                  shrinkWrap: true,
                  children: provider.cartItems.map((CartItem item) {
                    return Dismissible(
                      key: Key("cart_item_${item.product.id}"),
                      onDismissed: (direction) {
                        provider.removeFromCart(item.product);
                      },
                      background: Container(
                        color: AppColors.darkAltBg.withOpacity(0.01),
                      ),
                      child: Container(
                        width: context.width,
                        height: sy(35),
                        margin: EdgeInsets.only(
                          bottom: sy(2),
                        ),
                        decoration: BoxDecoration(
                          border: Border(
                            bottom: BorderSide(
                              color: AppColors.darkAltBg.withOpacity(0.3),
                            ),
                          ),
                        ),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Stack(
                              clipBehavior: Clip.none,
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(5),
                                  child: CachedNetworkImage(
                                    imageUrl: item.product.picture,
                                    height: sy(30),
                                    width: sy(30),
                                    fit: BoxFit.cover,
                                  ),
                                ),
                                Positioned(
                                  top: -sy(3),
                                  left: -sy(3),
                                  child: Container(
                                    height: sy(10),
                                    width: sy(10),
                                    decoration: const BoxDecoration(
                                      color: AppColors.darkAltBg,
                                      shape: BoxShape.circle,
                                    ),
                                    child: FittedBox(
                                      child: Text(
                                        "${item.quantity}",
                                        style: const TextStyle(
                                          color: Colors.white,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            SizedBox(
                              width: sx(5),
                            ),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    item.product.name,
                                    style: TextStyle(
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold,
                                      fontSize: sy(8),
                                    ),
                                  ),
                                  Text(
                                    "${item.product.description}",
                                    style: TextStyle(
                                      color: Colors.black54,
                                      fontWeight: FontWeight.normal,
                                      fontSize: sy(6),
                                    ),
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ],
                              ),
                            ),
                            Center(
                              child: Text(
                                item.product.price.money.symbolOnLeft,
                                style: TextStyle(
                                  color: Colors.black,
                                  fontWeight: FontWeight.w900,
                                  fontSize: sy(8),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  }).toList(),
                );
              }),
            ),
            const Divider(),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Total",
                  style: TextStyle(
                    color: Colors.black,
                    fontWeight: FontWeight.bold,
                    fontSize: sy(9),
                  ),
                ),
                Consumer<CartProvider>(builder: (context, provider, _) {
                  return Text(
                    provider.cartTotalAmount.money.symbolOnLeft,
                    style: TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.w900,
                      fontSize: sy(10),
                    ),
                  );
                }),
              ],
            ),
            Consumer<CartProvider>(builder: (context, provider, _) {
              return Text(
                "${provider.cartItemsLength} item(s)",
                style: TextStyle(
                  color: Colors.black54,
                  fontWeight: FontWeight.normal,
                  fontSize: sy(7),
                ),
              );
            }),
            SizedBox(
              height: sy(10),
            ),
            GestureDetector(
              onTap: () {
                if (Provider.of<CartProvider>(context, listen: false)
                        .cartLength >
                    0) {
                  context.goTo(
                    page: const TumaiPayPaymentMethodsPage(),
                  );
                } else {
                  EasyLoading.showError("Cart is empty");
                }
              },
              child: Container(
                alignment: Alignment.center,
                padding: EdgeInsets.symmetric(
                  vertical: sy(7),
                ),
                decoration: BoxDecoration(
                  color: AppColors.darkAltBg,
                  borderRadius: BorderRadius.circular(7),
                ),
                child: Text(
                  "Checkout",
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: sy(9),
                  ),
                ),
              ),
            ),
          ],
        ),
      );
    });
  }
}
