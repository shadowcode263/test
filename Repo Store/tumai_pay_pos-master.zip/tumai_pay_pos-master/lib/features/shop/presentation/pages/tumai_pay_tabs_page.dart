import 'package:flutter/material.dart';
import 'package:relative_scale/relative_scale.dart';
import 'package:tumaipay/configs/colors.dart';
import 'package:tumaipay/features/home/presentation/widgets/tumai_pay_appbar.dart';
import 'package:tumaipay/features/home/presentation/widgets/tumai_pay_bottom_appbar.dart';

class TumaiPayTabsPage extends StatefulWidget {
  const TumaiPayTabsPage({Key? key}) : super(key: key);

  @override
  State<TumaiPayTabsPage> createState() => _TumaiPayTabsPageState();
}

class _TumaiPayTabsPageState extends State<TumaiPayTabsPage> {
  final _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return RelativeBuilder(builder: (context, height, width, sy, sx) {
      return Scaffold(
        key: _scaffoldKey,
        drawer: const Drawer(
            // TODO: All signout on this drawer component
            ),
        backgroundColor: AppColors.scaffoldColor,
        appBar: TumaiPayAppBar(context),
        body: Container(),
        bottomNavigationBar: TumaiPayBottomAppbar(
          scaffoldKey: _scaffoldKey,
          pageName: "My Tabs",
        ),
      );
    });
  }
}
