import 'package:flutter/material.dart';
import 'package:handy_extensions/handy_extensions.dart';
import 'package:provider/provider.dart';
import 'package:relative_scale/relative_scale.dart';
import 'package:tumaipay/configs/colors.dart';
import 'package:tumaipay/features/home/presentation/widgets/tumai_pay_appbar.dart';
import 'package:tumaipay/features/home/presentation/widgets/tumai_pay_bottom_appbar.dart';
import 'package:tumaipay/features/receipt_management/models/receipt.dart';
import 'package:tumaipay/features/receipt_management/presentation/pages/print_receipt_page.dart';
import 'package:tumaipay/features/shop/data/repositories/impl/cart_provider.dart';
import 'package:tumaipay/features/shop/models/payment_method.dart';

class TumaiPayPaymentMethodsPage extends StatefulWidget {
  const TumaiPayPaymentMethodsPage({Key? key}) : super(key: key);

  @override
  State<TumaiPayPaymentMethodsPage> createState() =>
      _TumaiPayPaymentMethodsPageState();
}

class _TumaiPayPaymentMethodsPageState
    extends State<TumaiPayPaymentMethodsPage> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  PaymentMethod? paymentMethod;

  Future<List<PaymentMethod>>? future;

  @override
  void initState() {
    future =
        Provider.of<CartProvider>(context, listen: false).getPaymentMethods();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return RelativeBuilder(builder: (context, height, width, sx, sy) {
      return Scaffold(
        backgroundColor: AppColors.scaffoldColor,
        appBar: TumaiPayAppBar(context),
        resizeToAvoidBottomInset: false,
        body: SafeArea(
          child: Container(
            height: context.height,
            width: context.width,
            padding: EdgeInsets.symmetric(
              horizontal: sx(20),
              vertical: sy(10),
            ),
            child: Column(
              children: [
                Container(
                  width: context.width,
                  padding: EdgeInsets.symmetric(
                    horizontal: sx(10),
                    vertical: sy(10),
                  ),
                  decoration: BoxDecoration(
                    color: AppColors.darkAltBg,
                    borderRadius: BorderRadius.circular(10),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.3),
                        blurRadius: 3.0,
                        spreadRadius: 1.0,
                        offset: const Offset(1.0, 1.0),
                      )
                    ],
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Column(
                        children: [
                          Text(
                            "Number Of Items",
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w900,
                              fontSize: sy(11),
                            ),
                          ),
                          Consumer<CartProvider>(
                              builder: (context, provider, _) {
                            return Text(
                              "${provider.cartItemsLength}",
                              style: TextStyle(
                                color: Colors.white54,
                                fontWeight: FontWeight.w600,
                                fontSize: sy(10),
                              ),
                            );
                          }),
                        ],
                      ),
                      Column(
                        children: [
                          Text(
                            "Total Cost",
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w900,
                              fontSize: sy(11),
                            ),
                          ),
                          Consumer<CartProvider>(
                              builder: (context, provider, _) {
                            return Text(
                              provider.cartTotalAmount.money.symbolOnLeft,
                              style: TextStyle(
                                color: Colors.white54,
                                fontWeight: FontWeight.w600,
                                fontSize: sy(10),
                              ),
                            );
                          }),
                        ],
                      ),
                      Column(
                        children: [
                          Text(
                            "Currency",
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w900,
                              fontSize: sy(11),
                            ),
                          ),
                          Text(
                            "USD\$",
                            style: TextStyle(
                              color: Colors.white54,
                              fontWeight: FontWeight.w600,
                              fontSize: sy(10),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  height: sy(40),
                ),
                SizedBox(
                  height: sy(60),
                  width: context.width,
                  child:
                      Consumer<CartProvider>(builder: (context, provider, _) {
                    return FutureBuilder(
                      future: future,
                      builder: (BuildContext context,
                          AsyncSnapshot<List<PaymentMethod>> snapshot) {
                        if (snapshot.connectionState ==
                            ConnectionState.waiting) {
                          return Center(
                            child: Text(
                              "Getting payment methods ...",
                              style: TextStyle(
                                color: AppColors.darkAltBg,
                                fontWeight: FontWeight.bold,
                                fontSize: sy(10),
                              ),
                            ),
                          );
                        }

                        if (snapshot.hasError) {
                          return Center(
                            child: Text(
                              "Error getting payment methods",
                              style: TextStyle(
                                color: AppColors.darkAltBg,
                                fontWeight: FontWeight.bold,
                                fontSize: sy(10),
                              ),
                            ),
                          );
                        }

                        if (!snapshot.hasData) {
                          return Center(
                            child: Text(
                              "No payment methods found",
                              style: TextStyle(
                                color: AppColors.darkAltBg,
                                fontWeight: FontWeight.bold,
                                fontSize: sy(10),
                              ),
                            ),
                          );
                        }

                        List<PaymentMethod> paymentMethods = snapshot.data!;

                        return ListView(
                          scrollDirection: Axis.horizontal,
                          children: paymentMethods.map((PaymentMethod method) {
                            return GestureDetector(
                              onTap: () {
                                setState(() {
                                  paymentMethod = method;
                                });
                              },
                              child: Container(
                                padding: EdgeInsets.symmetric(
                                  horizontal: sx(20),
                                ),
                                margin: EdgeInsets.only(
                                  right: sx(10),
                                ),
                                decoration: BoxDecoration(
                                  color: AppColors.darkAltBg,
                                  borderRadius: BorderRadius.circular(10),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withOpacity(0.3),
                                      blurRadius: 3.0,
                                      spreadRadius: 1.0,
                                      offset: const Offset(1.0, 1.0),
                                    )
                                  ],
                                ),
                                child: Row(
                                  children: [
                                    Text(
                                      method.description,
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold,
                                        fontSize: sy(10),
                                      ),
                                    ),
                                    SizedBox(
                                      width: sx(100),
                                    ),
                                    AnimatedContainer(
                                      duration:
                                          const Duration(milliseconds: 300),
                                      height: sy(15),
                                      width: sy(15),
                                      alignment: Alignment.center,
                                      decoration: BoxDecoration(
                                        border: Border.all(
                                          color: Colors.white,
                                          width: sy(2),
                                        ),
                                        color: method == paymentMethod
                                            ? Colors.white
                                            : AppColors.darkAltBg,
                                        shape: BoxShape.circle,
                                      ),
                                      child: method == paymentMethod
                                          ? Icon(
                                              Icons.check,
                                              size: sy(10),
                                            )
                                          : null,
                                    ),
                                  ],
                                ),
                              ),
                            );
                          }).toList(),
                        );
                      },
                    );
                  }),
                ),
              ],
            ),
          ),
        ),
        bottomNavigationBar: TumaiPayBottomAppbar(
          scaffoldKey: _scaffoldKey,
          pageName: "Complete Checkout",
        ),
        floatingActionButton: paymentMethod != null
            ? Consumer<CartProvider>(
                builder: (context, provider, _) {
                  return FloatingActionButton(
                    backgroundColor: AppColors.darkAltBg,
                    onPressed: () async {
                      Receipt? receipt = await provider.checkoutCart(
                        paymentMethod!,
                      );

                      if (receipt != null) {
                        if (mounted) {
                          context.goToRefresh(
                            page: PrintReceiptPage(receipt: receipt),
                          );
                        }
                      }
                    },
                    child: const Icon(Icons.shopping_cart_checkout),
                  );
                },
              )
            : null,
      );
    });
  }
}
