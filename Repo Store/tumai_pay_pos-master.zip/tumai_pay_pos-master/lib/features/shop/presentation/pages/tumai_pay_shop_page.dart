import 'package:flutter/material.dart';
import 'package:handy_extensions/handy_extensions.dart';
import 'package:provider/provider.dart';
import 'package:relative_scale/relative_scale.dart';
import 'package:tumaipay/configs/configs.dart';
import 'package:tumaipay/features/home/presentation/widgets/tumai_pay_appbar.dart';
import 'package:tumaipay/features/home/presentation/widgets/tumai_pay_bottom_appbar.dart';
import 'package:tumaipay/features/shop/data/repositories/impl/cart_provider.dart';
import 'package:tumaipay/features/shop/presentation/widgets/products_corner.dart';
import 'package:tumaipay/features/shop/presentation/widgets/shop_cart.dart';

class TumaiPayShopPage extends StatefulWidget {
  const TumaiPayShopPage({Key? key}) : super(key: key);

  @override
  State<TumaiPayShopPage> createState() => _TumaiPayShopPageState();
}

class _TumaiPayShopPageState extends State<TumaiPayShopPage> {
  // Keys
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  dispose() {
    Provider.of<CartProvider>(context, listen: false).clearCart();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return RelativeBuilder(builder: (context, height, width, sx, sy) {
      return Scaffold(
        backgroundColor: AppColors.scaffoldColor,
        appBar: TumaiPayAppBar(context),
        resizeToAvoidBottomInset: false,
        body: SafeArea(
          child: Container(
            height: context.height,
            width: context.width,
            padding: EdgeInsets.symmetric(
              horizontal: sx(10),
              vertical: sy(10),
            ),
            child: Row(
              children: [
                const ProductsCorner(),
                Container(
                  width: sx(0.5),
                  height: context.height,
                  color: AppColors.darkAltBg.withOpacity(0.5),
                ),
                const ShopCart(),
              ],
            ),
          ),
        ),
        bottomNavigationBar: TumaiPayBottomAppbar(
          scaffoldKey: _scaffoldKey,
          pageName: "Shop",
        ),
      );
    });
  }
}
