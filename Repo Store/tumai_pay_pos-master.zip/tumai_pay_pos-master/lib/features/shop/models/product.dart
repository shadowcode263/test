import 'package:equatable/equatable.dart';
import 'package:json_annotation/json_annotation.dart';

part 'product.g.dart';

@JsonSerializable()
class Product extends Equatable {
  String id;
  String name;
  String? description;
  String category;
  double price;
  @JsonKey(name: "is_in_stock")
  bool isInStock;
  @JsonKey(name: "picture_real_url")
  String picture;
  String barcode;
  String currency;
  @JsonKey(name: "category_id")
  String categoryId;
  int quantity;
  int breakages;
  @JsonKey(name: "quantity_sold")
  int quantitySold;

  Product({
    required this.id,
    required this.name,
    this.description,
    required this.category,
    required this.price,
    required this.isInStock,
    required this.picture,
    required this.barcode,
    required this.currency,
    required this.categoryId,
    required this.quantity,
    required this.breakages,
    required this.quantitySold,
  });

  factory Product.fromJson(Map<String, dynamic> json) =>
      _$ProductFromJson(json);
  Map<String, dynamic> toJson() => _$ProductToJson(this);

  @override
  List<Object?> get props => [
        id,
        name,
        category,
        price,
        isInStock,
        picture,
        barcode,
        currency,
        categoryId
      ];
}
