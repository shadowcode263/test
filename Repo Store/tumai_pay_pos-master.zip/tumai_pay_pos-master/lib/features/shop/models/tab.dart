import 'package:equatable/equatable.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:tumaipay/features/shop/models/cart_item.dart';

part 'tab.g.dart';

@HiveType(typeId: 0)
class Tab extends Equatable {
  @HiveField(0)
  String id;
  @HiveField(1)
  List<CartItem> items;
  @HiveField(2)
  String savedBy;

  Tab({
    required this.id,
    required this.items,
    required this.savedBy,
  });

  @override
  List<Object?> get props => [id, items, savedBy];
}
