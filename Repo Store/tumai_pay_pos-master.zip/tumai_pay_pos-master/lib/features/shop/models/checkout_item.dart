import 'package:json_annotation/json_annotation.dart';

part 'checkout_item.g.dart';

@JsonSerializable()
class CheckoutItem {
  @JsonKey(name: 'product_id')
  String productId;
  int quantity;

  CheckoutItem({
    required this.productId,
    required this.quantity,
  });

  factory CheckoutItem.fromJson(Map<String, dynamic> json) => _$CheckoutItemFromJson(json);
  Map<String, dynamic> toJson() => _$CheckoutItemToJson(this);
}
