import 'package:json_annotation/json_annotation.dart';

part 'payment_method.g.dart';

@JsonSerializable()
class PaymentMethod {
  String id;
  String description;
  @JsonKey(name: "is_active")
  bool isActive;
  dynamic tax;

  PaymentMethod({
    required this.id,
    required this.description,
    required this.isActive,
    this.tax,
  });

  factory PaymentMethod.fromJson(Map<String, dynamic> json) => _$PaymentMethodFromJson(json);
  Map<String, dynamic> toJson() => _$PaymentMethodToJson(this);
}
