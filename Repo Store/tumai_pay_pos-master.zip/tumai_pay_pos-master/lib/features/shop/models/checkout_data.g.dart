// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'checkout_data.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

CheckoutData _$CheckoutDataFromJson(Map<String, dynamic> json) => CheckoutData(
      currency: json['currency'] as String? ?? "USD",
      billName: json['bill_name'] as String,
      paymentMethod: json['payment_method'] as String,
      phoneNumber: json['phone_number'] as String? ?? "263777213388",
      extras: (json['extras'] as List<dynamic>)
          .map((e) => CheckoutItem.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$CheckoutDataToJson(CheckoutData instance) =>
    <String, dynamic>{
      'currency': instance.currency,
      'bill_name': instance.billName,
      'payment_method': instance.paymentMethod,
      'phone_number': instance.phoneNumber,
      'extras': instance.extras,
    };
