// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'checkout_item.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

CheckoutItem _$CheckoutItemFromJson(Map<String, dynamic> json) => CheckoutItem(
      productId: json['product_id'] as String,
      quantity: json['quantity'] as int,
    );

Map<String, dynamic> _$CheckoutItemToJson(CheckoutItem instance) =>
    <String, dynamic>{
      'product_id': instance.productId,
      'quantity': instance.quantity,
    };
