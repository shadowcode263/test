import 'package:json_annotation/json_annotation.dart';
import 'package:tumaipay/features/shop/models/checkout_item.dart';

part 'checkout_data.g.dart';

@JsonSerializable()
class CheckoutData {
  String currency;
  @JsonKey(name: 'bill_name')
  String billName;
  @JsonKey(name: 'payment_method')
  String paymentMethod;
  @JsonKey(name: 'phone_number')
  String phoneNumber;
  List<CheckoutItem> extras;

  CheckoutData({
    this.currency = "USD",
    required this.billName,
    required this.paymentMethod,
    this.phoneNumber = "263777213388",
    required this.extras,
  });

  factory CheckoutData.fromJson(Map<String, dynamic> json) =>
      _$CheckoutDataFromJson(json);
  Map<String, dynamic> toJson() => _$CheckoutDataToJson(this);
}
