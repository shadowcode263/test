// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'product.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Product _$ProductFromJson(Map<String, dynamic> json) => Product(
      id: json['id'] as String,
      name: json['name'] as String,
      description: json['description'] as String?,
      category: json['category'] as String,
      price: (json['price'] as num).toDouble(),
      isInStock: json['is_in_stock'] as bool,
      picture: json['picture_real_url'] as String,
      barcode: json['barcode'] as String,
      currency: json['currency'] as String,
      categoryId: json['category_id'] as String,
      quantity: json['quantity'] as int,
      breakages: json['breakages'] as int,
      quantitySold: json['quantity_sold'] as int,
    );

Map<String, dynamic> _$ProductToJson(Product instance) => <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
      'description': instance.description,
      'category': instance.category,
      'price': instance.price,
      'is_in_stock': instance.isInStock,
      'picture_real_url': instance.picture,
      'barcode': instance.barcode,
      'currency': instance.currency,
      'category_id': instance.categoryId,
      'quantity': instance.quantity,
      'breakages': instance.breakages,
      'quantity_sold': instance.quantitySold,
    };
