import 'package:equatable/equatable.dart';
import 'package:json_annotation/json_annotation.dart';
import 'package:tumaipay/features/shop/models/checkout_item.dart';
import 'package:tumaipay/features/shop/models/product.dart';

part 'cart_item.g.dart';

@JsonSerializable()
class CartItem extends Equatable {
  Product product;
  int quantity;

  CartItem({
    required this.product,
    required this.quantity,
  });

  factory CartItem.fromJson(Map<String, dynamic> json) =>
      _$CartItemFromJson(json);
  Map<String, dynamic> toJson() => _$CartItemToJson(this);

  CheckoutItem toCheckoutItem() => CheckoutItem(
        productId: product.id,
        quantity: quantity,
      );

  @override
  List<Object?> get props => [product];
}
