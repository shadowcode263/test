enum BarcodeState { scanning, idle }
