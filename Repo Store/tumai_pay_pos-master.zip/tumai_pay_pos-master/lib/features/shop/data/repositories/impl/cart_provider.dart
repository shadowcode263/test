import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:handy_extensions/handy_extensions.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:tumaipay/core/extensions/cart_list_extension.dart';
import 'package:tumaipay/features/receipt_management/models/receipt.dart';
import 'package:tumaipay/features/shop/data/networking/cart_network.dart';
import 'package:tumaipay/features/shop/data/repositories/abstract/cart_repository.dart';
import 'package:tumaipay/features/shop/data/repositories/impl/products_provider.dart';
import 'package:tumaipay/features/shop/models/barcode_state.dart';
import 'package:tumaipay/features/shop/models/cart_item.dart';
import 'package:tumaipay/features/shop/models/checkout_data.dart';
import 'package:tumaipay/features/shop/models/checkout_item.dart';
import 'package:tumaipay/features/shop/models/payment_method.dart';
import 'package:tumaipay/features/shop/models/product.dart';
import 'package:tumaipay/features/shop/models/tab.dart' as models;
import 'package:uuid/uuid.dart';

class CartProvider extends ChangeNotifier implements CartRepository {
  List<CartItem> _cart = [];
  ProductsProvider? _productsProvider;

  // BAR CODE SCANNING - LET'S SEE IF
  // THIS WORKS AS EXPECTED
  BarcodeState _barcodeState = BarcodeState.idle;
  Box<models.Tab> tabsBox = Hive.box<models.Tab>("Tabs");

  void scanToCart(BuildContext context, String barcode) {
    debugPrint("BARCODE: $barcode");
    Product? product = _productsProvider?.products
        .firstWhereOrNull((p0) => p0.barcode == barcode);
    if (product != null) {
      addToCart(product);
    } else {
      EasyLoading.showError("Product not found");
    }
  }

  // END OF BAR CODE SCANNING CODE

  void updateProducts(ProductsProvider provider) {
    _productsProvider = provider;
  }

  toggleBarcodeState() {
    if (_barcodeState == BarcodeState.idle) {
      _barcodeState = BarcodeState.scanning;
    } else {
      _barcodeState = BarcodeState.idle;
    }
    notifyListeners();
  }

  @override
  void addToCart(Product product) {
    if (existsInCart(product)) {
      CartItem? item = productFromCart(product);
      _cart[_cart.indexOf(item!)].quantity++;
    } else {
      CartItem item = CartItem(
        product: product,
        quantity: 1,
      );
      _cart.add(item);
    }

    notifyListeners();
  }

  @override
  void removeFromCart(Product product) {
    _cart.removeWhere((p0) => p0.product == product);
    notifyListeners();
  }

  @override
  bool existsInCart(Product product) {
    CartItem? item = _cart.firstWhereOrNull((_) => _.product == product);
    return item != null;
  }

  @override
  CartItem? productFromCart(Product product) {
    return _cart.firstWhereOrNull((p0) => p0.product == product);
  }

  @override
  void clearCart() {
    _cart = [];
    notifyListeners();
  }

  @override
  void saveCartAsTab() {
    tabsBox.add(
      models.Tab(
        id: const Uuid().v4(),
        items: _cart,
        savedBy: "${_productsProvider?.auth?.authenticatedUser?.operatorName}",
      ),
    );
    clearCart();
    EasyLoading.showSuccess("New Tab Created");
  }

  Future<List<PaymentMethod>> getPaymentMethods() async {
    return CartNetwork.getPaymentMethods(
      accessToken: "${_productsProvider?.auth?.authenticatedUser?.accessToken}",
    );
  }

  @override
  Future<Receipt?> checkoutCart(PaymentMethod method) async {
    try {
      CheckoutData checkoutData = CheckoutData(
        billName: const Uuid().v4(),
        paymentMethod: method.description,
        extras: _cart
            .map<CheckoutItem>((CartItem item) => item.toCheckoutItem())
            .toList(),
      );

      EasyLoading.show(status: "Checking out...");
      Receipt receipt = await CartNetwork.checkoutCart(
        accessToken:
            "${_productsProvider?.auth?.authenticatedUser?.accessToken}",
        checkoutData: checkoutData,
      );

      EasyLoading.dismiss();
      EasyLoading.showSuccess("Checkout Successful");
      clearCart();
      return receipt;
    } catch (exception) {
      EasyLoading.dismiss();

      if (exception is DioError) {
        EasyLoading.showError(exception.message);
      } else {
        EasyLoading.showError("Checkout Failed");
      }
      return null;
    }
  }

  // Getters ===================================================================================================
  @override
  int get cartLength => _cart.length;

  @override
  int get cartItemsLength {
    int length = 0;

    for (CartItem item in _cart) {
      length += item.quantity;
    }

    return length;
  }

  @override
  double get cartTotalAmount => _cart.totalAmount;

  List<CartItem> get cartItems => _cart;
  BarcodeState get barcodeState => _barcodeState;
  bool get barcodeIsScanning => _barcodeState == BarcodeState.scanning;
}
