import 'package:tumaipay/features/receipt_management/models/receipt.dart';
import 'package:tumaipay/features/shop/models/cart_item.dart';
import 'package:tumaipay/features/shop/models/payment_method.dart';
import 'package:tumaipay/features/shop/models/product.dart';

abstract class CartRepository {
  // Methods
  void addToCart(Product product);
  void removeFromCart(Product product);
  void clearCart();
  bool existsInCart(Product product);
  CartItem? productFromCart(Product product);
  void saveCartAsTab();
  Future<Receipt?> checkoutCart(PaymentMethod method);

  // Getters
  int get cartLength;
  int get cartItemsLength;
  double get cartTotalAmount;
}
