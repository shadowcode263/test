import 'package:dartz/dartz.dart';
import 'package:flutter/material.dart';
import 'package:tumaipay/core/models/failure.dart';
import 'package:tumaipay/features/auth/data/repositories/impl/auth_provider.dart';
import 'package:tumaipay/features/shop/data/networking/shop_network.dart';
import 'package:tumaipay/features/shop/data/repositories/abstract/products_repository.dart';
import 'package:tumaipay/features/shop/models/product.dart';

class ProductsProvider extends ChangeNotifier implements ProductsRepository {
  AuthProvider? _auth;

  List<Product> _products = [];
  List<String> _categories = [];
  String _query = "";

  void updateAuth(AuthProvider provider) {
    _auth = provider;
  }

  void updateQuery(String value) {
    _query = value;
    notifyListeners();
  }

  @override
  Either<Failure, List<String>> getCategories() {
    return Right(_categories);
  }

  @override
  Future<Either<Failure, List<Product>>> getProducts() async {
    try {
      List<Product>? response = await ShopNetwork.getProducts(
        outletId: _auth!.authenticatedUser!.outletId,
        accessToken: "${_auth?.authenticatedUser?.accessToken}",
      );

      if (response != null) {
        _products = response;
        return Right(response);
      } else {
        return Left(Failure("Failed to fetch products"));
      }
    } catch (exception) {
      return Left(Failure(exception.toString()));
    }
  }

  List<Product> get products => _products;
  List<String> get categories => _categories;
  String get query => _query.toLowerCase();
  AuthProvider? get auth => _auth;
}
