import 'package:dartz/dartz.dart';
import 'package:tumaipay/core/models/failure.dart';
import 'package:tumaipay/features/shop/models/product.dart';

abstract class ProductsRepository {
  Future<Either<Failure, List<Product>>> getProducts();
  Either<Failure, List<String>> getCategories();
}
