import 'package:dio/dio.dart';
import 'package:tumaipay/configs/configs.dart';
import 'package:tumaipay/core/models/log_level.dart';
import 'package:tumaipay/features/receipt_management/models/receipt.dart';
import 'package:tumaipay/features/shop/models/checkout_data.dart';
import 'package:tumaipay/features/shop/models/payment_method.dart';
import 'package:tumaipay/services/logging.dart';
import 'package:tumaipay/services/services.dart';

class CartNetwork {
  static final Dio _dio = Dio()
    ..interceptors.add(
      LogInterceptor(
        responseBody: true,
        error: true,
        requestHeader: true,
        responseHeader: true,
        requestBody: true,
      ),
    );

  static final LoggingService _loggingService = locator<LoggingService>();

  static Future<List<PaymentMethod>> getPaymentMethods({
    required String accessToken,
  }) async {
    try {
      Response response = await _dio.get(
        "${NetworkApi.baseURl}/transaction/payment_methods/",
        options: Options(headers: {
          "Authorization": "Bearer $accessToken",
        }),
      );

      if (response.statusCode == 200) {
        return response.data["results"]
            .map<PaymentMethod>((json) => PaymentMethod.fromJson(json))
            .toList();
      } else {
        throw Exception("Failed to fetch payment methods");
      }
    } catch (exception, stacktrace) {
      _loggingService.log(
        LogLevel.ERROR,
        exception.toString(),
        stacktrace: stacktrace.toString(),
      );
      rethrow;
    }
  }

  static Future<Receipt> checkoutCart({
    required CheckoutData checkoutData,
    required String accessToken,
  }) async {
    try {
      Response response = await _dio.post(
        "${NetworkApi.baseURl}/transaction/process/express_checkout/",
        data: checkoutData.toJson(),
        options: Options(headers: {
          "Authorization": "Bearer $accessToken",
        }),
      );

      if (response.statusCode == 200) {
        return Receipt.fromJson(response.data["data"]);
      } else {
        throw Exception("Failed to checkout");
      }
    } catch (exception, stacktrace) {
      _loggingService.log(
        LogLevel.ERROR,
        exception.toString(),
        stacktrace: stacktrace.toString(),
      );
      rethrow;
    }
  }
}
