import 'package:dio/dio.dart';
import 'package:tumaipay/configs/configs.dart';
import 'package:tumaipay/core/models/log_level.dart';
import 'package:tumaipay/features/shop/models/product.dart';
import 'package:tumaipay/services/logging.dart';
import 'package:tumaipay/services/services.dart';

class ShopNetwork {
  static final Dio _dio = Dio()
    ..interceptors.add(
      LogInterceptor(
        responseBody: true,
        error: true,
        requestHeader: true,
        responseHeader: true,
        requestBody: true,
      ),
    );

  static final LoggingService _loggingService = locator<LoggingService>();

  static Future<List<Product>?> getProducts({
    required int outletId,
    required String accessToken,
  }) async {
    try {
      Response response = await _dio.get(
        "${NetworkApi.baseURl}/outlets/stock/$outletId/",
        options: Options(
          headers: {
            "Authorization": "Bearer $accessToken",
          },
        ),
      );

      if (response.statusCode == 200) {
        return response.data["stock"]
            .map<Product>((stockItem) =>
                Product.fromJson(stockItem as Map<String, dynamic>))
            .toList();
      }
      return null;
    } catch (exception, stacktrace) {
      _loggingService.log(
        LogLevel.ERROR,
        exception.toString(),
        stacktrace: stacktrace.toString(),
      );
      rethrow;
    }
  }
}
