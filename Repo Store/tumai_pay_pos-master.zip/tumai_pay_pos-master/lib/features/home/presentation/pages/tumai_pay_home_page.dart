import 'package:flutter/material.dart';
import 'package:handy_extensions/handy_extensions.dart';
import 'package:relative_scale/relative_scale.dart';
import 'package:tumaipay/configs/configs.dart';
import 'package:tumaipay/features/home/presentation/widgets/tumai_pay_appbar.dart';
import 'package:tumaipay/features/home/presentation/widgets/tumai_pay_bottom_appbar.dart';
import 'package:tumaipay/features/shop/presentation/pages/tumai_pay_outlet_products_page.dart';
import 'package:tumaipay/features/shop/presentation/pages/tumai_pay_shop_page.dart';
import 'package:tumaipay/features/shop/presentation/pages/tumai_pay_tabs_page.dart';

class TumaiPayHomePage extends StatefulWidget {
  const TumaiPayHomePage({Key? key}) : super(key: key);

  @override
  State<TumaiPayHomePage> createState() => _TumaiPayHomePageState();
}

class _TumaiPayHomePageState extends State<TumaiPayHomePage> {
  final _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return RelativeBuilder(builder: (context, height, width, sx, sy) {
      return Scaffold(
        key: _scaffoldKey,
        drawer: const Drawer(
            // TODO: All signout on this drawer component
            ),
        backgroundColor: AppColors.scaffoldColor,
        appBar: TumaiPayAppBar(context),
        bottomNavigationBar: TumaiPayBottomAppbar(
          scaffoldKey: _scaffoldKey,
        ),
        body: Container(
          width: context.width,
          height: context.height,
          padding: EdgeInsets.symmetric(
            horizontal: sx(20),
            vertical: sy(10),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(
                width: context.width,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    GestureDetector(
                      onTap: () => context.goTo(
                        page: const TumaiPayShopPage(),
                      ),
                      child: Container(
                        height: sy(90),
                        width: sx(250),
                        padding: EdgeInsets.symmetric(
                          horizontal: sx(20),
                          vertical: sy(15),
                        ),
                        decoration: BoxDecoration(
                          color: AppColors.darkAltBg,
                          borderRadius: BorderRadius.circular(7),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.3),
                              blurRadius: 10.0,
                              spreadRadius: 1.0,
                              offset: const Offset(
                                3.0,
                                3.0,
                              ),
                            )
                          ],
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Image(
                              image: const AssetImage(
                                  "assets/icons/transaction.png"),
                              height: sy(20),
                              color: AppColors.tumaiPayLightGreen,
                              // color: const Color(0xFF4B96D8),
                            ),
                            Text(
                              "Start Transaction",
                              style: TextStyle(
                                color: Colors.white.withOpacity(0.8),
                                fontWeight: FontWeight.bold,
                                fontSize: sy(11),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Container(
                      height: sy(90),
                      width: sx(250),
                      padding: EdgeInsets.symmetric(
                        horizontal: sx(20),
                        vertical: sy(15),
                      ),
                      decoration: BoxDecoration(
                        color: AppColors.darkAltBg,
                        borderRadius: BorderRadius.circular(7),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.3),
                            blurRadius: 10.0,
                            spreadRadius: 1.0,
                            offset: const Offset(
                              3.0,
                              3.0,
                            ),
                          )
                        ],
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Image(
                            image: const AssetImage(
                                "assets/icons/shopping-list.png"),
                            height: sy(20),
                            color: AppColors.tumaiPayLightGreen,
                            // color: const Color(0xFF4B96D8),
                          ),
                          Text(
                            "My Transactions",
                            style: TextStyle(
                              color: Colors.white.withOpacity(0.8),
                              fontWeight: FontWeight.bold,
                              fontSize: sy(11),
                            ),
                          ),
                        ],
                      ),
                    ),
                    GestureDetector(
                      onTap: () => context.goTo(
                        page: const TumaiPayOutletProductsPage(),
                      ),
                      child: Container(
                        height: sy(90),
                        width: sx(250),
                        padding: EdgeInsets.symmetric(
                          horizontal: sx(20),
                          vertical: sy(15),
                        ),
                        decoration: BoxDecoration(
                          color: AppColors.darkAltBg,
                          borderRadius: BorderRadius.circular(7),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.3),
                              blurRadius: 10.0,
                              spreadRadius: 1.0,
                              offset: const Offset(
                                3.0,
                                3.0,
                              ),
                            )
                          ],
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Image(
                              image:
                                  const AssetImage("assets/icons/product.png"),
                              height: sy(20),
                              color: AppColors.tumaiPayLightGreen,
                              // color: const Color(0xFF4B96D8),
                            ),
                            Text(
                              "Outlet Products",
                              style: TextStyle(
                                color: Colors.white.withOpacity(0.8),
                                fontWeight: FontWeight.bold,
                                fontSize: sy(11),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: sy(10),
              ),
              SizedBox(
                width: context.width,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    GestureDetector(
                      onTap: () => context.goTo(
                        page: const TumaiPayTabsPage(),
                      ),
                      child: Container(
                        height: sy(90),
                        width: sx(250),
                        padding: EdgeInsets.symmetric(
                          horizontal: sx(20),
                          vertical: sy(15),
                        ),
                        decoration: BoxDecoration(
                          color: AppColors.darkAltBg,
                          borderRadius: BorderRadius.circular(7),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.3),
                              blurRadius: 10.0,
                              spreadRadius: 1.0,
                              offset: const Offset(
                                3.0,
                                3.0,
                              ),
                            )
                          ],
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Image(
                              image:
                                  const AssetImage("assets/icons/invoice.png"),
                              height: sy(20),
                              color: AppColors.tumaiPayLightGreen,
                              // color: const Color(0xFF4B96D8),
                            ),
                            Text(
                              "My Tabs",
                              style: TextStyle(
                                color: Colors.white.withOpacity(0.8),
                                fontWeight: FontWeight.bold,
                                fontSize: sy(11),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Container(
                      height: sy(90),
                      width: sx(250),
                      padding: EdgeInsets.symmetric(
                        horizontal: sx(20),
                        vertical: sy(15),
                      ),
                      decoration: BoxDecoration(
                        color: AppColors.darkAltBg,
                        borderRadius: BorderRadius.circular(7),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.3),
                            blurRadius: 10.0,
                            spreadRadius: 1.0,
                            offset: const Offset(
                              3.0,
                              3.0,
                            ),
                          )
                        ],
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Image(
                            image:
                                const AssetImage("assets/icons/statistics.png"),
                            height: sy(20),
                            color: AppColors.tumaiPayLightGreen,
                            // color: const Color(0xFF4B96D8),
                          ),
                          Text(
                            "Sales Stats",
                            style: TextStyle(
                              color: Colors.white.withOpacity(0.8),
                              fontWeight: FontWeight.bold,
                              fontSize: sy(11),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      height: sy(90),
                      width: sx(250),
                      padding: EdgeInsets.symmetric(
                        horizontal: sx(20),
                        vertical: sy(15),
                      ),
                      decoration: BoxDecoration(
                        color: AppColors.darkAltBg,
                        borderRadius: BorderRadius.circular(7),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.3),
                            blurRadius: 10.0,
                            spreadRadius: 1.0,
                            offset: const Offset(
                              3.0,
                              3.0,
                            ),
                          )
                        ],
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Image(
                            image:
                                const AssetImage("assets/icons/printing.png"),
                            height: sy(20),
                            color: AppColors.tumaiPayLightGreen,
                          ),
                          Text(
                            "Printers",
                            style: TextStyle(
                              color: Colors.white.withOpacity(0.8),
                              fontWeight: FontWeight.bold,
                              fontSize: sy(11),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      );
    });
  }
}
