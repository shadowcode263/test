import 'package:flutter/material.dart';
import 'package:handy_extensions/handy_extensions.dart';
import 'package:provider/provider.dart';
import 'package:relative_scale/relative_scale.dart';
import 'package:tumaipay/configs/colors.dart';
import 'package:tumaipay/features/auth/data/repositories/impl/auth_provider.dart';
import 'package:tumaipay/features/home/presentation/controllers/show_about_app.dart';
import 'package:tumaipay/features/home/presentation/controllers/show_settings.dart';

class TumaiPayBottomAppbar extends StatelessWidget {
  TumaiPayBottomAppbar(
      {Key? key, required this.scaffoldKey, this.pageName = "Home"})
      : super(key: key);

  String pageName;
  final GlobalKey<ScaffoldState> scaffoldKey;

  @override
  Widget build(BuildContext context) {
    return RelativeBuilder(builder: (context, height, width, sx, sy) {
      return BottomAppBar(
        child: Consumer<AuthProvider>(builder: (context, provider, _) {
          return Container(
            width: context.width,
            padding: EdgeInsets.symmetric(
              horizontal: sx(10),
            ),
            height: sy(30),
            color: AppColors.darkAltBg,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    InkWell(
                      onTap: () => pageName == "Home"
                          ? scaffoldKey.currentState!.openDrawer()
                          : context.goBack(),
                      child: Icon(
                        pageName == "Home"
                            ? Icons.menu
                            : Icons.arrow_back_rounded,
                        color: Colors.white,
                        size: sy(15),
                      ),
                    ),
                    SizedBox(
                      width: sx(5),
                    ),
                    Text(
                      pageName,
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.normal,
                        fontSize: sy(11),
                      ),
                    ),
                  ],
                ),
                Text(
                  "${provider.authenticatedUser?.operatorName}",
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: sy(11),
                  ),
                ),
                Row(
                  children: [
                    InkWell(
                      onTap: () => showSettings(context),
                      child: Icon(
                        Icons.settings_outlined,
                        color: Colors.white,
                        size: sy(15),
                      ),
                    ),
                    SizedBox(
                      width: sx(5),
                    ),
                    InkWell(
                      onTap: () => showAboutApp(context),
                      child: Icon(
                        Icons.info_outline,
                        color: Colors.white,
                        size: sy(15),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          );
        }),
      );
    });
  }
}
