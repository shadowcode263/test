import 'package:flutter/material.dart';
import 'package:handy_extensions/handy_extensions.dart';
import 'package:tumaipay/configs/colors.dart';

AppBar TumaiPayAppBar(BuildContext context) {
  return AppBar(
    automaticallyImplyLeading: false,
    backgroundColor: AppColors.darkAltBg,
    title: Image(
      image: const AssetImage("assets/images/logo.png"),
      height: context.height * 0.03,
    ),
    centerTitle: true,
    toolbarHeight: context.height * 0.08,
  );
}
