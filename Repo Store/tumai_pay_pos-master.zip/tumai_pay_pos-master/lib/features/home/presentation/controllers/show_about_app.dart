import 'package:flutter/material.dart';
import 'package:tumaipay/services/application_information.dart';
import 'package:tumaipay/services/services.dart';

void showAboutApp(BuildContext context) {
  ApplicationInformationService applicationInformationService =
      locator<ApplicationInformationService>();
  showAboutDialog(
    context: context,
    applicationName: "Tumai Pay POS",
    applicationVersion: applicationInformationService.packageInfo.version,
    applicationIcon: const Image(
      image: AssetImage("assets/images/logo_circled.png"),
      height: 50,
      width: 50,
    ),
  );
}
