import 'package:tumaipay/features/shop/models/cart_item.dart';

extension CartListExtension on List<CartItem> {
  double get totalAmount {
    return fold(0.0,
        (value, element) => value + (element.quantity * element.product.price));
  }
}
