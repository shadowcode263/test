import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:intl/intl.dart';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'package:tumaipay/core/models/log_level.dart';
import 'package:tumaipay/core/models/logging.dart';
import 'package:tumaipay/services/logging.dart';
import 'package:tumaipay/services/services.dart';

const String externalLogFilename = "tumai_pay_log.txt";
const String externalBackupLogFilename = "tumai_pay_backup_log.txt";

class LoggingServiceWriter {
  LoggingService loggingService = locator<LoggingService>();
  File? _logFile;
  String? _logFilename;
  File? _backupLogFile;
  String? _backupLogFilename;

  Future<void> init() async {
    if (Platform.isAndroid) {
      Directory? directory = await getExternalStorageDirectory();
      loggingService.log(
          LogLevel.INFO, "External path reported ${directory!.path}");
      _logFilename = join(directory.path, externalLogFilename);
      _logFile = File(_logFilename!);
      _backupLogFilename = join(directory.path, externalBackupLogFilename);
      _backupLogFile = File(_backupLogFilename!);
      connectLogWriter();
    }
  }

  void connectLogWriter() {
    loggingService.setWriter(_writer);
  }

  void _writer(Logging logging) {
    try {
      if (_logFile!.existsSync() && _logFile!.lengthSync() > 1000000) {
        if (_backupLogFile!.existsSync()) {
          _backupLogFile!.deleteSync();
        }
        _backupLogFile = _logFile!.renameSync(_backupLogFilename!);
        _logFile = File(_logFilename!);
      }
      _logFile!.writeAsStringSync(
        '${DateFormat('dd-MM-yyyy HH:mm:ss').format(DateTime.now())} ${logging.message}\r\n',
        mode: FileMode.append,
        flush: true,
      );
    } catch (e) {
      debugPrint("Error while writing to file ${e.toString()}");
    }
  }
}
