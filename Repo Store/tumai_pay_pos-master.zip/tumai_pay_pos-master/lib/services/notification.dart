import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:tumaipay/core/functions/launch_url.dart';

class NotificationService {
  static final NotificationService _notificationService =
      NotificationService._internal();

  factory NotificationService() {
    return _notificationService;
  }

  NotificationService._internal();

  final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
      FlutterLocalNotificationsPlugin();

  Future<void> init() async {
    debugPrint("Setting up local notifications");
    // Initialize notification settings for Android
    const AndroidInitializationSettings initializationSettingsAndroid =
        AndroidInitializationSettings('ic_launcher');

    const IOSInitializationSettings initializationSettingsIOS =
        IOSInitializationSettings(
      requestSoundPermission: false,
      requestBadgePermission: false,
      requestAlertPermission: false,
    );

    // Configure the settings
    const InitializationSettings initializationSettings =
        InitializationSettings(
      android: initializationSettingsAndroid,
      iOS: initializationSettingsIOS,
      macOS: null,
    );
    // Initialize the settings withing the local notifications plugin
    await flutterLocalNotificationsPlugin.initialize(
      initializationSettings,
      onSelectNotification: selectNotification,
    );

    await flutterLocalNotificationsPlugin
        .resolvePlatformSpecificImplementation<
            IOSFlutterLocalNotificationsPlugin>()
        ?.requestPermissions(
          alert: true,
          badge: true,
          sound: true,
        );
  }

  Future selectNotification(String? payload) async {
    if (payload != null) {
      if (Platform.isAndroid) {
        String notificationData = payload;
        Map notification = json.decode(notificationData);

        if (notification["action"] == "download") {
        } else if (notification["action"] == "update") {
          launchURL(
            url:
                "https://play.google.com/store/apps/details?id=com.intelliafricasolutions.tumai",
          );
        }

        debugPrint("Notification selected");
      }
    }
  }

  Future<void> showNotification({
    required String title,
    required String message,
    Map? payload,
  }) async {
    const AndroidNotificationDetails androidPlatformChannelSpecifics =
        AndroidNotificationDetails(
      "tumai_notifications",
      "tumai_notifications",
      channelDescription: "Notifications From The Tumai Mobile",
      importance: Importance.max,
      priority: Priority.high,
      fullScreenIntent: true,
      styleInformation: BigTextStyleInformation(''),
    );

    const NotificationDetails platformChannelSpecifics = NotificationDetails(
      android: androidPlatformChannelSpecifics,
    );

    Random random = Random();
    await flutterLocalNotificationsPlugin.show(
      random.nextInt(1000),
      title,
      message,
      platformChannelSpecifics,
      payload: json.encode(payload ?? {}),
    );
  }
}
