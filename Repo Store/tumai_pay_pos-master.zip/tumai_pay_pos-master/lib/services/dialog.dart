import 'dart:async';

import 'package:flutter/cupertino.dart';

class DialogService {
  Function? _showLoaderDialogListener;
  Function? _showErrorDialogListener;
  Function? _showSuccessDialogListener;
  Function? _showChangeSuccessDialogListener;
  Completer? _dialogCompleter;
  Function? _removeDialog;
  Function? _showNotification;
  Function? _refreshToken;
  BuildContext? _context;

  /// Registration of listeners
  void registerLoaderDialogListener({required Function listener}) {
    this._showLoaderDialogListener = listener;
  }

  void registerContext({required BuildContext context}) {
    this._context = context;
  }

  void registerErrorDialogListener({required Function listener}) {
    this._showErrorDialogListener = listener;
  }

  void registerSuccessDialogListener({required Function listener}) {
    this._showSuccessDialogListener = listener;
  }

  void registerSuccessChangeDialogListener({required Function listener}) {
    this._showChangeSuccessDialogListener = listener;
  }

  void registerNotificationListener({required Function listener}) {
    this._showNotification = listener;
  }

  void registerDialogRemover({required Function listener}) {
    this._removeDialog = listener;
  }

  void registerRefreshTokenListener({required Function listener}) {
    this._refreshToken = listener;
  }

  /// Methods to invoke the dialogs
  Future showLoaderDialog({String? message}) {
    this._dialogCompleter = Completer();
    this._showLoaderDialogListener!(message: message);
    return this._dialogCompleter!.future;
  }

  Future showErrorDialog({
    required String title,
    required String message,
    String? buttonText,
    Function? onButtonClick,
    bool? isLogout = false,
  }) {
    this._dialogCompleter = Completer();
    this._showErrorDialogListener!(
      title: title,
      message: message,
      buttonText: buttonText,
      onButtonClick: onButtonClick,
      isLogout: isLogout,
    );
    return this._dialogCompleter!.future;
  }

  Future showSuccessDialog({required String title, required String message}) {
    this._dialogCompleter = Completer();
    this._showSuccessDialogListener!(
      title: title,
      message: message,
    );
    return this._dialogCompleter!.future;
  }

  Future showChangeSuccessDialog(
      {required String title, required String message}) {
    this._dialogCompleter = Completer();
    this._showChangeSuccessDialogListener!(
      title: title,
      message: message,
    );
    return this._dialogCompleter!.future;
  }

  void showNotification({required String message, bool isError = false}) {
    this._showNotification!(message: message, isError: isError);
  }

  BuildContext? useContext() {
    return this._context;
  }

  Future<String> refreshToken() {
    return _refreshToken!();
  }

  void dialogComplete() {
    this._dialogCompleter!.complete();
    this._removeDialog!();
    this._dialogCompleter = null;
  }
}
