import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:tumaipay/core/models/log_level.dart';
import 'package:tumaipay/core/models/logging.dart';
import 'package:uuid/uuid.dart';

class LoggingService {
  static LoggingService? _instance;
  static LoggingService getInstance() {
    _instance ??= LoggingService();
    _instance!._start();
    return _instance!;
  }

  final int _maxCacheRows = 1000;
  List<Logging> _cacheLog = [];
  void Function(Logging logging)? _writer;

  void _start() {
    log(LogLevel.INFO, "$runtimeType started");
  }

  void setWriter(void Function(Logging logging) writer) {
    _writer = writer;
    for (var a in _cacheLog) {
      _writer!(a);
    }
  }

  void log(LogLevel logLevel, String message, {String stacktrace = ""}) {
    var loggedLog = Logging(
      id: const Uuid().v4(),
      message: message,
      logLevel: logLevel,
      timestamp: DateTime.now().toUtc().toIso8601String(),
      stacktrace: stacktrace,
    );

    debugPrint(loggedLog.toString());

    if (Platform.isAndroid) {
      if (_writer == null) {
        debugPrint("Writer is not available");
        _cacheLog.add(loggedLog);
        if (_cacheLog.length > _maxCacheRows) {
          _cacheLog.removeRange(0, _cacheLog.length - _maxCacheRows);
        }
      } else {
        _writer!(loggedLog);
      }
    }
  }
}
