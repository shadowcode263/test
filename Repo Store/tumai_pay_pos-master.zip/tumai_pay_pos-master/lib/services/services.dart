import 'package:get_it/get_it.dart';
import 'package:tumaipay/core/classes/logging_service_writer.dart';
import 'package:tumaipay/services/dialog.dart';
import 'package:tumaipay/services/notification.dart';

import 'application_information.dart';
import 'logging.dart';
import 'storage.dart';

GetIt locator = GetIt.instance;

Future setupServices() async {
  StorageService instance = await StorageService.getInstance();
  LoggingService loggingInstance = LoggingService.getInstance();
  ApplicationInformationService applicationInformationInstance =
      await ApplicationInformationService.getInstance();

  locator.registerSingleton<StorageService>(instance);
  locator.registerSingleton<DialogService>(DialogService());
  locator.registerSingleton<LoggingService>(loggingInstance);
  locator.registerSingleton<ApplicationInformationService>(
      applicationInformationInstance);
  await LoggingServiceWriter().init();
  await NotificationService().init();
}
