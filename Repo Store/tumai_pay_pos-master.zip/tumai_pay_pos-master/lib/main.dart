import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:provider/provider.dart';
import 'package:tumaipay/features/auth/presentation/pages/sign_in_page.dart';
import 'package:tumaipay/features/shop/data/repositories/impl/cart_provider.dart';
import 'package:tumaipay/features/shop/data/repositories/impl/products_provider.dart';
import 'package:tumaipay/features/shop/models/tab.dart' as tabModel;
import 'package:tumaipay/services/services.dart';

import 'features/auth/data/repositories/impl/auth_provider.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  Platform.isAndroid
      ? SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky)
      : null;
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.landscapeLeft,
  ]);
  await setupServices();

  // Initialize Hive, Connect Adapters and Open Boxes
  await Hive.initFlutter();
  Hive.registerAdapter(tabModel.TabAdapter());
  Hive.openBox<tabModel.Tab>(
    "Tabs",
    crashRecovery: true,
  );

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthProvider()),
        ChangeNotifierProxyProvider<AuthProvider, ProductsProvider>(
          create: (_) => ProductsProvider(),
          update: (_, auth, products) => products!..updateAuth(auth),
        ),
        ChangeNotifierProxyProvider<ProductsProvider, CartProvider>(
          create: (_) => CartProvider(),
          update: (_, products, cart) => cart!..updateProducts(products),
        ),
      ],
      child: const TumaiPay(),
    ),
  );
}

class TumaiPay extends StatelessWidget {
  const TumaiPay({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    precacheImage(const AssetImage("assets/images/unsplash_1.jpg"), context);

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Tumai Pay',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        fontFamily: "Karla",
      ),
      builder: EasyLoading.init(
        builder: (context, widget) => Navigator(
          onGenerateRoute: (route) => MaterialPageRoute(
            builder: (context) => TumaiPayKeyboardListener(child: widget!),
          ),
        ),
      ),
      home: const SignInPage(),
    );
  }
}

class TumaiPayKeyboardListener extends StatelessWidget {
  const TumaiPayKeyboardListener({
    Key? key,
    required this.child,
  }) : super(key: key);

  final Widget child;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        if (MediaQuery.of(context).viewInsets.bottom > 0) {
          FocusScope.of(context).requestFocus(FocusNode());
        }
      },
      child: child,
    );
  }
}
