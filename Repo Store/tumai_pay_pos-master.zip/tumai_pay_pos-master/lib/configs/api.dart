class NetworkApi {
  /// Current Api version
  static String apiVersion = "v1";

  static String api = "http://192.81.211.54:9555/api";

  /// Base url containing [api] and [apiVersion]
  static String baseURl = "$api/$apiVersion";
}
