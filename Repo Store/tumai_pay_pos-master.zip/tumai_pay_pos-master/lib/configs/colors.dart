import 'package:flutter/material.dart';

class AppColors {
  static const Color primaryColor = Color(0xFFF8BC31);
  static const Color primaryColorAlt = Color(0xFF2E5E61);

  static const Color primaryColorLight = Color(0xFFE99203);
  static const Color primaryColorDark = Color(0xFFC86518);
  static const Color textBlue = Color(0xFF02B7A1);

  static const Color textNavy = Color(0xFF005A5F);
  static const Color darkBg = Color(0xFF183133);
  static const Color darkAltBg = Color(0xFF012D53);

  static const lightBlue = Color(0xFF5BCFBF);
  static const darkBlue = Color(0xFF246E79);

  static const lightGreen = Color(0xFF8BC43E);
  static const darkGreen = Color(0xFF62812D);

  static const lightRed = Color(0xFFEE404A);
  static const darkRed = Color(0xFFA2272F);

  static const Color scaffoldColor = Color(0xFFF6F7F9);
  static const Color tumaiPayLightGreen = Color(0xFF00B14B);
  static const Color tumaiPayDarkGreen = Color(0xFF00883B);
}
