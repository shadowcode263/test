package com.intelliafricasolutions.tumaipay

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
