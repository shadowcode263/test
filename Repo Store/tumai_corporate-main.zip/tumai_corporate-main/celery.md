> 

    HOW TO INSTALL CELERY AND RELATED STUFF


######1.sudo apt-get install rabbitmq-server

######2.install requirements.txt

######3.add start_flower.sh start_celery.sh to supervisor

######4.<a href="http://127.0.0.1:5555/dashboard">Monitoring</a>

