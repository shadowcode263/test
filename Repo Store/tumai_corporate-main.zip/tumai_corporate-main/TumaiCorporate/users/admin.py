from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin


from users.models import User

@admin.register(User)
class UserAdmin(BaseUserAdmin):
    list_display = ('ID', 'username', 'email', 'is_verified',"is_deleted")
    list_per_page = 100
    search_fields = ('email', 'username')
    fieldsets = (
        (None, {'fields': ('username', "is_deleted")}),
        ('Personal Info',
         {'fields': ('email','balance','usd_balance','company_name')
          }),
        ('Permissions', {'fields': ('is_active', 'is_staff', 'is_superuser', 'is_verified'),
                         }),
        ('Important Dates', {'fields': ('last_login', 'date_joined')}),
    )
    list_filter = ('date_joined', 'is_active', 'is_staff', 'is_superuser', 'is_superuser', 'is_verified')
