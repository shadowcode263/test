from django.contrib.auth.base_user import BaseUserManager


class CustomUserManager(BaseUserManager):
    def create_superuser(self, username, password, **other_fields):
        other_fields.setdefault('is_staff', True)
        other_fields.setdefault('is_superuser', True)
        other_fields.setdefault('is_active', True)

        if other_fields.get('is_staff') is not True:
            raise ValueError(
                'Superuser must be assigned to is_staff=True.'
            )
        if other_fields.get('is_superuser') is not True:
            raise ValueError(
                'Superuser must be assigned to is_superuser=True.'
            )
        return self.create_user(username, password, **other_fields)

    def create_user(self, username, password, **other_fields):
        if not username:
            raise ValueError(
                'You must provide username'
            )
        user = self.model(username=username, **other_fields)
        user.set_password(password)
        user.save()
        return user

    def register_corporate(self, payload):

        print(f'Debug = {payload}')
        
        user = self.model(username=payload.get('username'),
                          email=payload.get('email'),
                          company_name=payload.get('company_name'),
                          is_active=True)

        user.set_password(payload.get('password'))
        user.save()
        return user

    def find_by_email(self, email):
        return self.filter(email=email).first()    

    def find_by_username(self, username):
        return self.filter(username=username).first()     

    # def find_users_by_role(self, role):
    #     return self.filter(role__icontains=role)    

    def find_by_uuid(self, ID):
        return self.filter(ID=ID).first()    

    def reset_user_password(self, password, ID):
        
        instance = self.find_by_uuid(ID) 
        instance.set_password(password)
        instance.save()

        return instance   

    