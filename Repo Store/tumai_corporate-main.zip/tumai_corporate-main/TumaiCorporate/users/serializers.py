from rest_framework import serializers

from users.models import User


class UserAddSerializer(serializers.Serializer):

    """
        USER CREATION SERIALIZER

    """
    username = serializers.CharField(required=True, min_length=3, max_length=255, label='Username')
    company_name = serializers.CharField(required=True, min_length=3, max_length=255, label='Company')
    email = serializers.EmailField(required=True, max_length=255, label='Email')


    def create(self, validated_data):
        return UserAddSerializer(**validated_data)

    def update(self, instance, validated_data):
        instance.email = validated_data.get('email', instance.email)
        instance.username = validated_data.get('username', instance.username)
        instance.first_name = validated_data.get('first_name', instance.first_name)
        instance.last_name = validated_data.get('last_name', instance.last_name)
        instance.save()
        return instance


class UserChangePasswordSerializer(serializers.Serializer):
    model = User

    """
    Serializer for password change endpoint.
    """
    old_password = serializers.CharField(required=True)
    new_password = serializers.CharField(required=True)

    def password_reset(self, instance, validated_data):
        instance.password = validated_data.get('password', instance.password)
        instance.save()
        return instance


class UserSerializer(serializers.ModelSerializer):

    class Meta:
        model = User
        fields = ['username','company_name','balance']
