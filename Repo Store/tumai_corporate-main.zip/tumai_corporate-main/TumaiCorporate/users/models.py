import datetime
import uuid
import json
from django.db.models import Sum
from django.contrib.auth.base_user import BaseUserManager
from django.contrib.auth.models import AbstractUser
from django.db import models

from users.managers import CustomUserManager


class User(AbstractUser):
    ID = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    company_name = models.CharField(max_length=30, blank=False)
    email = models.EmailField(unique=True)
    is_verified = models.BooleanField(default=False)
    is_active = models.BooleanField(default=False)
    is_deleted = models.BooleanField(default=False)
    balance = models.DecimalField(max_digits=15, decimal_places=2, default=0.0)
    usd_balance = models.DecimalField(max_digits=15, decimal_places=2, default=0.0)
    phone = models.CharField(max_length=50,blank=True, null=True)


    objects = CustomUserManager()

    def __str__(self):
        return f"{self.username}-{self.company_name}"

    class Meta:
        ordering = ["company_name"]
        verbose_name = "User"
        verbose_name_plural = "Users"

    @classmethod
    def getUser(cls, uuid):
        return cls.objects.filter(ID=uuid).first()
    
    def check_balance(self, transaction_amount: float):
        if self.balance >= float(transaction_amount):
            return True
        else:
            return False

    def check_usd_balance(self, transaction_amount: float):
        if self.usd_balance >= float(transaction_amount):
            return True
        else:
            return False
    
    def deduct_usd_balance(self, transaction_amount: float):
        self.usd_balance = float(self.usd_balance) - float(transaction_amount)
        self.save()
    
    def deduct_balance(self, transaction_amount: float):
        self.balance = float(self.balance) - float(transaction_amount)
        self.save()

    def get_failed(self):
        from transactions.models import Transactions
        txn = Transactions.filter_user(self.ID)
        return txn.aggregate(Sum('number_of_failed')).get('number_of_failed__sum')
    def get_processed(self):
        from transactions.models import Transactions
        txn = Transactions.filter_user(self.ID)
        return txn.aggregate(Sum('number_of_processed')).get('number_of_processed__sum')
    def get_transactions(self):
        from transactions.models import Transactions
        txn = Transactions.filter_user(self.ID)
        return txn.aggregate(Sum('number_of_transactions')).get('number_of_transactions__sum')
    def get_processed_amount(self):
        from transactions.models import Transactions
        txn = Transactions.filter_user(self.ID)
        return txn.aggregate(Sum('processed_amount')).get('processed_amount__sum')

    def save(self, *args, **kwargs):
        # set admin user permissions
        if self.is_superuser:
            self.user_type = 'ADMIN'
            self.is_verified = True
        super().save(*args, **kwargs)
        