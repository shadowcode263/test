import requests
from decouple import config
import datetime
import random


class SinglePurchaseProcessor:
    def __init__(self) -> None:
        self.url = "https://bpa.tumai.to/api/v1/transactions/post/"
        self.headers = {"apiUsername": config("APIUSERNAME"), "apiKey": config("APIKEY")}

    def process(self, payload):
        try:
            print("now trying", payload)
            response = requests.post(url=self.url, json=payload, headers=self.headers)
            print("\n\nRESPONSE : ", response.content, '\n')
        except Exception as e:
            print(f"Exception ::::::::: {e}")
            class Error:
                self.status_code = 500
                self.message = {"success": False, "message": {"response": f"Internal server erro during processing ({e})"}}
            response = Error()
        return response
    

        
        


# 
# amount 
#  
# currency 
# extras: phoneNumber