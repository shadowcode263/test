from concurrent import futures
import threading
import datetime
import pandas as pd
import numpy as np
import logging
import random
from services.batch.single_purchase_processor import SinglePurchaseProcessor
from transactions.models import Transactions
from django.core.files.uploadedfile import InMemoryUploadedFile
from io import StringIO
import sys
import csv

logging.getLogger().setLevel(logging.INFO)
class BatchProcess:
    def __init__(self, file, txnId, threads=7, name="Intelli", currency="zwl", service="AIRTIME") -> None:
        self.dataFrame = pd.read_csv(file)
        self.processor = SinglePurchaseProcessor()
        self.threads = threads
        self.divided_tasks_list = None
        self.failed = []
        self.done = []
        self.tasks = []
        self.name = name
        self.currency = currency
        self.txnId = txnId
        self.service = service
        self.payload = {}
        self.divide_tasks()

    
    def divide_tasks(self):
        rows = self.dataFrame.shape[0]
        txn = Transactions.filter_reference(self.txnId)
        txn.set_transactions(rows)
        del txn
        self.divided_tasks_list = [np.array(part) for part in np.array_split(self.dataFrame, self.threads)]

    @staticmethod
    def get_vendor_reference(prefix='TC'):
        """generating vendor reference
        Args:
            prefix: Prefix to vendor reference
        Returns:
            response: Generated vendor number
        """
        MN = ["JA", 'FB', 'MA', 'AP', 'MY', 'JN', 'JL', 'AG', 'SP', 'OC', 'NV', 'DC']
        created = datetime.datetime.now()
        return f"{prefix if prefix else ''}{created.year}{MN[created.month - 1]}{created.day}{created.second}{random.randint(20000, 99999)}"


    def process_transaction(self, batch):
        response = None
        pin = None
        batch = list(batch)
        try:
            #TODO :
            # LOGIC GOES HERE  
            logging.info(f"Processing {batch}")
            try:
                payload = {
                    "vendorReference": self.get_vendor_reference(),
                    "amount": float(batch[1]),
                    "transactionType": f"00{batch[2]}" if self.payload.get("transaction_type").upper() in  ["AIRTIME", "DATA"] else f"016",
                    "currency": self.currency.upper() if self.payload.get("transaction_type").upper() in  ["AIRTIME", "DATA"] else "USD",
                    "extras": self.extract_extras(batch=batch, service=self.payload.get("transaction_type").upper())
                }
                print("\n\n", payload)
            except Exception as e:
                print(f">>>>>>>{e}")
            
            response = self.processor.process(payload=payload)
            res = response.json()
            if response.status_code == 200 and res.get("successful"):
                txn = Transactions.filter_reference(self.txnId)
                txn.increment_processed()
                if payload["transactionType"] == "016":
                    message = res['message']
                    pin = message.get("Description")
                    if message['ResponseCode'] == "00000":
                        txn.user.deduct_usd_balance(batch[1])
                else:
                    txn.user.deduct_balance(batch[1])
                txn.increment_processed_amount(batch[1])
                del txn
                response = res
                
                batch.extend([payload["vendorReference"], response.get("successful"), pin])
                self.done.append(batch)
            else:
                txn = Transactions.filter_reference(self.txnId)
                txn.increment_failed()
                del txn
                response = response.message
                batch.extend([payload["vendorReference"], response.get("successful"), pin])
                self.done.append(batch)
        except Exception as e:
            response = {"success": False, "response": {"message": f"Internal server error during processing ({e})"}}
            batch.extend([None, False, pin])
            self.done.append(batch)
        del payload
        return response

    def extract_extras(self, batch, service="AIRTIME"):
        if service == "AIRTIME":
            extras = {
                "phoneNumber": f"{batch[0]}"
            }
        elif service == "VOUCHERS":
            data  = {
                "recepient_phone_number": f"{batch[0]}",
                "amount": batch[1],
                "recepient_first_name": batch[2],
                "recepient_last_name": batch[3],
                "recepient_national_id":  batch[4],
                "currency": "USD",
            }
            extras = {
                "CustomerMSISDN": data['recepient_phone_number'],
                "billerId": self.payload.get('biller_id'),
                "CustomerData": ",".join([str(i) for i in data.values()]),
            }
        
        elif service == "DATA":
            extras = {
                "phoneNumber": f"{batch[0]}",
                "billerProduct": self.payload.get('product_id')
            }
        else:
            extras = {

            }
        return extras

    def batch_process(self, batch=[]):
        with futures.ThreadPoolExecutor(max_workers=1) as executor:
            responses = executor.map(self.process_transaction, batch)
        return responses

    def convert_to_csv(self, columns):
        in_memory_file = StringIO()
        csv_writer = csv.writer(in_memory_file)
        columns = [columns]
        columns.extend(np.array(pd.DataFrame(data=self.done, columns=columns)).tolist())
        csv_writer.writerows(columns)
        in_memory_file.seek(0)
        return InMemoryUploadedFile(file=in_memory_file,field_name="processed_csv", name=f"{self.name}_{self.txnId}".upper()+".csv", content_type="text/csv", size=sys.getsizeof(csv_writer), charset="Unicode - UTF8")
        

    def startProcessing(self, payload={}):
        self.payload = payload
        for batch in self.divided_tasks_list:
            task = threading.Thread(target=self.batch_process, args=[batch])
            self.tasks.append(task)
            task.start()

        for task in self.tasks:
            task.join()

        if self.payload.get("transaction_type").upper() in  ["AIRTIME", "DATA"]:
            columns = ["Phone Number", "Amount", "Provider", "Vendor Reference", "Successful", "Narration"]
        elif self.payload.get("transaction_type").upper() == "VOUCHERS":
            columns = ["Phone Number", "Amount", "Receiver Firstname", "Receiver Lastname", "Receiver National ID #", "Vendor Reference", "Successful", "Narration"]
        print("COLUMNS : ", columns, self.done)
        txn = Transactions.filter_reference(self.txnId)
        txn.set_status(True)
        txn = Transactions.filter_reference(self.txnId)
        txn.save_processed(self.convert_to_csv(columns=columns))
        
        

