from django.http.response import JsonResponse
from rest_framework import status
from config.tasks import process_bulk
from services.batch.batch_processing import BatchProcess
from services.batch.single_purchase_processor import SinglePurchaseProcessor
from transactions.models import Transactions
from api.responses.ApiResponse import ApiResponse
from services.utils.logger import Logger
from services.utils.utils import Utils
from django.core.exceptions import BadRequest, ObjectDoesNotExist

 
"""
    TRANSACTION SERVICE MANAGER
"""

class TransactionsService:
    """
        Transaction Service Initialisation
    """

    def __init__(self, payload: dict, user:object, csv_data = None):
        self.payload = payload
        self.csv_data = csv_data
        self.user = user

    def process(self):
        try:
            print('Payload: ', self.payload)
            print('CSV Data: ', self.csv_data)
            # pre commit
            extras = {
                "phone_number":self.payload.get('phone_number'),
                "transaction_type":self.payload.get('transactionType')
            }
            post_status, transaction = Transactions.post(
                self.payload.get('transaction_type'),
                self.payload.get('amount'), 
                self.payload.get('currency'), 
                self.payload.get('processing_type'),
                Utils.get_vendor_reference(prefix='TC'), 
                self.user, 
                extras,
                self.csv_data
            )
            if transaction.transaction_type.lower() == 'vouchers':
                if self.user.check_usd_balance(self.payload.get('amount')):
                    pass
                else:
                    # insufficient balance
                    response = ApiResponse(False, {'response': 'Insufficient Balance'})
                    return JsonResponse(status=status.HTTP_403_FORBIDDEN, data=response.map())
            else:
                if self.user.check_balance(self.payload.get('amount')):
                    pass
                else:
                    # insufficient balance
                    response = ApiResponse(False, {'response': 'Insufficient Balance'})
                    return JsonResponse(status=status.HTTP_403_FORBIDDEN, data=response.map())
            
            if post_status:
                # response
                if self.payload.get('processing_type') == 'single':
                    if transaction.transaction_type.lower() == 'airtime':
                        payload = {
                            "vendorReference": transaction.vendor_reference,
                            "amount": float(transaction.amount),
                            "transactionType": transaction.extras.get('transaction_type'),
                            "currency": transaction.currency,
                            "extras": {
                                "phoneNumber":transaction.extras.get('phone_number')
                            }
                        }
                        # set number of transaction to 1
                        transaction.set_transactions(1)
                    elif transaction.transaction_type.lower() == 'vouchers':
                        data  = {
                            "recepient_phone_number": transaction.extras.get('recepient_phone_number'),
                            "amount": float(transaction.amount),
                            "recepient_first_name": transaction.extras.get('recepient_first_name'),
                            "recepient_last_name": transaction.extras.get('recepient_last_name'),
                            "recepient_national_id":  transaction.extras.get('recepient_national_id'),
                            "currency": self.payload.get('currency'),
                        }
                        payload = {
                            "vendorReference": transaction.vendor_reference,
                            "amount": float(transaction.amount),
                            "transactionType": transaction.extras.get('transaction_type'),
                            "currency": transaction.currency,
                            "extras": {
                                "CustomerMSISDN": data['recepient_phone_number'],
                                "billerId": self.payload.get('biller_id'),
                                "CustomerData": ",".join([str(i) for i in data.values()]),
                            } 
                        }
                        # set number of transaction to 1
                        transaction.set_transactions(1)
                    elif transaction.transaction_type.lower() == 'data':
                        payload = {
                            "vendorReference": transaction.vendor_reference,
                            "amount": float(transaction.amount),
                            "transactionType": transaction.extras.get('transaction_type'),
                            "currency": transaction.currency,
                            "extras": {
                                "phoneNumber":transaction.extras.get('phone_number'),
                                "billerProduct": self.payload.get('product_id')
                            }
                        }
                        # set number of transaction to 1
                        transaction.set_transactions(1)
                    else:
                        payload = {
                            "vendorReference": transaction.vendor_reference,
                            "amount": transaction.amount,
                            "transactionType": transaction.extras.get('transaction_type'),
                            "currency": transaction.currency,
                            "extras": {
                                "phoneNumber":transaction.extras.get('phone_number')
                            }
                        }
                    processor_response = SinglePurchaseProcessor()
                    request = processor_response.process(payload)
                    print("response",request.status_code)
                    if request.status_code == 200:
                        # set number of processed to 1
                        transaction.increment_processed()
                        transaction.set_status(True)
                        # deduct balance
                        self.user.deduct_balance(transaction.amount) if transaction.transaction_type.lower() != 'vouchers' else self.user.deduct_usd_balance(transaction.amount)
                        transaction.increment_processed_amount(transaction.amount)
                        response = ApiResponse(True, {'response': {"narration":"Transaction Sent for Processing","vendor_reference":transaction.vendor_reference}})
                        return JsonResponse(status=status.HTTP_200_OK, data=response.map())
                    else:
                        transaction.increment_failed()
                        transaction.set_status(False)
                        response = ApiResponse(True, {'response': 'Transaction could not be processed'})
                        return JsonResponse(status=status.HTTP_200_OK, data=response.map())
                else: 
                    # process_bulk(self.payload,transaction.csv.path, transaction.vendor_reference)
                    try:
                        process_bulk.delay(self.payload,transaction.csv.path, transaction.vendor_reference)
                    except Exception as e:
                        print("CELERY EXCEPTION ", e)
                    response = ApiResponse(True, {"response": {"narration":"Transaction Sent for Processing","vendor_reference":transaction.vendor_reference}})
                    return JsonResponse(status=status.HTTP_200_OK, data=response.map())
            else:
                    # duplicate merchant reference
                    response = ApiResponse(False, {'response': 'Transaction Could not Be Processed'})
                    return JsonResponse(status=status.HTTP_403_FORBIDDEN, data=response.map())
         
        except Exception as e:
            """
                Exception
            """
            Logger.output('Transactions Exception', {'error': e})
            response = ApiResponse(False, Utils().get_messages()['400_Exception'])
            return JsonResponse(data=response.map(),
                                status=status.HTTP_400_BAD_REQUEST)