import datetime
from transactions.models import TransactionType


class DateValidator:
    @staticmethod
    def validate(date):
        date_format = "%Y-%m-%d"
        try:
            return True, datetime.datetime.strptime(date, date_format)
        except ValueError:
            return False, "Set Date  format should be YYYY-mm-dd"


class TransactionTypeValidator:
    @staticmethod
    def validate(transaction_type):
        if TransactionType.filterByCode(transaction_type):
            return True,transaction_type
        else:
            return False,"Transaction Type does not exist"