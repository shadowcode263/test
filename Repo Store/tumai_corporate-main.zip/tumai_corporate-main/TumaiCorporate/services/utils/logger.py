"""
    LOGGING CLASS
"""


class Logger:

    @staticmethod
    def output(url: str, payload: dict):
        print(f'{url} : {payload}')
