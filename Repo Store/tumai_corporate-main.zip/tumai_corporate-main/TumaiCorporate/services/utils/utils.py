import datetime
import random
"""
    COMMON UTILITIES
"""

class Utils:

    @staticmethod
    def get_messages():
        return {
            "non_or_empty": ["", None],
            "401": "Unauthorized",
            "400_Missing_Headers": "Missing api key or username",
            "invalid_data": "Invalid data format",
            "success": "Success",
            '403_Invalid_Transaction': 'Invalid transaction type',
            '400_Exception': "Transaction couldn't be processed",
            '400_Missing_Number': "Phone number not supplied",
            'invalid_dates': 'Invalid date formats, format is YYYY-mm-dd',
            'invalid_transaction_type': 'Invalid Transaction Type',
            '400_Invalid_BillerId': 'Invalid biller id',
            'connection_error': 'Connection error',
            '406_Invalid_Currency': 'Invalid currency',
            '406_Low_Balance': "Insufficient balance to perform the transaction",
        }
        
    @staticmethod
    def get_vendor_reference(prefix='T'):
        """generating vendor reference
        Args:
            prefix: Prefix to vendor reference
        Returns:
            response: Generated vendor number
        """
        MN = ["JA", 'FB', 'MA', 'AP', 'MY', 'JN', 'JL', 'AG', 'SP', 'OC', 'NV', 'DC']
        created = datetime.datetime.now()
        return f"{prefix if prefix else ''}{created.year}{MN[created.month - 1]}{created.day}{created.second}{random.randint(20000, 99999)}"
