from django.contrib import admin
from .models import Transactions


"""
    ADMIN MODEL REGISTRATION
"""


@admin.register(Transactions)
class TransactionsAdmin(admin.ModelAdmin):
    list_display = ('transaction_type', 'user', 'status', 'number_of_transactions', 'amount', 'currency', 'last_updated')
    list_per_page = 100
    search_fields = ('processing_type', 'vendor_reference')
    fieldsets = (
        ('User Info',
         {'fields': ('user', 'vendor_reference')
          }),
        ('Transactions Info',
         {'fields': ('transaction_type', 'amount', 'currency','status', 'processing_type', 'extras', 'csv', 'number_of_transactions','number_of_processed','number_of_failed','processed_amount','processed_csv')
          }),
    )
    list_filter = ('status',)

