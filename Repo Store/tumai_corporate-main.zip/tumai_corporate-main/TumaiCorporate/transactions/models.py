from django.db import models

# Create your models here.
import uuid
import datetime

from django.db import models
from users.models import User

"""
    TRANSACTIONS
"""


class Transactions(models.Model):
    ID = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    transaction_type = models.CharField(max_length=255)
    source = models.CharField(max_length=150, blank=True, default="TumaiCorporate")
    amount = models.FloatField(blank=True, null=True)
    status = models.BooleanField(null=True)
    narration = models.CharField(max_length=255,blank=True, null=True)
    processing_type = models.CharField(max_length=255,blank=False, null=False, default="single")
    currency = models.CharField(max_length=255, default="USD")
    number_of_processed= models.IntegerField(default=0)
    number_of_failed= models.IntegerField(default=0)
    number_of_transactions = models.IntegerField(default=0)
    processed_amount = models.FloatField(default=0)
    vendor_reference = models.CharField(max_length=255, unique=True)
    user = models.ForeignKey(
        User, on_delete=models.PROTECT, null=True
    )
    extras = models.JSONField(null=True, blank=True)
    date_created = models.DateTimeField(auto_now_add=True)
    last_updated = models.DateTimeField(auto_now=True)
    csv = models.FileField(upload_to='csv', max_length=100, blank=True, null=True)
    processed_csv = models.FileField(upload_to='csv', max_length=100, blank=True, null=True)

    def __str__(self):
        return f'{self.vendor_reference} - {self.transaction_type}'

    def save(self, *args, **kwargs):
        self.last_updated = datetime.datetime.today()
        super().save(*args, **kwargs)

    class Meta:
        ordering = ['-date_created']
        verbose_name = 'Transactions'
        verbose_name_plural = 'Transactions'

    @classmethod
    def post(cls, transaction_type, amount, currency, processing_type,
             vendor_reference, user, extras, csv_data):
      
        transaction = cls.objects.create(
                status=False, extras=extras, transaction_type=transaction_type,
                amount=amount, vendor_reference=vendor_reference,
                user=user,currency=currency,csv = csv_data,processing_type=processing_type
            )
        return True, transaction

    @classmethod
    def filter_reference(cls, reference):
        return cls.objects.filter(vendor_reference=reference).first()

    @classmethod
    def filter_user(cls, user):
        return cls.objects.filter(user__ID=user)

    def set_transactions(self, number):
        self.number_of_transactions = number
        self.save()

    def set_status(self, status):
        self.status = status
        self.save()

    def increment_failed(self):
        self.number_of_failed += 1
        self.save()

    def increment_processed(self):
        self.number_of_processed += 1
        self.save()

    def increment_processed_amount(self,amount):
        self.processed_amount += float(amount)
        self.save()

    def save_processed(self,processed):
        self.processed_csv = processed
        self.save()
