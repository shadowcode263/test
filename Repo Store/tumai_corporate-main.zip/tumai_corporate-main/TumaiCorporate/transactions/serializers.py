from locale import currency
from django.forms import ValidationError
from rest_framework import serializers
import pandas as pd

from transactions.models import Transactions

class TransactionSerializer(serializers.Serializer):
    currency = serializers.CharField(required=True, max_length=255, label='Currency')
    transaction_type = serializers.CharField(required=True, min_length=3, max_length=255, label='Transaction Type')
    amount = serializers.DecimalField(required=True, max_digits=10, decimal_places=2)
    processing_type = serializers.CharField(required=True, max_length=255, label='Processing Type')
    extras = serializers.JSONField(required=False)
    phone_number = serializers.CharField(required=False, max_length=255, label='phone_number')
    transactionType = serializers.CharField(required=False, max_length=255, label='TransactionType')
    biller_id = serializers.CharField(required=False, min_length=3, max_length=255, label='Biller Identifier')
    product_id = serializers.CharField(required=False, min_length=3, max_length=255, label='Product Identifier')
    data_csv = serializers.FileField(required=False)
    
    def validate(self, attrs):
        if attrs['processing_type'] == 'single':
            if attrs['transaction_type'].lower() == 'airtime':
                extras = {
                    "phone_number":attrs['phone_number'],
                    "transaction_type":attrs['transactionType']
                }
                validate_extra = AirtimeTransactionSerializer(data=extras)
                if validate_extra.is_valid():
                    return super().validate(attrs)
                else:
                    raise serializers.ValidationError({"Extras": validate_extra.errors})
            else:
                validate_extra = VoucherTransactionSerializer(data=attrs['extras'])
                if validate_extra.is_valid():
                    return super().validate(attrs)
                else:
                    raise serializers.ValidationError({"Extras": validate_extra.errors})
        elif attrs['processing_type'].lower() == 'bulk':
            if attrs['transaction_type'].lower() == 'vouchers':
                if not attrs.get('biller_id'):
                    raise serializers.ValidationError({"biller_id": 'Missing biller id'})
            if attrs['transaction_type'].lower() == 'data':
                if not attrs.get('product_id'):
                    raise serializers.ValidationError({"product_id": 'Missing product id'})
            validate_bulk = BulkTransactionSerializer(data=attrs)
            if validate_bulk.is_valid():
                return super().validate(attrs)
            else:
                raise serializers.ValidationError({"Extras": validate_bulk.errors})
        else:
            return super().validate(attrs)
            
class BulkTransactionSerializer(serializers.Serializer):
    transaction_type = serializers.CharField(required=True, min_length=3, max_length=255, label='Transaction Type')
    amount = serializers.DecimalField(required=True, max_digits=10, decimal_places=2)
    biller_id = serializers.CharField(required=False, min_length=3, max_length=255, label='Biller Identifier')
    product_id = serializers.CharField(required=False, min_length=3, max_length=255, label='Product Identifier')
    data_csv = serializers.FileField(required=True)
    
    def validate(self, attrs):
        if attrs['transaction_type'].lower() == 'airtime':
            correct_headers = ['phone_number', 'amount', 'transaction_type']
        elif attrs['transaction_type'].lower() == 'vouchers':
            if not attrs.get('biller_id'):
                raise serializers.ValidationError({"biller_id": 'Missing biller id'})
            correct_headers = ['phone_number', 'amount', 'receiver_firstname', 'receiver_lastname', 'receiver_nationalid']
        elif attrs['transaction_type'].lower() == 'data':
            if not attrs.get('product_id'):
                raise serializers.ValidationError({"product_id": 'Missing product id'})
            correct_headers = ['phone_number', 'amount', 'transaction_type']
        headers = pd.read_csv(attrs['data_csv']).columns.tolist()
        if correct_headers == headers:
            return super().validate(attrs)
        else:
            raise serializers.ValidationError({"CSV": 'Invalid CSV provided'})
class AirtimeTransactionSerializer(serializers.Serializer):
    transaction_type = serializers.CharField(required=True, min_length=3, max_length=255, label='Transaction Type')
    phone_number = serializers.CharField(required=True, min_length=3, max_length=255, label='Phone Number')


class DataTransactionSerializer(serializers.Serializer):
    transaction_type = serializers.CharField(required=True, min_length=3, max_length=255, label='Transaction Type')
    phone_number = serializers.CharField(required=True, min_length=3, max_length=255, label='Phone Number')
    
class VoucherTransactionSerializer(serializers.Serializer):
    recepient_phone_number = serializers.CharField(required=True, max_length=255, label='Recepient Phone Number')
    amount = serializers.FloatField(required=False, label='Amount', min_value=1)
    recepient_national_id = serializers.CharField(required=True, max_length=20, label='Recepient')
    recepient_first_name = serializers.CharField(required=True, max_length=255, label='Recepient First Name')
    recepient_last_name = serializers.CharField(required=True, max_length=255, label='Recepient Last Name')
    billerId = serializers.CharField(required=True, max_length=20, label='Biller Id')


class TransactionViewSerializer(serializers.ModelSerializer):

    progress = serializers.SerializerMethodField()
    class Meta:
        model = Transactions
        fields = ['user', 'transaction_type', 'amount', 'narration', 'vendor_reference', 'status', 
        'date_created','number_of_processed','number_of_transactions','number_of_failed','processing_type','progress','processed_amount','processed_csv']

    def get_progress(self, obj):
        processed = obj.number_of_processed + obj.number_of_failed
        if obj.number_of_transactions >0: 
            return (processed/obj.number_of_transactions)*100
        else:
            return 100