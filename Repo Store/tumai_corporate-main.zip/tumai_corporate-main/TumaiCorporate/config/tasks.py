from celery import shared_task
from decouple import config
from services.batch.batch_processing import BatchProcess

@shared_task(name="process_bulk_transactions")
def process_bulk(data,csv, txnId):
    print(f"Processing bulk transactions")
    p = BatchProcess(file=csv, txnId=txnId, threads=7)
    p.startProcessing(payload=data)
    return

