import json

from rest_framework.views import APIView
from rest_framework.renderers import JSONRenderer
from rest_framework.parsers import JSONParser
from django.http import JsonResponse, Http404
from rest_framework import status, generics
from django.forms.models import model_to_dict
from rest_framework.permissions import IsAuthenticated, IsAdminUser
# from django.core.exceptions import raise404
from django.core.exceptions import ObjectDoesNotExist

from users.serializers import UserAddSerializer, UserChangePasswordSerializer, UserSerializer
from services.UsersService import AddUserService
from users.models import User
from django.contrib.auth.hashers import check_password
# from utils.services import EmailService



##############################################################################################

# *********************************ADD CORPORATE**************************************************

##############################################################################################

class CorporateAdd(APIView):
    parser_classes = [JSONParser]
    renderer_classes = [JSONRenderer]
    permission_classes = (IsAuthenticated,)
    serializer_class = UserAddSerializer

    def post(self, request):

        try:
            if not request.body:
                return JsonResponse(
                    status=status.HTTP_400_BAD_REQUEST, data={'message': f'No Payload Received.'}
                )

            data = json.loads(request.body)

            print(f'\n\n\nDATA ===========================> {data}\n\n\n')

            serializer = UserAddSerializer(data=data)

            if serializer.is_valid():
                service = AddUserService(request=request, payload=data)
                return service.register()
            else:
                
                return JsonResponse(
                    status=status.HTTP_400_BAD_REQUEST, data={'message': serializer.errors}
                )    
        except Exception as e:
            return JsonResponse(
                status=status.HTTP_500_INTERNAL_SERVER_ERROR, data={'message': f'{e}'}
            )

##############################################################################################

# *********************************LIST AGENTS**************************************************

##############################################################################################

class PersonnelListView(generics.ListAPIView):
    renderer_classes = [JSONRenderer]
    permission_classes = (IsAdminUser,)
    serializer_class = UserAddSerializer
    queryset = User.objects.all()


##############################################################################################

# *********************************GET/UPDATE AGENT**************************************************

##############################################################################################

class UserDetailView(APIView):
    permission_classes = (IsAuthenticated,)
    renderer_classes = [JSONRenderer]
    serializer_class = UserSerializer

    def get(self, request, *args, **kwargs):  
        try:
            user =  request.user
            return JsonResponse(status=status.HTTP_200_OK, data={"message":{
                "balance":user.balance,
                "usd_balance": user.usd_balance,
                "company_name":user.company_name,
                "username":user.username,
                "failed":user.get_failed(),
                "processed":user.get_processed(),
                "transactions":user.get_transactions(),
                "amount":user.get_processed_amount()
            }})
        except ObjectDoesNotExist:
            return JsonResponse(status=status.HTTP_404_NOT_FOUND, data={'message': 'Details could not be loaded'})
    
class UserChangePasswordView(APIView):
    permission_classes = (IsAuthenticated,)
    renderer_classes = [JSONRenderer]
    password_serializer_class = UserChangePasswordSerializer

    def post(self, request, *args, **kwargs):
        try:
            payload = self.password_serializer_class(data=request.data)
            if payload.is_valid():
                user = request.user
                if user.check_password(payload.validated_data["old_password"]):
                    user.set_password(payload.validated_data["new_password"])
                    user.save()
                    print('here')
                    response = {
                             "message": 'Password Updated Successfully',
                        }
                    return JsonResponse(status=status.HTTP_200_OK,data=response)
                else:
                    """
                    USER ERRORS
                    """
                    response = {
                        "status_code": 400,
                        "success": False,
                        "data": {},
                        "info": {"message": {"error": "Incorrect Old Password"}},
                    }

            else:
                """
                SERIALIZER ERRORS
                """
                response = {
                    "status_code": 400,
                    "success": False,
                    "data": {},
                    "info": {"message": payload.errors},
                }
        except Exception as e:
            """
            EXCEPTION
            """
            print(f"Exception : {e}")
            response = {
                "status_code": 500,
                "success": False,
                "data": {},
                "info": {"message": {"error": f"Exception : {e}"}},
            }

        return JsonResponse(status=response.pop("status_code"), data=response)
