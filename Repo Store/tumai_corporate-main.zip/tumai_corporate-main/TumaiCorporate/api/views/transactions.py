from operator import truediv
from django.http.response import JsonResponse
from rest_framework.views import APIView
from rest_framework import status,generics
from services.transaction.TransactionService import TransactionsService
from transactions.models import Transactions
from transactions.serializers import TransactionSerializer,TransactionViewSerializer
from rest_framework.permissions import IsAuthenticated

from api.responses.ApiResponse import ApiResponse


"""
    POST TRANSACTION
"""

class PostTransactionsView(APIView):
    permission_classes = (IsAuthenticated,)
    
    def post(self, request, *args, **kwargs):
        try:
            validated_data = TransactionSerializer(data=request.data)
            if validated_data.is_valid():
                user = request.user
                processing_type = request.data.get('processing_type')
                if processing_type == 'bulk':
                    csv_data = request.FILES['data_csv']
                    print(type(csv_data))
                else:
                     csv_data = None 
                service = TransactionsService(validated_data.data,user, csv_data)
                return service.process()
            else:
                """
                SERIALIZER ERRORS
                """
                print("SERIALIZER ERRORS : ", validated_data.errors)
                response = ApiResponse(False, {"errors": validated_data.errors})
                return JsonResponse(status=status.HTTP_406_NOT_ACCEPTABLE, data=response.map())
                
        except Exception as e:
            """
            EXCEPTION
            """
            print(f"Exception : {e}")
            return JsonResponse(data={"message": "Verification Failed"}, status=status.HTTP_400_BAD_REQUEST)
    
class TransactionInfoView(generics.ListAPIView):
    permission_classes = (IsAuthenticated,)
    serializer_class = TransactionViewSerializer
    model = Transactions

    def get_queryset(self,**kwargs):
        return Transactions.objects.filter(user=self.user)
    
    def get(self, request, *args, **kwargs):
        self.user = request.user
        return self.list(request, *args, **kwargs)
    
    def list(self, request, *args, **kwargs):
        queryset = self.filter_queryset(self.get_queryset())

        page = self.paginate_queryset(queryset)
        if page is not None:
            serializer = self.get_serializer(page, many=True)
            payload = {"transactions": serializer.data,}
            return self.get_paginated_response(payload)

        serializer = self.get_serializer(queryset, many=True)
        payload = {"transactions": serializer.data,}
        return JsonResponse(status=status.HTTP_200_OK, data=payload)


class FilterByReference(generics.ListAPIView):
    permission_classes = (IsAuthenticated,)
    serializer_class = TransactionViewSerializer
    model = Transactions

    
    def get(self, request, *args, **kwargs):
        payload = self.model.objects.filter(user=request.user, vendor_reference=kwargs.get("vendor_reference"))
        serializer = self.serializer_class(data=payload, many=True)
        serializer.is_valid()
        return JsonResponse(status=status.HTTP_200_OK, data=serializer.data[0] if serializer.data else {})












