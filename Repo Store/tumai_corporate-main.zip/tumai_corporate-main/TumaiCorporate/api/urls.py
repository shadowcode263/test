from django.urls import path
from rest_framework_simplejwt import views as jwt_views
from api.views.transactions import FilterByReference, PostTransactionsView, TransactionInfoView

from api.views.users import (
    CorporateAdd,
    UserChangePasswordView,
    UserDetailView
)


urlpatterns = [
    # Corporate Crud Endpoints
    path('corporate/add/', CorporateAdd.as_view(), name='corporate_add'),
    path('transactions/post/',PostTransactionsView.as_view(), name='post_transaction'),
    path('user/info/',UserDetailView.as_view(),name="user_view"),
    path('password/change/',UserChangePasswordView.as_view(),name="password_change"),
    path('transactions/info/',TransactionInfoView.as_view(),name="transactions_view"),
    path('transaction/<str:vendor_reference>/',FilterByReference.as_view(),name="transaction_filter_by_reference")
    
]

