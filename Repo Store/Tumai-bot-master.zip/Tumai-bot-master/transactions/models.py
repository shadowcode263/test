import uuid
import datetime

from django.db import models

from services.utils.Utils import Utils
from users.models import SystemUser

"""
    TRANSACTIONS
"""


class Transactions(models.Model):
    ID = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    transaction_type = models.CharField(max_length=255)
    amount = models.FloatField()
    status = models.BooleanField(null=True)
    narration = models.CharField(max_length=255)
    currency = models.CharField(max_length=255, default="")
    email = models.EmailField(null=True,blank=True)
    upstream_response_message = models.CharField(max_length=255)
    vendor_reference = models.CharField(max_length=255, unique=True)
    user = models.ForeignKey(
        SystemUser, on_delete=models.PROTECT, null=True
    )
    extras = models.JSONField(null=True, blank=True)
    date_created = models.DateTimeField(auto_now_add=True)
    last_updated = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f'{self.vendor_reference} - {self.transaction_type}'

    def save(self, *args, **kwargs):
        self.last_updated = datetime.datetime.today()
        super().save(*args, **kwargs)

    class Meta:
        ordering = ['-date_created']
        verbose_name = 'Transactions'
        verbose_name_plural = 'Transactions'

    @classmethod
    def filter_transaction_by_reference(cls, reference):
        return cls.objects.filter(vendor_reference=reference).first()

    @classmethod
    def post(cls, transaction_type, amount, narration,
             merchant_reference, merchant, extras):
        if cls.filter_by_merchant_reference(merchant_reference):
            return False, Utils.get_messages()['403_Duplicate_Reference']
        else:
            transaction = cls.objects.create(
                status=False, extras=extras, transaction_type=transaction_type,
                amount=amount, narration=narration, merchant_reference=merchant_reference,
                merchant=merchant
            )
            return True, transaction

    def update_status(self, status):
        self.status = status
        self.save()

    def update_response(self, reference, status, narration, response_msg):
        self.system_reference = reference
        self.narration = narration
        self.upstream_response_message = response_msg
        self.status = status
        self.save()

    @classmethod
    def generate_reference(cls):
        return f"{datetime.datetime.today().strftime('%d%m%y.%H:%M:%S')}.{cls.objects.count() + 1}"


class SubTransactions(models.Model):
    ID = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    amount = models.FloatField()
    status = models.BooleanField(null=True)
    narration = models.CharField(max_length=255)
    currency = models.CharField(max_length=255, default="")
    upstream_response_message = models.CharField(max_length=255)
    vendor_reference = models.CharField(max_length=255, unique=True)
    transaction = models.ForeignKey(
        Transactions, on_delete=models.PROTECT, null=True
    )
    date_created = models.DateTimeField(auto_now_add=True)
    last_updated = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f'{self.vendor_reference} '

    def save(self, *args, **kwargs):
        self.last_updated = datetime.datetime.today()
        super().save(*args, **kwargs)

    class Meta:
        ordering = ['-date_created']
        verbose_name = 'SubTransactions'
        verbose_name_plural = 'SubTransactions'

    @classmethod
    def filter_sub_transaction_by_reference(cls, reference):
        return cls.objects.filter(vendor_reference=reference).first()
    
    @classmethod
    def filter_sub_transaction_by_transaction(cls, transactions):
        return cls.objects.filter(transaction=transactions).first()

    @classmethod
    def post(cls, amount, narration,
             merchant_reference, merchant):
        if cls.filter_by_merchant_reference(merchant_reference):
            return False, Utils.get_messages()['403_Duplicate_Reference']
        else:
            transaction = cls.objects.create(
                status=False,
                amount=amount, narration=narration, merchant_reference=merchant_reference,
                merchant=merchant
            )
            return True, transaction

    def update_status(self, status):
        self.status = status
        self.save()

    def update_response(self, reference, status, narration, response_msg):
        self.system_reference = reference
        self.narration = narration
        self.upstream_response_message = response_msg
        self.status = status
        self.save()

    @classmethod
    def generate_reference(cls):
        return f"{datetime.datetime.today().strftime('%d%m%y.%H:%M:%S')}.{cls.objects.count() + 1}"


class TransactionRecord(models.Model):
    ID = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    transaction_type = models.CharField(max_length=255, blank=True, null = True)
    biller_id = models.CharField(max_length=255, blank=True, null = True)
    country = models.CharField(max_length=255, blank=True, null = True)
    provider = models.CharField(max_length=255, blank=True, null = True)
    airtime_type = models.CharField(max_length=255, blank=True, null = True)
    payment_type = models.CharField(max_length=255, blank=True, null = True)
    amount = models.FloatField(blank=True, null = True)
    status = models.CharField(max_length=255, blank=True, null = True,default="Initiated")
    currency = models.CharField(max_length=255, blank=True, null = True)
    account_number = models.CharField(max_length=255, blank=True, null = True)
    full_name = models.CharField(max_length=255, blank=True, null = True)
    addons = models.CharField(max_length=255, blank=True, null = True)
    bouquets = models.CharField(max_length=255, blank=True, null = True)
    policy_number = models.CharField(max_length=255, blank=True, null = True)
    country_code = models.CharField(max_length=255, blank=True, null = True)
    transaction_type = models.CharField(max_length=255, blank=True, null = True)
    conversion_rate = models.FloatField(blank=True, null = True)
    base_currency = models.CharField(max_length=255, blank=True, null = True)
    selected_currency = models.CharField(max_length=255, blank=True, null = True)
    to_currency = models.CharField(max_length=255, blank=True, null = True)
    academic_semester = models.CharField(max_length=255, blank=True, null = True)
    purpose = models.CharField(max_length=255, blank=True, null = True)
    registration_number = models.CharField(max_length=255, blank=True, null = True)
    package = models.CharField(max_length=255, blank=True, null = True)
    narration = models.CharField(max_length=255,blank=True, null = True)
    upstream_reference = models.CharField(max_length=255, blank=True, null = True)
    phone_number = models.CharField(max_length=255, blank=True, null = True)
    email = models.EmailField(null=True,blank=True)
    upstream_response_message = models.CharField(max_length=255)
    vendor_reference = models.CharField(max_length=255, blank=True, null = True)
    customer_extra_details1 = models.CharField(max_length=255, blank=True, null = True)
    customer_extra_details2 = models.CharField(max_length=255, blank=True, null = True)
    customer_extra_details3 = models.CharField(max_length=255, blank=True, null = True)
    customer_extra_details4 = models.CharField(max_length=255, blank=True, null = True)
    user = models.ForeignKey(
        SystemUser, on_delete=models.PROTECT, null=True
    )
    extras = models.JSONField(null=True, blank=True)
    transaction_confirmation = models.CharField(max_length=255, blank=True, null = True)
    transaction = models.ForeignKey(
        Transactions, on_delete=models.PROTECT, null=True
    )
    stage = models.CharField(max_length=255, blank=True, null = True)
    position = models.CharField(max_length=255, blank=True , null = True)
    date_created = models.DateTimeField(auto_now_add=True)
    last_updated = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f'{self.user} - {self.transaction_type}'
    
    def save(self, *args, **kwargs):
        self.last_updated = datetime.datetime.today()
        super().save(*args, **kwargs)
        