import json
from datetime import datetime

import django_filters
import pytz
from django.conf import settings
from django.db.models import Q
from django.utils.timezone import make_aware

from .models import Transactions


class TransactionFilter(django_filters.FilterSet):
    class Meta:
        model = Transactions
        fields = ['date_created', 'transaction_type', 'amount', 'status']


class CustomFilter(django_filters.FilterSet):
    q = django_filters.CharFilter(method='custom_filter')

    class Meta:
        model = Transactions
        fields = ['q']

    @staticmethod
    def custom_filter(query_data=None):
        reverse = lambda data: make_aware(datetime.strptime(data, "%m/%d/%Y"), pytz.timezone(settings.TIME_ZONE))
        date = query_data.get('date_range').split('-') if query_data.get('date_range') else None
        try:
            q_set = {
                'amount': Q(amount=query_data.get('amount')) if query_data.get('amount') else None,
                'transaction_type': Q(
                    transaction_type=query_data.get('transaction_type')) if query_data.get('transaction_type') else None,
                'status': Q(status=True if query_data.get('status') == 'Success' else None if query_data.get(
                    'status') == 'Unknown' else False) if query_data.get('status') else None,
                'start_date': Q(date_created__gte=reverse(date[0].strip())) if date else None,
                'end_date': Q(date_created__lte=reverse(date[-1].strip())) if date else None
            }
        except (KeyError, AttributeError, ValueError):
            q_set = {}
        query = None
        for item in q_set.values():
            if item:
                if not query:
                    query = item
                else:
                    query &= item
        return Transactions.objects.filter(query, user=query_data['user']) if query else []
