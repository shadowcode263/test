from rest_framework import serializers

from transactions.models import Transactions

"""
    TRANSACTION PAYLOAD SERIALIZER
"""
class TransactionExtrasAirtimeSerializer(serializers.Serializer):
    phoneNumber = serializers.CharField(required=True, max_length=255, label='PhoneNumber')

    def create(self, validated_data):
        return TransactionExtrasAirtimeSerializer(**validated_data)

class TransactionPayloadSerializer(serializers.Serializer):
    vendorReference = serializers.CharField(required=False, max_length=255, label='Vendor Reference')
    transactionType = serializers.CharField(required=True, max_length=20, label='Transaction Type')
    amount = serializers.FloatField(required=True, label='Amount', min_value=1)
    currency = serializers.CharField(default="ZAR")
    paymentType = serializers.CharField(default="Payfast")
    sender_email = serializers.EmailField(required=False,label='Email')
    extras = serializers.JSONField(required=False, label='Extras')

    def create(self, validated_data):
        return TransactionPayloadSerializer(**validated_data)

"""
    TRANSACTION NOTIFICATION PAYLOAD SERIALIZER
"""


class TransactionnNotificationPayloadSerializer(serializers.Serializer):
    reference = serializers.CharField(required=True, max_length=255, label='Reference')
    reason = serializers.CharField(required=True, max_length=255, label='Reason')
    message = serializers.BooleanField(required=True, label='Message')
    extras = serializers.JSONField(required=False, label='Extras')

    def create(self, validated_data):
        return TransactionnNotificationPayloadSerializer(**validated_data)
