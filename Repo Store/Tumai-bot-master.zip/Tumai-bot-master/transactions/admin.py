from django.contrib import admin
from .models import TransactionRecord, Transactions, SubTransactions


"""
    ADMIN MODEL REGISTRATION
"""


@admin.register(Transactions)
class TransactionsAdmin(admin.ModelAdmin):
    list_display = ('transaction_type', 'user', 'email', 'status', 'amount', 'last_updated')
    list_per_page = 100
    search_fields = ('narration', 'vendor_reference')
    fieldsets = (
        ('SystemUser Info',
         {'fields': ('user', 'vendor_reference')
          }),
        ('Transactions Info',
         {'fields': ( 'transaction_type', 'amount', 'email', 'status', 'narration', 'extras')
          }),
        ('Response Info',
         {'fields': ('upstream_response_message', )
          }),
    )
    list_filter = ('status',)

@admin.register(SubTransactions)    
class TransactionsAdmin(admin.ModelAdmin):
    list_display = ('transaction','status', 'amount', 'last_updated')
    list_per_page = 100
    search_fields = ('narration', 'vendor_reference')
    fieldsets = (
        ('SystemUser Info',
         {'fields': ('transaction', 'vendor_reference')
          }),
        ('Transactions Info',
         {'fields': ( 'amount','status', 'narration')
          }),
        ('Response Info',
         {'fields': ('upstream_response_message', )
          }),
    )
    list_filter = ('status',)
    
@admin.register(TransactionRecord)
class TransactionRecordAdmin(admin.ModelAdmin):
    list_display = ('transaction_type', 'country', 'email', 'status', 'amount', 'user', 'last_updated')
    list_per_page = 100
    search_fields = ('user', 'vendor_reference','transaction_type','phone_number')
    fieldsets = (
        ('SystemUser Info',
         {'fields': ('user', 'vendor_reference')
          }),
        ('Transactions Info',
         {'fields': ('transaction_type','biller_id','country','provider','airtime_type','payment_type',\
           'amount','currency','status','account_number','full_name','addons','bouquets',\
             'policy_number','country_code','conversion_rate','base_currency','selected_currency',\
               'to_currency','academic_semester','purpose','registration_number','package','narration',\
                 'upstream_reference','phone_number','email','customer_extra_details1','customer_extra_details2',\
                   'customer_extra_details3','customer_extra_details4','extras','transaction_confirmation','stage','position')
          }),
        ('Response Info',
         {'fields': ('upstream_response_message', )
          }),
    )
    list_filter = ('status',)
