"""
    TRANSACTION PAYLOAD REQUEST
"""


class TransactionPayload:
    def __init__(self, payload: dict):
        self.currency = payload.get('currency')
        self.amount = payload.get('amount')
        self.transactionType = payload.get('transactionType')
        self.extras = payload.get('extras')

    def map(self):
        return {
            'currency': self.currency,
            'amount': self.amount,
            'transactionType': self.transactionType,
            'extras': self.extras
        }

"""
    TRANSACTION NOTIFICATION PAYLOAD REQUEST
"""


class TransactionNotificationPayload:
    def __init__(self, payload: dict):
        self.reference = payload.get('reference')
        self.message = payload.get('message')
        self.reason = payload.get('reason')
        self.extras = payload.get('extras')

    def map(self):
        return {
            'reference': self.reference,
            'message': self.message,
            'reason': self.reason,
            'extras': self.extras
            
        }
