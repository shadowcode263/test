import requests
from rest_framework import serializers
from services.utils.Utils import Utils
from transactions.models import Transactions
from transactions.serializers import TransactionPayloadSerializer
from django.conf import settings
from services.bills.constants import zb_billers

# =================================================================================
#  Transaction Processing Service
# =================================================================================

class TransactionService:
    def __init__(self,transaction_type,user):
        self.transaction_type = transaction_type
        self.user = user
        
    @staticmethod
    def get_headers():
        return {"apiUsername": settings.API_USERNAME, "apiKey": settings.API_KEY}
    
    def process(self):
        if self.transaction_type == 'airtime':
            return self.process_airtime()
        
        if self.transaction_type == 'dstv':
            return self.process_dstv()
        
        if self.transaction_type == 'electricity':
            return self.process_electricity()

        if self.transaction_type.replace(" ", "") == "014":
            return self.process_nyaradzo()
           

        if self.transaction_type.strip() in zb_billers:
            return self.process_bill()
            
        if self.transaction_type == 'voucher':
            return self.process_voucher()
        
    # =================================================================================
    #  Airtime Transaction Processing Service
    # =================================================================================   
    def process_airtime(self):
        print('process airtime')
        payload = {
            "vendorReference": f'TB{Utils().get_vendor_reference(9)}{Utils().get_otp()}',
            "transactionType": self.user.extras.get("transaction_type"),
            "amount": self.user.extras.get("amount"),
            "currency": self.user.extras.get("currency"),
            "sender_email": self.user.email,
            "paymentType": self.user.extras.get("payment_method"),
            "extras": {
                "phoneNumber": self.user.extras.get("phone_number"),
            }
        }
        # validating transaction serializer
        serializer_class = TransactionPayloadSerializer(data=payload)
        if serializer_class.is_valid():
            print("valid")
            bpa_integration_url = settings.BPA_INTEGRATION_URL
            transaction = Transactions.objects.create(
                vendor_reference=serializer_class.data["vendorReference"],
                amount=serializer_class.data["amount"],
                transaction_type=serializer_class.data["transactionType"],
                currency=serializer_class.data["currency"],
                email=serializer_class.data.get("sender_email"),
                extras=serializer_class.data.get("extras"),
            )
            transaction.save()
            # posting transaction to Payment
            path = "transaction/post/"
            payment_response = requests.post(
                url=bpa_integration_url + path,
                json=serializer_class.data,
                headers=self.get_headers(),
            )
            print(
                    {
                        "status": payment_response.status_code,
                        "response": payment_response.json(),
                        "transaction": str(transaction.ID)
                        
                    }
                )
            # Getting Payment URL from Gateway
            if payment_response.status_code == 200:
                return {
                    "status": True,
                    "url":payment_response.json().get('data').get("paymentUrl"),
                    "transaction": str(transaction.ID)
                }
            else:
                return {
                    "status": False,
                    "url":None,
                    "transaction": str(transaction.ID)
                }
            
                
    # =================================================================================
    #  Electricity Transaction Processing Service
    # =================================================================================   
    def process_electricity(self):
        print('process electricty')
        payload = {
            "vendorReference": f'TB{Utils().get_vendor_reference(9)}{Utils().get_otp()}',
            "transactionType": '005',
            "amount": self.user.extras.get("amount"),
            "currency": self.user.extras.get("currency"),
            "sender_email": self.user.email,
            "paymentType": self.user.extras.get("payment_method"),
            "extras": {
                "accountNumber": self.user.extras.get("accountNumber"),
                "fullName": self.user.extras.get("fullName"),
                "billerId": 'ZETDC',
                "phoneNumber": self.user.phone_number,
            }
        }
        # validating transaction serializer
        serializer_class = TransactionPayloadSerializer(data=payload)
        if serializer_class.is_valid():
            print("valid")
            bpa_integration_url = settings.BPA_INTEGRATION_URL
            transaction = Transactions.objects.create(
                vendor_reference=serializer_class.data["vendorReference"],
                amount=serializer_class.data["amount"],
                transaction_type=serializer_class.data["transactionType"],
                currency=serializer_class.data["currency"],
                email=serializer_class.data.get("sender_email"),
                extras=serializer_class.data.get("extras"),
            )
            transaction.save()
            # posting transaction to Payment
            path = "transaction/post/"
            payment_response = requests.post(
                url=bpa_integration_url + path,
                json=serializer_class.data,
                headers=self.get_headers(),
            )
            print(
                    {
                        "status": payment_response.status_code,
                        "response": payment_response.json(),
                    }
                )
            # Getting Payment URL from Gateway
            if payment_response.status_code == 200:
                return {
                    "status": True,
                    "url":payment_response.json().get('data').get("paymentUrl")
                }
            else:
                return {
                    "status": False,
                    "url":None
                }

    # =================================================================================
    #  Airtime Transaction Processing Service
    # =================================================================================   
    def process_dstv(self):
        print('process dstv')
        payload = {
            "vendorReference": f'TB{Utils().get_vendor_reference(9)}{Utils().get_otp()}',
            "transactionType": "006",
            "amount": self.user.extras.get("amount"),
            "currency": self.user.extras.get("currency"),
            "sender_email": self.user.email,
            "paymentType": self.user.extras.get("payment_method"),
            "extras": {
                "phoneNumber": self.user.extras.get("phone_number"),
                "bouquet": self.user.extras.get("bouquet"),
                "currency": self.user.extras.get("currency"),
                "addons": self.user.extras.get("addon"),
                "accountNumber": self.user.extras.get("account_number"),
                "fullName": self.user.extras.get("cutsomer_name"),
                "billerId": "DSTV",
            }
        }
        # validating transaction serializer
        serializer_class = TransactionPayloadSerializer(data=payload)
        if serializer_class.is_valid():
            print("valid")
            bpa_integration_url = settings.TUMAI_URL
            transaction = Transactions.objects.create(
                vendor_reference=serializer_class.data["vendorReference"],
                amount=serializer_class.data["amount"],
                transaction_type=serializer_class.data["transactionType"],
                currency=serializer_class.data["currency"],
                email=serializer_class.data.get("sender_email"),
                extras=serializer_class.data.get("extras"),
            )
            transaction.save()
            # posting transaction to Payment

            path = "transaction/post/"
            payment_response = requests.post(
                url=bpa_integration_url + path,
                json=serializer_class.data,
                headers=self.get_headers(),
            )
            print(
                    {
                        "status": payment_response.status_code,
                        "response": payment_response.json(),
                    }
                )

            if payment_response.status_code == 200:
                return {
                    "status": True,
                    "url":payment_response.json().get("data").get("paymentUrl")
                }
            
            else:
                return {
                    "status": False,
                    "url":None
                }
            
     # =================================================================================
    
    #  Bill Transaction Processing Service
    # =================================================================================   
    def process_bill(self):
        print('process bill')
        payload = {
            "vendorReference": f'TB{Utils().get_vendor_reference(9)}{Utils().get_otp()}',
            "transactionType": '007',
            "amount": self.user.extras.get("amount"),
            "currency": self.user.extras.get("currency"),
            "sender_email": self.user.email,
            "paymentType": self.user.extras.get("payment_method"),
            "extras": {
                "accountNumber": self.user.extras.get("accountNumber"),
                "fullName": self.user.extras.get("fullName"),
                "billerId": self.user.extras.get("transaction_type"),
                "phoneNumber": self.user.phone_number,
            }
        }
        # validating transaction serializer
        serializer_class = TransactionPayloadSerializer(data=payload)
        if serializer_class.is_valid():
            print("valid")
            bpa_integration_url = settings.BPA_INTEGRATION_URL
            transaction = Transactions.objects.create(
                vendor_reference=serializer_class.data["vendorReference"],
                amount=serializer_class.data["amount"],
                transaction_type=serializer_class.data["transactionType"],
                currency=serializer_class.data["currency"],
                email=serializer_class.data.get("sender_email"),
                extras=serializer_class.data.get("extras"),
            )
            transaction.save()
            # posting transaction to Payment
            path = "transaction/post/"
            payment_response = requests.post(
                url=bpa_integration_url + path,
                json=serializer_class.data,
                headers=self.get_headers(),
            )
            print(
                    {
                        "status": payment_response.status_code,
                        "response": payment_response.json(),
                    }
                )
            # Getting Payment URL from Gateway
            if payment_response.status_code == 200:
                return {
                    "status": True,
                    "url":payment_response.json().get('data').get("paymentUrl")
                }
            else:
                return {
                    "status": False,
                    "url":None
                }

    def process_voucher(self):
        print('process voucher')
        payload = {
            "vendorReference": f'TB{Utils().get_vendor_reference(9)}{Utils().get_otp()}',
            "transactionType": '016',
            "amount": self.user.extras.get("amount"),
            "currency": self.user.extras.get("currency"),
            "sender_email": self.user.email,
            "paymentType": self.user.extras.get("payment_method"),
            "extras": {
                "recepient_phone_number": self.user.extras.get("phone_number"),
                "recepient_national_id":self.user.extras.get("national_id"),
                "recepient_first_name": self.user.extras.get("first_name"),
                "recepient_last_name": self.user.extras.get("last_name")
            }
        }
    
        # validating transaction serializer
        serializer_class = TransactionPayloadSerializer(data=payload)
        if serializer_class.is_valid():
            print("valid")
            bpa_integration_url = settings.BPA_INTEGRATION_URL
            transaction = Transactions.objects.create(
                vendor_reference=serializer_class.data["vendorReference"],
                amount=serializer_class.data["amount"],
                transaction_type=serializer_class.data["transactionType"],
                currency=serializer_class.data["currency"],
                email=serializer_class.data.get("sender_email"),
                extras=serializer_class.data.get("extras"),
            )
            transaction.save()
            # posting transaction to Payment
            path = "transaction/post/"
            payment_response = requests.post(
                url=bpa_integration_url + path,
                json=serializer_class.data,
                headers=self.get_headers(),
            )
            print(
                    {
                        "status": payment_response.status_code,
                        "response": payment_response.json(),
                    }
                )
            # Getting Payment URL from Gateway
            if payment_response.status_code == 200:
                return {
                    "status": True,
                    "url":payment_response.json().get('data').get("paymentUrl")
                }
            else:
                return {
                    "status": False,
                    "url":None
                }

def process_nyaradzo(self):
        print('process nyaradzo')
        payload = {
            "vendorReference": f'TB{Utils().get_vendor_reference(9)}{Utils().get_otp()}',
            "transactionType": '007',
            "amount": self.user.extras.get("amount"),
            "currency": self.user.extras.get("currency"),
            "sender_email": self.user.email,
            "paymentType": self.user.extras.get("payment_method"),
            "extras": {
                "accountNumber": self.user.extras.get("account_number"),
                "sourceReference": self.user.extras.get("customer_extras").get("sourceReference"),
                "monthlyPremium": self.user.extras.get("customer_extras").get("monthlyPremium"),
                "numberOfMonths": self.user.extras.get("customer_extras").get("numberOfMonths"),
                "billerId": "014",
                "phoneNumber": self.user.phone_number,
            }
        }
        # validating transaction serializer
        serializer_class = TransactionPayloadSerializer(data=payload)
        if serializer_class.is_valid():
            print("valid")
            bpa_integration_url = settings.BPA_INTEGRATION_URL
            transaction = Transactions.objects.create(
                vendor_reference=serializer_class.data["vendorReference"],
                amount=serializer_class.data["amount"],
                transaction_type=serializer_class.data["transactionType"],
                currency=serializer_class.data["currency"],
                email=serializer_class.data.get("sender_email"),
                extras=serializer_class.data.get("extras"),
            )
            transaction.save()
            # posting transaction to Payment
            path = "transaction/post/"
            payment_response = requests.post(
                url=bpa_integration_url + path,
                json=serializer_class.data,
                headers=self.get_headers(),
            )
            print(
                    {
                        "status": payment_response.status_code,
                        "response": payment_response.json(),
                    }
                )
            # Getting Payment URL from Gateway
            if payment_response.status_code == 200:
                return {
                    "status": True,
                    "url":payment_response.json().get('data').get("paymentUrl")
                }
            else:
                return {
                    "status": False,
                    "url":None
                }