from django.conf import settings
import requests
from services.utils.logger import Logger

"""
    TRANSACTION PAYMENT PROCESSOR
    AFTER PAYFAST DEDUCTION
"""


class TransactionProcessingService:

    def __init__(self, payload: dict, transaction: object):
        self.payload = payload
        self.transaction = transaction
        self.senderId = 'TumaiBot'
        # BPA configs
        self.api_username = settings.BPA_USERNAME
        self.api_key = settings.BPA_KEY
        self.url = settings.BPA_URL
        # SMS configs
        self.sms_username = settings.SMS_USERNAME
        self.sms_key = settings.SMS_KEY
        self.sms_url = settings.SMS_URL

    def get_headers(self):
        return {
            'apiUsername': self.api_username,
            'apiKey': self.api_key
        }


    def send_sms(self, message: str, recipients: str):
        # sms payload
        payload = {
            'message': message,
            'recipients': [recipients],
            'senderId': self.senderId
        }
        """send sms to client"""
        sms_response = requests.post(url=self.sms_url, json=payload, headers=self.get_sms_headers())
        """Logger"""
        Logger.output('SMS Response',
                      {'statusCode': sms_response.status_code, 'body': sms_response.json()})
        
    def process(self):
        # send to bpa
        bpa_response = requests.post(self.url + 'transactions/post/',
                                    json=self.payload, headers=self.get_headers())

        """BPA Response Logger"""
        Logger.output('BPA Response',
                    {'statusCode': bpa_response.status_code, 'body': bpa_response.json()})

        """ Update Transaction Upstream Data"""
        self.transaction.update_response(
            bpa_response.json()['message']['response']['reference'],
            bpa_response.json()['successful'],
            bpa_response.json()['message']['response']['narration'],
            bpa_response.json()['message']['response']['narration']
        )

        """ Broadcast SMS """
        # ZESA MSG
        if (self.payment.payload.get('transactionType') == '005') and bpa_response.json()['successful']:
            # msg details
            zesa_token = bpa_response.json()['message']['response']['narration']["Token"]
            sender = 'Tumai'
            meter_number = self.payment.payload.get('extras').get('accountNumber')

            # send token msg
            self.send_sms(f"You have received ZETDC Token  {zesa_token}  From {sender} for meter number {meter_number}",
                        self.payment.payload.get('extras').get('phoneNumber'))