
available_countries_list = [
            {"position": 1, "name": "Zimbabwe", "country_code": "Zimbabwe"},
        ]

available_countries_message = """Select country below
 
1. Zimbabwe 🇿🇼"""

get_voucher_billers = """Select a biller below\n
1. N Richards"""

transaction_confirmation = """*Please Confirm The Details Below*

*Transaction Type :* {0}
*Recipient Phone Number :* {1}
*Recipient Name :* {2} {3}
*Recipient Id Number :* {4}
*Amount :* ${5} {6}
*Payment Method :* {7}

Type *Yes* To Confirm and *No* to Cancel"""
