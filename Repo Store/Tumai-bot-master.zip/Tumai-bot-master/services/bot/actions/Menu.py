from services.utils.Utils import Utils
from services.whatsApp.WhatsApp import WhatsApp

"""
    MENU DISPLAY
"""


class Menu:

    def __init__(self, phone_number: str, chat_name: str):
        self.phone_number = phone_number
        self.chat_name = chat_name

    """
        display menu
    """
    def show_menu(self):
        whatsapp = WhatsApp(self.phone_number, Utils.get_menu(self.chat_name))
        return whatsapp.send_captioned_message()
