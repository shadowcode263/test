from services.utils.Utils import Utils
from services.whatsApp.WhatsApp import WhatsApp
"""
    Registration
"""


class Register:

    def __init__(self, user: str, chat_name: None, message: None):
        self.phone_number = user.phone_number
        self.chat_name = chat_name
        self.user = user
        self.message = message


    """
        display registration
    """
    def show_registration(self):
        whatsapp = WhatsApp(self.phone_number, Utils.get_registration(self.chat_name))
        return whatsapp.send_message()
    
    def process(self):
        if self.user.position == 0:
            self.user.set_name(self.message)
            whatsapp = WhatsApp(self.phone_number, Utils.get_email(self.user.full_name)) 
            self.user.set_position(1)
            return whatsapp.send_message()
        
        # if self.user.position == 1:
        #     self.user.set_email(self.message)
        #     whatsapp = WhatsApp(self.phone_number, Utils.get_id_number())
        #     self.user.set_position(2)
        #     return whatsapp.send_message()
        
        # if self.user.position == 2:
        #     self.user.set_id_number(self.message)
        #     whatsapp = WhatsApp(self.phone_number, Utils.get_address())
        #     self.user.set_position(3)
        #     return whatsapp.send_message()
        
        if self.user.position == 1:
            self.user.set_email(self.message)
            self.user.is_registered = True
            self.user.save()
            self.user.reset_to_menu()
            self.user.extras = {}
            self.user.save()
            whatsapp = WhatsApp(self.phone_number, Utils.get_registration_complete(self.user))
            self.user.set_position(2)
            return whatsapp.send_message()
        
            
