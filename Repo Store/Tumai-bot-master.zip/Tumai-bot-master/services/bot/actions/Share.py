from services.utils.Utils import Utils
from services.whatsApp.WhatsApp import WhatsApp

"""
    SHARING 
"""


class Share:

    def __init__(self, phone_number: str):
        self.phone_number = phone_number

    def process(self):
        # instructions
        instructions = WhatsApp(self.phone_number, Utils.get_message()['instructions'])
        instructions.send_message()
        # link
        link = WhatsApp(self.phone_number, Utils.get_message()['share_message'])
        link.send_message()
        # menu instruction
        menu = WhatsApp(self.phone_number,  Utils.get_message()['menu'])
        return menu.send_message()
