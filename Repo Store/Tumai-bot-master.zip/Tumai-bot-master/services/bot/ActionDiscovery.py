from services.airtime.Airtime import Airtime
from services.bills.Bill import Bill
from services.data.Data import Data
from services.voucher.Voucher import Voucher
from services.bot.actions.Menu import Menu
from services.bot.actions.Registration import Register
from services.bot.actions.Share import Share
from services.dstv.Dstv import DTSV
from services.electricity.Electricity import Electricity
from services.utils.Utils import Utils
from services.whatsApp.WhatsApp import WhatsApp
from transactions.models import TransactionRecord
from users.models import SystemUser

from services.utils.logger import Logger

import os.path
from os import path

"""
    CHECK FOR USER ACTIONS 
"""


class ActionDiscovery:
    def __init__(
        self, phone_number: str, message: object, chat_name: str, message_type
    ):
        self.phone_number = phone_number
        self.message = message
        self.type = message_type
        self.chat_name = chat_name

    def discover(self):
        user = SystemUser.get_or_create(self.phone_number)

        print("message sent")
        print(self.message)

        if self.phone_number == "263719810157":
            pass
        else:
            if user.is_registered:
                if self.message.lower() in Utils.get_message()["greetings"]:
                    user.reset_to_menu()
                    user.extras = {}
                    user.save()
                    menu = Menu(self.phone_number, self.chat_name)
                    return menu.show_menu()
                # Option 1
                elif user.stage == 'menu':
                    try:
                        record = TransactionRecord.objects.create(user=user)
                        user.set_record(str(record.ID))  
                    except Exception as e:
                        print(e)
                    if self.message == "1":
                        user.set_position(0)
                        user.set_stage('airtime')
                        service = Airtime(self.phone_number, self.message, user)
                        return service.show_countries()
                    
                    elif self.message == "2":
                        user.set_position(0)
                        user.set_stage('electricity')
                        service =Electricity(self.phone_number, self.message, user)
                        return service.show_countries()
                    
                    elif self.message == "3":
                        user.set_position(0)
                        user.set_stage('voucher')
                        service =Voucher(self.phone_number, self.message, user)
                        return service.show_countries()

                    elif self.message == "4":
                        user.set_position(0)
                        user.set_stage("dstv")
                        service = DTSV(self.phone_number, self.message, user)
                        return service.show_countries()

                    elif self.message == "5":
                        user.set_position(0)
                        user.set_stage('bill')
                        service =Bill(self.phone_number, self.message, user)
                        return service.show_countries()
                    
                    elif self.message in ['6','7']:
                        whatsapp = WhatsApp(
                            self.phone_number, Utils.get_coming_soon() + Utils.get_message()['menu']
                        )
                        return whatsapp.send_message()
                    
                    else:
                        whatsapp = WhatsApp(
                            self.phone_number, Utils.get_message()["invalid_option"]
                        )
                        return whatsapp.send_message()

                elif user.stage == 'airtime':
                    service = Airtime(self.phone_number, self.message, user)
                    service.process()
                
                elif user.stage == 'electricity':
                    service = Electricity(self.phone_number, self.message, user)
                    service.process()
                
                elif user.stage == "dstv":
                    service = DTSV(self.phone_number, self.message, user)
                    service.process()

                elif user.stage == 'bill':
                    service = Bill(self.phone_number, self.message, user)
                    service.process()
                    
                elif user.stage == 'voucher':
                    service = Voucher(self.phone_number, self.message, user)
                    service.process()
                
                elif user.stage == 'data':
                    service = Data(self.phone_number, self.message, user)
                    service.process()
                
                else:
                    # invalid option
                    whatsapp = WhatsApp(
                        self.phone_number, Utils.get_message()["invalid_option"]
                    )
                    return whatsapp.send_message()
            else:
                if user.stage == 'registration':
                    register = Register(user, self.chat_name, self.message)
                    return register.process()
                else:
                    registration = Register(user, self.chat_name, self.message)
                    user.set_stage('registration')
                    user.set_position(0)
                    return registration.show_registration() 
                     
