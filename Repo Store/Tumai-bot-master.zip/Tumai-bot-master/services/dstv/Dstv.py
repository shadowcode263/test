from services.transactions.Transaction import TransactionService
from transactions.models import Transactions
import requests
from services.utils.Utils import Utils
from services.whatsApp.WhatsApp import WhatsApp
from users.models import SystemUser
from services.bot.actions.Menu import Menu

"""
    Airtime CLASS
"""


class DTSV:
    def __init__(self, phone_number: str, message: str, user):
        self.phone_number = phone_number
        self.message = message
        self.user = user
        self.countries = Utils.get_countries()

    def show_countries(self):
        countries = """Select country below

1. Zimbabwe 🇿🇼"""

        whatsapp = WhatsApp(self.phone_number, countries  + Utils.get_message()['menu'])
        return whatsapp.send_message()

    def get_boquet(self):
        url = "https://www.tests.voucher.tumai.to/api/v1/services/"
        response = requests.get(url)
        data = response.json()
        additional_data = data["data"]["SERVICES"]["006"]["additional_data"]["BOUQUETS"]

        bouquet_text = """Select bouquet below\n"""
        counter = 1
        bouquet = []
        bouquet_code = []
        bouquet_amount = []
        for dstv_bouquet in additional_data:
            bouquets = {
                "name": dstv_bouquet["productName"],
                "code": dstv_bouquet["productId"],
                "amount": dstv_bouquet["cost"],
            }
            bouquet.append(f"{counter}. {bouquets['name']} ➡️ $USD{bouquets['amount']} \n")
            bouquet_code.append(f"{counter}.{bouquets['code']} \n")
            bouquet_amount.append(bouquets["amount"])
            counter = counter + 1

        self.user.save_bouquet(bouquet)
        self.user.save_bouquet_code(bouquet_code)
        self.user.save_bouquet_amount(bouquet_amount)

        dstv_bouquet_list = "".join(bouquet)
        whatsapp = WhatsApp(self.phone_number, f"{bouquet_text}{dstv_bouquet_list}" + Utils.get_message()['menu'])
        return whatsapp.send_message()

    def get_addon(self):
        url = "https://www.tests.voucher.tumai.to/api/v1/services/"
        response = requests.get(url)
        data = response.json()
        additional_data = data["data"]["SERVICES"]["006"]["additional_data"]["ADDONS"]

        addon_text = """Select addon below\n"""
        counter = 1
        addon = []
        addon_code = []
        addon_amount = []
        for dstv_bouquet in additional_data:
            addons = {
                "name": dstv_bouquet["ADDONNAME"],
                "code": dstv_bouquet["ADDONID"],
                "amount": dstv_bouquet["COST"],
            }
            addon.append(f"{counter}. {addons['name']} ➡️ $USD{addons['amount']} \n")
            addon_code.append(f"{counter}. {addons['code']} \n")
            addon_amount.append(addons["amount"])
            counter = counter + 1

        self.user.save_addon(addon)
        self.user.save_addon_code(addon_code)
        self.user.save_addon_amount(addon_amount)

        dstv_addon_list = "".join(addon)
        whatsapp = WhatsApp(self.phone_number, f"{addon_text}{dstv_addon_list}"  + Utils.get_message()['menu'])
        return whatsapp.send_message()

    # ====================================================================================
    # Handle Dstv Positions
    # ====================================================================================
    def process(self):
        # ============================================================================
        # GET COUNTRY SELECTED BY USER
        # REQUEST DSTV account number
        # ============================================================================
        if self.user.position == 0:
            for country in self.countries:
                if self.message == str(country["position"]):
                    self.user.save_country(country["country_code"])

                    message = "Enter your DTSV account number"

                    whatsapp = WhatsApp(self.phone_number, message  + Utils.get_message()['menu'])

                    self.user.set_position(1)
                    return whatsapp.send_message()

        # ==============================================================================
        #   Get Account Number and verify account
        # ==============================================================================
        elif self.user.position == 1:
            url = "https://www.tests.voucher.tumai.to/api/v1/verify/account/"
            payload = {"billerId": "DSTV", "accountNumber": self.message}
            headers = {"Content-Type": "application/json"}
            response = requests.request("POST", url, headers=headers, json=payload)

            if response:
                self.user.set_position(2)
                dstv_response = response.json()["data"]
                self.user.save_account_number(self.message)
                self.user.save_customer_name(dstv_response["customerName"])

                message = f"*Please Confirm The Details Below*\n*Account Number :* {self.message}\n*Account Name :* {dstv_response['customerName']}\n\nType *Yes* To Confirm and *No* to Cancel"

            else:
                message = f"*😒Failed to verify the account number that you entered*\n\n Please enter the correct account number to continue"

            whatsapp = WhatsApp(self.phone_number, message  + Utils.get_message()['menu'])

            return whatsapp.send_message()

        # ===============================================================================
        #  Get User Account Confirmation
        # ===============================================================================
        elif self.user.position == 2:
            if self.message.lower() == "yes":
                self.user.set_position(3)
                self.get_boquet()

            if self.message.lower() == "no":
                message = "Enter your DTSV account number"

                whatsapp = WhatsApp(self.phone_number, message  + Utils.get_message()['menu'])
                self.user.set_position(1)
                return whatsapp.send_message()

        elif self.user.position == 3:
            bouquets = self.user.extras.get("bouquet_code")
            amount = self.user.extras.get("bouquet_amount")

            if int(self.message):
                selected = bouquets[int(self.message) - 1]

                selected_method = selected.split(".")[1]

                bouquet = selected_method.replace("\n", "")
                self.user.save_bouquet(bouquet)
                self.user.save_bouquet_code("")

                selected_amount = amount[int(self.message) - 1]

                self.user.save_bouquet_amount(selected_amount)

                self.user.set_position(4)
                self.get_addon()

        # =================================================================================
        # SAVE ADDON
        #
        # REQUEST SELECT CURRENCY
        # =================================================================================
        elif self.user.position == 4:
            addons = self.user.extras.get("addon_code")
            amount = self.user.extras.get("addon_amount")

            self.user.save_phone_number(self.phone_number)

            selected_addons = self.message.split(",")

            addon_list = []
            addon_amount = []

            print(selected_addons)
            for list_addon in selected_addons:

                if int(list_addon):
                    selected = addons[int(list_addon) - 1]

                    selected = selected.split(". ")[1]
                    addon = selected.replace("\n", "")
                    addon = addon.replace(" ", "")
                    addon_list.append(addon)

                    selected_amount = amount[int(list_addon) - 1]

                    addon_amount.append(selected_amount)

            self.user.save_addon(" | ".join(addon_list))
            self.user.save_addon_code("")
            self.user.save_addon_amount(sum(addon_amount))

            rates = Utils.get_rates()
            currencies = [
                f"{counter+1}. {rate['from_currency'].upper()}\n"
                for rate, counter in zip(rates, range(0, len(rates)))
            ]
            self.user.save_rates(currencies)

            currencies = "".join(currencies)
            message = f"Select currency below:\n{currencies}"

            whatsapp = WhatsApp(self.phone_number, message  + Utils.get_message()['menu'])

            self.user.set_position(5)
            return whatsapp.send_message()
        # =================================================================================
        #  SELECT PAYMENT METHOD
        # =================================================================================
        elif self.user.position == 5:
            currency = self.user.extras.get("currency")
            if int(self.message):
                print(self.message)
                selected = currency[int(self.message) - 1]
                selected_currency = selected.split(". ")

                currency_selected = selected_currency[1].replace("\n", "")

                self.user.save_rates(currency_selected)

                addon_amount = self.user.extras.get("addon_amount")
                bouquet_amount = self.user.extras.get("bouquet_amount")
                
                usd_amount = addon_amount + bouquet_amount

                total_amount = usd_amount
                if self.user.extras.get("currency") == "zar":
                    total_amount = usd_amount
                self.user.save_amount(total_amount)
                payment_methods = Utils.get_payment_methods(
                    self.user.extras.get("currency")
                )
                self.user.save_payment_method(payment_methods)

                payment_methods = "".join(payment_methods)
                message = f"""Select payment method below: 
    {payment_methods}"""

                whatsapp = WhatsApp(self.phone_number, message  + Utils.get_message()['menu'])
                self.user.set_position(6)
                return whatsapp.send_message()

        # =================================================================================
        #  Confirmation of Transaction Details
        # =================================================================================
        elif self.user.position == 6:
            payment_methods = self.user.extras.get("payment_method")
            if int(self.message):
                selected = payment_methods[int(self.message) - 1]
                selected_method = selected.split(". ")

                payment_method = selected_method[1].replace("\n", "")

                self.user.save_payment_method(payment_method)
                message = f"""*Please Confirm The Details Below*

*Biller :* DSTV
*Bouquet :* {self.user.extras.get('bouquet')}
*Addon :* {self.user.extras.get('addon')}
*Amount :* ${self.user.extras.get('currency')} {self.user.extras.get('amount')}
*Payment Method :* {self.user.extras.get('payment_method')}

Type *Yes* To Confirm and *No* to Cancel"""

                whatsapp = WhatsApp(
                    self.phone_number, message + Utils.get_message()["menu"]
                )

                self.user.set_position(7)
                return whatsapp.send_message()

        # =================================================================================
        #  Send Transaction for Processing
        # =================================================================================

        elif self.user.position == 7:
            if self.message.lower() == "yes":
                self.user.save_confirmation(self.message)
                service = TransactionService(transaction_type="dstv", user=self.user)
                transaction = service.process()
                print(transaction)
                if transaction["status"]:
                    message = f"""Thank You For Transacting on Tumai, 
Your Payment Link is: {transaction['url']}"""
                else:
                    message = "*Transaction Failed*"
                whatsapp = WhatsApp(
                    self.phone_number, message + Utils.get_message()["menu"]
                )
                # self.user.set_position(7)
                return whatsapp.send_message()
            if self.message.lower() == "no":
                self.user.reset_to_menu()
                self.user.extras = {}
                self.user.save()
                menu = Menu(self.phone_number, self.phone_number)
                return menu.show_menu()

        else:
            whatsapp = WhatsApp(
                self.phone_number, Utils.get_message()["invalid_option"]
            )
            return whatsapp.send_message()
