import requests

from services.bills.constants import (
    available_countries_list,
    available_countries_message,
    transaction_confirmation,
)
from services.bot.actions.Menu import Menu
from services.transactions.Transaction import TransactionService
from services.utils.Utils import Utils
from services.whatsApp.WhatsApp import WhatsApp

"""
    Bill CLASS
"""


class Bill:
    def __init__(self, phone_number: str, message: str, user):
        self.phone_number = phone_number
        self.message = message
        self.user = user
        self.countries = available_countries_list

    def show_countries(self):
        whatsapp = WhatsApp(self.phone_number, available_countries_message  + Utils.get_message()['menu'])
        return whatsapp.send_message()

    def show_billers(self):
        url = "https://www.tests.voucher.tumai.to/api/v1/services/"
        response = requests.get(url)
        data = response.json()
        additional_data = data["data"]["SERVICES"]["007"]["additional_data"]["Billers"]

        biller_text = """*Select a biller below*\n"""
        counter = 1
        billers = []
        biller_code = []
        for biller in additional_data:
            if biller["country"] == self.user.extras.get("country"):
                name = {
                    "name": biller["name"],
                    "code": biller["code"],
                }
                billers.append(f"{counter}. {name['name'].upper()} \n")
                biller_code.append(f"{counter}. {name['code']} \n")
                counter = counter + 1

        biller_list = "".join(billers)
        self.user.save_service_provider(billers)
        self.user.save_transaction_type(biller_code)

        whatsapp = WhatsApp(
            self.phone_number, f"{biller_text}{biller_list}"  + Utils.get_message()['menu']
        )
        return whatsapp.send_message()

    def get_telco_packages(self):
        extras = self.user.exras.get("customer_extras")
        print("extras: ", extras)
        whatsapp = WhatsApp(
                        self.phone_number, ""
                    )
        # self.user.set_position(7)
        return whatsapp.send_message()
    # ====================================================================================
    # Handle Airtime Positions
    # ====================================================================================
    def process(self):
        # ============================================================================
        # GET COUNTRY SELECTED BY USER
        # ============================================================================
        if self.user.position == 0:
            for country in self.countries:
                if self.message == str(country["position"]):
                    self.user.save_country(country["country_code"])
                    self.user.set_position(1)
                    return self.show_billers()
                else:
                    whatsapp = WhatsApp(
                        self.phone_number, Utils.get_message()["invalid_option"]
                    )
                return whatsapp.send_message()

        # SAVE BILLER AND REQUEST account number
        # ============================================================================
        if self.user.position == 1:
            billers = self.user.extras.get("service_provider")
            biller_codes = self.user.extras.get("transaction_type")
            if int(self.message):
                biller = billers[int(self.message) - 1]
                selected = biller.split(". ")
                selected_biller = selected[1].replace("\n", "")

                self.user.save_service_provider(selected_biller)
                Utils.save_response(
                    self.user.extras.get("record"), "provider", selected_biller
                )
                transaction_type = biller_codes[int(self.message) - 1]
                selected_transaction_type = transaction_type.split(". ")
                trans_type = selected_transaction_type[1].replace("\n", "")
                self.user.save_transaction_type(trans_type)
                Utils.save_response(
                    self.user.extras.get("record"), "transaction_type", trans_type
                )

                whatsapp = WhatsApp(
                    self.phone_number,
                    Utils.get_account_number() + Utils.get_message()["menu"],
                )

                self.user.set_position(2)
                return whatsapp.send_message()
            else:
                whatsapp = WhatsApp(
                    self.phone_number, Utils.get_message()["invalid_option"]
                )
            return whatsapp.send_message()
        # ==============================================================================
        #   Get Account Number and verify account
        # ==============================================================================
        elif self.user.position == 2:
            url = "https://www.tests.voucher.tumai.to/api/v1/verify/account/"
            payload = {
                "billerId": self.user.extras.get("transaction_type"),
                "accountNumber": self.message,
            }   
            headers = {"Content-Type": "application/json"}
            response = requests.request("POST", url, headers=headers, json=payload)
            print(response.status_code)
            print(response.json())
            if response:
                self.user.set_position(3)
                verification_response = response.json()["data"]
                self.user.save_account_number(self.message)
                self.user.save_customer_name(verification_response["customerName"])
                self.user.save_customer_extras(
                    verification_response["customerExtraDetails"]
                )

                message = f"*Please Confirm The Details Below*\n*Account Number :* {self.message}\n*Account Name :* {verification_response['customerName']}\n\nType *Yes* To Confirm and *No* to Cancel"

            else:
                message = f"*😒Failed to verify the account number that you entered*\n\n Please enter the correct account number to continue"

            whatsapp = WhatsApp(self.phone_number, message  + Utils.get_message()['menu'])

            return whatsapp.send_message()

        # ===============================================================================
        #  Saving Confirmation and Resetting if details are not correct
        #  Request for Currency
        # ===============================================================================
        if self.user.position == 3:
            if self.message.lower() == "no":
                self.user.extras.pop("fullName")
                self.user.extras.pop("accountNumber")
                whatsapp = WhatsApp(
                    self.phone_number,
                    Utils.get_account_number() + Utils.get_message()["menu"],
                )
                self.user.set_position(2)
                return whatsapp.send_message()

            elif self.message.lower() == "yes":
                rates = Utils.get_rates()
                currencies = [
                    f"{counter+1}. {rate['from_currency'].upper()}\n"
                    for rate, counter in zip(rates, range(0, len(rates)))
                ]
                self.user.save_rates(currencies)

                currencies = "".join(currencies)
                message = f"""Select currency below:\n\n{currencies}"""

                whatsapp = WhatsApp(self.phone_number, message  + Utils.get_message()['menu'])

                self.user.set_position(4)
                return whatsapp.send_message()
            else:
                whatsapp = WhatsApp(
                    self.phone_number, Utils.get_message()["invalid_option"]
                )
            return whatsapp.send_message()

        # =================================================================================
        #  SAVE SELECTED CURRENCY
        #
        #  REQUEST AMOUNT
        # =================================================================================
        if self.user.position == 4:
            currency = self.user.extras.get("currency")

            if int(self.message):
                selected = currency[int(self.message) - 1]
                selected_currency = selected.split(". ")

                currency_selected = selected_currency[1].replace("\n", "")

                self.user.save_rates(currency_selected)

                whatsapp = WhatsApp(
                    self.phone_number, Utils.get_amount() + Utils.get_message()["menu"]
                )
                self.user.set_position(5)
                return whatsapp.send_message()
            else:
                whatsapp = WhatsApp(
                    self.phone_number, Utils.get_message()["invalid_option"]
                )
            return whatsapp.send_message()

        # =================================================================================
        #  SELECT PAYMENT METHOD
        # =================================================================================
        if self.user.position == 5:
            self.user.save_amount(self.message)
            payment_methods = Utils.get_payment_methods(
                self.user.extras.get("currency")
            )

            self.user.save_payment_method(payment_methods)

            payment_methods = "".join(payment_methods)
            message = f"""Select payment method below:\n\n{payment_methods}"""

            whatsapp = WhatsApp(self.phone_number, message  + Utils.get_message()['menu'])
            self.user.set_position(6)
            return whatsapp.send_message()

        # =================================================================================
        #  Confirmation of Transaction Details
        # =================================================================================
        if self.user.position == 6:
            payment_methods = self.user.extras.get("payment_method")
            if int(self.message):
                selected = payment_methods[int(self.message) - 1]
                selected_method = selected.split(". ")

                payment_method = selected_method[1].replace("\n", "")

                self.user.save_payment_method(payment_method)
                message = transaction_confirmation.format(
                    self.user.extras.get("service_provider"),
                    self.user.extras.get("customer_name"),
                    self.user.extras.get("account_number"),
                    self.user.extras.get("currency"),
                    self.user.extras.get("amount"),
                    self.user.extras.get("payment_method"),
                )

                whatsapp = WhatsApp(
                    self.phone_number, message + Utils.get_message()["menu"]
                )

                self.user.set_position(7)
                return whatsapp.send_message()
            else:
                whatsapp = WhatsApp(
                    self.phone_number, Utils.get_message()["invalid_option"]
                )
            return whatsapp.send_message()

        # =================================================================================
        #  Send Transaction for Processing
        # =================================================================================

        if self.user.position == 7:
            if self.message.lower() == "yes":
                self.user.save_confirmation(self.message)
                if self.user.extras.get("transaction_type") == "013":
                    self.get_telco_packages()
                else:
                    service = TransactionService(
                        transaction_type=self.user.extras.get("transaction_type"),
                        user=self.user,
                    )
                    transaction = service.process()
                    print("transaction", transaction)
                    if transaction["status"]:
                        message = f"Thank You For Transacting on Tumai,\n\n Your Payment Link is: {transaction['url']}"
                    else:
                        message = "*Transaction Failed*"
                    whatsapp = WhatsApp(
                        self.phone_number, message + Utils.get_message()["menu"]
                    )
                    self.user.set_position(7)
                    return whatsapp.send_message()
            elif self.message.lower() == "no":
                self.user.reset_to_menu()
                self.user.extras = {}
                self.user.save()
                menu = Menu(self.phone_number, self.phone_number)
                return menu.show_menu()

            else:
                whatsapp = WhatsApp(
                    self.phone_number, Utils.get_message()["invalid_option"]
                )
            return whatsapp.send_message()
