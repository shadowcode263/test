
available_countries_list = [
            {"position": 1, "name": "Zimbabwe", "country_code": "Zimbabwe"},
        ]

zb_billers = ['COH','EDGARS','RUWA','TOPICS','CIMAS','MASVINGO','MEIKLES','CHINHOYI','KADOMA','TRUWORTH']

available_countries_message = """Select country below
 
1. Zimbabwe"""


transaction_confirmation = """*Please Confirm The Details Below*

*Transaction Type :* {0}
*Account Name :* {1}
*Account Number :* {2}
*Amount :* ${3} {4}
*Payment Method :* {5}

Type *Yes* To Confirm and *No* to Cancel"""
