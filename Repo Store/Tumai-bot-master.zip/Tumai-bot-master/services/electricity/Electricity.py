from services.transactions.Transaction import TransactionService
from transactions.models import Transactions
import requests
from services.utils.Utils import Utils
from services.whatsApp.WhatsApp import WhatsApp
from users.models import SystemUser
from services.bot.actions.Menu import Menu
from services.electricity.constants import available_countries_list, available_countries_message, validation_confirmation, \
    transaction_confirmation,validation_failure
"""
    Electricity CLASS
"""


class Electricity:
    def __init__(self, phone_number: str, message: str, user):
        self.phone_number = phone_number
        self.message = message
        self.user = user
        self.countries = available_countries_list

    def show_countries(self):
        whatsapp = WhatsApp(self.phone_number, available_countries_message  + Utils.get_message()['menu'])
        return whatsapp.send_message()

    # ====================================================================================
    # Handle Electricity Positions
    # ====================================================================================
    def process(self):
        # ============================================================================
        # GET COUNTRY SELECTED BY USER
        # ============================================================================
        if self.user.position == 0:
            for country in self.countries:
                if self.message == str(country["position"]):
                    self.user.save_country(country["country_code"])
                    whatsapp = WhatsApp(
                        self.phone_number,
                        Utils.get_account_number() + Utils.get_message()["menu"],
                    )
                    self.user.set_position(1)
                    return whatsapp.send_message()

        # ==============================================================================
        #   Get Account Number
        # ==============================================================================
        if self.user.position == 1:
            # Verify Account Number
            url = "https://www.tests.voucher.tumai.to/api/v1/verify/account/"
            payload={
                "billerId": "ZETDC",
                "accountNumber": self.message
            }
            headers = {
            'Content-Type': 'application/json'
            }
            response = requests.request("POST", url, headers=headers, json=payload)
            if response.status_code == 200:
                verify_response = response.json()["data"]
                message = validation_confirmation.format(self.message,
                                                          verify_response["customerName"]
                                                          )
                self.user.save_account_number(self.message)
                self.user.save_account_name(verify_response["customerName"])
                self.user.set_position(2)
            else:
                message = validation_failure

            whatsapp = WhatsApp(self.phone_number, message  + Utils().get_message()["menu"])
            return whatsapp.send_message()

        # ===============================================================================
        #  Saving Confirmation and Resetting if details are not correct
        #  Request for Currency
        # ===============================================================================
        if self.user.position == 2:
            if self.message.lower() == "no":
                self.user.extras.pop('fullName')
                self.user.extras.pop('accountNumber')
                whatsapp = WhatsApp(
                        self.phone_number,
                        Utils.get_account_number() + Utils.get_message()["menu"],
                    )
                self.user.set_position(1)
                return whatsapp.send_message()
                
            else:
                rates = Utils.get_rates()
                currencies = [
                    f"{counter+1}. {rate['from_currency'].upper()}\n"
                    for rate, counter in zip(rates, range(0, len(rates)))
                ]
                self.user.save_rates(currencies)

                currencies = "".join(currencies)
                message = f"""Select currency below:\n\n{currencies}"""

                whatsapp = WhatsApp(self.phone_number, message  + Utils.get_message()['menu'])

                self.user.set_position(3)
                return whatsapp.send_message()

        # =================================================================================
        #  SAVE SELECTED CURRENCY
        #
        #  REQUEST AMOUNT
        # =================================================================================
        if self.user.position == 3:
            currency = self.user.extras.get("currency")

            if int(self.message):
                selected = currency[int(self.message) - 1]
                selected_currency = selected.split(". ")

                currency_selected = selected_currency[1].replace("\n", "")

                self.user.save_rates(currency_selected)

                whatsapp = WhatsApp(
                    self.phone_number, Utils.get_amount() + Utils.get_message()["menu"]
                )
                self.user.set_position(4)
                return whatsapp.send_message()

        # =================================================================================
        #  SELECT PAYMENT METHOD
        # =================================================================================
        if self.user.position == 4:
            self.user.save_amount(self.message)
            payment_methods = Utils.get_payment_methods(
                self.user.extras.get("currency")
            )

            self.user.save_payment_method(payment_methods)

            payment_methods = "".join(payment_methods)
            message = f"""Select payment method below:\n\n{payment_methods}"""

            whatsapp = WhatsApp(self.phone_number, message  + Utils.get_message()['menu'])
            self.user.set_position(5)
            return whatsapp.send_message()
        # =================================================================================
        #  Confirmation of Transaction Details
        # =================================================================================
        if self.user.position == 5:
            payment_methods = self.user.extras.get('payment_method')
            if int(self.message):
                selected = payment_methods[int(self.message) - 1]
                selected_method = selected.split(". ")

                payment_method = selected_method[1].replace("\n", "")

                self.user.save_payment_method(payment_method)
                message = transaction_confirmation.format(self.user.extras.get("customer_name"),
                                                          self.user.extras.get('account_number'),
                                                          self.user.extras.get('currency'),
                                                          self.user.extras.get('amount'),
                                                          self.user.extras.get('payment_method')
                                                          )

                whatsapp = WhatsApp(
                    self.phone_number, message + Utils.get_message()["menu"]
                )

                self.user.set_position(6)
                return whatsapp.send_message()
            
        # =================================================================================
        #  Send Transaction for Processing
        # =================================================================================
            
        if self.user.position == 6:
            if self.message.lower() == 'yes':
                print('yes')
                self.user.save_confirmation(self.message)
                service = TransactionService(transaction_type='electricity', user=self.user)
                transaction = service.process()
                if transaction['status']:
                    message = f"Thank You For Transacting on Tumai,\n\n Your Payment Link is: {transaction['url']}"
                else:
                    message = "*Transaction Failed*"
                whatsapp = WhatsApp(
                self.phone_number, message + Utils.get_message()["menu"]
                )
                self.user.set_position(7)
                return whatsapp.send_message()
            if self.message == 'No':
                self.user.reset_to_menu()
                self.user.extras = {}
                self.user.save()
                menu = Menu(self.phone_number, self.phone_number)
                return menu.show_menu()
   