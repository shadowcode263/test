
available_countries_list = [
            {"position": 1, "name": "Zimbabwe", "country_code": "Zimbabwe"},
        ]

available_countries_message = """Select country below
 
1. Zimbabwe 🇿🇼"""


transaction_confirmation = """*Please Confirm The Details Below*

*Transaction Type :* ZETDC
*Account Name :* {0}
*Account Number :* {1}
*Amount :* ${2} {3}
*Payment Method :* {4}

Type *Yes* To Confirm and *No* to Cancel"""

validation_confirmation =  """Please Confirm The Details Below

Account Number : {0}
Account Name : {1}

Type Yes To Confirm and No to Cancel"""

validation_failure = """*😒Failed to verify the account number that you entered*,

Please enter the correct Account Number to continue"""