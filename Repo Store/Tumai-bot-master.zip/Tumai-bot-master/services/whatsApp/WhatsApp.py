from django.conf import settings
import requests

from services.utils.logger import Logger

"""
    WHATSAPP MESSAGE BROADCASTING
"""


class WhatsApp:

    def __init__(self, phone_number: str, message: str):
        self.phone_number = phone_number
        self.message = message
        self.image_url = settings.GREETING_MESSAGE_PICTURE_URL
        self.token = settings.CHAT_API_TOKEN
        self.instance = settings.CHAT_API_INSTANCE

    """
        plain message
    """

    def send_message(self):
        payload = {
            "phone": self.phone_number,
            "body": self.message
        }
        url = f" https://api.chat-api.com/instance388483/sendMessage?token=mugowpwjx0b2ydoo"
        response = requests.post(url=url, data=payload)
        """
            logger
        """
        from pprint import pprint
        pprint(self.message)
        # Logger.output("Whatsapp Response ",
        #               {'code': response.status_code, 'phoneNumber': self.phone_number, 'message': self.message})

    """
        message with image
    """

    def send_captioned_message(self):
        payload = {
            "phone": self.phone_number,
            "body": self.image_url,
            "filename": 'promotion.png',
            "caption": self.message
        }
        url = f" https://api.chat-api.com/instance388483/sendFile?token=mugowpwjx0b2ydoo"
        response = requests.post(url=url, data=payload)
        """
            logger
        """
        Logger.output("Whatsapp Response ",
                      {'code': response.status_code, 'phoneNumber': self.phone_number, 'caption': self.message})

    """
        message with image
    """

    def send_captioned_message_pdf(self):
        payload = {
                "phone": self.phone_number,
                "body": "http://fundo.school/test/WhatsApp%20Image%202021-07-04%20at%2011.33.23.jpeg",
                "filename": "promotion.pdf",
            }
        url = f" https://api.chat-api.com/instance388483/sendFile?token=mugowpwjx0b2ydoo"
        response = requests.post(url=url, data=payload)
        """
            logger
        """
        return Logger.output(
                "Whatsapp Response ",
                {
                    "code": response.status_code,
                    "phoneNumber": self.phone_number,
                    "caption": "option 2 sent",
                },
            )
