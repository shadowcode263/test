# EMAIL REGISTATION CONSTANTS
EMAIL_TEMPLATE_TITLE_REGISTRATION = "VERIFY YOUR ACCOUNT"
EMAIL_TEMPLATE_MESSAGE_REGISTRATION = (
    "Good day, thank you for creating an account with us. Click the button below to verify your account"
)
EMAIL_TEMPLATE_BUTTON_REGISTRATION = "Verify Account"

EMAIL_TEMPLATE_TITLE_OTP = "LOGIN OTP"
EMAIL_TEMPLATE_MESSAGE_OTP = "Use this once off number to login"

EMAIL_TEMPLATE_TITLE_RESET = "PASSWORD CHANGED SUCCESSFULLY"
EMAIL_TEMPLATE_MESSAGE_RESET = "Your password has been changed successfully"
EMAIL_TEMPLATE_BUTTON_RESET = "TUMAI"

EMAIL_TEMPLATE_TITLE_FORGOT = "RESET PASSWORD"
EMAIL_TEMPLATE_MESSAGE_FORGOT = "We received a reset password request from this email. Click the button below to continue. You can ignore if it was a mistake"
EMAIL_TEMPLATE_BUTTON_FORGOT = "RESET PASSWORD"

