import json

from celery.decorators import task
from celery import shared_task
from celery.utils.log import get_task_logger

from datetime import datetime

from services.notifications.pop.GeneratePOP import GeneratePOP
from services.notifications.email import EmailAttachment, Emails
from services.notifications.sms import SMS
from services.celery.constants import (
    # EMAIL REGISTRATION
    EMAIL_TEMPLATE_TITLE_REGISTRATION,
    EMAIL_TEMPLATE_MESSAGE_REGISTRATION,
    EMAIL_TEMPLATE_BUTTON_REGISTRATION,
    EMAIL_TEMPLATE_TITLE_OTP,
    EMAIL_TEMPLATE_MESSAGE_OTP,
    EMAIL_TEMPLATE_TITLE_RESET,
    EMAIL_TEMPLATE_MESSAGE_RESET,
    EMAIL_TEMPLATE_BUTTON_RESET,
    EMAIL_TEMPLATE_TITLE_FORGOT,
    EMAIL_TEMPLATE_MESSAGE_FORGOT,
    EMAIL_TEMPLATE_BUTTON_FORGOT,
)

with open("config.json") as config_file:
    config = json.load(config_file)

logger = get_task_logger(__name__)

@task(name="send_contact_email")
def send_contact_email(enquiry_message, email_address, customer_name):

    title = "Tumai Enquiry"
    message = ""
    sender = email_address
    to = config["DEFAULT_FROM_EMAIL"]

    email = Emails(
        f"Enquiry From: {customer_name}",
        enquiry_message,
        "TUMAI",
        "",
    )
    email.send(to, message, title, sender)


@task(name="send_registration_notification")
def send_registration_notification(email_address, phone_number, user_id, host):

    title = "Tumai Registration"
    message = ""
    to = email_address
    sender = config["DEFAULT_FROM_EMAIL"]

    # Send email
    link = "http://" + host + "/verify/" + user_id + "/"
    email = Emails(
        EMAIL_TEMPLATE_TITLE_REGISTRATION,
        EMAIL_TEMPLATE_MESSAGE_REGISTRATION,
        EMAIL_TEMPLATE_BUTTON_REGISTRATION,
        link,
    )
    email.send(to, message, title, sender)

    # Send text message
    sms = SMS()
    sms.send(EMAIL_TEMPLATE_MESSAGE_REGISTRATION + ". Tumai", phone_number)


@task(name="send_user_reset_email")
def send_user_reset_email(email_address):

    title = "Tumai Reset Password"
    message = ""
    to = email_address
    sender = config["DEFAULT_FROM_EMAIL"]

    # Send email
    email = Emails(
        EMAIL_TEMPLATE_TITLE_RESET,
        EMAIL_TEMPLATE_MESSAGE_RESET,
        EMAIL_TEMPLATE_BUTTON_RESET,
        "",
    )
    email.send(to, message, title, sender)


@task(name="send_user_forgot_email")
def send_user_forgot_email(email_address, user_id, host):

    title = "Tumai Password Reset"
    message = ""
    to = email_address
    sender = config["DEFAULT_FROM_EMAIL"]

    # Send email
    link = "https/" + host + "/api/v1/public/user/reset-password/" + user_id + "/"
    email = Emails(
        EMAIL_TEMPLATE_TITLE_FORGOT,
        EMAIL_TEMPLATE_MESSAGE_FORGOT,
        EMAIL_TEMPLATE_BUTTON_FORGOT,
        link,
    )
    email.send(to, message, title, sender)


@task(name="send_transaction_notification")
def send_transaction_notification(
    email_address,
    extras,
    transaction_reference,
    transaction_type,
    transaction_amount,
    transaction_date
):
    logger.info(email_address)
    logger.info(extras["fullName"])

    dt = datetime.fromisoformat('2021-01-05T23:19:30.685658Z'[:-1])
    transaction_date = dt.strftime('%Y-%m-%d')

    create_pop = GeneratePOP()
    create_pop.create_pdf(
        extras["fullName"],
        extras["accountNumber"],
        extras["billerId"],
        extras["academicSemester"],
        transaction_amount,
        transaction_date,
        transaction_type,
        transaction_reference,
        extras["purpose"],
    )

    # # Send email
    email = EmailAttachment()
    email.send_pop_as_email(transaction_reference, email_address)


@task(name="send_login_otp")
def send_login_otp(email_address, phone_number, otp):

    title = "Tumai Login"
    message = ""
    to = email_address
    sender = config["DEFAULT_FROM_EMAIL"]

    # Send email
    email = Emails(
        EMAIL_TEMPLATE_TITLE_OTP,
        EMAIL_TEMPLATE_MESSAGE_OTP,
        otp,
        "",
    )
    email.send(to, message, title, sender)

    # Send text message
    sms = SMS()
    sms.send(otp, phone_number)
