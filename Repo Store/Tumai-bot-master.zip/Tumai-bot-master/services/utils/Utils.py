from datetime import datetime
from django.conf import settings
import pyotp
import requests
from random import randint

class Utils:

    @staticmethod
    def get_message():
        return {
            'greetings': ["menu", "how are you", "how are you doing", "Wasup", "H", "Sup", "wassap", "Hie", "hie", "Hi", "hi", "Hey", "hey", "Hello", "Ndeipi", "Wadii", "Howfar", "good day", "good morning","good evening",'morning', "evening"],
            'invalid_option': 'You have selected an invalid option.\nType in the correct response to proceed',
            'success': 'Success',
            'menu': '\n\nYou can type *Menu* at any time to go back to main menu',
            'instructions': 'Give your friends and family access to our wide range of services, easy-to-use store and more... all you have to do is forward them the message below and they\'re in!',
            'share_message': f"Hi 👋 have you heard about Tumai?, An all in one service provision platform to do bill payments, airtime purchase and grocery shopping: "
                             f"API available to integrate any of the services on your platform within or outside zimbabwe, "
                             f"all conveniently on your phone or whatsapp and even web based."
                             f"Click the following link to get started \n {settings.SHARE_CHAT_LINK} and to know more",
            'thank_you': 'Thank you for using our service, Have a great day',
            'failed': 'Failed'
        }

    @staticmethod
    def get_menu(full_name: str):
        current_time = datetime.now()
        message = f'''Welcome! {full_name}\n\nWhat would you like to do today?\n\n1️⃣ Buy Airtime\n2️⃣ Buy Electricity\n3️⃣ Buy Voucher \n4️⃣ Pay DSTV\n5️⃣ Pay Bills\n6️⃣ Pay School Fees  🔜\n7️⃣ Go to our shop 🔜\n \nYou can type *Menu* at any time to return to main menu
        '''
        return message
    
    @staticmethod
    def get_registration(full_name: str):
        current_time = datetime.now()
        message = f'''*Hey There* 🙋🏽‍♀️, *Welcome to Tumai*😃\n\nMy name is Tumi, and i will be assisting you.\n\nLet's get to know each other\n*So what can i call you?* \n
        '''
        return message
    
    @staticmethod
    def get_email(name):
        current_time = datetime.now()
        message = f'''Nice to meet you {name} 😃\n\nFor us to send you updates, promotions, transaction history we require your email address \n\n*May i please have your email address?*
        '''
        return message
    
    @staticmethod
    def get_id_number():
        current_time = datetime.now()
        message = f'''May i also have your ID Number \n
        '''
        return message
    
    @staticmethod
    def get_account_number():
        message = f'Enter Meter Number/Account Number: \n'
        return message
    
    @staticmethod
    def get_address():
        current_time = datetime.now()
        message = f'''Lastly please leave me home Address. \n
        '''
        return message
    
    @staticmethod
    def get_registration_complete(user: str):
        current_time = datetime.now()
        message = f'''Congratulations {user.full_name}, you are now able to transact on Tumai 👏👏\n\n *_Please select any of the following options to get started?_* \n\n1️⃣ Buy Airtime\n2️⃣ Buy Electricity\n3️⃣ Buy Voucher \n4️⃣ Pay DSTV\n5️⃣ Pay Bills\n6️⃣ Pay School Fees  🔜\n7️⃣ Go to our shop 🔜\n \n\nYou can type *Menu* at any time to return to main menu'''
        return message

    
    # services
    @staticmethod
    def get_airtime_providers():
        message = f'''Select Mobile Operator\n\n1️⃣ Econet Airtime\n2️⃣ Netone Airtime\n3️⃣ Telecel Airtime \n\nYou can type *Menu* at any time to return to main menu
        '''
        return message
    
    @staticmethod
    def get_coming_soon():
        message = f'''*Apologies 😒, This option is not yet available*\nStay tuned, its coming soon
        '''
        return message
    
    @staticmethod
    def get_phone_number():
        message = f'Enter Mobile Number: \n*use format 263770000000*'
        return message
    
    @staticmethod
    def get_amount():
        message = f'''Enter Amount: '''
        return message
    
    @staticmethod
    def get_payment_details():
        current_time = datetime.now()
        message = f'''Choose Payment mode\n1️⃣ Pay Now\n2️⃣ Split Payment \n\nYou can type *Menu* at any time to return to main menu'''
        return message
    
    @staticmethod
    def get_split_details(user):
        current_user = user
        current_time = datetime.now()
        message = f'''Set number of splits, \n To settle in three splits enter 3, make sure split number is less than 4 \n\nYou can type *Menu* at any time to return to main menu'''
        return message
    
    @staticmethod
    def get_amount_one(user):
        current_user = user
        current_time = datetime.now()
        message = f'''Enter first payment amount,make sure you settle {user.extras.get("amount")} \n\nYou can type *Menu* at any time to return to main menu'''
        return message
    
    @staticmethod
    def get_amount_two(user):
        current_user = user
        current_time = datetime.now()
        balance = float(user.extras.get('amount')) - float(user.extras.get("first_amount"))
        message = f'''Enter second payment amount,make sure you settle {balance} \n\nYou can type *Menu* at any time to return to main menu'''
        return message
    
    @staticmethod
    def get_amount_three(user):
        current_user = user
        current_time = datetime.now()
        balance = float(user.extras.get('amount')) - float(user.extras.get("first_amount")) - float(user.extras.get("second_amount"))
        message = f'''Enter last payment amount, make sure you settle {balance} \n\nYou can type *Menu* at any time to return to main menu'''
        return message
    
    @staticmethod
    def confirm_splits(user):
        current_user = user
        current_time = datetime.now()
        message = f''' Confirm Splits \nAmount : {user.extras.get("amount")}\nFirst : {user.extras.get("first_amount")}\nSecond : {user.extras.get("second_amount")}\nThird : {user.extras.get("third_amount")}\n  \n1️⃣ Proceed \n2️⃣ restart split \n\nYou can type *Menu* at any time to return to main menu'''
        return message
    
    @staticmethod
    def get_confirmation(user):
        current_user = user
        current_time = datetime.now()
        message = f'''Enter "tumai" to confirm purchase of airtime of amount {current_user.extras.get('amount')} to {current_user.extras.get('phone_number')} \n\nYou can type *Menu* at any time to return to main menu
        '''
        return message
    
    
    def get_payment_url(payment_url):
        try:
            current_time = datetime.now()
            message = f'''Click on the url below to make payment \n\n{links(payment_url)}\n\nYou can type *Menu* at any time to return to main menu
            '''
            return message
        except Exception as e:
            print(e)
            return " ndafoira"
    
    @staticmethod
    def get_otp():
        totp = pyotp.TOTP("base32secret3232")
        otp = totp.now()
        return otp
    
    @staticmethod
    def get_vendor_reference(n):
        """generating vendor reference
        Args:
            n: total number
        Returns:
            response: randomly generated vendor number
        """
        range_start = 10 ** (n - 1)
        range_end = (10 ** n) - 1
        return randint(range_start, range_end)

    @staticmethod
    def get_rates():
        url = "https://www.tests.voucher.tumai.to/api/v1/rates/"
        response = requests.get(url)
        rates = response.json()["data"]
        return rates

    @staticmethod
    def get_countries():
        countries = [
            {"position": 1, "name": "Zimbabwe", "country_code": "Zimbabwe"},
        ]
        return countries

    @staticmethod
    def get_payment_methods(currency):
        currency = currency.lower()
        url = f"https://www.tests.voucher.tumai.to/api/v1/payment/types/{currency}/"
        response = requests.get(url)
        payment_methods = response.json()

        payment_methods = payment_methods["data"]["payload"]
        
        payment_details = []
        counter = 1
        for payment_method in payment_methods:
            if payment_method["payment_type"] != "Wallet":
                payment_details.append(
                    f"{counter}. {payment_method['payment_type']}\n"
                )
                counter = counter + 1
        
        return payment_details

    @staticmethod
    def save_response(transaction_id,given_field, message):
        from transactions.models import TransactionRecord
        transaction = TransactionRecord.objects.get(ID=transaction_id)
        setattr(transaction,given_field,message)
        transaction.save()
        
def links(payload: dict) -> str:
    data = ""
    count = 1
    for item in payload.values():
        data += f'{count}. {item}\n'
        count += 1
    return data

    