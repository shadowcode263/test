from PyPDF2 import PdfFileWriter, PdfFileReader
import io
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter


class GeneratePOP:
    def create_pdf(
        self,
        student_name: str,
        registration_number: str,
        school_name: str,
        year: str,
        transaction_amount: str,
        transaction_date: str,
        transaction_type: str,
        transaction_reference: str,
        transaction_purpose: str,
    ):
        """Create PDF

        Args:
            student_name: student_name
            registration_number: registration_number
            school_name: school_name
            year: year
            transaction_amount: transaction_amount
            transaction_date: transaction_date
            transaction_type: transaction_type
            transaction_reference: transaction_reference
            transaction_purpose: transaction_purpose

        """
        packet = io.BytesIO()

        can = canvas.Canvas(packet, pagesize=letter)

        can.drawString(280, 551, student_name)
        can.drawString(280, 525, registration_number)
        can.drawString(280, 500, transaction_purpose)
        can.drawString(280, 476, school_name)
        can.drawString(280, 453, year)
        can.drawString(280, 427, "$" + str(transaction_amount))
        can.drawString(280, 402, transaction_date)
        can.drawString(280, 377, transaction_type)
        can.drawString(280, 355, transaction_reference)
        can.drawString(280, 330, transaction_purpose)
        can.save()

        packet.seek(0)
        new_pdf = PdfFileReader(packet)
        # getting the existing pdf file
        existing_pdf = PdfFileReader(
            open("services/notifications/pop/assets/original.pdf", "rb")
        )
        output = PdfFileWriter()

        # add our text to the pdf
        page = existing_pdf.getPage(0)
        page.mergePage(new_pdf.getPage(0))
        output.addPage(page)

        # genertate a new pdf
        outputStream = open(
            "services/notifications/pop/generated-pdf/"
            + transaction_reference
            + ".pdf",
            "wb",
        )
        output.write(outputStream)
        outputStream.close()
