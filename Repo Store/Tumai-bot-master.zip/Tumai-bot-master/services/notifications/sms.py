from django.conf import settings
import json
from urllib.request import urlopen
from urllib.parse import quote


"""
    SMS BROADCASTING
"""

with open("config.json") as config_file:
    config = json.load(config_file)


class SMS:
    def send(self, message, phone_number):
        sms_url = config["SMS_URL"]
        sms_token = config["SMS_TOKEN"]
        sms_username = config["SMS_USERNAME"]

        destinations = phone_number

        ws_str = sms_url + "&u=" + sms_username + "&h=" + sms_token + "&op=pv"
        ws_str = ws_str + "&to=" + quote(destinations) + "&msg=" + quote(message)

        http_response = urlopen(ws_str).read()
