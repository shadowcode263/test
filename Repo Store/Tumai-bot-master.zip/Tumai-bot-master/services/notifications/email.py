from django.core.mail.message import EmailMultiAlternatives, BadHeaderError
from django.template.loader import render_to_string
import json
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders

"""
    EMAIL HANDLER
"""

with open("config.json") as config_file:
    config = json.load(config_file)
class Emails:
    def __init__(
        self,
        template_title,
        template_message,
        template_btn,
        template_link,
    ):
        self.templatePath = render_to_string(
            "portal/email.html",
            {
                "template_title": template_title,
                "template_message": template_message,
                "template_btn": template_btn,
                "template_link": template_link,
            },
        )

    def send(self, to, message, title, sender):
        try:
            msg = EmailMultiAlternatives(title, message, sender, [to])
            msg.attach_alternative(self.templatePath, "text/html")
            msg.send()
            # if error occurs
        except BadHeaderError:
            return

class EmailAttachment:
    def send_pop_as_email(self, transaction_reference, email_address):
        """Send generated pdf as email

        Args:
            transaction_reference: transaction_reference


        """
        # body of the email
        body = '''
        Good day,

        Please find attached a copy of your proof of payment

        Kind regards
        Tumai
        '''
        # ============================================
        # sender email address eg a@gmail.com
        # these will be used to authenticate to gmail
        sender = config["EMAIL_HOST_USER"]
        password = config["EMAIL_HOST_PASSWORD"]
    
        # enter the reciever email address eg b@gmail.com
        receiver = email_address
        
        message = MIMEMultipart()
        message['From'] = sender
        message['To'] = receiver
        message['Subject'] = 'TUMAI PROOF OF PAYMENT'
        
        message.attach(MIMEText(body, 'plain'))
        
        # select the file you want to send
        pdfname = 'services/notifications/pop/generated-pdf/'+transaction_reference+'.pdf'

        # rewrite the name of the pdf
        pdffilename = transaction_reference+'.pdf'
        
        # prepare payload
        binary_pdf = open(pdfname, 'rb')
        
        payload = MIMEBase('application', 'pdf', Name=pdfname)
        payload.set_payload((binary_pdf).read())

        encoders.encode_base64(payload)
        
        payload.add_header('Content-Disposition', 'attachment', filename=pdffilename)
        message.attach(payload)
        
        #use gmail with port
        session = smtplib.SMTP(config["EMAIL_HOST"], config["EMAIL_PORT"])
        
        #enable security
        session.starttls()
        
        #login with mail_id and password
        session.login(sender, password)
        
        text = message.as_string()
        session.sendmail(sender, receiver, text)
        session.quit()
        print('Mail Sent')
