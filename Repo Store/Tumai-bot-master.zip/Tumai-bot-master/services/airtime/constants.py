
available_countries_list = [
            {"position": 1, "name": "Zimbabwe", "country_code": "Zimbabwe"},
            {"position": 2, "name": "Zambia", "country_code": "ZM"},
        ]

available_countries_message = """Select country below
 
1. Zimbabwe 🇿🇼
2. Zambia 🇿🇲"""

airtime_types = """Select one of the following options\n
1. Airtime
2. Data"""

transaction_confirmation = """*Please Confirm The Details Below*

*Transaction Type :* {0}
*Recipient Phone Number :* {1}
*Amount :* ${2} {3}
*Payment Method :* {4}

Type *Yes* To Confirm and *No* to Cancel"""
