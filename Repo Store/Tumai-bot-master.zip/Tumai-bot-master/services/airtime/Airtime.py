import requests

from services.airtime.constants import available_countries_list, available_countries_message, airtime_types, \
    transaction_confirmation
from services.bot.actions.Menu import Menu
from services.transactions.Transaction import TransactionService
from services.utils.Utils import Utils
from services.whatsApp.WhatsApp import WhatsApp
from transactions.models import Transactions

"""
    Airtime CLASS
"""


class Airtime:
    def __init__(self, phone_number: str, message: str, user):
        self.phone_number = phone_number
        self.message = message
        self.user = user
        self.countries = available_countries_list

    def show_countries(self):
        whatsapp = WhatsApp(self.phone_number, available_countries_message  + Utils.get_message()['menu'])
        return whatsapp.send_message()

    def show_airtime_type_options(self):
        whatsapp = WhatsApp(self.phone_number, airtime_types + Utils.get_message()['menu'])
        return whatsapp.send_message()

    def show_service_providers(self):
        url = "https://www.tests.voucher.tumai.to/api/v1/services/"
        response = requests.get(url)
        data = response.json()
        additional_data = data["data"]["SERVICES"]["00X"]["additional_data"]

        service_provider_list = """Select service provider below\n"""
        counter = 1
        provider = []
        provider_code = []
        for service_provider in additional_data:
            if service_provider["country"] == self.user.extras.get("country"):
                name = {
                    "name": service_provider["name"],
                    "code": service_provider["code"],
                }
                provider.append(f"{counter}. {name['name']} \n")
                provider_code.append(f"{counter}. {name['code']} \n")
                counter = counter + 1

        provider_list = "".join(provider)
        self.user.save_service_provider(provider)
        self.user.save_transaction_type(provider_code)

        whatsapp = WhatsApp(
            self.phone_number, f"{service_provider_list} {provider_list}"  + Utils.get_message()['menu']
        )
        return whatsapp.send_message()

    # ====================================================================================
    # Handle Airtime Positions
    # ====================================================================================
    def process(self):
        # ============================================================================
        # GET COUNTRY SELECTED BY USER
        # ============================================================================
        if self.user.position == 0:
            for country in self.countries:
                if self.message == str(country["position"]):
                    self.user.save_country(country["country_code"])
                    Utils.save_response(self.user.extras.get('record'),'country',country["country_code"])
                    self.user.set_position(1)
                    return self.show_airtime_type_options()
                
                else:
                    whatsapp = WhatsApp(
                    self.phone_number, Utils.get_message()["invalid_option"]
                    )
                    return whatsapp.send_message()

        # ==============================================================================
        #   Get Service Providers
        # ==============================================================================
        elif self.user.position == 1:
            # Get Airtime
            if self.message == "1":
                self.user.set_position(2)
                return self.show_service_providers()

            # Get Data
            elif self.message == "2":
                self.user.set_position(0)
                self.user.set_stage("data")
                return self.show_service_providers()
            
            else:
                whatsapp = WhatsApp(
                self.phone_number, Utils.get_message()["invalid_option"]
                )
                return whatsapp.send_message()

        # ===============================================================================
        #  Saving Selected Service Provider
        # ===============================================================================
        elif self.user.position == 2:
            service_providers = self.user.extras.get("service_provider")
            transaction_types = self.user.extras.get("transaction_type")

            if int(self.message):
                service_provider = service_providers[int(self.message) - 1]
                selected = service_provider.split(". ")
                selected_service_provider = selected[1].replace("\n", "")

                self.user.save_service_provider(selected_service_provider)
                Utils.save_response(self.user.extras.get('record'),'provider',selected_service_provider)
                transaction_type = transaction_types[int(self.message) - 1]
                selected_transaction_type = transaction_type.split(". ")
                trans_type = selected_transaction_type[1].replace("\n", "")
                self.user.save_transaction_type(trans_type)
                Utils.save_response(self.user.extras.get('record'),'transaction_type',trans_type)

                whatsapp = WhatsApp(
                    self.phone_number,
                    Utils.get_phone_number() + Utils.get_message()["menu"],
                )
                self.user.set_position(3)
                return whatsapp.send_message()
            
            else:
                whatsapp = WhatsApp(
                self.phone_number, Utils.get_message()["invalid_option"]
                )
                return whatsapp.send_message()

        # =================================================================================
        # SAVE USER PHONE NUMBER
        #
        # REQUEST SELECT CURRENCY
        # =================================================================================
        elif self.user.position == 3:

            self.user.save_phone_number(self.message)
            Utils.save_response(self.user.extras.get('record'),'phone_number',self.message)
            rates = Utils.get_rates()
            currencies = [
                f"{counter + 1}. {rate['from_currency'].upper()}\n"
                for rate, counter in zip(rates, range(0, len(rates)))
            ]
            self.user.save_rates(currencies)

            currencies = "".join(currencies)
            message = f"Select currency below:\n\n{currencies}"

            whatsapp = WhatsApp(self.phone_number, message  + Utils.get_message()['menu'])

            self.user.set_position(4)
            return whatsapp.send_message()

        # =================================================================================
        #  SAVE SELECTED CURRENCY
        #
        #  REQUEST AMOUNT
        # =================================================================================
        elif self.user.position == 4:
            currency = self.user.extras.get("currency")

            if int(self.message):
                selected = currency[int(self.message) - 1]
                selected_currency = selected.split(". ")

                currency_selected = selected_currency[1].replace("\n", "")

                self.user.save_rates(currency_selected)
                Utils.save_response(self.user.extras.get('record'),'selected_currency',currency_selected)

                whatsapp = WhatsApp(
                    self.phone_number, Utils.get_amount() + Utils.get_message()["menu"]
                )
                self.user.set_position(5)
                return whatsapp.send_message()
            else:
                whatsapp = WhatsApp(
                self.phone_number, Utils.get_message()["invalid_option"]
                )
                return whatsapp.send_message()

        # =================================================================================
        #  SELECT PAYMENT METHOD
        # =================================================================================
        elif self.user.position == 5:
            self.user.save_amount(self.message)
            Utils.save_response(self.user.extras.get('record'),'amount',self.message)
            payment_methods = Utils.get_payment_methods(
                self.user.extras.get("currency")
            )
            print(">>>", payment_methods)

            self.user.save_payment_method(payment_methods)

            payment_methods = "".join(payment_methods)
            message = f"Select payment method below: \n\n{payment_methods}"

            whatsapp = WhatsApp(self.phone_number, message  + Utils.get_message()['menu'])
            self.user.set_position(6)
            return whatsapp.send_message()
        # =================================================================================
        #  Confirmation of Transaction Details
        # =================================================================================
        elif self.user.position == 6:
            payment_methods = self.user.extras.get('payment_method')
            if int(self.message):
                selected = payment_methods[int(self.message) - 1]
                selected_method = selected.split(". ")

                payment_method = selected_method[1].replace("\n", "")

                self.user.save_payment_method(payment_method)
                Utils.save_response(self.user.extras.get('record'),'payment_type',payment_method)
                message = transaction_confirmation.format(self.user.extras.get('service_provider'),
                                                          self.user.extras.get('phone_number'),
                                                          self.user.extras.get('currency'),
                                                          self.user.extras.get('amount'),
                                                          self.user.extras.get('payment_method')
                                                          )

                whatsapp = WhatsApp(
                    self.phone_number, message + Utils.get_message()["menu"]
                )
                self.user.set_position(7)
                return whatsapp.send_message()
            else:
                whatsapp = WhatsApp(
                self.phone_number, Utils.get_message()["invalid_option"]
                )
                return whatsapp.send_message()

        # =================================================================================
        #  Send Transaction for Processing
        # =================================================================================

        elif self.user.position == 7:
            if self.message.lower() == 'yes':
                self.user.save_confirmation(self.message)
                Utils.save_response(self.user.extras.get('record'),'transaction_confirmation',self.message)
                service = TransactionService(transaction_type='airtime', user=self.user)
                print('tyring to send')
                transaction = service.process()
                print(transaction)
                if transaction['status']:
                    Utils.save_response(self.user.extras.get('record'),'status','Actioned')
                    Utils.save_response(self.user.extras.get('record'),'transaction',Transactions.objects.  get(ID=transaction['transaction']))
                    Utils.save_response(self.user.extras.get('record'),'narration',transaction['url'])
                    message = f"Thank You For Transacting on Tumai,\n\n Your Payment Link is: {transaction['url']}"
                else:
                    Utils.save_response(self.user.extras.get('record'),'status','Failed')
                    Utils.save_response(self.user.extras.get('record'),'transaction',Transactions.objects.get(ID=transaction['transaction']))
                    message = "*Transaction Failed*"
                whatsapp = WhatsApp(
                    self.phone_number, message + Utils.get_message()["menu"]
                )
                self.user.set_position(7)
                return whatsapp.send_message()
            elif self.message.lower() == 'no':
                Utils.save_response(self.user.extras.get('record'),'transaction_confirmation',self.message)
                Utils.save_response(self.user.extras.get('record'),'status','Cancelled')
                self.user.reset_to_menu()
                self.user.extras = {}
                self.user.save()
                menu = Menu(self.phone_number, self.phone_number)
                return menu.show_menu()
            else:
                whatsapp = WhatsApp(
                self.phone_number, Utils.get_message()["invalid_option"]
                )
                return whatsapp.send_message()
        else:
            whatsapp = WhatsApp(
                self.phone_number, Utils.get_message()["invalid_option"]
            )
            return whatsapp.send_message()
