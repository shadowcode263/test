import json

from django.http.response import JsonResponse
from rest_framework.parsers import JSONParser
from rest_framework import status
from rest_framework.renderers import JSONRenderer
from rest_framework.views import APIView

from api.responses.ApiResponse import ApiResponse
from services.bot.ActionDiscovery import ActionDiscovery
from services.utils.Utils import Utils
from services.utils.logger import Logger

"""
    WHATSAPP WEBHOOK
"""


class WebHookView(APIView):
    parser_classes = [JSONParser]
    renderer_classes = [JSONRenderer]

    def post(self, request):
        try:
            payload = json.loads(request.body)

            """
                BOT MENU
            """

            service = ActionDiscovery(payload['messages'][0]['author'].split('@')[0], payload['messages'][0]['body'],
                                      payload['messages'][0]['senderName'],
                                      payload['messages'][0]['type'])
            service.discover()

            """
                WEBHOOK SUCCESS RESPONSE
            """
            response = ApiResponse(True, Utils.get_message()['success'])

            """
                LOGGER
            """
            Logger.output("New Message", {
                'phoneNumber': payload['messages'][0]['author'].split('@')[0],
                'message': payload['messages'][0]['body'],
                'senderName': payload['messages'][0]['senderName']
            })

            return JsonResponse(status=status.HTTP_200_OK, data=response.map())
        except Exception as e:
            """
                LOGGER
            """
            Logger.output("WebHook", {'exception': e})
            response = ApiResponse(True, Utils.get_message()['failed'])
            return JsonResponse(status=status.HTTP_200_OK, data=response.map())
