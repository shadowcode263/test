from rest_framework.views import APIView


"""
    POST TRANSACTION
"""


class PostTransactionsView(APIView):
    pass