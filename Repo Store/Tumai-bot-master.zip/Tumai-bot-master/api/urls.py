from django.urls import path
from django.views.decorators.csrf import csrf_exempt

from api.views.webhook.views import WebHookView

urlpatterns = [
    path("whatsapp/webhook/", csrf_exempt(WebHookView.as_view())),
]
