import datetime
import uuid

from django.contrib.auth.models import AbstractUser
from django.db import models

"""

    ADMIN USER(S) MODEL

"""


class User(AbstractUser):
    ID = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    email = models.EmailField(unique=True)
    first_name = models.CharField(max_length=255)
    last_name = models.CharField(max_length=255)

    class Meta:
        verbose_name = 'Admin User'
        verbose_name_plural = 'Admin Users'
        ordering = ['username']

    def __str__(self):
        return self.username


"""

    SYSTEM USER(S) MODEL

"""


class SystemUser(models.Model):
    ID = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    email = models.EmailField(unique=True, blank=True, null=True)
    full_name = models.CharField(max_length=255, null=True)
    phone_number = models.CharField(max_length=20)
    id_number = models.CharField(max_length=255, blank=True, null=True)
    address = models.CharField(max_length=255, blank=True, null=True)
    image = models.CharField(max_length=255, blank=True, null=True)
    is_registered = models.BooleanField(default=False)

    date_created = models.DateTimeField(auto_now_add=True)

    position = models.IntegerField(default=0)
    stage = models.CharField(max_length=20, default='menu')
    extras = models.JSONField(null=True, blank=True)

    class Meta:
        verbose_name = 'System User'
        verbose_name_plural = 'System Users'
        ordering = ['phone_number']

    def __str__(self):
        return self.phone_number

    @classmethod
    def get_user_by_uuid(cls, user_uuid: str):
        return cls.objects.filter(ID=user_uuid).first()

    @classmethod
    def get_user_by_phone_number(cls, phone_number: str):
        return cls.objects.filter(phone_number=phone_number).first()

    @classmethod
    def get_user_by_id_number(cls, id_number: str):
        return cls.objects.filter(id_number=id_number).first()

    @classmethod
    def get_user_by_email(cls, email: str):
        return cls.objects.filter(email=email).first()

    def reset_to_menu(self):
        self.stage = 'menu'
        self.position = 0
        self.save()
    
    def set_position(self, position: int):
        self.position = position
        self.save()

    def set_stage(self, stage: str):
        self.stage = stage
        self.save()    

    def set_name(self, name: int):
        self.full_name = name
        self.save()
    
    def set_email(self, email: int):
        self.email = email
        self.save()
        
    def set_id_number(self, id_number: int):
        self.id_number = id_number
        self.save()
        
    def set_address(self, address: int):
        self.address = address
        self.save()
        
    def set_extras(self, extras: int):
        self.extras = extras
        self.save()
        
    def set_record(self, record):
        self.extras['record'] = record
        self.save()

# ======================================================================
# Airtime Model service
# ======================================================================
    def save_country(self, country: str):
        self.extras['country'] = country
        self.save()

    def save_service_provider(self, service_provider: str):
        self.extras['service_provider'] = service_provider
        self.save()
    
    def save_transaction_type(self, transaction_type: str):
        self.extras['transaction_type'] = transaction_type
        self.save()
        

    def save_phone_number(self, phone_number: str):
        self.extras['phone_number'] = phone_number
        self.save()

# =====================================================================
# DSTV
# =====================================================================
    def save_bouquet(self, bouquet: str):
        self.extras['bouquet'] = bouquet
        self.save()

    def save_bouquet_code(self, bouquet_code: str):
        self.extras['bouquet_code'] = bouquet_code
        self.save()

    def save_bouquet_amount(self, bouquet_amount: str):
        self.extras['bouquet_amount'] = bouquet_amount
        self.save()

    def save_addon(self, addon: str):
        self.extras['addon'] = addon
        self.save()

    def save_addon_code(self, addon_code: str):
        self.extras['addon_code'] = addon_code
        self.save()

    def save_addon_amount(self, addon_amount: str):
        self.extras['addon_amount'] = addon_amount
        self.save()

    def save_account_number(self, account_number: str):
        self.extras['account_number'] = account_number
        self.save()

    def save_customer_name(self, customer_name: str):
        self.extras['customer_name'] = customer_name
        self.save()
        
    def save_recipient_firstname(self, first_name: str):
        self.extras['first_name'] = first_name
        self.save()
    
    def save_recipient_lastname(self, last_name: str):
        self.extras['last_name'] = last_name
        self.save()
    
    def save_recipeint_id(self, id: str):
        self.extras['national_id'] = id
        self.save()
    
    def save_customer_address(self, address: str):
        self.extras['customer_address'] = address
        self.save()

# ======================================================================
#  GENERIC
# ======================================================================
    def save_rates(self, currency: str):
        self.extras['currency'] = currency
        self.save()

    def save_amount(self, amount: str):
        self.extras['amount'] = amount
        self.save()

    def save_payment_method(self, payment_method: str):
        self.extras['payment_method'] = payment_method
        self.save()
    
    def save_confirmation(self, confirmation: str):
        self.extras['confirmation'] = confirmation
        self.save()
        
    def save_account_number(self, account: str):
        self.extras['account_number'] = account
        self.save()
        
    def save_account_name(self, account_name: str):
        self.extras['cutsomer_name'] = account_name
        self.save()

    def save_customer_extras(self, customer_extras: str):
        self.extras['customer_extras'] = customer_extras
        self.save()

    def save_data(self, status: str):
        self.extras['data_status'] = status
        self.save()

    def save_data_package(self, package: str):
        self.extras['data_package'] = package
        self.save()

    def save_data_code(self, data_code: str):
        self.extras['data_code'] = data_code
        self.save()

    def save_data_amount(self, data_amount: str):
        self.extras['data_amount'] = data_amount
        self.save()

    @classmethod
    def get_or_create(cls, phone_number: str):
        user = cls.get_user_by_phone_number(phone_number=phone_number)
        if user:
            user.last_interaction = datetime.datetime.today()
            user.save()
        else:
            user = cls.objects.create(phone_number=phone_number)
        return user
