from django.conf import settings
from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from .models import User, SystemUser


"""
    ADMIN SITE LABELS
"""


admin.site.site_header = f"{settings.PLATFORM_NAME} Super Admin"
admin.site.site_title = "Admin Portal"
admin.site.index_title = f"{settings.PLATFORM_NAME} Admin"


"""
    ADMIN MODEL REGISTRATION
"""


@admin.register(SystemUser)
class SystemUserAdmin(admin.ModelAdmin):
    list_display = ('phone_number', 'full_name', 'id_number', 'email', 'address', 'is_registered', 'image', 'date_created','extras')
    list_per_page = 100
    search_fields = ('email', 'phone_number')
    fieldsets = (
        (None, {'fields': ('phone_number',)}),
        ('Personal Info',
         {'fields': ('full_name', 'address', 'email','image', 'id_number','is_registered')
          }),
        ('Stage Info',
         {'fields': ('position', 'stage','extras')
          })
    )


@admin.register(User)
class UserAdmin(BaseUserAdmin):
    list_display = ('username', 'first_name', 'last_name', 'email')
    list_per_page = 100
    search_fields = ('email', 'username')
    fieldsets = (
        (None, {'fields': ('username',)}),
        ('Personal Info',
         {'fields': ('first_name', 'last_name', 'email')
          }),
        ('Permissions', {'fields': ('is_active', 'is_staff', 'is_superuser'),
                         }),
        ('Important Dates', {'fields': ('last_login', 'date_joined')}),
    )
    list_filter = ('date_joined', 'is_active', 'is_staff', 'is_superuser', 'is_superuser')
