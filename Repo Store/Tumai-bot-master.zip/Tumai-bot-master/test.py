import requests

url = "https://www.tests.voucher.tumai.to/api/v1/services/"
response = requests.get(url)
data = response.json()
additional_data = data["data"]["SERVICES"]["00X"]["additional_data"][0]["additional_data"]["packages"]

print(additional_data)

service_provider_list = """Select service provider below\n"""
counter = 1
data = []
data_code = []
data_amount = []
for data_package in additional_data:
    data_ = {
        "name": data_package["name"],
        "code": data_package["code"],
        "price": data_package["price"],
    }
    data.append(f"{counter}. {data_['name']} \n")
    data_code.append(f"{counter}. {data_['code']} \n")
    data_amount.append(f"{counter}. {data_['price']} \n")
    counter = counter + 1

provider_list = "".join(data)

print(provider_list)
