"""
    USER CHAT PAYLOAD
"""


class UserPayload:

    def __init__(self, phone_number: str, message: object, chat_name=None):
        self.phone_number = phone_number
        self.message = message
        self.chat_name = chat_name

    def map(self):
        return {
            'phoneNumber': self.phone_number,
            'message': self.message,
            'chat_name': self.chat_name
        }
