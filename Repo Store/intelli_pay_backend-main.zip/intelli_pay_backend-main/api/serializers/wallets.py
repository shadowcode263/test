from rest_framework import serializers
from merchant.models import MerchantProfile


def phone_number_formatter(phone_number):
    status = True
    if phone_number[0] == '0':
        phone_number = '263' + phone_number[1:]
    elif phone_number[0] == '+':
        phone_number = phone_number[1:]
    elif phone_number[0] == '7':
        phone_number = '263' + phone_number
    elif phone_number[0] == '2':
        phone_number = phone_number
    else:
        status = False    
    return status, phone_number 


class UserWalletSerializer(serializers.Serializer):
    first_name = serializers.CharField(required=True, max_length=100)
    last_name = serializers.CharField(required=True, max_length=100)
    phone_number = serializers.CharField(required=True, max_length=20)
    national_id = serializers.CharField(required=False, max_length=20)
    merchant_code = serializers.CharField(required=True)
    password = serializers.CharField(required=True, max_length=4)

    def validate(self, data):
        status, data['phone_number'] = phone_number_formatter(data['phone_number'].strip().replace(' ', ''))
        if status is False:
            raise serializers.ValidationError("Invalid phone number")
        if not MerchantProfile.get_by_merchant_code(merchant_code=data['merchant_code']):
            raise serializers.ValidationError("Merchant does not exist!")
        if not data['national_id']:
            data['national_id'] = 'XX-XXXXXXX'
        return data


class OTPSerializer(serializers.Serializer):
    pin = serializers.CharField(required=True, max_length=6)
    pin2 = serializers.CharField(required=True, max_length=6)

    def validate(self, data):
        if data['pin'] != data['pin2']:
            raise serializers.ValidationError("Pin does not match")
        return data



class VerifyOTPSerializer(serializers.Serializer):
    phone_number = serializers.CharField(required=True, max_length=20)
    otp = serializers.CharField(required=True, max_length=6)
    self_registration = serializers.BooleanField(required=False)
    amount = serializers.DecimalField(required=False, max_digits=10, decimal_places=2)

    def validate(self, data):
        if data['self_registration'] is False:
            if not data['amount']:
                raise serializers.ValidationError("Amount is required")
        return data




class PasswordSerializer(serializers.Serializer):
    password1 = serializers.CharField(required=True, max_length=50)
    password2 = serializers.CharField(required=True, max_length=50)

    def validate(self, data):
        if data['password1'] != data['password2']:
            raise serializers.ValidationError("Password1 and Password2 do not match")
        return data

class LoginSerializer(serializers.Serializer):
    username = serializers.CharField(required=True, max_length=20)
    password = serializers.CharField(required=True, max_length=4)


class LookUpSerializer(serializers.Serializer):
    phone_number = serializers.CharField(required=True, max_length=20)
    merchant_code =  serializers.CharField(required=True)

    def validate(self, data):
        if not MerchantProfile.get_by_merchant_code(merchant_code=data['merchant_code']):
            raise serializers.ValidationError("Merchant does not exist!")
        return data



class SendMoneySerializer(serializers.Serializer):
    receiver_account = serializers.CharField(required=True, max_length=20)
    amount =  serializers.JSONField(required=True)
    currency = serializers.CharField(required=True, max_length=3)
    merchant_code =  serializers.CharField(required=True)

    def validate(self, data):
        if not MerchantProfile.get_by_merchant_code(merchant_code=data['merchant_code']):
            raise serializers.ValidationError("Merchant does not exist!")
        if float(data['amount']) < 0:
            raise serializers.ValidationError("Amount cannnot be less than 0")
        data['amount'] = {
            "amount": data.pop('amount'),
            "currency": data.pop('currency')
        }   
        data['merchant'] = data.pop('merchant_code')
        
        return data

