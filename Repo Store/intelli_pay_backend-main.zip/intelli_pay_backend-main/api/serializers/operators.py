from rest_framework import serializers


class PinChangeSerializer(serializers.Serializer):
    phone_number = serializers.CharField(required=True, max_length=20)
    password =  serializers.CharField(required=True, max_length=4)



class TopUpSerializer(serializers.Serializer):
    receiver_account = serializers.CharField(required=True, max_length=20)
    amount =  serializers.JSONField(required=True)
    currency = serializers.CharField(default="USD",  max_length=3)

    def validate(self, data, *args, **kwargs):
        request = self.context.get('request')
        if float(data['amount']) < 0:
            raise serializers.ValidationError("Amount cannnot be less than 0")
        data['amount'] = {
            "amount": data.pop('amount'),
            "currency": data.pop('currency')
        } 
        data['merchant'] = request.user.merchant_code
        return data
