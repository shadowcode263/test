from merchant.serializers import UserBalanceSerializer
from rest_framework.views import APIView
from rest_framework import status, viewsets
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated
from merchant.models import MerchantProfile
from merchant.permissions import HasChangedPassword
from django.http import JsonResponse
from rest_framework.parsers import JSONParser
from api.serializers.wallets import(
    OTPSerializer, 
    PasswordSerializer, 
    UserWalletSerializer,
    LookUpSerializer,
    SendMoneySerializer,
    LoginSerializer,
    VerifyOTPSerializer
) 
import requests
from decouple import config


class UserWalletsView(viewsets.ViewSet):
    permission_classes = ()
    parser_classes = (JSONParser,)


    def serializer_errors(self, serializer):
        message = ""
        added = False
        for error in serializer.errors.keys():
            for e in serializer.errors[error]:
                if not added:
                    message =  f"{e}".replace('_', ' ').replace("This", f"{error}")
                    added = True
        return message
    
    @action(methods=['post'], detail=False, url_path='register', url_name='register')
    def user_registration(self, request, *args, **kwargs):
        serializer = UserWalletSerializer(data=request.data)
        if serializer.is_valid():
            response = requests.post(
                url=f"{config('WALLET_API_URL')}api/v1/users/", 
                json=serializer.data
            )
            print(response.content)
            if response.status_code == 201:
                return JsonResponse({"success":True,"message":"Account created!"}, status=status.HTTP_200_OK)
            return JsonResponse(data={"success":False,"message":response.json()}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return JsonResponse(data={"success":False,"message":{"error": self.serializer_errors(serializer)}}, status=status.HTTP_400_BAD_REQUEST)
    
    @action(methods=['post'], detail=False, url_path='verify/otp', url_name='verify')
    def verify_otp(self, request, *args, **kwargs):
        serializer = VerifyOTPSerializer(data=request.data)
        if serializer.is_valid():
            response = requests.post(
                url=f"{config('WALLET_API_URL')}api/v1/users/validate_otp/", 
                json=serializer.data
            )
            print(response.content)
            if response.status_code == status.HTTP_200_OK:
                if serializer.validated_data['self_registration']:
                    return JsonResponse({"success": True, "message": "Account verified!"}, status=status.HTTP_200_OK)
                else:
                    print(request.user.merchant_code)
                    payload = {
                        "receiver_account": serializer.data['phone_number'],
                        "amount": {"amount": serializer.data['amount'], "currency":"USD"},
                        "currency": 'USD',
                        "merchant": request.user.merchant_code
                    }
                    response = requests.post(
                    url=f"{config('WALLET_API_URL')}api/v1/customer/topup/", 
                    json=payload
                    )  
                    print(response.content)
                    return JsonResponse({"success": True, "message": f"Account verified and topped up with {serializer.validated_data['amount']} successfully!"}, status=status.HTTP_200_OK) 
            return JsonResponse(data={"success":False,"message":response.json()}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return JsonResponse(data={"success":False,"message":{"error": self.serializer_errors(serializer)}}, status=status.HTTP_400_BAD_REQUEST)

        
    @action(methods=['post'], detail=False, url_path='login', url_name='login')
    def login(self, request, *args, **kwargs):
        serializer = LoginSerializer(data=request.data)
        if serializer.is_valid():
            response = requests.post(
                url=f"{config('WALLET_API_URL')}auth/login/", 
                data=serializer.data
            )
            if response.status_code == status.HTTP_200_OK:
                return JsonResponse({"success": True, "message": response.json()}, status=status.HTTP_200_OK)
            return JsonResponse(data={"success":False,"message":response.json()}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return JsonResponse(data={"success":False,"message":{"error": self.serializer_errors(serializer)}}, status=status.HTTP_400_BAD_REQUEST)


    @action(methods=['post'], detail=False, url_path='lookup', url_name='lookup')
    def lookup(self, request, *args, **kwargs):
        serializer = LookUpSerializer(data=request.data)
        if serializer.is_valid():
            response = requests.post(
                url=f"{config('WALLET_API_URL')}api/v1/users/info/", 
                json=serializer.data,
            )
            if response.status_code == status.HTTP_200_OK:
                return JsonResponse(response.json(), status=status.HTTP_200_OK)

            return JsonResponse(data={"success":False,"message": response.json()}, status=status.HTTP_401_UNAUTHORIZED)
        else:
            return JsonResponse(data={"success":False,"message":{"error": self.serializer_errors(serializer)}}, status=status.HTTP_400_BAD_REQUEST)
    

    @action(methods=['get'], detail=False, url_path='balance', url_name='balance')
    def balance(self, request, *args, **kwargs):
        merchant_code = request.query_params.get('merchant_code')
        
        if not merchant_code:
            return JsonResponse(data={"success":False,"message": "No merchant code provided!"}, status=status.HTTP_400_BAD_REQUEST)
        if  MerchantProfile.get_by_merchant_code(merchant_code):
            print({"Authorization": f"{request.headers.get('Authorization')}", "Content-Type": "application/json"})
            response = requests.get(
                url=f"{config('WALLET_API_URL')}api/v1/user/balance/{merchant_code}/", 
                headers={"Authorization": f"{request.headers.get('Authorization')}", "Content-Type": "application/json"}
            )
            if response.status_code == status.HTTP_200_OK:
                return JsonResponse(response.json(), status=status.HTTP_200_OK)
            return JsonResponse(data={"success":False,"message": response.json()}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return JsonResponse(data={"success":False,"message":"Merchant does not exist"}, status=status.HTTP_400_BAD_REQUEST)

    @action(methods=['get'], detail=False, url_path='user_balance', url_name='user_balance')
    def user_balance(self, request, *args, **kwargs):
        serializer = UserBalanceSerializer(data=request.data)
        if serializer.is_valid():
            payload = {
                "phone_number": serializer.validated_data["phone_number"],
                "merchant_code": serializer.validated_data['merchant_code']
            }
            # Login first
            login_data = {
                "username": "cletus",
                "password": "passcode"
            }
            response = requests.post(
                url=f"{config('WALLET_API_URL')}auth/login/", 
                data=login_data
            )
            # print(response.json())
            data = response.json()
            # print(data['access_token'])
            response = requests.post(
                url=f"{config('WALLET_API_URL')}api/v1/user_balance/", 
                json=payload,
                headers={"Authorization": f"Bearer {data['access_token']}", "Content-Type": "application/json"}
            )
            if response.status_code == status.HTTP_200_OK:
                return JsonResponse(response.json(), status=status.HTTP_200_OK)
            return JsonResponse(data={"success":False,"message": response.json()}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return JsonResponse(data={"success":False,"message":{"error": serializer.errors}}, status=status.HTTP_400_BAD_REQUEST)
        


    @action(methods=['post'], detail=False, url_path='send/money', url_name='send_money')
    def send_money(self, request, *args, **kwargs):
        serializer = SendMoneySerializer(data=request.data)

        if serializer.is_valid():
            print(serializer.validated_data)
            response = requests.post(
                url=f"{config('WALLET_API_URL')}api/v1/transactions/send_money/", 
                json=serializer.validated_data,
                headers={"Authorization": f"Bearer {request.headers.get('Authorization')}", "Content-Type": "application/json"}
            )
            if response.status_code == status.HTTP_200_OK:
                return JsonResponse({"success": True, "message": response.json()}, status=status.HTTP_200_OK)
            return JsonResponse(data={"success":False,"message":response.json()}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return JsonResponse(data={"success":False,"message":{"error": self.serializer_errors(serializer)}}, status=status.HTTP_400_BAD_REQUEST)

        
        
        


class ChangePaswordView(APIView):
    permission_classes = (IsAuthenticated, )
    parser_classes = (JSONParser,)
    serializer_class = PasswordSerializer

    def serializer_errors(self, serializer):
        message = ""
        added = False
        for error in serializer.errors.keys():
            for e in serializer.errors[error]:
                if not added:
                    message =  f"{e}".replace('_', ' ').replace("This", f"{error}")
                    added = True
        return message
    
    
    def post(self, request, *args, **kwargs):
        print("HEADERS : ", request.headers)
        self.serializer_class = self.serializer_class(data=request.data)
        if self.serializer_class.is_valid():
            
            message = request.user.set_password(self.serializer_class.data['password1']).get('message')
            if message == 'Password reset complete!':
                if not request.user.has_used_default_password:
                    request.user.has_used_default_password = True
                    request.user.save()
                return JsonResponse(data={"success":True,"message":"Password reset complete!"}, status=status.HTTP_200_OK)
            return JsonResponse(data={"success":False,"message":message}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return JsonResponse(data={"success":False,"message":{"error": self.serializer_errors(self.serializer_class)}}, status=status.HTTP_400_BAD_REQUEST)




