from rest_framework.views import APIView
from rest_framework import status, viewsets
from django.http import JsonResponse
from rest_framework.parsers import JSONParser
from rest_framework.decorators import action
from api.serializers.operators import PinChangeSerializer, TopUpSerializer
from rest_framework.permissions import IsAuthenticated
from api.serializers.wallets import LookUpSerializer
from merchant.permissions import HasChangedPassword
from merchant.models import MerchantProfile
import requests
from decouple import config

class OperatorView(viewsets.ViewSet):
    permission_classes = (IsAuthenticated, HasChangedPassword)
    parser_classes = (JSONParser,)
    model = MerchantProfile


    def serializer_errors(self, serializer):
        message = ""
        added = False
        for error in serializer.errors.keys():
            for e in serializer.errors[error]:
                if not added:
                    message =  f"{e}".replace('_', ' ').replace("This", f"{error}")
                    added = True
        return message
    
    @action(methods=['post'], detail=False, url_path='reset/user/pin', url_name='pin_reset')
    def reset_user_pin(self, request, *args, **kwargs):
        serializer = PinChangeSerializer(data=request.data)
        if serializer.is_valid():
            serializer.data['merchant_code'] = request.user.merchant_code
            response = requests.post(
                url=f"{config('WALLET_API_URL')}api/v1/users/reset_pin/", 
                json=serializer.data
            )
            if response.status_code == status.HTTP_200_OK:
                return JsonResponse({"success":True,"message":"Pin successfully changed!!"}, status=status.HTTP_200_OK)
            return JsonResponse(data={"success":False,"message":response.json()}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return JsonResponse(data={"success":False,"message":{"error": self.serializer_errors(serializer)}}, status=status.HTTP_400_BAD_REQUEST)
    
    

    @action(methods=['post'], detail=False, url_path='topup/user', url_name='topup_user')
    def user_top_up(self, request, *args, **kwargs):
        serializer = TopUpSerializer(data=request.data, context={'request':request})
        if serializer.is_valid():
            response = requests.post(
                url=f"{config('WALLET_API_URL')}api/v1/customer/topup/", 
                json=serializer.validated_data
            )
            if response.status_code == status.HTTP_200_OK:
                return JsonResponse({"success":True,"message":response.json()}, status=status.HTTP_200_OK)
            return JsonResponse(data={"success":False,"message":response.json()}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return JsonResponse(data={"success":False,"message":{"error": self.serializer_errors(serializer)}}, status=status.HTTP_400_BAD_REQUEST)


    @action(methods=['post'], detail=False, url_path='give/change', url_name='give_change')
    def give_change(self, request, *args, **kwargs):
        serializer = TopUpSerializer(data=request.data, context={'request':request})
        if serializer.is_valid():
            response = requests.post(
                url=f"{config('WALLET_API_URL')}api/v1/customer/change/", 
                json=serializer.validated_data
            )
            if response.status_code == status.HTTP_200_OK:
                return JsonResponse({"success":True,"message":response.json()}, status=status.HTTP_200_OK)
            return JsonResponse(data={"success":False,"message":response.json()}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return JsonResponse(data={"success":False,"message":{"error": self.serializer_errors(serializer)}}, status=status.HTTP_400_BAD_REQUEST)

    
    @action(methods=['get'], detail=False, url_path='fetch/wallets', url_name='fetch_wallets')
    def fetch_all_users(self, request, *args, **kwargs):
        response = requests.get(
            url=f"{config('WALLET_API_URL')}api/v1/merchant/users/{request.user.merchant_code}/", 
        )
        if response.status_code == status.HTTP_200_OK:
            return JsonResponse({"success":True,"message":response.json()}, status=status.HTTP_200_OK)
        return JsonResponse(data={"success":False,"message":response.json()}, status=status.HTTP_400_BAD_REQUEST)

    
    @action(methods=['post'], detail=False, url_path='lookup/user', url_name='lookup_user')
    def lookup_user(self, request, *args, **kwargs):
        if request.data.get('phone_number'):
            response = requests.post(
                url=f"{config('WALLET_API_URL')}api/v1/users/info/", 
                json={
                    "phone_number":request.data.get('phone_number'), 
                    "merchant_code":request.user.merchant_code},
            )
            if response.status_code == status.HTTP_200_OK:
                return JsonResponse(response.json(), status=status.HTTP_200_OK)

            return JsonResponse(data={"success":False,"message": response.json()}, status=400)
        else:
            return JsonResponse(data={"success":False,"message":{"error": "phone_number not provided"}}, status=status.HTTP_400_BAD_REQUEST)

    @action(methods=['post'], detail=False, url_path='request/balance', url_name='request_balance')
    def request_balance(self, request, *args, **kwargs):
        if request.data.get('phone_number'):
            if request.data.get('pin'):
                response = requests.post(
                    url=f"{config('WALLET_API_URL')}api/v1/customer/balance/", 
                    json={
                        "phone_number":request.data.get('phone_number'), 
                        "pin": request.data.get('pin'), 
                        "merchant_code":request.user.merchant_code
                    }
                )
                if response.status_code == status.HTTP_200_OK:
                    return JsonResponse(response.json(), status=status.HTTP_200_OK)

                return JsonResponse(data={"success":False,"message": response.json()}, status=400)
            else:
                return JsonResponse(data={"success":False,"message":{"error": "pin not provided"}}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return JsonResponse(data={"success":False,"message":{"error": "phone_number not provided"}}, status=status.HTTP_400_BAD_REQUEST)
    
    

class PublicOperatorLookup(APIView):
    permission_classes = ( )
    parser_classes = (JSONParser,)
    
    def post(self, request, *args, **kwargs):
        if request.data.get('phone_number'):
            if request.data.get('merchant_code'):
                response = requests.post(
                    url=f"{config('WALLET_API_URL')}api/v1/users/info/", 
                    json={
                        "phone_number":request.data.get('phone_number'), 
                        "merchant_code":request.data.get('merchant_code')
                    },
                )
                if response.status_code == status.HTTP_200_OK:
                    return JsonResponse(response.json(), status=status.HTTP_200_OK)
                return JsonResponse(data=response.json(), status=400)
            else:
                return JsonResponse(data={"success":False,"message":{"error": "merchant_code not provided"}}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return JsonResponse(data={"success":False,"message":{"error": "phone_number not provided"}}, status=status.HTTP_400_BAD_REQUEST)