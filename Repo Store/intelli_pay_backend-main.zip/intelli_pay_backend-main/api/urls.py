from django.urls import path, include
from api.views.wallets import ChangePaswordView, UserWalletsView
from api.views.operators import OperatorView, PublicOperatorLookup
from rest_framework import routers
from transaction.views import TransactionsFilterView, TransactionsFilterDataView, OperatorsFilterDataView, TransactionsFilterOrderView
from merchant.views import FetchAllMerchants
router = routers.DefaultRouter()
router.register(r'wallets', UserWalletsView, basename='wallets')
router.register(r'operator', OperatorView, basename='operators')

urlpatterns = [
    path('change/password/', ChangePaswordView.as_view(), name='change_password'),
    path('fetch/merchants/', FetchAllMerchants.as_view(), name='get_merchant'),
    path('filter/transactions/', TransactionsFilterView.as_view(), name='filter_transactions'),
    path('filter/operators/', OperatorsFilterDataView.as_view(), name='filter_operators'),
    path('transactions-details/<str:transaction_id>/', TransactionsFilterOrderView.as_view(), name='get_order_items'),
    path('public/lookup/', PublicOperatorLookup.as_view(), name='public_lookup'),
    path('filter/transactions/data/', TransactionsFilterDataView.as_view(), name='filter_transactions_data'),
    path('', include(router.urls)),
]
