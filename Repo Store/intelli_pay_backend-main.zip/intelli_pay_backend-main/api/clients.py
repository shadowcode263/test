from decouple import config
import requests


class WalletsClient:
    def __init__(self):
        pass

    def lookup(self, phone_number, merchant_code):
        try:
            response = requests.post(
                url=f"{config('WALLET_API_URL')}api/v1/users/info/", 
                json={"phone_number": phone_number, "merchant_code": merchant_code},
            )
            if response.status_code == 200:
                return response.json(),response.status_code
        except Exception as e:
            pass
        return {"status":False, "message": {"first_name": None, "last_name": None, "phone_number": None, "national_id": None}},400

    def makepayment(self, serialized_data, merchant_code):
        payload = {
            "merchant": merchant_code,
            "sender_account": serialized_data.get("phone_number"),
            "amount":{
                    "amount": float(serialized_data.get('transaction').amount),
                    "currency": serialized_data.get('transaction').currency
                },
            "pin": serialized_data.get("pin"),
        }
        serialized_data['merchant_code'] = merchant_code,
        
        try:
            response = requests.post(
                url=f"{config('WALLET_API_URL')}api/v1/customer/payment/", 
                json=payload,
            )
            print("Wallet Response",response.json())
            print("Response",response.status_code)
            if response.status_code == 200:
                response_data = {
                    "status": True,
                    "narration": response.json().get("message"),
                    "transaction_id": response.json().get("transaction_id"),
                }
                return response_data
            else:
                print("Failed ",  response.json().keys())
                if "non_field_errors" in list(response.json().keys()):
                    messages = response.json()
                    return {"status":False, "transaction_id": None, "narration": messages["non_field_errors"][0]}
                if "message" in list(response.json().keys()):
                    messages = response.json()
                    if "non_field_errors" in list(messages.keys()):
                        return {"status":False, "transaction_id": None, "narration": messages["non_field_errors"][0]}
                    return {"status":False, "transaction_id": None, "narration": messages["message"]}
        except Exception as e:
            print(e)
        return {"status": False, "transaction_id": None, "narration": "Failed to process transaction!"}

    def send_money(self, serialized_data, merchant_code):
        payload = {
            "merchant": merchant_code,
            "sender_account": serialized_data.get("phone_number"),
            "receiver_account": serialized_data.get("receiver_account"),
            "amount":{
                    "amount": float(serialized_data.get('amount')),
                    "currency": serialized_data.get('currency')
                },
            "pin": serialized_data.get("pin"),
        }
        serialized_data['merchant_code'] = merchant_code,
        
        try:
            response = requests.post(
                url=f"{config('WALLET_API_URL')}api/v1/customer/send_money/", 
                json=payload,
            )
            print("Wallet Response",response.json())
            print("Response",response.status_code)
            if response.status_code == 200:
                response_data = {
                    "status": True,
                    "narration": response.json().get("message"),
                    "transaction_id": response.json().get("transaction_id"),
                }
                return response_data, response.status_code
            else:
                print("Failed ",  response.json().keys())
                if "non_field_errors" in list(response.json().keys()):
                    messages = response.json()
                    return {"status":False, "transaction_id": None, "narration": messages["non_field_errors"][0]}, response.status_code
                if "message" in list(response.json().keys()):
                    messages = response.json()
                    if "non_field_errors" in list(messages.keys()):
                        return {"status":False, "transaction_id": None, "narration": messages["non_field_errors"][0]}, response.status_code
                    return {"status":False, "transaction_id": None, "narration": messages["message"]}, response.status_code
        except Exception as e:
            print(e)
        return {"status": False, "transaction_id": None, "narration": "Failed to process transaction!"}

