from locale import currency
import uuid

from django.shortcuts import render
from rest_framework import viewsets
from rest_framework.views import APIView
from django.http import JsonResponse, Http404
from rest_framework.decorators import action

from services.permissions.is_pos_user import IsPOSUser
from services.permissions.has_terminal import HasTerminal
from services.shop_services.add_items_to_cart import BatchOrderService
from services.shop_services.rates_service import RatesService
from rest_framework.permissions import IsAuthenticated
from shop.serializers import *
from shop.models import Order, OrderItem
from transaction.models import Transaction, TransactionType
from merchant.permissions import HasChangedPassword


class OrderViewSet(viewsets.ModelViewSet):
    """
    Order ViewSet
    """
    permission_classes = [IsAuthenticated, HasChangedPassword]
    serializer_class = OrderSerializer
    model = Order

    @action(detail=False, methods=['POST'])
    def create_order(self, request):
        serializer = OrderSerializer(data=request.data)
        if serializer.is_valid():
            order = Order.objects.create(
                bill_name = serializer.validated_data['bill_name'],
                currency = serializer.validated_data['currency'],                
                created_by=self.request.user,
                status="PENDING"
            )
            return JsonResponse(data={"success":True,"order_id":order.id}, status=201)
        else:
            return JsonResponse(data={"success":False,"message":serializer.errors}, status=400)

        
    @action(detail=True, methods=['POST'])
    def save_order(self,request):
        return 'done'
        serializer = SaveOrderSerializer(data=request.data)
        if serializer.is_valid():
            order = Order.filter_id(serializer.validated_data['order_id'])
        
    def get_queryset(self):
        return self.model.objects.filter(created_by=self.request.user)

    def get_object(self, pk):
        try:
            return self.model.objects.get(pk=pk)
        except Exception as e:
            raise Http404("Order not found")

    def destroy(self, request, pk):
        order = self.get_object(pk)

        try:
            order.soft_delete()
            return JsonResponse(
                status=204,
                data={
                    "status": True,
                    "message": "Successfully deleted order",
                    "data": None,
                    "issues": None
                }
            )        
        except Exception as e:
            return JsonResponse(
                status=400,
                data={
                    "status": False,
                    "message": "Error deleting order",
                    "data": None,
                    "issues": str(e)
                }
            )    



class AddToCart(APIView):
    serializer_class = AddToCartSerializer
    permission_classes = [IsAuthenticated, IsPOSUser, HasChangedPassword]
    order_item_serializer = OrderItemSerializer(many=True)

    def get_order(self, id):
        try:
            return Order.objects.get(id=id)
        except Exception as e:
            raise Http404("Order not found")

    def post(self, request):        
        print("INCOMING PAYLOAD :: ", request.data)
        serializer = self.serializer_class(data=request.data)
        if serializer.is_valid():
            order = self.get_order(serializer.data.get('order_id'))
            cart_data = BatchOrderService().create_cart_batch_items(
                order, 
                serializer.data.get('extras'), request, serializer.data.get('save')
            )

            if cart_data:
                return JsonResponse(
                    status=201,
                    data={
                        "status": True,
                        "message": "Successfully added items to cart",
                        "data": cart_data,
                        "issues": None
                    }
                )
            else:
                print(">>>>>>>>>> ", cart_data[1])
                return JsonResponse(
                    status=400,
                    data={
                        "status": False,
                        "message": "Error adding items to cart",
                        "data": None,
                        "issues": cart_data[1]
                    }
                )    
        else:
            print("#############", serializer.errors)
            return JsonResponse(
                status=400,
                data={
                    "status": False,
                    "message": "Error adding to cart",
                    "data": None,
                    "issues": serializer.errors
                }
            )

class RemoveFromCart(APIView):

    permission_classes = [IsAuthenticated, IsPOSUser, HasChangedPassword]
    serializer_class = RemoveItemSerializer
    canceled = False
    balance = None
    uid = None
    currency = None

    def post(self,request):
        
        serializer = self.serializer_class(data=request.data)

        if serializer.is_valid():

            print(f">>>>{serializer.data.get('order_id')} {serializer.data.get('order_item_id')}")

            print(f"{request.data}")

            order = Order.objects.filter(id=request.data.get('order_id')).first()
            order_item = OrderItem.objects.filter(id=request.data.get('order_item_id')).first()


            if order and order_item:
                order_item.soft_delete()
                RatesService().recalculate_order_total(order)
                self.uid = order.id
                self.balance = order.total
                self.currency = order.transaction.currency
                
                return JsonResponse(
                    status=200,
                    data={
                        "status": True,
                        "message": "Successfully removed from cart",
                        "data": {
                            "New Balance": self.balance,
                            "Currency": self.curre|ncy,
                            "Order": self.uid,
                            "Canceled": self.canceled},
                        "issues": None
                    })
            else:
                return JsonResponse(
                    status=400,
                    data={
                        "status": False,
                        "message": "Error removing from cart",
                        "data": None,
                        "issues": "Order or Order Item not found"
                    }
                )
        else:
            return JsonResponse(
                status=400,
                data={
                    "status": False,
                    "message": "Error removing from cart",
                    "data": None,
                    "issues": serializer.errors
                }
            )                

        
class OrderPayment(APIView):
    permission_classes = [IsAuthenticated, IsPOSUser, HasChangedPassword]
    serializer_class = OrderPaymentSerializer
    # order_item_serializer = OrderItemSerializer(many=True)
    amount_paid = False
    balance = None
    paid_off = False

    def post(self, request):

        transaction_type = TransactionType.objects.filter(name='Order Payment').first()

        if not transaction_type:
            return JsonResponse(
                status=500,
                data={
                    "status": False,
                    "message": "Order Payment transaction type not found",
                    "data": None,
                    "issues": None
                }
            )
        
        serializer = self.serializer_class(data=request.data)

        if serializer.is_valid():

            order = Order.objects.filter(id=serializer.data.get('order_id')).first()
            order_item = OrderItem.objects.filter(id=serializer.data.get('order_item_id')).first()

            if order.is_fully_paid:
                return JsonResponse(
                    status=400,
                    data={
                        "status": False,
                        "message": "Order is fully paid",
                        "data": None,
                        "issues": None
                    }
                )

            if order_item.paid_off:
                return JsonResponse(
                    status=400,
                    data={
                        "status": False,
                        "message": "Order Item already paid off",
                        "data": None,
                        "issues": None
                    }
                )


            order_item.paid_off = True
            order_item.save()

            RatesService().recalculate_order_total(order)

            if order.total == 0:
                order.transaction.status = 'Paid Off'
                order.transaction.save()
                order.is_fully_paid = True
                order.save()
                self.paid_off = True
                # order.soft_delete()

            # get last transaction id from Transaction table
           
            transaction = Transaction.objects.create(
                transaction_type=order.transaction.transaction_type,
                amount=serializer.data.get('amount'),
                payment_method=order.transaction.payment_method,
                status='Paid',
                reference=reference,
                pos_terminal=request.user.get_pos_terminal(),
            )
            return JsonResponse(
                status=200,
                data={
                    "status": True,
                    "message": "Successfully paid order",
                    "data": {
                        "New Balance": order.total,
                        "Order": order.id,
                        "Transaction": transaction.id},
                        "Paid Off": self.paid_off,
                    "issues": None
                }
            )
        else:
            return JsonResponse(
                status=400,
                data={
                    "status": False,
                    "message": "Error adding to cart",
                    "data": None,
                    "issues": serializer.errors
                }
            )    




class OrderFullPaymentView(APIView):

    serializer_class = OrderFullPaymentSerializer
    permission_classes = [IsAuthenticated, IsPOSUser, HasChangedPassword]

    def post(self, request):

        transaction_type = TransactionType.objects.filter(name='Order Full Payment').first()

        if not transaction_type:
            return JsonResponse(
                status=500,
                data={
                    "status": False,
                    "message": "Order Full Payment transaction type not found",
                    "data": None,
                    "issues": None
                }
            )

        serializer = self.serializer_class(data=request.data)

        if serializer.is_valid():

            order = Order.objects.filter(id=serializer.data.get('order_id')).first()
            order.transaction.status = 'Paid Off'
            order.transaction.save()
            order.is_fully_paid = True
            order.save()

            amount = serializer.data.get("amount")

            order_items = OrderItem.objects.filter(order=order)

            for item in order_items:
                item.paid_off = True
                item.save()

            RatesService().recalculate_order_total(order)    

            transaction = Transaction.objects.create(
                transaction_type=order.transaction.transaction_type,
                amount=amount,
                payment_method=order.transaction.payment_method,
                status='One Time Payment',
                reference=str(uuid.uuid4())[:12],
                pos_terminal=request.user.get_pos_terminal(),
            )

            return JsonResponse(
                status=200,
                data={
                    "status": True,
                    "message": "Successfully paid order",
                    "data": None,
                    "issues": None
                }
            )
        else:
            return JsonResponse(
                status=400,
                data={
                    "status": False,
                    "message": "Error adding to cart",
                    "data": None,
                    "issues": serializer.errors
                }
            )
        

class ViewCartView(APIView):
    permission_classes = [IsAuthenticated, IsPOSUser, HasChangedPassword]
    serializer_class = ViewCartSerializer

    def post(self, request):

        serializer = self.serializer_class(data=request.data)

        if serializer.is_valid():

            try:
                order = Order.objects.get(id=serializer.data.get('order_id'))
                cart = order.generate_cart()

                return JsonResponse(
                    status=200,
                    data={
                        "status": True,
                        "message": "Successfully retrieved cart",
                        "data": cart,
                        "issues": None
                    }
                )
            
            except Exception as e:
                return JsonResponse(
                    status=400,
                    data={
                        "status": False,
                        "message": f"Error getting order {e}",
                        "data": None,
                        "issues": None
                    }
                )
        else:
            return JsonResponse(
                status=400,
                data={
                    "status": False,
                    "message": "Error getting order",
                    "data": None,
                    "issues": serializer.errors
                }
            )

class ModifyCartView(APIView):
    permission_classes = [IsAuthenticated, IsPOSUser, HasChangedPassword]
    serializer_class = RegenerateCartSerializer

    def post(self, request):

        serializer = self.serializer_class(data=request.data)

        if serializer.is_valid():

            try:
                for item in serializer.data.get('order_items'):
                    order_item = OrderItem.objects.get(id=item.get('id'))
                    order_item.quantity = item.get('quantity')
                    order_item.save()

                order = Order.objects.get(id=serializer.data.get('order_id'))
                order.recalculate_order_total()
                cart = order.generate_cart()

                return JsonResponse(
                    status=200,
                    data={
                        "status": True,
                        "message": "Successfully updated cart",
                        "data": cart,
                        "issues": None
                    }
                )
            
            except Exception as e:
                return JsonResponse(
                    status=400,
                    data={
                        "status": False,
                        "message": f"Error getting order {e}",
                        "data": None,
                        "issues": None
                    }
                )
        else:
            return JsonResponse(
                status=400,
                data={
                    "status": False,
                    "message": "Error getting order",
                    "data": None,
                    "issues": serializer.errors
                }
            )

class BillViewset(APIView):
    permission_classes = [IsAuthenticated, IsPOSUser, HasChangedPassword] 
    serializer_class = BillSerializer   

    def get(self, request):
        orders = Order.objects.filter(created_by=request.user, saved=True).all()
        print(len(orders))
        if len(orders)==0:
            return JsonResponse(
                status=400,
                data={
                    "status": False,
                    "message": "No orders found",
                }
            )
        response = {}
        for order in orders:
            order_list = []
            response_data = {
                "id": order.id,
                "bill_name": order.bill_name,
                "total": order.total,
            }
            order_list.append(response_data)
        response['orders'] = order_list
        return JsonResponse(status=200, data=response)

   
class ViewOrderViewset(APIView):
    permission_classes = [IsAuthenticated, IsPOSUser ]
    serializer_class = BillSerializer
    def get(self, request):
        serializer = BillSerializer(data=request.data)
        if serializer.is_valid():
            order_items = OrderItem.objects.filter(order=serializer.validated_data['order']).all()
            extras = []
            for order in order_items:
                product = {}
                product['product_id'] = order.product.id
                product['product_name'] = order.product.name
                product['quantity'] = order.quantity
                product['price'] = float(order.product.price) * float(order.quantity)
                extras.append(product)
            response = {"order_id": serializer.validated_data['order'].id, 
                        "total": serializer.validated_data['order'].total, "extras": extras}
            return JsonResponse(status=200, data=response)
        else:
            return JsonResponse(status=400, data=serializer.errors)

    
class DeleteOrderViewset(APIView):
    permission_classes = [IsAuthenticated, IsPOSUser ]
    serializer_class = BillSerializer
    def get(self, request):
        serializer = BillSerializer(data=request.data)
        if serializer.is_valid():
            serializer.validated_data['order'].saved = False
            serializer.validated_data['order'].save()
            return JsonResponse(status=200, data={"message": "Successfully deleted order"})
    
        else:
            return JsonResponse(status=400, data=serializer.errors)


class AppendToOrderView(APIView):
    serializer_class = AppendToOrderSerializer
    permission_classes = [IsAuthenticated, IsPOSUser, HasChangedPassword]

    def post(self, request):
            
            serializer = self.serializer_class(data=request.data)
    
            if serializer.is_valid():
    
                try:
                    order = Order.objects.get(id=serializer.data.get('order_id'))
                    product = Product.objects.filter(id=serializer.data.get('product_id')).first()
                    order_item = OrderItem.objects.create(
                        order=order,
                        product=product,
                        quantity=serializer.data.get('quantity'),
                        title=f'{product.name} Order Item',
                        description=f'{product.name} Order Item',
                    )
                    # Recalculate order total with additional item
                    RatesService().recalculate_order_total(order)
                    cart = order.generate_cart()
    
                    return JsonResponse(
                        status=200,
                        data={
                            "status": True,
                            "message": "Successfully updated cart",
                            "data": cart,
                            "issues": None
                        }
                    )
                
                except Exception as e:
                    return JsonResponse(
                        status=400,
                        data={
                            "status": False,
                            "message": f"Error getting order {e}",
                            "data": None,
                            "issues": None
                        }
                    )
            else:
                return JsonResponse(
                    status=400,
                    data={
                        "status": False,
                        "message": "Error getting order",
                        "data": None,
                        "issues": serializer.errors
                    }
                )