import uuid

from django.db import models
from django.conf import settings

from core.model import SoftDeleteModel
from merchant.models import Product
from transaction.models import Transaction, TransactionType


class OrderStatusChoiceSet(models.TextChoices):
    PENDING = 'PENDING', ('PENDING')
    PROCESSING = 'PROCESSING', ('PROCESSING')
    COMPLETED = 'COMPLETED', ('COMPLETED')
    CANCELLED = 'CANCELLED', ('CANCELLED')

class OrderCurrencies(models.TextChoices):
    USD = 'USD', ('USD')
    KES = 'KES', ('KES')
    ZAR = 'ZAR', ('ZAR')
    ZWL = 'ZWL', ('ZWL')    


class Order(SoftDeleteModel):
    """
    Order Model
    """
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    # order_id = models.CharField(max_length=20, unique=True)
    date = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=20, choices=OrderStatusChoiceSet.choices, default=OrderStatusChoiceSet.PENDING)
    total = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    currency = models.CharField(max_length=3, choices=OrderCurrencies.choices, default=OrderCurrencies.USD)
    bill_name = models.CharField(max_length=100, blank=True, null=True)
    # order_customer_email = models.EmailField(blank=True, null=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, default=None)
    is_fully_paid = models.BooleanField(default=False)
    saved = models.BooleanField(default=False)    
    transaction = models.ForeignKey(Transaction, on_delete=models.PROTECT, null=True, blank=True)

    def __str__(self):
        return f"{self.bill_name} - {self.date.strftime('%d/%m/%Y: %H:%M:%S')}"
    
    @classmethod
    def filter_id(cls,id):
        return cls.objects.filter(id=id).first()

    @classmethod
    def filter_by_transaction(cls,txn):
        return cls.objects.filter(transaction=txn).first()
    
    def get_order_items(self):
        return OrderItem.objects.filter(order=self, paid_off=False)

    def generate_cart(self):

        order_items = [
            {"id": item.id, "product": item.product.name, "product_id": item.product.id, "quantity": item.quantity, "price": item.product.price} for item in self.get_order_items()
        ]

        return  {"order_id": self.id, "total": self.total, "currency": self.currency, "order_items": order_items}

    def recalculate_order_total(self, rate=None):
        order_total = 0
        for item in self.get_order_items():
            order_total += item.product.price * item.quantity

        if rate:
            order_total = round((order_total * rate), 2)

        self.total = order_total
        self.save()    

        self.transaction.amount = order_total
        self.transaction.save()

    class Meta:
        verbose_name = 'Order'
        verbose_name_plural = 'Orders'


class OrderItem(SoftDeleteModel):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    created_at = models.DateTimeField(auto_now_add=True)
    title = models.CharField(max_length=100)
    description = models.CharField(max_length=255)
    quantity = models.IntegerField()
    product = models.ForeignKey(Product, on_delete=models.PROTECT)
    order = models.ForeignKey(Order, on_delete=models.CASCADE)
    paid_off = models.BooleanField(default=False) 


    def __str__(self):
        return f'{self.product.name} - Qty: {self.quantity} - {self.created_at.strftime("%a %m %y | %H:%M:%S")}'

    @classmethod
    def filter_by_order(cls,order):
        return cls.objects.filter(order=order)
    
    class Meta:
        verbose_name = 'Order Item'
        verbose_name_plural = 'Order Items'