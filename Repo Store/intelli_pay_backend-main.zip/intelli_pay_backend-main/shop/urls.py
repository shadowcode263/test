from django.urls import path, include
from rest_framework import routers

from shop.views import *

router = routers.DefaultRouter()
router.register(r'orders', OrderViewSet, basename='orders')

urlpatterns = [
    path('', include(router.urls)),
    path('bills/', BillViewset.as_view(), name='bills'),
    path('view_bill/', ViewOrderViewset.as_view(), name='view_bill'),
    path('delete_bill/', DeleteOrderViewset.as_view(), name='view_bill'),
    path('add_to_cart/', AddToCart.as_view(), name='add_to_cart'),
    path('view_cart/', ViewCartView.as_view(), name='view_cart'),
    path('remove_item_from_cart/', RemoveFromCart.as_view(), name='remove_from_cart'),
    path('modify_cart/', ModifyCartView.as_view(), name='modify_cart'),
    path('order_payment/', OrderPayment.as_view(), name='order_payment'),
    path('append_to_order/', AppendToOrderView.as_view(), name='append_to_order'),
    path('order_full_payment/', OrderFullPaymentView.as_view(), name='order_fill_payment'),
]
