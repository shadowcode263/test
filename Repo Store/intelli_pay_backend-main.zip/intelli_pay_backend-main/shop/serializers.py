import uuid

from rest_framework import serializers
from django.http import JsonResponse

from shop.models import Order, OrderItem
from merchant.models import Product, ProductCategory
from transaction.models import Transaction, TransactionType, PaymentMethod
from services.shop_services.rates_service import RatesService

class OrderSerializer(serializers.ModelSerializer):

    class Meta:
        model = Order
        fields = (   
            'currency',            
            'bill_name',
        )

        extra_kwargs = {
            'order_total': {'read_only': True},
            'created_by': {'required': False},
        }

    def validate(self, data):
        # get number of rows in Order table
        order_count = Order.objects.count()
        data['bill_name'] = "Bill-" + str(order_count + 1)
        return data

class SaveOrderSerializer(serializers.Serializer):
    order_id = serializers.UUIDField(required=False)
    
    def validate(self, data):
        order_id = data.get('order_id')
        if order_id:
            try:
                order = Order.objects.get(id=order_id)
            except Order.DoesNotExist:
                raise serializers.ValidationError('Order does not exist')
        else:
            order = Order()
        return data




class OrderItemSerializer(serializers.ModelSerializer):
    product = serializers.PrimaryKeyRelatedField(queryset=Product.objects.all())
    order = serializers.PrimaryKeyRelatedField(queryset=Order.objects.all())
    
    class Meta:
        model = OrderItem
        fields = (
            'id',
            'title',
            'description',
            'quantity',
            'product',
            'order'
        )
        read_only_fields = ('id',)
        extra_kwargs = {
            'title': {'required': False},
            'description': {'required': False},
            'quantity': {'required': False},
            'product': {'required': False},
            'order': {'required': False}
        }


class AddToCartSerializer(serializers.Serializer):
    order_id = serializers.UUIDField()
    extras = serializers.ListField(child=serializers.DictField())
    save = serializers.BooleanField(default=True)


    def validate(self, data):
        print("This one Ran")
        if not data.get('order_id'):
            raise serializers.ValidationError('Order ID is required') 

       
        if not data.get('extras'):
            raise serializers.ValidationError('Extras is required')

        order = Order.objects.filter(id=data['order_id']).first()

        if not order:
            raise serializers.ValidationError("Order Not Found")

        if order.get_order_items():
            if order.saved==True:
                pass
            else:
                raise serializers.ValidationError("This Order Already Has Order Items")

        

        return data

    # def validate_category(self, value):
    #     if not ProductCategory.objects.filter(id=value).exists():
    #         raise serializers.ValidationError("Category Not Found")
    #     return value

    # def validate_currency(self, value):
    #     if value not in ['USD', 'ZAR', 'ZWL']:
    #         raise serializers.ValidationError('Invalid currency, must be USD, ZAR or ZWL...')
    #     return value

    # def validate(self, data):

    #     if not Order.objects.filter(id=data['order_id']).exists():
    #         raise serializers.ValidationError("Order Not Found")

    #     order = Order.objects.get(id=data.get('order_id'))
    #     if OrderItem.objects.filter(order=order):
    #         raise serializers.ValidationError("This Order Already Has Order Items")
    #     return data    

    # def validate_payment_method(self, value):

    #     print(f"Payment Method: {value}")
    #     print(f"Payment Method: {PaymentMethod.objects.filter(id=value).exists()}")

        # try:
        #     uuid.UUID(value, version=4)
        # except Exception as e:
        #     raise serializers.ValidationError(f"Invalid payment method UUID: {e}")  

        # if not PaymentMethod.objects.filter(id=value).exists():
        #     raise serializers.ValidationError("Payment Method Not Found")
        # return value   

    def vaildate_order_id(self, value):
        print(f'Checking Shit')
        try:
            uuid.UUID(value)
        except ValueError:
            raise serializers.ValidationError("Invalid order id")    

        if not Order.objects.filter(id=value).exists():
            raise serializers.ValidationError("Order Not Found<")
        return value

        order = Order.objects.get(id=value)

        if OrderItem.objects.filter(order=order):
            raise serializers.ValidationError("This Order Already Has Order Items")

    def validate_extras(self, value):
        if len(value) == 0:
            raise serializers.ValidationError("No extras selected")
        
        for extra in value:
            # Validating Product ID

            if not extra.get('product_id'):
                raise serializers.ValidationError("No product id")

            try:
                uuid.UUID(extra.get('product_id'))
            except ValueError:
                raise serializers.ValidationError("Invalid product id")

            if not Product.objects.filter(id=extra.get('product_id')).exists():
                raise serializers.ValidationError(f"Product Not Found : {extra.get('product_id')}")

            # Validating Quantity    
            if not extra.get('quantity'):
                raise serializers.ValidationError("No quantity")

            if not isinstance(extra.get('quantity'), int):
                raise serializers.ValidationError("Quantity must be an integer")    

            if extra.get('quantity') < 1:
                raise serializers.ValidationError("Quantity must be greater than 0")
            if not extra.get('quantity'):
                raise serializers.ValidationError("Invalid value for quantity")

        return value


class RemoveItemSerializer(serializers.Serializer):
    order_id = serializers.UUIDField()
    order_item_id = serializers.UUIDField()

    def vaildate_order_id(self, value):
        try:
            uuid.UUID(value)
        except ValueError:
            raise serializers.ValidationError("Invalid order id")    

        if not Order.objects.filter(id=value).exists():
            raise serializers.ValidationError("Order Not Found")
        return value

    def vaildate_order_item_id(self, value):
        try:
            uuid.UUID(value)
        except ValueError:
            raise serializers.ValidationError("Invalid order item id")    

        if not OrderItem.objects.filter(id=value).exists():
            raise serializers.ValidationError("Order Item Not Found")
        return value     


class OrderPaymentSerializer(serializers.Serializer):
    order_id = serializers.UUIDField()
    order_item_id = serializers.UUIDField()
    amount = serializers.FloatField()

    def validate(self, attrs):

        if not Order.objects.filter(id=attrs['order_id']).exists():
            raise serializers.ValidationError("Order Not Found")

        if not OrderItem.objects.filter(id=attrs['order_item_id']).exists():
            raise serializers.ValidationError("Order Item Not Found")

        order_item = OrderItem.objects.get(id=attrs['order_item_id'])  

        if order_item.paid_off:
            raise serializers.ValidationError("This Item Has Already Been Paid Off.")

        balance = order_item.quantity * order_item.product.price

        if order_item.order.currency != order_item.order.category_currency:
            balance =  RatesService().calculate_amount(
                order_item.order.currency, order_item.order.category_currency, balance)

            if isinstance(balance, tuple):
                return JsonResponse(
                    status=500,
                    data={
                        'status': 'error',
                        'message': balance[1]
                    }) 

        if float(balance) != float(attrs.get('amount')):
            raise serializers.ValidationError(f"Amount does not match order total : {balance} ")
            

        return attrs

    def vaildate_order_id(self, value):
        try:
            uuid.UUID(value)
        except ValueError:
            raise serializers.ValidationError("Invalid order id")      

        if not Order.objects.filter(id=value).exists():
            raise serializers.ValidationError("Order Not Found")

        if Order.objects.get(id=value).is_fully_paid:
            raise serializers.ValidationError("Order Already Paid")

        return value

    def vaildate_order_item_id(self, value):

        print(f"Validator Ran")
        
        try:
            uuid.UUID(value)
        except ValueError:
            raise serializers.ValidationError("Invalid order item id")    

        if not OrderItem.objects.filter(id=value).exists():
            raise serializers.ValidationError("Order Item Not Found")
        return value   

        order_item = OrderItem.objects.get(id=value)  

        if order_item.paid_off:
            raise serializers.ValidationError("This Item Has Already Been Paid Off.")

        balance = order_item.quantity * order_item.product.price

        if order_item.order.order_currency != order_item.order.category.currency:
            balance =  RatesService().calculate_amount(
                order_item.order.order_currency, order_item.order.category_currency, balance)

            if isinstance(balance, tuple):
                return JsonResponse(
                    status=500,
                    data={
                        'status': 'error',
                        'message': balance[1]
                    }) 

        if float(balance) != float(self.validated_data.get('amount')):
            raise serializers.ValidationError(f"Amount does not match order total : {balance} ")
            

    def validate_amount(self, value):
        print(f"\n\n\n{value}\n\n\n")
        if value <= 0:
            raise serializers.ValidationError("Amount Too Low To Process {value}")
        return value

        try:
            float(value)
        except ValueError:
            raise serializers.ValidationError("Amount must be a number")    


class OrderFullPaymentSerializer(serializers.Serializer):
    order_id = serializers.UUIDField()
    amount = serializers.FloatField()


    def validate(self, attrs):
        order_id = attrs.get('order_id')
        amount = attrs.get('amount')

        if not Order.objects.filter(id=order_id).exists():
            raise serializers.ValidationError("Order Not Found")

        if Order.objects.get(id=order_id).is_fully_paid:
            raise serializers.ValidationError("Order Already Fully Paid")

        if not OrderItem.objects.filter(order__id=order_id).exists():
            raise serializers.ValidationError("Order Has No Items Yet")    

        if amount <= 0:
            raise serializers.ValidationError("Amount Too Low To Process")

        if amount != Order.objects.get(id=order_id).order_total:
            raise serializers.ValidationError(f"Amount does not match order total {Order.objects.get(id=order_id).order_total}")

        return attrs


class ViewCartSerializer(serializers.Serializer):
    order_id = serializers.UUIDField()


    def validate_order_id(self, value):

        print(f"Validator Ran : {value}")

        try:
            uuid.UUID(str(value))
        except Exception as e:
            raise serializers.ValidationError(f"Invalid order id {e}")    

        if not Order.objects.filter(id=value).exists():
            raise serializers.ValidationError("Order Not Found>>")
        return value


class RegenerateCartSerializer(serializers.Serializer):
    order_id = serializers.UUIDField()
    order_items = serializers.ListField(child=serializers.DictField())

    def validate(self, attrs):

        print(f"Running Validator !!!!")

        order_id = attrs.get('order_id')
        order_items = attrs.get('order_items')

        if not Order.objects.filter(id=order_id).exists():
            raise serializers.ValidationError("Order Not Found")

        for item in order_items:
            if not OrderItem.objects.filter(id=item.get('id')).exists():
                raise serializers.ValidationError("Order Item Not Found")

        for item in order_items:
            if OrderItem.objects.get(id=item.get('id')).paid_off:
                raise serializers.ValidationError("This Item Has Already Been Paid Off.")   

        return attrs  

class AppendToOrderSerializer(serializers.Serializer):
    order_id = serializers.UUIDField()
    product_id = serializers.UUIDField()
    quantity = serializers.IntegerField()

    def validate(self, attrs):

        order_id = attrs.get('order_id')
        order_items = attrs.get('order_items')

        if not Order.objects.filter(id=order_id).exists():
            raise serializers.ValidationError("Order Not Found")

        if not Product.objects.filter(id=attrs.get("product_id")).exists():
            raise serializers.ValidationError("Product Not Found")

        return attrs    

class BillSerializer(serializers.Serializer):
    order = serializers.CharField(label='Order ID') 

    def validate(self, attrs):
        order_id = attrs['order']
        order = Order.objects.filter(id=order_id).filter(saved=True).first()
        print(order)
        print(order_id)
        if order is None:
            raise serializers.ValidationError("Order Not Found")
        attrs['order'] = Order.objects.get(id=order_id)
        return attrs


class TransactionOrderItemsSerializer(serializers.ModelSerializer):
    
    class Meta:
        model = OrderItem
        fields = (
            'id',
            'quantity',
            'product'
        )

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        representation['name'] = instance.product.name
        representation['quantity'] = instance.quantity
        representation['amount'] = instance.product.price
        return representation
