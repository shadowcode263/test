import datetime

from django.utils import timezone

from users.models import User


def generate_jwt_payload(user: User, otp_verified: bool = False) -> dict:
    payload = {}
    if otp_verified:
        payload = {
            "access": {
                "type": "access",
                "__value": str(user.id),
                "name": user.get_full_name(),
                "role": user.role,
                "is_verified": user.is_verified,
                "is_active": user.is_active,
                "iat": timezone.now(),
                "exp": timezone.now() + datetime.timedelta(hours=2),
                "iss": "IntelliDevs",
                "otp_verified": True
            },
            "refresh": {
                "type": "refresh",
                "__value": str(user.id),
                "iat": timezone.now(),
                "exp": timezone.now() + datetime.timedelta(hours=2),
                "iss": "IntelliDevs",
            }
        }
    else:
        payload = {
            "__value": str(user.id),
            "name": user.get_full_name(),
            "role": user.role,
            "is_verified": user.is_verified,
            "is_active": user.is_active,
            "iat": timezone.now(),
            "exp": timezone.now() + datetime.timedelta(minutes=5),
            "iss": "IntelliDevs",
            "otp_verified": False
        }
    return payload
