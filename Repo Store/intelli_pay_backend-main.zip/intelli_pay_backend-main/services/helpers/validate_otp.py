from services.helpers.generate_otp import generate_otp


def validate_otp(otp: str, shared_secret: str) -> bool:
    return otp == generate_otp(shared_secret)
