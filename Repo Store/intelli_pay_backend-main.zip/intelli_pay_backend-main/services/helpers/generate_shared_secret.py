import secrets


def generate_shared_secret() -> str:
    return secrets.token_hex(16)
