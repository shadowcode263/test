import hmac


def dynamic_truncation(value: hmac.HMAC, length: int) -> str:
    bitstring = bin(int(value.hexdigest(), base=16))
    last_four_bits = bitstring[-4:]
    offset = int(last_four_bits, base=2)
    chosen_32_bits = bitstring[offset * 8: offset * 8 + 32]
    full_otp = str(int(chosen_32_bits, base=2))
    return full_otp[-length:]
