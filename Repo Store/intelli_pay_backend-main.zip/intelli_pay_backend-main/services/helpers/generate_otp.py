import hashlib
import hmac
import math
import time

from services.helpers.dynamic_truncation import dynamic_truncation


def generate_otp(shared_secret: str, length: int = 6) -> str:
    now_in_seconds = math.floor(time.time())
    step_in_seconds = 300
    t = math.floor(now_in_seconds / step_in_seconds)
    hash_value = hmac.new(
        bytes(shared_secret, encoding="utf-8"),
        t.to_bytes(length=8, byteorder="big"),
        hashlib.sha256
    )

    return dynamic_truncation(hash_value, length)
