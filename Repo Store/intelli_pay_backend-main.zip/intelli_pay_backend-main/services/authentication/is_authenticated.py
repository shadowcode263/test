from django.conf import settings
from django.http import JsonResponse
from jwt import ExpiredSignatureError, DecodeError
from rest_framework import exceptions
from rest_framework.authentication import BaseAuthentication
import jwt
from django.utils.translation import gettext_lazy as _

from users.models import User


class IsAPIAuthenticated(BaseAuthentication):
    def authenticate(self, request):
        print("REQUEST DATA: ", request.data)
        header = request.headers.get("Authorization")

        # Check if required authentication header is present
        if header is None:
            return None

        header_values = header.split(" ")

        if len(header_values) == 2:
            # Get the bearer text --> Format: Bearer XXXIX
            bearer = header_values[0]
            # Get the actual token from the header value
            token = header_values[1]
            try:
                # Decode token
                decoded = jwt.decode(token, options={"require": ["exp", "iat", "iss"]}, key=settings.JWT_SECRET, verify=True)

                if decoded.get('type') != 'access':
                    msg = _('Invalid Token Type')
                    raise exceptions.AuthenticationFailed(msg)

                if not decoded.get('otp_verified'):
                    msg = _('User hasn\'t verified otp.')
                    raise exceptions.AuthenticationFailed(msg)

                user_id = decoded.get("__value")
                user = User.get_user(user_id)

                if user is None:
                    msg = _('Token doesn\'t represent any user.')
                    raise exceptions.AuthenticationFailed(msg)

                return user, None
            except ExpiredSignatureError as e:
                msg = _('Invalid or Expired Token.')
                raise exceptions.AuthenticationFailed(msg)
            except DecodeError as e:
                msg = _('Token Decoding Failure')
                raise exceptions.AuthenticationFailed(msg)
        else:
            msg = _('WHO ARE YOU? LETS TALK LIKE ADULTS.')
            raise exceptions.AuthenticationFailed(msg)


class APIAuthenticationForOtp(BaseAuthentication):
    def authenticate(self, request):
        header = request.headers.get("Authorization")

        # Check if required authentication header is present
        if header is None:
            msg = _('WHO ARE YOU? LETS TALK LIKE ADULTS.')
            raise exceptions.NotAuthenticated(msg)

        header_values = header.split(" ")

        if len(header_values) == 2:
            # Get the bearer text --> Format: Bearer XXXIX
            bearer = header_values[0]
            # Get the actual token from the header value
            token = header_values[1]
            try:
                # Decode token
                decoded = jwt.decode(token, options={"require": ["exp", "iat", "iss"]}, key=settings.JWT_SECRET, verify=True)

                if decoded.get('otp_verified'):
                    msg = _('Given token cannot be used for otp validation.')
                    raise exceptions.AuthenticationFailed(msg)

                user_id = decoded.get("__value")
                user = User.get_user(user_id)

                if user is None:
                    msg = _('Token doesn\'t represent any user.')
                    raise exceptions.AuthenticationFailed(msg)

                return user, None
            except ExpiredSignatureError as e:
                msg = _('Invalid or Expired Token.')
                raise exceptions.AuthenticationFailed(msg)
            except DecodeError as e:
                msg = _('Token Decoding Failure')
                raise exceptions.AuthenticationFailed(msg)
        else:
            msg = _('WHO ARE YOU? LETS TALK LIKE ADULTS.')
            raise exceptions.AuthenticationFailed(msg)
