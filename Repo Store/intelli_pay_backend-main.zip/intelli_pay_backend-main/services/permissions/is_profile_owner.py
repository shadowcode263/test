from rest_framework.permissions import BasePermission


class IsProfileOwner(BasePermission):
    message = "You must be the owner of this profile."

    def has_object_permission(self, request, view, obj):
        return obj == request.user
