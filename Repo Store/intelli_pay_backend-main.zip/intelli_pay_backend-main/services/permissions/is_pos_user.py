from rest_framework.permissions import BasePermission


class IsPOSUser(BasePermission):
    message = "You must be an POS User to access this resource."

    def has_permission(self, request, view):
        print("USER ROLE: ", request.user.role)
        return request.user.role.lower() == 'pos_user'