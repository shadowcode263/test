from rest_framework.permissions import BasePermission


class IsProfileOwnerOrAdmin(BasePermission):
    message = "You must be the owner of this profile or an admin."

    def has_object_permission(self, request, view, obj):
        # if profile owner
        if obj == request.user:
            return True
        # if admin
        if request.user.role.lower() == 'admin':
            return True   

        return False     
