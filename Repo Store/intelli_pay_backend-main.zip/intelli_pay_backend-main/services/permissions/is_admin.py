from rest_framework.permissions import BasePermission


class IsAdmin(BasePermission):
    message = "You must be an admin to access this resource."

    def has_permission(self, request, view):
        print("USER ROLE: ", request.user.role)
        return request.user.role.lower() == 'admin'