from rest_framework.permissions import BasePermission


class HasTerminal(BasePermission):
    message = "Your profile must have a terminal to access this resource."

    def has_permission(self, request, view):
        print("USER ROLE: ", request.user.role)
        if not request.user.get_pos_terminal():
            return False
        else:
            return True    