import requests
from decouple import config

class RatesService:

    def get_rates(self):

        url = config('RATES_API_URL')
        re = requests.get(url)

        if re.status_code == 200:
            return re.json()['data']
        else:
            return None, re.json()

    def calculate_amount(self, from_currency, to_currency, amount):
        rates = self.get_rates()

        if from_currency.lower() == 'zar' and to_currency.lower() == 'usd':
            rate = next(item for item in rates if item["from_currency"] == 'zar')
            return round((rate['converted_rate'] * amount), 2)
        if from_currency.lower() == 'usd' and to_currency.lower() == 'zar':
            rate = next(item for item in rates if item["from_currency"] == 'zar')
            return round((rate['rate'] * amount), 2)
        if from_currency.lower() == 'zwl' and to_currency.lower() == 'usd':
            rate = next(item for item in rates if item["from_currency"] == 'zwl')
            return round((rate['converted_rate'] * amount), 2)
        if from_currency.lower() == 'usd' and to_currency.lower() == 'zwl':
            rate = next(item for item in rates if item["from_currency"] == 'usd')
            return round((rate['rate'] * amount), 2)
        else:
            return None, {'message': 'Currency cant be resolved'}      


    def recalculate_order_total(self, order):

        if order.currency == order.category_currency:
            return order.recalculate_order_total()
        else:
            rates = self.get_rates()

        if order.currency.lower() == 'zar' and order.category_currency.lower() == 'usd':
            rate = next(item for item in rates if item["from_currency"] == 'zar')
            return order.recalculate_order_total(rate=rate['converted_rate'])

        elif order.currency.lower() == 'usd' and order.category_currency.lower() == 'zar':
            rate = next(item for item in rates if item["from_currency"] == 'zar')
            return order.recalculate_order_total(rate=rate['rate']) 

        elif order.currency.lower() == 'zwl' and order.category_currency.lower() == 'usd':
            rate = next(item for item in rates if item["from_currency"] == 'zwl')
            return order.recalculate_order_total(rate=rate['converted_rate'])

        elif order.currency.lower() == 'usd' and order.category_currency.lower() == 'zwl':
            rate = next(item for item in rates if item["from_currency"] == 'usd')
            return order.recalculate_order_total(rate=rate['rate'])

        elif order.currency.lower() == 'zwl' and order.category_currency.lower() == 'zar':
            rate = next(item for item in rates if item["from_currency"] == 'zwl')
            return order.recalculate_order_total(rate=rate['converted_rate'])    

        elif order.currency.lower() == 'zar' and order.category_currency.lower() == 'zwl':
            rate = next(item for item in rates if item["from_currency"] == 'zwl')
            return order.recalculate_order_total(rate=rate['rate'])    
        else:
            return None, {'message': 'Currency cant be resolved'}   