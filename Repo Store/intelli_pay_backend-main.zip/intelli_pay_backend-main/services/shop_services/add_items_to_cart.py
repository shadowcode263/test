import uuid
import json

from django.http import JsonResponse, Http404
import requests

from shop.models import OrderItem
from django.core import serializers
from merchant.models import Product, ProductCategory
from transaction.models import Transaction, TransactionType
from decouple import config


class BatchOrderService:

    def generate_unique_reference(self):
        return str(uuid.uuid4())[:12]

    def get_current_exchange_rate(self, currency):
        url = config('RATES_API_URL')   

        response = requests.get(url)

        if response.status_code == 200:
            return next(item for item in response.json()['data'] if item["from_currency"] == currency.lower())
        else:
            return None, response.json()

    def create_single_item(self, order, extra):
        
        product = Product.objects.filter(id=extra['product_id']).first()
        item = OrderItem(
            order=order,
            title=f'Order Item {product.name}',
            description=product.description,
            quantity=extra['quantity'],
            product=product
        )

        item.save()

        return serializers.serialize('json', [item])[1:-1]

    def calculate_single_item_cost(self, extra):
        product = Product.objects.filter(id=extra['product_id']).first()
        return extra.get('quantity') * product.price    

    def create_cart_batch_items(self, order, payload, request, save):
        total_cost = sum([self.calculate_single_item_cost(extra) for extra in payload]) 
        total_cost = round(total_cost, 2)      

        # Saving the order total
        order.total = total_cost
        order.currency = order.currency
        order.saved = save
        order.save()

        # Now creating transaction
        last_transaction = Transaction.objects.all().count()
        import random
        reference = str(last_transaction+  1) + str(random.randint(100, 999))
        transaction_type = TransactionType.objects.filter(code='MP').first()

        transaction = Transaction.objects.create(
            amount=total_cost,
            transaction_type=transaction_type,
            order=order,
            status='INITIATED',
            reference=reference,
            currency=order.currency,
            created_by=request.user
        )

        order.transaction = transaction
        order.save()
        [self.create_single_item(order, extra) for extra in payload]
        order_items_inst = OrderItem.objects.filter(order=order).all()
        print("Order",order_items_inst)
        print("Order",order)
        order_items = []
        for ord in order_items_inst:
            item = {}
            item["product"] = ord.product.name
            item["product_id"] = ord.product.id
            item["quantity"] = ord.quantity
            order_items.append(item)
            

        return {"total cost": total_cost , "transaction_id": transaction.reference,"order_items": order_items}



    