source venv/bin/activate
python manage.py rqworker intelli_pay_sms
