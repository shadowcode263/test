

from intelli_gateway.gateway_client import GatewayClient
from django_rq import job
from decouple import config


@job('intelli_pay_sms')
def send_sms(data):
    print('sending sms')
    client = GatewayClient(config("SMS_USERNAME"), config("SMS_PASSWORD"))
    client.authenticate()

    try:
        client.send_sms(message=f'{data["message"]}', receiver=data['to'], sender_id="TUMAI")
    except Exception as e:
        print(e)


# @job('intelli_pay')
# def send_otp(user, otp):
#     client = GatewayClient(config("SMS_USERNAME"), config("SMS_PASSWORD"))
#     client.authenticate()

#     message = f": Your security code is: {otp}." \
#               f" It expires in 5 minutes. Don't share this code with anyone."
#     phone_number = f"{user.mobile_number.country_code}{user.mobile_number.national_number}"
#     print("PHONE: ", phone_number)
#     client.send_sms(message=message, receiver=phone_number, sender_id="IAS")
#     client.send_email(body=message, setting_id="2819bdaa-6035-4e45-9d93-ce5d3724ec52", receiver_email=user.email,
#                       subject="Validate Login")