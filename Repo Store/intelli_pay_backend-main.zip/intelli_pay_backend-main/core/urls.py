from django.contrib import admin
from django.urls import path, include
from users.views import AuthTokenObtainPairView
from rest_framework_simplejwt.views import (
    TokenRefreshView,
)
from django.conf import settings
from django.conf.urls.static import static


urlpatterns = [
    path('admin/', admin.site.urls),

    path('api/v1/auth/authenticate/', AuthTokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('api/v1/token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    path('api/v1/merchants/', include('merchant.urls')),
    path('api/v1/users/', include('users.urls')),
    path('api/v1/shop/', include('shop.urls')),
    path('api/v1/transaction/', include('transaction.urls')),
    path('api/v1/', include('api.urls')),

]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
