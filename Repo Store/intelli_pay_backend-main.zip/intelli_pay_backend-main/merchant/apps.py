from django.apps import AppConfig
from django.db.models.signals import post_save
from django.dispatch import receiver
from decouple import config
import requests

class MerchantConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'merchant'
    
    def ready(self):
        from merchant.models import MerchantProfile
        @receiver([post_save], sender=MerchantProfile)
        def update_user(sender, instance, **kwargs):
            if not instance.user.registration_complete:
                print("User Saved : ", instance.user.registration_complete)
                #TODO: REGISTER WALLET
                profile = {
                    "name": instance.name, 
                    "contact_person": f"{instance.user.first_name}{instance.user.last_name}", 
                    "contact_phone": str(instance.user.mobile_number), 
                    "balance": 100000
                }
                try:
                    response = requests.post(url=f"{config('WALLET_API_URL')}api/v1/create/merchant/", json=profile)
                    if response.status_code == 200:
                        response = response.json()
                        instance.user.registration_complete = True
                        instance.merchant_code = response['message']['merchant_code']
                        instance.user.merchant_code = response['message']['merchant_code']
                        instance.user.save()
                        instance.save()
                except Exception as e:
                    print("ERROR: ", e)