from rest_framework.permissions import BasePermission
class HasChangedPassword(BasePermission):
    message = 'You are still using the default password. You have to change your password before continuing!'
    """
    Allows access only users that have changed their password.
    """

    def has_permission(self, request, view):
        return bool(request.user and request.user.has_used_default_password)
