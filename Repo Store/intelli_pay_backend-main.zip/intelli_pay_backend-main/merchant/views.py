from unicodedata import category
from urllib import response
from django.shortcuts import render
from rest_framework import viewsets
from rest_framework.views import APIView
from django.http import JsonResponse, Http404
from rest_framework.decorators import action
from django.db.models import Q
from merchant.models import MerchantProfile, OperatorProfile, POSTerminal, BankAccount, ProductCategory
from merchant.permissions import HasChangedPassword
from merchant.serializers import *
from rest_framework.permissions import IsAuthenticated
from services.permissions.is_admin import IsAdmin
from services.permissions.is_merchant_profile_owner import IsMerchantOwnerOrAdmin
from users.serializers import UserSerializer
from users.models import User

class MerchantProfileViewSet(APIView):
    """
    Merchant Profile ViewSet
    """
    permission_classes = [IsAuthenticated,]
    serializer_class = MerchantProfileSerializer
    model = MerchantProfile

    # def get_object(self):
    #     try:
    #         return self.model.objects.get(user=self.request.user)
    #     except Exception as e:
    #         raise Http404    

    def get(self, request):
        merchants = MerchantProfile.objects.filter(user=request.user)
        data = MerchantProfileSerializer(merchants, many=True).data
        return JsonResponse(
            status=200,
            data=data, safe=False
        )

    def patch(self, request):
        
        try:
            profile = MerchantProfile.objects.get(user=request.user)
        except Exception as e:
            raise Http404('Merchant profile not found')

        serializer = self.serializer_class(profile, data=request.data,
                                           partial=True)  # set partial=True to update a data partially
        if serializer.is_valid():
            serializer.update(profile, validated_data=request.data)
            return JsonResponse(
                status=204,
                data={
                    "status": True,
                    "message": "Successfully updated user",
                    "data": serializer.data,
                    "issues": None
                }
            )
        else:
            return JsonResponse(
                status=400,
                data={
                    "status": False,
                    "message": "Invalid Data",
                    "data": None,
                    "issues": serializer.errors
                }
            )    


class OperatorProfilesView(APIView):

    serializer_class = UserSerializer

    def get(self, request):

        return JsonResponse(
            status=200,
            data={
                "status": True,
                "message": "Success",
                "data": self.serializer_class(
                    User.objects.filter(
                        parent_code=request.user.parent_code, is_deleted=False).filter(Q(role='POS_USER')|Q(role='TOP_UP_USER')), many=True).data,
                "issues": None
            }
        )

class OperatorProfileAddView(viewsets.ModelViewSet):
    permission_classes = (IsAuthenticated, IsMerchantOwnerOrAdmin, HasChangedPassword)
    serializer_class = OperatorProfileSerializer
    queryset = OperatorProfile.objects.all()

    def patch(self, request, *args, **kwargs):
        
        operator_profile = self.get_object()
                  
        serializer = self.serializer_class(operator_profile, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.update(operator_profile, validated_data=request.data)

            return JsonResponse(
                status=201,
                data={
                    "status": True,
                    "message": "Successfully created operator profile",
                    "data": {
                        "operator_profile": serializer.data,
                    },
                    "issues": None
                }
            )
        else:
            return JsonResponse(
                status=400,
                data={
                    "status": False,
                    "message": "Invalid Data",
                    "data": None,
                    "issues": serializer.errors
                }
            )

    def delete(self, request, *args, **kwargs):
            
        operator_profile = self.get_object()
        
        try:
            operator_profile.soft_delete()
            return JsonResponse(
                status=204,
                data={
                    "status": True,
                    "message": "Successfully deleted operator profile",
                    "data": None,
                    "issues": None
                }
            )

        except Exception as e:
            return JsonResponse(
                status=400,
                data={
                    "status": False,
                    "message": f"Failed to delete operator profile {e}",
                    "data": None,
                    "issues": None
                }
            )    



class POSTerminalViewset(viewsets.ModelViewSet):
    serializer_class = POSUpdateTerminalSerializer
    permission_classes = (IsAuthenticated, IsAdmin, HasChangedPassword)

    def get_queryset(self):
        return POSTerminal.objects.filter(merchant=self.request.user.merchant_profile)




class AssignPOSTerminal(APIView):
    """
    Assign POS Terminal ViewSet
    """
    model = POSTerminal
    permission_classes = [IsAuthenticated, HasChangedPassword]
    serializer_class = POSTerminalAssignmentSerializer

    def post(self, request):
        """
        This view should return a list of all the terminals
        for the currently authenticated merchant admin user.
        """
 

        try:
            payload = self.serializer_class(data=request.data)
            
            if payload.is_valid():
                
                print(f"\n\n\n\nPayload {payload.data} \n\n\n\n")

                terminal = POSTerminal.objects.get(pos_id=payload.data['terminal_pos_id'])
                operator_profile = OperatorProfile.objects.get(id=payload.data['operator_profile_id'])

                terminal.operator_profile = operator_profile
                terminal.save()

                return JsonResponse(
                    status=200,
                    data={
                        "status": True,
                        "message": "Successfully assigned terminal",
                        "data": None,
                        "issues": None
                    }
                )
            else:
                return JsonResponse(
                    status=400,
                    data={
                        "status": False,
                        "message": "Invalid Data",
                        "data": None,
                        "issues": payload.errors
                    }
                )    
        except Exception as e:
            print(f"\n\n\nError {e} \n\n\n")
            return JsonResponse(
                status=500,
                data={
                    "status": False,
                    "message": "Internal Server Error",
                    "data": None,
                    "issues": str(e)
                }
            )


class ProductCategoryViewset(viewsets.ModelViewSet):
    serializer_class = ProductCategorySerializer
    permission_classes = (IsAuthenticated, IsMerchantOwnerOrAdmin, HasChangedPassword)
    queryset = ProductCategory.objects.all()

    def destroy(self, request, *args, **kwargs):
        category = self.get_object()
        products = Product.objects.filter(category=category).first()
        if products is not None:
              return JsonResponse(
                status=400,
                data={
                     "status": False,
                     "message": "Cannot delete category that has products",
                     "data": None,
                     "issues": None
                }
              )
        else:
            return super().destroy(request, *args, **kwargs)

    @action(detail=False, methods=['get'])
    def get_products_by_category(self, request):
        try:
            merchant = MerchantProfile.objects.filter(merchant_code=self.request.user.merchant_code).first()
            categories = ProductCategory.objects.filter(merchant=merchant, is_deleted=False).filter(~Q(quantity_in_stock=0)).all()            
            response_data = {}
            print(categories)
            for category in categories:                
                products = Product.objects.filter(category=category, is_deleted=False, ).all()
                products_list = []                
                for product in products:
                    category_products = {}
                    category_products['name'] = product.name
                    category_products['search_field'] = product.name.lower()
                    category_products['price'] = product.price
                    category_products['description'] = product.description
                    category_products['category_id'] = category.id
                    category_products['number_in_stock'] = category.in_stock
                    products_list.append(category_products)
                print(products_list)
                response_data[category.name] = products_list
            return JsonResponse(status=200, data=response_data)
        except Exception as e:
            return JsonResponse(
                status=500,
                data={
                    "status": False,
                    "message": "Internal Server Error",
                    "data": None,
                    "issues": str(e)
                }
            )
    def post(self, request):
        try:
            payload = self.serializer_class(data=request.data)
            if payload.is_valid():
                merchant = MerchantProfile.objects.filter(merchant_code=request.user.merchant_code).first()
                payload.validated_data['merchant'] = merchant
                payload.save()
                return JsonResponse(
                    status=200,
                    data={
                        "status": True,
                        "message": "Successfully created category",
                    }
                )
            else:
                return JsonResponse(
                    status=400,
                    data={
                        "status": False,
                        "message": "Invalid Data",
                        "data": None,
                        "issues": payload.errors
                    }
                )
        except Exception as e:
            return JsonResponse(
                status=500,
                data={
                    "status": False,
                    "message": "Internal Server Error",
                    "data": None,
                    "issues": str(e)
                }
            )
    
    def get_queryset(self):
        merchant = MerchantProfile.objects.filter(merchant_code=self.request.user.merchant_code).first()
        return ProductCategory.objects.filter(merchant=merchant, is_deleted=False).all()

class ProductViewset(viewsets.ModelViewSet):
    serializer_class = ProductSerializer
    permission_classes = (IsAuthenticated,)


    def get_queryset(self):
        merchant = MerchantProfile.objects.filter(merchant_code=self.request.user.merchant_code).first()
        queryset = Product.objects.filter(category__merchant=merchant).all()
        return queryset

    def destroy(self, request, pk):

        try:
            product = self.get_object()
            product.is_deleted = True
            product.save()
            product.soft_delete()
            return JsonResponse(
                status=204,
                data={
                    "status": True,
                    "message": "Successfully deleted product",
                    "data": None,
                    "issues": None
                }
            )
        except Exception as e:
            return JsonResponse(
                status=500,
                data={
                    "status": False,
                    "message": "Internal Server Error",
                    "data": None,
                    "issues": str(e)
                }
            )

    @action(detail=False, methods=['get'])
    def get_products_by_category(self, request):
        try:
            merchant = MerchantProfile.objects.filter(merchant_code=self.request.user.merchant_code).first()
            categories = ProductCategory.objects.filter(is_deleted=False).filter(merchant=merchant).all()
            response_data = {}
            print(categories)
            for category in categories:                
                products = Product.objects.filter(category=category, is_deleted=False).all()
                products_list = []                
                for product in products:
                    category_products = {}
                    category_products['product_id'] = product.id
                    category_products['name'] = product.name
                    category_products['search_field'] = product.name.lower()
                    category_products['price'] = product.price
                    category_products['description'] = product.description
                    category_products['category_id'] = category.id                    
                    products_list.append(category_products)
                print(products_list)
                response_data[category.name] = products_list
            return JsonResponse(status=200, data=response_data)
        except Exception as e:
            return JsonResponse(
                status=500,
                data={
                    "status": False,
                    "message": "Internal Server Error",
                    "data": None,
                    "issues": str(e)
                }
            )
class PaymentMethodViewset(viewsets.ModelViewSet):
    serializer_class = PaymentMethodsSerializer
    permission_classes = (IsAuthenticated, IsMerchantOwnerOrAdmin, HasChangedPassword)
    queryset = PaymentMethod.objects.all()

    def destroy(self, request, *args, **kwargs):
        payment_method = self.get_object()
        payment_method.is_active = False
        payment_method.save()
        return JsonResponse(data='delete success', status=200)


class ToggleProductStock(APIView):

    permission_classes = (IsAuthenticated, IsMerchantOwnerOrAdmin, HasChangedPassword)
    model = Product

    def get(self, request, product_id):  

        try:
            product = self.model.objects.get(id=product_id)
            product.is_in_stock = not product.is_in_stock
            product.save()
            return JsonResponse(
                status=200,
                data={
                    "status": True,
                    "message": "Successfully toggled product stock",
                    "data": {
                        "is_in_stock": product.is_in_stock,
                        "product_id": product.id
                    },
                    "issues": None
                }
            )
        except Exception as e:
            return JsonResponse(
                status=400, 
                data={
                    "status": False,
                    "message": "Invalid Data",
                    "data": None,
                    "issues": str(e)
                }
            )   




class FilterProductsView(APIView):
    serializer_class = FilterProductSerializer

    def post(self, request):

        serializer = self.serializer_class(data=request.data)

        if serializer.is_valid():
            print("Serializer------------", serializer)
            category = self.request.query_params.get('category')
            search_field = self.request.query_params.get('name')
            print(category, search_field)
           
            if category is not None:
                category = ProductCategory.objects.filter(id=category).first()
                print(category)
                products = Product.objects.filter(category=category, is_deleted=False).all()
            elif search_field is not None:
                products = Product.objects.filter(name__icontains=search_field, is_deleted=False).all()
            else:
                products = Product.objects.all()
            
            


            response_data = ProductsSerializer(products,context={"request":request}, many=True)

            return JsonResponse(
                status=200,
                data={
                    "status": True,
                    "message": "Successfully filtered products",
                    "data": response_data.data,
                    "issues": None
                }
            )
        else:
            return JsonResponse(
                status=400,
                data={
                    "status": False,
                    "message": "Invalid Data",
                    "data": None,
                    "issues": serializer.errors
                }
            )
                                




class FetchAllMerchants(APIView):
    """
        Fetch all merchants
    """
    model = MerchantProfile
    permission_classes = []
    serializer_class = MerchantProfileSerializer

    def get(self, request, *args, **kwargs):
        """
        This view should return a list of all the merchants
        """
        try:
            payload = self.serializer_class(data=self.model.objects.filter(is_merchant_active=True).all(), many=True)
            payload.is_valid()
            return JsonResponse(status=200, data={"merchants": payload.data, "exception": None})
        except Exception as e:
            return JsonResponse(status=500, data={"merchants": [], "exception": f"{e}"})


class AddBreakage(APIView):
    """
    Add soiled product
    """
    model = Product
    permission_classes = [IsAuthenticated, HasChangedPassword]
    serializer_class = ProductBreakageSerializer

    def post(self, request):
        try:
            payload = self.serializer_class(data=request.data)
            
            if payload.is_valid():
                return JsonResponse(
                    status=200,
                    data={
                        "status": True,
                        "message": "Successfully added breakage",
                        "data": None,
                        "issues": None
                    }
                )
            else:
                return JsonResponse(
                    status=400,
                    data={
                        "status": False,
                        "message": "Invalid Data",
                        "data": None,
                        "issues": payload.errors
                    }
                )    
        except Exception as e:
            print(f"\n\n\nError {e} \n\n\n")
            return JsonResponse(
                status=500,
                data={
                    "status": False,
                    "message": "Internal Server Error",
                    "data": None,
                    "issues": str(e)
                }
            )
