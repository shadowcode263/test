from rest_framework import serializers
from phonenumber_field.serializerfields import PhoneNumberField
from django_countries.serializer_fields import CountryField

from merchant.models import MerchantProfile, OperatorProfile, POSTerminal, BankAccount, PaymentMethod, ProductCategory, Product
from users.models import User

class MerchantProfileSerializer(serializers.ModelSerializer):
    country = CountryField()
    phone_number = PhoneNumberField()
    class Meta:
        model = MerchantProfile
        fields = (
            'name', 
            'country', 
            'phone_number',
            'address',
            'merchant_code',
            'logo'
        )


class POSTerminalSerializer(serializers.ModelSerializer):
    
    class Meta:
        model = POSTerminal

        fields = (
            'id',
            'pos_id',
            'last_logged_device',
            'last_active',
            'operator_profile',
            'merchant'
        )

    def validate(self, attrs):

        if not attrs.get('operator_profile'):
            raise serializers.ValidationError('Operator Profile is required')  

        if POSTerminal.objects.filter(operator_profile=attrs.get('operator_profile')).exists():
            raise serializers.ValidationError('Terminal Already Assgigned to Operator')

        return attrs     

class POSUpdateTerminalSerializer(serializers.ModelSerializer):
    
    class Meta:
        model = POSTerminal

        fields = (
            'id',
            'pos_id',
            'last_logged_device',
            'last_active',
            'operator_profile',
            'merchant'
        )

        extra_kwargs = {
            'pos_id': {'required': False},
            'last_logged_device': {'required': False},
            'last_active': {'required': False},
            'operator_profile': {'required': False},
            'merchant': {'required': False},
        }
class POSTerminalAssignmentSerializer(serializers.Serializer):
    terminal_pos_id = serializers.CharField(max_length=200)
    operator_profile_id = serializers.UUIDField()

    def validate_terminal_pos_id(self, value):
        if not POSTerminal.objects.filter(pos_id=value).exists():
            raise serializers.ValidationError('Terminal Does Not Exist')

        # if POSTerminal.objects.filter(pos_id=value).first().operator_profile:
        #     raise serializers.ValidationError("This Terminal Has Already Been Assigned")    
   
        return value

    def validate_operator_profile_id(self, value):

        # try:
        #     uuid.UUID(value, version=4)
        # except ValueError:
        #     raise serializers.ValidationError('Invalid Operator Profile ID')    

        if not OperatorProfile.objects.filter(pk=value).exists():
            raise serializers.ValidationError('Operator Profile Not Found')
        return value      

        if OperatorProfile.objects.filter(pk=value).first().fetch_terminal():
            raise serializers.ValidationError("This Operator Has Already Been Assigned A Terminal.")   


class ProductCategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = ProductCategory
        fields = (
            'id',
            'name',
            'description',
            'merchant',
            'currency'
        )

        extra_kwargs = {
            'currency': {'required': True}
        }

class ProductSerializer(serializers.ModelSerializer):
    class Meta:
        model = Product
        fields = (
            'id',
            'name',
            'description',
            'category',
            'price',
            'is_in_stock',
            'picture_1',
            'quantity_in_stock',
            'total_sold'
        )

    def to_representation(self, instance):
        data = super().to_representation(instance)
        data['currency'] = instance.category.currency
        data['category'] = instance.category.name
        return data

class ProductsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Product
        fields = (
            'id',
            'name',
            'description',
            'category',
            'price',
            'is_in_stock',
            'picture_1',
            'quantity_in_stock'
        )

    def to_representation(self, instance):
        data = super().to_representation(instance)
        data['currency'] = instance.category.currency
        return data


class OperatorProfileSerializer(serializers.ModelSerializer):

    class Meta:
        model = OperatorProfile
        fields = (
            'id',
            'first_name',
            'last_name',
            'phone_number',
        )
    
    extra_kwargs = {
        'id': {'required': True},
        'first_name': {'required': False},
        'last_name': {'required': False},
        'phone_number': {'required': False},
    }


    def validate_id(self, value):
        if not OperatorProfile.objects.filter(pk=value).exists():
            raise serializers.ValidationError('Operator Profile Not Found')
        return value

    def update(self, instance, validated_data):

        if validated_data.get('first_name'):
            instance.first_name = validated_data.get('first_name')

        if validated_data.get('last_name'):
            instance.last_name = validated_data.get('last_name')

        if validated_data.get('phone_number'):
            instance.phone_number = validated_data.get('phone_number')

        instance.save()

        return instance


class PaymentMethodsSerializer(serializers.ModelSerializer):
    class Meta:
        model = PaymentMethod
        fields = (            
            'name',
            'is_active',            
        )

    

class FilterProductSerializer(serializers.Serializer):

    name = serializers.CharField(max_length=200, required=False)
    category = serializers.UUIDField(required=False)

    def validate_category(self, value):
        if not ProductCategory.objects.filter(pk=value).exists():
            raise serializers.ValidationError('Product Category Not Found')
        return value

    def validate_price(self, value):
        if not Product.objects.filter(price=value).exists():
            raise serializers.ValidationError('Product Category Price Not Found')
        return value

class UserBalanceSerializer(serializers.Serializer):
    phone_number = serializers.CharField(max_length=200, required=True)
    merchant_code = serializers.CharField(max_length=200, required=True)

    def validate(self, attrs):
        if not MerchantProfile.objects.filter(merchant_code=attrs.get('merchant_code')).exists():
            raise serializers.ValidationError('Merchant Not Found')

        return attrs


class ProductBreakageSerializer(serializers.Serializer):
    product_id = serializers.CharField(max_length=200, required=True)
    quantity = serializers.IntegerField(required=True)

    def validate(self, attrs):
        product =  Product.objects.filter(id=attrs.get('product_id')).first()
        if not product:
            raise serializers.ValidationError('Product Not Found')
        product.add_breakage(attrs.get('quantity'))
        return attrs