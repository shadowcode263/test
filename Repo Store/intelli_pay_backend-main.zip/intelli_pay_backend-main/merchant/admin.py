from django.contrib import admin

from merchant.models import *

# class ProductAdmin(admin.ModelAdmin):
#     list_display = ('name', 'category', 'price', 'created', 'is_deleted')
#     list_filter = ('category', 'created')
#     search_fields = ('name', 'category__name')


# class MerchantProfileAdmin(admin.ModelAdmin):
#     list_display = ('name', 'phone_number', 'address', 'merchant_code', 'user')




@admin.register(OperatorProfile, POSTerminal,BankAccount, ProductCategory, Product, MerchantProfile, PaymentMethod,)
class UniversalAdmin(admin.ModelAdmin):
    exclude = ('deleted_at',)

    def get_list_display(self, request):
        return [field.name for field in self.model._meta.concrete_fields]
