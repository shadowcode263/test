from django.urls import path, include
from rest_framework import routers

from merchant.views import *

router = routers.DefaultRouter()
router.register('terminals', POSTerminalViewset, basename='terminals')
router.register('categories', ProductCategoryViewset, basename='categories')
router.register('products', ProductViewset, basename='products')
router.register('payment_methods', PaymentMethodViewset, basename='payment_methods')
router.register('operator_profiles', OperatorProfileAddView, basename='operator_profile')


urlpatterns = [
    path('', include(router.urls)),
    path('merchant_profile/', MerchantProfileViewSet.as_view()),
    path('pos_operators/', OperatorProfilesView.as_view()),
    # path('pos_operators/<uuid:id>/', OperatorProfileAddView.as_view({'patch': 'delete'})),
    path('pos_terminals/assign/', AssignPOSTerminal.as_view()), 
    path('filter/products/', FilterProductsView.as_view()),
    path('products/add/breakage/', AddBreakage.as_view()),

]
