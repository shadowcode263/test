import uuid

from django.db import models
from django_countries.fields import CountryField
from phonenumber_field.modelfields import PhoneNumberField
from django.conf import settings
from django.utils import timezone

from core.model import SoftDeleteModel


class BankChoiceSet(models.TextChoices):
    AFC = 'AFC', ('AFC')
    AGRIBANK = 'AGRIBANK', ('AGRIBANK')
    BANCABC = 'BANC ABC', ('BANC ABC')
    CABS = 'CABS', ('CABS')
    CBZ = 'CBZ', ('CBZ')
    ECOBANK = 'ECOBANK', ('ECOBANK')
    FBC = 'FBC', ('FBC')
    FBCBS = 'FBC BS', ('FBC BS')
    FIRSTCAPITAL_BANK = 'FIRST CAPITAL BANK', ('FIRST CAPITAL BANK')
    GETBUCKS = 'GETBUCKS', ('GETBUCKS')
    NEDBANK = 'NEDBANK', ('NEDBANK')
    METBANK = 'METBANK', ('METBANK')
    MFS = 'MFS', ('MFS')
    NBS = 'NBS', ('NBS')
    NMB = 'NMB', ('NMB')

    POSB = 'POSB', ('POSB')
    STANBICBANK = 'STANBIC BANK', ('STANBIC BANK')
    STANDARDCHARTERED = 'STANDARD CHARTERED', ('STANDARD CHARTERED')
    STEWARDBANK = 'STEWARD BANK', ('STEWARD BANK')
    ONEMONEY = 'ONEMONEY', ('ONEMONEY')
    EMPOWERBANK = 'EMPOWER BANK', ('EMPOWER BANK')
    ZB_BANK = 'ZB BANK', ('ZB BANK')


class CurrencyChoiceSet(models.TextChoices):
    USD = 'USD', ('USD')
    ZWL = 'ZWL', ('ZWL')
    ZAR = 'ZAR', ('ZAR')


class MerchantProfile(SoftDeleteModel):
    """
    Merchant Business Profile
    """
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=100, unique=True)
    country = CountryField()
    phone_number = models.CharField(max_length=20, blank=True, null=True)
    address = models.CharField(max_length=255)
    merchant_code = models.CharField(max_length=20, unique=True, null=True, blank=True)
    user = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='merchant_profile'
    )
    logo = models.ImageField(null=True, blank=True)
    is_active = models.BooleanField(default=True)
    is_merchant_active = models.BooleanField(default=True)

    def __str__(self):
        return f'{self.name}  - {self.user.first_name} {self.user.last_name}'
    
    # get by merchant code
    @classmethod
    def get_by_merchant_code(cls, merchant_code):
        return cls.objects.filter(merchant_code=merchant_code).first()
    
    @classmethod
    def get_by_user(cls, user):
        return cls.objects.filter(user=user).first()

class BankAccount(SoftDeleteModel):
    """ 
    Merchant Bank Account Details 
    """
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    account_number = models.CharField(max_length=30)
    destination_bank = models.CharField(max_length=100, default='', choices=BankChoiceSet.choices)
    merchant = models.ForeignKey(
        MerchantProfile,
        on_delete=models.CASCADE,
        related_name='bank_accounts'
    )

    @property
    def masked_account_number(self):
        """
        Masks account number to only show the last N digits
        """
        pass

    def __str__(self):
        return f'{self.account_number}'


class OperatorProfile(SoftDeleteModel):
    """
    POS Operator Personal Profile
    """
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    phone_number = PhoneNumberField()
    user = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
    )
    merchant = models.ForeignKey(
        MerchantProfile, 
        on_delete=models.CASCADE,
        related_name='operators'
    )

    def __str__(self):
        return f'{self.phone_number}'


    def fetch_terminal(self):
        """
        Fetches all terminal associated with this operator
        """
        return POSTerminal.objects.filter(operator_profile=self).first()


class POSTerminal(SoftDeleteModel):
    """
    Represents the Merchant POS Terminal
    where customer transactions take place
    """
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    pos_id = models.CharField(max_length=200)
    last_logged_device = models.CharField(max_length=100)
    last_active = models.DateTimeField(auto_now_add=True)
    operator_profile = models.OneToOneField(
        OperatorProfile, 
        on_delete=models.SET_NULL,
        null=True
    )
    merchant = models.ForeignKey(
        MerchantProfile, 
        on_delete=models.CASCADE,
        related_name='pos_terminals'
    )

    class Meta:
        ordering= ['pk']

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        self.pos_id = f'IntelliPOS-{self.pk}'
        super().save(update_fields=['pos_id'])
  
    def __str__(self):
        return f'{self.pos_id}'

   

    @property
    def operator(self):
        return self.operator_profile

    @operator.setter
    def operator(self, operator):
        """Sets POS Operator"""
        if operator:
            operator = OperatorProfile.objects.get(pk=operator)
            self.operator_profile = operator
        else:
            self.operator_profile = None


class ProductCategory(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    created = models.DateTimeField(auto_now=True, auto_now_add=False)
    name = models.CharField(max_length=150)
    description = models.TextField(max_length=200)
    image = models.ImageField(null=True, blank=True)
    merchant = models.ForeignKey(MerchantProfile, on_delete=models.RESTRICT)
    is_deleted = models.BooleanField(default=False)
    currency = models.CharField(max_length=3, choices=CurrencyChoiceSet.choices, default=CurrencyChoiceSet.USD)


    def __str__(self):
        return f"{self.name} - {self.merchant.name}"

    def get_children(self):
        return Product.objects.filter(category=self)    

    class Meta:
        ordering = ['name']
        verbose_name = 'Product Category'
        verbose_name_plural = 'Product Categories'



class Product(SoftDeleteModel):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    created = models.DateTimeField(auto_now=True, auto_now_add=False)
    category = models.ForeignKey(ProductCategory, on_delete=models.RESTRICT)
    name = models.CharField(max_length=150)
    description = models.TextField()
    product_type = models.CharField(max_length=150, default='Normal',choices=(('Normal', 'Normal'), ('Monetary', 'Monetary')))
    price = models.FloatField(default=0)
    picture_1 = models.ImageField(blank=False, null=True, upload_to='pictures')
    picture_2 = models.ImageField(blank=False, null=True, upload_to='pictures')
    picture_3 = models.ImageField(blank=False, null=True, upload_to='pictures')
    is_in_stock = models.BooleanField(default=False)
    is_deleted = models.BooleanField(default=False)
    quantity_in_stock = models.PositiveIntegerField(default=0)
    breakages = models.PositiveIntegerField(default=0)
    total_sold = models.PositiveIntegerField(default=0)

    def __str__(self):
        return f"{self.name} - {self.category.name} - {self.category.merchant.name}"

    class Meta:
        ordering = ['name']
        verbose_name_plural = "Products"


    @classmethod
    def get_store_products(cls, merchant):
        return cls.objects.filter(category__merchant=merchant)

    
    def add_breakage(self, quantity):
        self.breakages += quantity
        self.quantity_in_stock -= quantity
        self.save()

class PaymentMethod(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name  = models.CharField(max_length=100)
    # merchant = models.ForeignKey(MerchantProfile, on_delete=models.CASCADE)
    description = models.TextField(max_length=200)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.name}"


    @classmethod
    def filter_by_name(cls, name):
        return cls.objects.filter(name=name).first()

# class Outlets(models.Model):
#     id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
#     code = models.CharField(max_length=100)
#     name = models.TextField(max_length=200)
#     is_active = models.BooleanField(default=True)

#     def __str__(self):
#         return f"{self.name}"


#     @classmethod
#     def filter_by_name(cls, name):
#         return cls.objects.filter(name=name).first()

