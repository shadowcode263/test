from ast import operator
from django.shortcuts import render
from api.clients import WalletsClient
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated
from django.http import JsonResponse, Http404
from django.db import transaction
from rest_framework.renderers import JSONRenderer
from rest_framework.parsers import JSONParser


from users.models import User
from merchant.models import MerchantProfile, OperatorProfile, BankAccount, POSTerminal
from users.serializers import *
from merchant.permissions import HasChangedPassword

from services.permissions.is_admin import IsAdmin
from services.permissions.is_profile_owner import IsProfileOwner
from services.exceptions.passwords import PasswordUsedException
from services.permissions.is_profile_owner_or_admin import IsProfileOwnerOrAdmin
from services.mailer.mailer import EmailService

from rest_framework_simplejwt.views import TokenObtainPairView
from users.serializers import AuthTokenObtainPairSerializer
from core.jobs import send_sms


class AuthTokenObtainPairView(TokenObtainPairView):
    serializer_class = AuthTokenObtainPairSerializer


class AdminRegistration(APIView):
    serializer_class = AdminRegistrationSerializer
    permission_classes = []

    def post(self, request):

        try:
            payload = self.serializer_class(data=request.data)

            if payload.is_valid():

                try:
                    with transaction.atomic():
                        user = User.objects.register_admin(request.data)
                        merchant_profile = MerchantProfile.objects.create(
                            user=user,
                            name=request.data.get('merchant_name'),
                            country="ZW",
                            phone_number=request.data.get('merchant_phone_number'),
                            address=request.data.get('merchant_address')
                        )
                      
                        bank_account = BankAccount.objects.create(
                            account_number=payload.data.get('account_number'),
                            destination_bank=payload.data.get('destination_bank'),
                            merchant=merchant_profile
                        )
                        try:
                            username = user.first_name[0] + user.last_name
                            
                            username_exists = User.objects.filter(username=username).first()
                            if username_exists:
                                import random
                                username = f"{username}{random.randint(10,99)}"
                            username = username.lower()
                            password = f"{username}@intelli_pay"
                            print("Username", username)
                            print("PASSWORD", password)
                            user.username = username.lower()
                            user.save()
                            send_sms.delay(
                                {
                                    "to": str(user.mobile_number), 
                                    "message": f"Hi {user.get_full_name().title()}, your TumaiPay merchant profile has been successfully created." 
                                           f"Your merchant password is {password}. Please login to your merchant account and change your password."
                                }
                            )
                        except Exception as e:
                            print(e)

                except Exception as e:
                    return JsonResponse(
                        status=500,
                        data={
                            "status": False,
                            "message": "Internal Server Error",
                            "data": None,
                            "issues": {
                                "exception": str(e)
                            }
                        }    
                    )        


                return JsonResponse(
                    status=201,
                    data={
                        "status": True,
                        "message": "Registration Successful",
                        "exception": None
                    }
                )
            else:
                return JsonResponse(
                    status=400,
                    data={
                        "status": False,
                        "message": "Registration Failed",
                        "exception": payload.errors
                    }
                )
        except Exception as e:
            return JsonResponse(
                status=500,
                data={
                    "status": False,
                    "message": "Server Exception",
                    "exception": {
                          "exception": str(e)
                    },
                    "data": None
                }
            )                           



class RegisterPOSUser(APIView):
    permission_classes = (IsAuthenticated, IsAdmin, HasChangedPassword)
    serializer_class = RegisterPosUserSerializer
    renderer_classes = [JSONRenderer]
    parser_classes = [JSONParser]

    def get_merchant_profile(self, user):
        merchant = MerchantProfile.objects.filter(user=user).first()
        if not merchant:
            raise Http404("Merchant Not Found")
        return merchant

    def post(self, request):

        try:
            payload = self.serializer_class(data=request.data)
            if payload.is_valid():
                with transaction.atomic():
                    try:   
                        import random                     
                        merchant = self.get_merchant_profile(request.user)    
                        username = request.data.get('first_name')[0] + request.data.get('last_name')
                        username_instance = User.objects.filter(username=username).first()
                        if username_instance:
                            username += str(User.objects.filter(username=username).count()) + str(random.randint(10,99))
                        username=username.lower()
                        user = User.objects.register_pos_user(request, username)
                        user.parent_code=request.user.parent_code
                        user.merchant_code=merchant.merchant_code
                        user.save()
                        operator = OperatorProfile(
                            user=user,
                            first_name=user.first_name,
                            last_name=user.last_name,
                            phone_number=user.mobile_number,
                            merchant=merchant
                        )
                        operator.save()
                        import random
                        pos_id = random.randint(1000, 9999)
                        print("Failure Point 6")
                        password = f"{user.username}@intelli_pay"
                        print(merchant, pos_id, operator)
                        terminal = POSTerminal(merchant=merchant,
                                    operator=operator.id, pos_id=pos_id)
                        terminal.save() 
                        print("Failure Point 7")
                        send_sms.delay({'to': str(user.mobile_number), 'message': f"Hi {user.first_name.title()}, your TumaiPay POS account has been successfully created. Your email is {user.email} and your password is {password}. Please login to your POS account and change your password."})
                        print("Failure Point 8")
                        return JsonResponse(
                            status=201,
                            data={
                                "status": True,
                                "message": "Registration Successful",
                                "operator_id": operator.id,
                                "pos_id": pos_id,
                                "merchant_id": merchant.id,
                                "except": None,
                                "data": {
                                    "user_id": user.id
                                }
                            }
                        )

                    except Exception as e:
                        return JsonResponse(
                            status=500,
                            data={
                                "status": False,
                                "message": "Internal Server Error",
                                "data": None,
                                "issues": {
                                    "exception": str(e)
                                }
                            }
                        )
            else:
                return JsonResponse(
                    status=400,
                    data={
                        "status": False,
                        "message": "Registration Failed",
                        "except": payload.errors
                    }
                )  
        except Exception as e:
            return JsonResponse(   
                status=500,
                data={
                    "status": False,
                    "message": "Server Exception",
                    "data": None,
                    "issues": {
                        "exception": str(e)
                    }
                }
            )


class UserPasswordResetView(APIView):
    permission_classes = (IsProfileOwner,)
    renderer_classes = [JSONRenderer]
    serializer_class = ChangePasswordSerializer

    def get_object(self, pk):
        user = User.objects.find_by_uuid(pk=pk)

        if not user:
            raise Http404
        return user

    def post(self, request, pk):
        try:

            serializer = self.serializer_class(data=request.data)

            if serializer.is_valid():
                # Check old password
                user = self.get_object(pk=pk)
                if not user.check_password(serializer.data.get("old_password")):
                    return JsonResponse(
                        status=400,
                        data={
                            "status": False,
                            "message": "Password Entered Is Incorrect",
                            "data": None,
                            "issues": None
                        }
                    )

                # set_password also hashes the password that the user will get
                message =  user.set_password(serializer.data.get("new_password"))
                if message.get("message", "") == 'Password reset complete!':
                    if not user.has_used_default_password:
                        user.has_used_default_password = True
                    user.save()
                    return JsonResponse(
                        status=200,
                        data={
                            "status": True,
                            "message": "Password Successfully Reset",
                            "data": None,
                            "issues": None
                        }
                    )
                return JsonResponse(
                        status=400,
                        data={
                            "status": True,
                            "message": message,
                            "data": None,
                            "issues": None
                        }
                    )

            else:
                return JsonResponse(
                    status=400,
                    data={
                        "status": False,
                        "message": "Invalid Data",
                        "data": None,
                        "issues": serializer.errors
                    }
                )
        except PasswordUsedException as e:
            return JsonResponse(
                status=400,
                data={
                    "status": False,
                    "message": "Password Already Used On This Account",
                    "data": None,
                    "issues": {
                        "exception": str(e)
                    }
                }
            )


class UserDetailView(APIView):
    permission_classes = (IsAuthenticated, IsProfileOwnerOrAdmin, HasChangedPassword)
    parser_classes = [JSONParser]
    renderer_classes = [JSONRenderer]
    serializer_class = UserSerializer

    def get_object(self, pk):
        user = User.objects.find_by_uuid(pk=pk)
        if not user:
            raise Http404
        return user

    def get(self, request, pk):
        user = self.get_object(pk=pk)
        user_data = self.serializer_class(user)

        return JsonResponse(
            status=200,
            data={
                "status": True,
                "message": "Successfully retrieved user",
                "data": user_data.data,
                "issues": None
            }
        )

    def patch(self, request, pk):
        user = self.get_object(pk=pk)
        serializer = self.serializer_class(user, data=request.data,
                                           partial=True)  # set partial=True to update a data partially
        if serializer.is_valid():
            serializer.update(user, validated_data=request.data)
            return JsonResponse(
                status=204,
                data={
                    "status": True,
                    "message": "Successfully updated user",
                    "data": serializer.data,
                    "issues": None
                }
            )
        else:
            return JsonResponse(
                status=400,
                data={
                    "status": False,
                    "message": "Invalid Data",
                    "data": None,
                    "issues": serializer.errors
                }
            )

    def delete(self, request, pk):

        instance = self.get_object(pk)
        instance.is_deleted = True
        instance.is_active = False
        instance.save()

        if instance.get_operator_profile():
            instance.get_operator_profile().soft_delete()

        return JsonResponse(
            status=204, data={"message": "User Deleted"}
        )


class UserListView(APIView):
    
    permission_classes = (IsAuthenticated, IsAdmin, HasChangedPassword)
    parser_classes = [JSONParser]
    renderer_classes = [JSONRenderer]
    serializer_class = UserSerializer

    def get(self, request):
        
        try:
            users = User.objects.filter(parent_code=request.user.parent_code, is_deleted=False).exclude(id=request.user.id)
            serializer = self.serializer_class(users, many=True)
            return JsonResponse(
                status=200,
                data={
                    "status": True,
                    "message": "Successfully retrieved users",
                    "data": serializer.data,
                    "issues": None
                }
            )
        except Exception as e:
            return JsonResponse(
                status=500,
                data={
                    "status": False,
                    "message": "Server Exception",
                    "data": None,
                    "issues": {
                        "exception": str(e)
                    }
                }
            )   


class UserLookup(APIView):    
    # permission_classes = (IsAuthenticated)
    parser_classes = [JSONParser]
    renderer_classes = [JSONRenderer]
    serializer_class = LookupSerializer
    client = WalletsClient()

    def get(self, request):
        serializer = self.serializer_class(data=request.data)
        if serializer.is_valid():
            response_data,status_code = self.client.lookup(
                phone_number=serializer.validated_data['phone_number'], 
                merchant_code=serializer.validated_data['merchant_code'],
            )
            response = {
                "status": status_code,
                "message": response_data
            }
            return JsonResponse(data=response, status=status_code)
        else:
            return JsonResponse(
                status=400,
                data={
                    "status": False,
                    "message": serializer.errors,
                }
            )
