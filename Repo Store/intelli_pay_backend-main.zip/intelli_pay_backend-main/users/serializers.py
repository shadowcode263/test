from rest_framework import serializers
from django.contrib.auth.password_validation import validate_password

from users.constants import COUNTRY_CODES
from users.models import User
from merchant.models import MerchantProfile, BankChoiceSet


from rest_framework_simplejwt.serializers import TokenObtainPairSerializer

class AuthTokenObtainPairSerializer(TokenObtainPairSerializer):
    def validate(self, attrs):
        print('LOGIN ATTEMPTS>>>>>>>>>> ', attrs)
        data = super().validate(attrs)
        refresh = self.get_token(self.user)

        data['refresh'] = str(refresh)
        data['access'] = str(refresh.access_token)

        # Add extra responses here
        data['username'] = self.user.username
        data['is_admin'] = True if  self.user.role == "ADMIN" else False
        merchant = MerchantProfile.get_by_merchant_code(merchant_code=self.user.merchant_code)
        data['merchant_id'] = merchant.id if merchant else None
        data['merchant_name'] = merchant.name
        data['merchant_code'] = self.user.merchant_code
        data['operator_name'] = f"{self.user.first_name} {self.user.last_name}"
        data['has_changed_default_password'] = self.user.has_used_default_password
        data['user_id'] = self.user.id
        return data



class AdminRegistrationSerializer(serializers.Serializer):
    first_name = serializers.CharField(max_length=100)
    last_name = serializers.CharField(max_length=100)
    mobile_number = serializers.CharField(max_length=20)
    email = serializers.EmailField()
    merchant_name = serializers.CharField(max_length=100)
    merchant_country = serializers.CharField(max_length=100)
    merchant_phone_number = serializers.CharField(max_length=20)
    merchant_address = serializers.CharField(max_length=100)
    destination_bank = serializers.ChoiceField(choices=BankChoiceSet.choices)
    account_number = serializers.CharField(max_length=30)

    # def create(self, validated_data):
    #     return RegistrationSerializer(**validated_data)

    def validate_account_number(self, value):
        if len(value) < 10:
            raise serializers.ValidationError("Invalid account number")

        return value

    def validate_email(self, value):
        if User.objects.find_by_email(value):
            raise serializers.ValidationError("Email already exists")
        return value    

    def validate_merchant_name(self, value):
        if MerchantProfile.objects.filter(name=value):
            raise serializers.ValidationError("Merchant name already exists")
        return value

    def validate_user_role(self, value):
        if value not in ['ADMIN', 'POS_USER']:
            raise serializers.ValidationError("Invalid user role")
        return value 

    def validate_merchant_phone_number(self, value):
        if len(value) < 10:
            raise serializers.ValidationError("Invalid mobile number")

        if MerchantProfile.objects.filter(phone_number=value):
            raise serializers.ValidationError("Merchant phone number already exists")

        return value

    


    def validate_merchant_country(self, value):
        if value not in COUNTRY_CODES:
            raise serializers.ValidationError("Invalid country")
        return value

    def validate_password(self, value):
        
        if len(value) < 8:
            raise serializers.ValidationError("Password must be at least 8 characters long")


        return value


class RegisterPosUserSerializer(serializers.Serializer):
    first_name = serializers.CharField(max_length=100)
    last_name = serializers.CharField(max_length=100)
    mobile_number = serializers.CharField(max_length=20)
    role = serializers.CharField(max_length=20,required=True)
   
    def validate(self,attrs):
        if attrs['role'] not in ['POS_USER','TOP_UP_USER']:
            raise serializers.ValidationError("Invalid user role")
        return attrs
    
    def validate_merchant_name(self, value):
        if MerchantProfile.objects.filter(name=value):
            raise serializers.ValidationError("Merchant name already exists")
        return value

    def validate_user_role(self, value):
        if value not in ['ADMIN', 'POS_USER','TOP_UP_USER']:
            raise serializers.ValidationError("Invalid user role")
        return value 

    def validate_mobile_number(self, value):
        if len(value) < 10:
            raise serializers.ValidationError("Invalid mobile number")

        if User.objects.filter(mobile_number=value):
            raise serializers.ValidationError("Phone number already exists")

        return value

    


class UserSerializer(serializers.ModelSerializer):

    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'first_name', 'last_name', 'role', 'mobile_number']

    def update(self, instance, validated_data):
        instance.email = validated_data.get('email', instance.email)
        instance.username = validated_data.get('username', instance.username)
        instance.first_name = validated_data.get('first_name', instance.first_name)
        instance.last_name = validated_data.get('last_name', instance.last_name)
        instance.role = validated_data.get('role', instance.role)
        instance.mobile_number = validated_data.get('mobile_number', instance.mobile_number)
        instance.save()
        return instance
    



class ChangePasswordSerializer(serializers.Serializer):
    old_password = serializers.CharField(required=True)
    new_password = serializers.CharField(
        required=True, validators=[validate_password])
    new_password_confirmation = serializers.CharField(
        write_only=True, required=True, validators=[validate_password])

    def create(self, validated_data):
        return ChangePasswordSerializer(**validated_data)

    def validate(self, attrs):
        validate_password(attrs["new_password"])
        if attrs["new_password"] != attrs["new_password_confirmation"]:
            raise serializers.ValidationError(
                {"new_password": "Password fields didn't match."}
            )
        return attrs


class LookupSerializer(serializers.Serializer):
    phone_number = serializers.CharField(required=True)
    merchant_code = serializers.CharField(required=True)

    def validate(self, attrs):
        merchant = MerchantProfile.objects.filter(merchant_code=attrs['merchant_code']).first()
        if merchant is None:
            raise serializers.ValidationError(
                {"merchant_code": "Merchant code does not exist."}
            )
       
        return attrs