from django.urls import path, include

from users.views import *


urlpatterns = [
    path('registration/', AdminRegistration.as_view()),
    path('create_pos_user/', RegisterPOSUser.as_view()),
    path('password_reset/<uuid:pk>/', UserPasswordResetView.as_view()),
    path('user/list/', UserListView.as_view()),
    path('user/lookup/', UserLookup.as_view()),
    path('user/<uuid:pk>/', UserDetailView.as_view()),
]    

