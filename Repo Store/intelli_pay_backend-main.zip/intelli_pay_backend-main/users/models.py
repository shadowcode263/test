import json
import uuid

from django.contrib.auth.hashers import make_password, check_password
from django.contrib.auth.models import AbstractUser
from django.db import models
from django.contrib.postgres.fields import ArrayField
from django.utils import timezone
from phonenumber_field.modelfields import PhoneNumberField
from django.utils.translation import gettext_lazy as _

from services.exceptions.passwords import PasswordUsedException
from services.helpers.generate_shared_secret import generate_shared_secret
from users.manager import CustomUserManager
from merchant.models import OperatorProfile, POSTerminal, MerchantProfile



class UserRoles(models.TextChoices):
    ADMIN = 'ADMIN', _('Admin')
    POS_ = 'POS_USER', _('Point OF Sale User')
    TOPUP_ = 'TOP_UP_USER', _('Top Up User')


class User(AbstractUser):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    first_name = models.CharField(max_length=30, blank=False)
    last_name = models.CharField(max_length=30, blank=False)
    email = models.EmailField(unique=True)
    mobile_number = models.CharField(unique=True, max_length=200)
    is_verified = models.BooleanField(default=False)
    is_active = models.BooleanField(default=False)
    role = models.CharField(choices=UserRoles.choices, default=UserRoles.ADMIN, max_length=50, blank=False, null=False)
    shared_secret = models.CharField(blank=False, default=generate_shared_secret, max_length=100)
    password_history = ArrayField(models.JSONField(), default=list)
    has_used_default_password = models.BooleanField(default=False)
    password_updated_at = models.DateTimeField(blank=True, null=True)
    registration_complete = models.BooleanField(default=False)
    is_deleted = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    parent_code = models.UUIDField(blank=True, null=True)
    merchant_code = models.CharField(blank=True, null=True, max_length=200)
    

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['username', 'first_name', 'last_name', 'mobile_number']

    objects = CustomUserManager()

    def __str__(self):
        return f"{self.first_name} {self.last_name}"

    class Meta:
        ordering = ["last_name"]
        verbose_name = "User"
        verbose_name_plural = "Users"

    def set_password(self, raw_password):
        try:
            for password_json in self.password_history:
                print("PASSWORD_JSON: ", password_json)
                password_object = json.loads(password_json)
                print("PASSWORD_OBJECT: ", password_object)

                if check_password(password=raw_password, encoded=password_object.get('password'), setter=None):
                    return {"message": f"This password was used before and was changed on: {password_object.get('changed_on')}"}

            # Add previous password to history list
            print("CHANGING PASSWORD RIGHT NOW: ", timezone.now())
            self.password_history.append(
                json.dumps(
                    {
                        "password": self.password,
                        "changed_on": str(timezone.now())
                    }
                )
            )

            self.password = make_password(raw_password)
            self._password = raw_password
            self.password_updated_at = timezone.now()
            self.save()
            return {"message": "Password reset complete!"}
        except Exception as e:
            print(">>>>>> ", {"message": f"{e}"})
            return {"message": f"{e}"}

    @classmethod
    def get_user(cls, user_id: str):
        return cls.objects.filter(id=user_id).first()

    @classmethod
    def get_user_by_merchant_code(cls, merchant_code: str, user_type=None):
        if not user_type:
            return cls.objects.filter(merchant_code=merchant_code)
        return cls.objects.filter(merchant_code=merchant_code, role="POS_USER")

    @classmethod
    def get_merchant(self, merchant_id):
        return MerchantProfile.query.filter_by(id=merchant_id).first()

    def get_operator_profile(self):
        return OperatorProfile.objects.filter(user=self).first()

    def get_pos_terminal(self):
        if self.role.lower() in ["pos_user","top_up_user"]:
            return POSTerminal.objects.filter(operator_profile=self.get_operator_profile()).first()
        return None    

    def get_merchant_profile(self):
        if self.role.lower() in ["pos_user","top_up_user"]:
            return self.get_operator_profile().merchant
        if self.role.lower() == "admin":
            return MerchantProfile.objects.filter(user=self).first()     


    def save(self, *args, **kwargs):
        # set admin user permissions
        if self.is_superuser:
            self.user_type = 'ADMIN'
            self.parent_code = uuid.uuid4()
            self.is_verified = True
        super().save(*args, **kwargs)