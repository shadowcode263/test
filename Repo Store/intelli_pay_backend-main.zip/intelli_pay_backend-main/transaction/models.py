import datetime
from email.policy import default
import uuid
from django.forms import CharField


from django.utils import timezone
from django.db import models
from merchant.models import POSTerminal, CurrencyChoiceSet, PaymentMethod
from core.model import SoftDeleteModel
from users.models import User
            
#txn.
class TransactionType(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    code = models.CharField(max_length=30, blank=False, unique=True)
    name = models.CharField(max_length=255, blank=False)

    def __str__(self):
        return f'{self.name}'

    @classmethod
    def filter_by_code(cls, code):
        return cls.objects.filter(code=code).first()

    @classmethod
    def get_all(cls):
        return cls.objects.all()
    



class Transaction(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    created_at = models.DateTimeField(auto_now_add=True)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    reference = models.CharField(max_length=255, default='', unique=True)
    date = models.DateField(default=timezone.now)
    completed_at = models.DateTimeField(blank=True, null=True)
    status = models.CharField(max_length=255, default='', blank=True)
    narration = models.CharField(max_length=255, default='', blank=True)
    is_successful = models.BooleanField(default=False)
    method_of_payment = models.ForeignKey(PaymentMethod, on_delete=models.CASCADE, blank=True, null=True)
    extras = models.JSONField(null=True, blank=True)
    upstream_reference = models.CharField(max_length=255, blank=True)
    transaction_type = models.ForeignKey(TransactionType, on_delete=models.PROTECT, null=True, blank=True)
    created_by = models.ForeignKey(User, on_delete=models.PROTECT, null=True, blank=True)
    currency = models.CharField(max_length=3, choices=CurrencyChoiceSet.choices, default=CurrencyChoiceSet.USD)
    carnival = models.CharField(default='Day 2', max_length=20)

    def __str__(self):
        return f'Transaction - {self.status} - {self.created_at.strftime("%a %d/%b/%y %H:%M")}'

    @classmethod
    def filter_all(cls):
        return cls.objects.all()
    
    @classmethod
    def filter_by_id(cls, id):
        return cls.objects.filter(id=id).first()


    class Meta:
        verbose_name = 'Transaction'
        verbose_name_plural = 'Transactions'