import uuid
from merchant.models import MerchantProfile, PaymentMethod

from rest_framework import serializers

from transaction.models import Transaction, TransactionType

def phone_number_formatter(phone_number):
    status = True
    if phone_number[0] == '0':
        phone_number = '263' + phone_number[1:]
    elif phone_number[0] == '+':
        phone_number = phone_number[1:]
    elif phone_number[0] == '7':
        phone_number = '263' + phone_number
    elif phone_number[0] == '2':
        phone_number = phone_number
    else:
        status = False    
    return status, phone_number 

class CheckoutSerializer(serializers.Serializer):
    transaction = serializers.CharField(max_length=100)
    payment_method = serializers.CharField(max_length=100)
    phone_number = serializers.CharField(max_length=100)

    def validate(self, data):
        transaction = Transaction.objects.filter(reference=data['transaction']).first()
        if transaction is None:
            raise serializers.ValidationError('Transaction not found')
        if transaction.status == 'COMPLETED':
            raise serializers.ValidationError('Transaction already completed')
        payment_method = PaymentMethod.objects.filter(name=data['payment_method']).first()
        if payment_method is None:
            raise serializers.ValidationError('Payment method not found')
        
        status, data['phone_number'] = phone_number_formatter(data['phone_number'].strip().replace(' ', ''))        
        data['transaction'] = transaction
        data['payment_method'] = payment_method
        return data

 

class ConfirmCheckoutSerializer(serializers.Serializer):
    phone_number = serializers.CharField(max_length=100)
    transaction = serializers.CharField(max_length=100)
    pin = serializers.CharField(max_length=100)

    def validate(self, data):
        transaction = Transaction.objects.filter(reference=data['transaction']).first()
        if transaction is None:
            raise serializers.ValidationError('Transaction not found')
        if transaction.status == 'COMPLETED':
            raise serializers.ValidationError('Transaction already completed')
        data['transaction'] = transaction
        status, data['phone_number'] = phone_number_formatter(data['phone_number'].strip().replace(' ', ''))
        return data

class SendMoneySerializer(serializers.Serializer):
    phone_number = serializers.CharField(max_length=100, required=True)
    receiver_account = serializers.CharField(max_length=100, required=True)
    amount = serializers.DecimalField(max_digits=10, decimal_places=2, required=True)
    currency = serializers.CharField(max_length=100, required=True)
    merchant_code = serializers.CharField(max_length=100, required=True)
    pin = serializers.CharField(max_length=100)

    def validate(self, data):
        status, data['phone_number'] = phone_number_formatter(data['phone_number'].strip().replace(' ', ''))
        status, data['receiver_account'] = phone_number_formatter(data['receiver_account'].strip().replace(' ', ''))
        merchant = MerchantProfile.objects.filter(merchant_code=data['merchant_code']).first()
        if merchant is None:
            raise serializers.ValidationError('Merchant not found')
        return data


class TransactionTypeSerializer(serializers.ModelSerializer):

    class Meta:
        model = TransactionType
        fields = (
            'id',
            'name',
            'code',
        )

    def validate(self, attrs):
        if TransactionType.objects.filter(code=attrs.get('code')).exists():
            raise serializers.ValidationError('Transaction Type Already Exists')
        return attrs 

    def validate_transaction_type_code(self, value):
        if not TransactionType.objects.filter(id=value).exists():
            raise serializers.ValidationError('Transaction Type Does Not Exist')
        return value       

class TransactionSerializer(serializers.ModelSerializer):
    
    class Meta:
        model = Transaction
        fields = (
            'id',
            'created_at',
            'amount',
            'reference',
            'status',
            'method_of_payment',
            'upstream_reference',
            'transaction_type',
            'is_successful',
            'narration',
            'extras'
        )

    def validate(self, attrs):
        if not attrs.get('method_of_payment'):
            raise serializers.ValidationError(
                'Payment method is required'
            )    
        return attrs

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        representation['method_of_payment'] = instance.method_of_payment.name if instance.method_of_payment else None
        representation['transaction_type'] = instance.transaction_type.name if instance.transaction_type else None
        try:
            full_name = instance.created_by.first_name + " " + instance.created_by.last_name
        except:
            full_name = " "
        representation['upstream_reference'] = full_name
        return representation

        
class PaymentMethodSerializer(serializers.ModelSerializer):

    class Meta:
        model = PaymentMethod
        fields = '__all__'
        read_only_fields = ('id', 'created_at', 'updated_at')
        # extra_kwargs = {
        #     'name': {'required': False},
        #     'description': {'required': False}
        # }


    def validate(self, attrs):
        name = attrs.get('name')
        description = attrs.get('description')

        if not name and not description:
            raise serializers.ValidationError(
                f'Name: {name} or description: {description} is required'
            )   

        return attrs

class PaymentUpdateMethodSerializer(serializers.ModelSerializer):
    
    class Meta:
        model = PaymentMethod
        fields = (
            'id',
            'name',
            'description',
            'created_at',
            'updated_at',
            'extras'
        )
        read_only_fields = ('id', 'created_at', 'updated_at')
        extra_kwargs = {
            'name': {'required': False},
            'description': {'required': False}
        }


    def validate(self, attrs):
        name = attrs.get('name')
        description = attrs.get('description')

        if not name or not description:
            raise serializers.ValidationError(
                f'Name: {name} or description: {description} is required'
            )

        if PaymentMethod.objects.filter(name__iexact=name.lower()).exists():
            raise serializers.ValidationError(
                f'Payment method with name: {name} already exists'
            )    

        return attrs        


class TransactionDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = Transaction
        fields = (
            'id',
            'created_at',
            'amount',
            'reference',
            'status',
            'method_of_payment',
            'upstream_reference',
            'transaction_type',
            'is_successful',
            'narration',
            'extras'
        )

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        representation['created_at'] = instance.created_at.strftime('%Y-%m-%d %H:%M:%S')
        representation['method_of_payment'] = instance.method_of_payment.name if instance.method_of_payment else None
        return representation

class TransactionLookupSerializer(serializers.Serializer):
    transaction = serializers.CharField(max_length=100, required=True)

    def validate(self, data):
        transaction = Transaction.objects.filter(reference=data['transaction']).first()
        if transaction is None:
            raise serializers.ValidationError('Transaction not found')
        data['transaction'] = transaction
        return data

   