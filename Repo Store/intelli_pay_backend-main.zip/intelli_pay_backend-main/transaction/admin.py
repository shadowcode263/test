from django.contrib import admin

from transaction.models import Transaction, TransactionType



@admin.register(Transaction, TransactionType)
class UniversalAdmin(admin.ModelAdmin):
    exclude = ('deleted_at',)

    def get_list_display(self, request):
        return [field.name for field in self.model._meta.concrete_fields]
