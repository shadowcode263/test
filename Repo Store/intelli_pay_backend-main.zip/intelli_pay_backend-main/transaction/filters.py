from transaction.models import Transaction
from django.utils.timezone import make_aware
import django_filters
from django.db.models import Q
from django.conf import settings

import datetime
import pytz
import json

class CustomFilter(django_filters.FilterSet):
    q = django_filters.CharFilter(method='custom_filter')

    class Meta:
        model = Transaction
        fields = ['q']


    @staticmethod
    def custom_filter(query_data=None):
        make_date = lambda data: make_aware(datetime.datetime.strptime(data, '%Y-%m-%d'), pytz.timezone(settings.TIME_ZONE))
        # if query_data.get('user'):
        #     if query_data.get('user').is_superuser:
        #         query_data.pop('user')
        # print("ORIGINAL ", query_data)
        # user = query_data.get('user')
        # if user.is_superuser:
        #     user = None
        # elif user.role == "ADMIN":
        #     user = Q(created_by=query_data.get('user'))
        # else:
        #     user = Q(created_by=query_data.get('user'))
        print("USER : ", query_data.get('user'))
        

        q_set = {
            'amount': Q(amount=query_data.get('amount')) if query_data.get('amount') else None,
            'transaction_type': Q(transaction_type__name=query_data.get('transaction_type')) if query_data.get('transaction_type') else None,
            'reference': Q(reference__icontains=query_data.get('reference')) if query_data.get('reference') else None,
            'upstream_reference': Q(upstream_reference__icontains=query_data.get('upstream_reference')) if query_data.get('upstream_reference') else None,
            'narration': Q(narration__icontains=query_data.get('narration')) if query_data.get('narration') else None,
            'currency': Q(currency__icontains=query_data.get('currency')) if query_data.get('currency') else None,
            'method_of_payment': Q(method_of_payment__name__icontains=query_data.get('method_of_payment')) if query_data.get('method_of_payment') else None,
            'created_by': query_data.get('user'),
            'status': Q(status=query_data.get('status')) if query_data.get('status') else None,
            'is_successful': Q(is_successful=json.loads(query_data.get('is_successful').lower())) if query_data.get('is_successful') else None,
            'start_date': Q(date=make_date(query_data.get('start_date'))) if query_data.get('start_date') else None,
            'end_date': Q(completed_at__lte=make_date(query_data.get('end_date'))) if query_data.get('end_date') else None
        }
        print("QUERY SET : ", q_set)
        query = None
        for item in q_set.values():
            if item:
                if not query:
                    query = item
                else:
                    query &= item
        print(query)
        return Transaction.objects.filter(query) if query else []
