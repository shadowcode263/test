from django.urls import path, include
from rest_framework import routers

from transaction.views import *

router = routers.DefaultRouter()
router.register(r'transactions', TransactionViewset, basename='transactions')
router.register('operator', TransactionDetailsView, basename='operator_transactions')
# router.register(r'checkout', CheckoutView, basename='checkout')
router.register(r'payment_methods', PaymentMethodViewset, basename='payment_methods')
router.register(r'transaction_types', TransactionTypeViewset, basename='transaction_types')
router.register('checkout', CheckoutViewSet, basename='checkout'),


urlpatterns = [
    path('', include(router.urls)),
]
