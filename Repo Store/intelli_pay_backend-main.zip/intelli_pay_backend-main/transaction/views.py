from datetime import datetime
from telnetlib import STATUS
from rest_framework import viewsets
from rest_framework.views import APIView
from django.http import JsonResponse, Http404
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated
from shop.models import Order, OrderItem
from shop.serializers import TransactionOrderItemsSerializer

from transaction.models import Transaction, TransactionType
from transaction.serializers import CheckoutSerializer, ConfirmCheckoutSerializer, SendMoneySerializer, TransactionDetailSerializer, TransactionLookupSerializer, TransactionSerializer, PaymentMethodSerializer, TransactionTypeSerializer
from services.permissions.is_pos_user import IsPOSUser
from services.permissions.is_merchant_profile_owner import IsMerchantOwnerOrAdmin
from api.clients import WalletsClient
from merchant.models import MerchantProfile, PaymentMethod
from users.models import User
from transaction.filters import CustomFilter
from rest_framework.parsers import JSONParser
from users.serializers import UserSerializer
from django.db.models import Q

class TransactionsFilterOrderView(APIView):
    serializer_class = TransactionOrderItemsSerializer
    parser_classes = (JSONParser, )
    model = OrderItem
    
    def get(self, request, *args, **kwargs):
        transaction = Transaction.filter_by_id(kwargs.get('transaction_id'))
        print('TXN', transaction)
        if transaction:
            payload =self.model.filter_by_order(order=Order.filter_by_transaction(transaction))
            self.serializer_class = self.serializer_class(data=payload, many=True)
            self.serializer_class.is_valid()
            print(self.serializer_class.data)
            return JsonResponse(status=200, data={"results": self.serializer_class.data})
        return JsonResponse(status=404, data={"message": "Transaction not found!"})

class TransactionsFilterDataView(APIView):
    serializer_class = TransactionSerializer
    parser_classes = (JSONParser, )
    model = Transaction
    
    def get(self, request, *args, **kwargs):
        payload = {
            "payment_methods": ["CASH", "VOUCHER", "WALLET"],
            "transaction_types": ["POS Sale"],
            "currency": ["USD", "ZWL"]

        }
        return JsonResponse(status=200, data=payload)


class OperatorsFilterDataView(APIView):
    serializer_class = UserSerializer
    permission_classes = [IsAuthenticated, ]
    parser_classes = (JSONParser, )
    model = User
    
    def get(self, request, *args, **kwargs):
        try:
            if not request.user.is_superuser:
                payload = self.model.get_user_by_merchant_code(request.user.merchant_code)
            else:
                if kwargs.get('merchant_code'):
                    payload = self.model.get_user_by_merchant_code(kwargs.get('merchant_code'))
                else:
                    payload = self.model.get_user_by_merchant_code(request.user.merchant_code)
                    # payload = self.model.objects.all()
            
            self.serializer_class = self.serializer_class(data=payload, many=True)
            self.serializer_class.is_valid()
        except Exception as e:
            print(e)
        return JsonResponse(status=200, data={"operators": self.serializer_class.data})
    


class TransactionsFilterView(APIView):
    serializer_class = TransactionSerializer
    parser_classes = (JSONParser, )
    filter = CustomFilter
    model = Transaction
    
    def post(self, request, *args, **kwargs):
        transaction_records = self.apply_filter(payload=request.data, user=request.user)
        total_amount = 0 
        total_cash = 0
        total_voucher = 0 
        total_nostro = 0
        for transaction in transaction_records:
            if transaction.is_successful:
                total_amount += transaction.amount            
                if transaction.method_of_payment.name == "CASH":
                    total_cash += transaction.amount
                elif transaction.method_of_payment.name == "VOUCHER":
                    total_voucher += transaction.amount
                elif transaction.method_of_payment.name == "NOSTRO":
                    total_nostro += transaction.amount
                else:
                    pass
        transactions = self.serializer_class(
            data=transaction_records, 
            many=True
        )
        transactions.is_valid()
        print("Sending ----> ", {'transactions': transactions.data, 'total_amount':total_amount, 'total_cash':total_cash, 'total_voucher':total_voucher, 'total_nostro':total_nostro})
        return JsonResponse(status=200, data={'transactions': transactions.data, 'total_amount':total_amount, 'total_cash':total_cash, 'total_voucher':total_voucher, 'total_nostro':total_nostro})

    
    def get(self, request, *args, **kwargs):
        transactions = self.serializer_class(
            data=self.model.filter_all(), 
            many=True
        )
        transactions.is_valid()
        return JsonResponse(status=200, data={'transactions': transactions.data})
    
    
    def apply_filter(self, payload: dict, user=None):
        print("Original payload ::: ", payload)
        payload['is_successful'] = f"{payload.get('is_successful')}"
        payload.pop('is_successful') if payload['is_successful'] == 'None' else None
        query = {
            field: payload.get(field)
            for field in [
                'reference', 
                'upstream_reference',
                'transaction_type', 
                'method_of_payment',
                'is_successful',
                'currency',
                'narration',
                'amount', 
                'status', 
                'user', 
                'start_date',
                'end_date'
            ] if payload.get(field)
        }
        if user:
            if user.is_superuser:
                if query.get('user'):
                    query['user'] =  Q(created_by=User.get_user(payload.get("user")))
                else:
                    query['user'] = None
            elif user.role == "ADMIN":
                if query.get('user'):
                    query['user'] =  Q(created_by=User.get_user(payload.get("user")))
                else:
                    query['user'] = Q(created_by__merchant_code=user.merchant_code)
            else:
                 query['user'] = user
                

            

        object_list = self.filter.custom_filter(query) 
        return object_list


class TransactionViewset(viewsets.ModelViewSet):
    """
    Transaction ViewSet
    """
    permission_classes = [IsAuthenticated, IsPOSUser]
    serializer_class = TransactionSerializer
    model = Transaction


    def get_queryset(self):

        parent = User.objects.filter(parent_code=self.request.user.parent_code).first()

        if not parent:
            raise Http404("User has not parent user")

        merchant = MerchantProfile.objects.filter(user=parent)

        if merchant:
            return self.model.objects.filter(merchant=merchant)

        return []

    def get_object(self, pk):
        try:
            return self.model.objects.get(pk=pk)
        except Exception as e:
            raise Http404("Transaction not found")

    def destroy(self, request, transaction_id):
        transaction = self.get_object(transaction_id)

        try:
            transaction.delete()
            return JsonResponse(
                status=204,
                data={
                    "status": True,
                    "message": "Successfully deleted transaction",
                    "data": None,
                    "issues": None
                }
            )        
        except Exception as e:
            return JsonResponse(
                status=400,
                data={
                    "status": False,
                    "message": "Error deleting order",
                    "data": None,
                    "issues": str(e)
                }
            )    
 

class PaymentMethodViewset(viewsets.ModelViewSet):

    """
    PaymentMethod ViewSet
    """
    permission_classes = [IsAuthenticated, IsMerchantOwnerOrAdmin]
    serializer_class = PaymentMethodSerializer
    model = PaymentMethod


    def get_queryset(self):
        return self.model.objects.all()


    def destroy(self, request, *args, **kwargs):
        payment_method = self.get_object()
        try:
            payment_method.delete()
            return JsonResponse(
                status=204,
                data={
                    "status": True,
                    "message": "Successfully deleted payment method",
                    "data": None,
                    "issues": None
                }
            )        
        except Exception as e:
            return JsonResponse(
                status=400,
                data={
                    "status": False,
                    "message": "Error deleting order",
                    "data": None,
                    "issues": str(e)
                }
            )

class TransactionTypeViewset(viewsets.ModelViewSet):
    queryset = TransactionType.objects.all()
    serializer_class = TransactionTypeSerializer
    permission_classes = [IsAuthenticated]
    queryset = TransactionType.objects.all()
    model = TransactionType

    def create(self, request):
        serializer = self.serializer_class(data=request.data)

        if serializer.is_valid():
            self.model.objects.create(**serializer.validated_data)
            return JsonResponse(
                status=201,
                data={
                    "status": True,
                    "message": "Successfully created transaction type",
                    "data": serializer.validated_data,
                    "issues": None
                }

            )
        else:
            return JsonResponse(
                status=400,
                data={
                    "status": False,
                    "message": "Error creating transaction type",
                    "data": None,
                    "issues": serializer.errors
                })

              


    def get_object(self, id=None):
        
        try:
            return self.model.objects.get(pk=self.kwargs.get('id'))
        except Exception as e:
            raise Http404("Transaction type not found")

    def destroy(self, request, id):

        print(f'/n/n/n/n/DEBUG {id} /n/n/n/n/')
        transaction_type = self.get_object(id=id)
        try:
            transaction_type.delete()
            return JsonResponse(
                status=204,
                data={
                    "status": True,
                    "message": "Successfully deleted transaction type",
                    "data": None,
                    "issues": None
                }
            )        
        except Exception as e:
            return JsonResponse(
                status=400,
                data={
                    "status": False,
                    "message": "Error deleting order",
                    "data": None,
                    "issues": str(e)
                }
            )        
        
class CheckoutViewSet(viewsets.ModelViewSet):
    # permission_classes = [IsAuthenticated]
    serializer_class = CheckoutSerializer
    client = WalletsClient()
    # queryset = Transaction.objects.all()

    @action(detail=False, methods=['post'])
    def checkout(self, request):
        serializer = self.serializer_class(data=request.data)        
        if serializer.is_valid():
            print(serializer.validated_data['payment_method'])
            serializer.validated_data['transaction'].method_of_payment = serializer.validated_data['payment_method']
            transaction_type = TransactionType.objects.filter(code='MP').first()
            serializer.validated_data['transaction'].transaction_type = transaction_type
            if serializer.validated_data['payment_method'].name == 'WALLET':
                response_data,status_code = self.client.lookup(
                    phone_number=serializer.validated_data['phone_number'], 
                    merchant_code=request.user.merchant_code
                )
            elif serializer.validated_data['payment_method'].name == 'CASH' or serializer.validated_data['payment_method'].name == 'VOUCHER' or serializer.validated_data['payment_method'].name == 'NOSTRO':
                order = Order.objects.filter(transaction=serializer.validated_data['transaction']).first()
                order_items = OrderItem.objects.filter(order=order).all()
                for item in order_items:
                    item.product.quantity_in_stock = item.product.quantity_in_stock - item.quantity
                    item.product.total_sold = item.product.total_sold + item.quantity
                    item.product.save()
                serializer.validated_data['transaction'].is_successful = True
                serializer.validated_data['transaction'].status = 'COMPLETED'
                serializer.validated_data['transaction'].date = '2022-05-01'
                serializer.validated_data['transaction'].created_at = '2022-05-01'
                serializer.validated_data['transaction'].carnival = 'Day 3'
                serializer.validated_data['transaction'].narration = 'Transaction Successful'
                serializer.validated_data['transaction'].completed_at = datetime.now()
                serializer.validated_data['transaction'].save()
                status_code = 200
                response_data = {
                    "status": True,
                    "message": "Transaction Processing Succeful",
                }
            else:
                status_code = 400
                response_data = {
                    "status": False,
                    "message": "Payment method not supported",
                }
            return JsonResponse(status=status_code, data=response_data)
        else:
            return JsonResponse(
                status=400,
                data={
                    "status": False,
                    "message": serializer.errors,
                }
            )

    @action(detail=False, methods=['post'])
    def confirm_checkout(self, request):
        serializer = ConfirmCheckoutSerializer(data=request.data)
        if serializer.is_valid():
            txn_obj = self.client.makepayment(
                serializer.validated_data, 
                merchant_code=request.user.merchant_code,
            )
            print("Payment Methods", [i.name for i in PaymentMethod.objects.all()])
            # Sharara to complete transaction
            serializer.validated_data['transaction'].is_successful = txn_obj['status']
            serializer.validated_data['transaction'].status = 'COMPLETED' if txn_obj['status'] else 'FAILED'
            serializer.validated_data['transaction'].upstream_reference = txn_obj['transaction_id'] if txn_obj['status'] else ""
            serializer.validated_data['transaction'].narration = txn_obj['narration']
            serializer.validated_data['transaction'].method_of_payment = PaymentMethod.filter_by_name("WALLET")
            serializer.validated_data['transaction'].completed_on = datetime.now()
            serializer.validated_data['transaction'].save()
            if serializer.validated_data['transaction'].is_successful:
                order = Order.objects.filter(transaction=serializer.validated_data['transaction']).first()
                order_items = OrderItem.objects.filter(order=order).all()
                for item in order_items:
                    item.product.quantity_in_stock = item.product.quantity_in_stock - item.quantity
                    item.product.total_sold = item.product.total_sold + item.quantity
                    item.product.save()
            response_message = {
                "status": serializer.validated_data['transaction'].is_successful,
                "message": serializer.validated_data['transaction'].narration
            }
            return JsonResponse(status=200 if response_message.get('status') else 400, data=response_message)
        else:
            response_message = {
                "status": False,
                "message": serializer.errors}
            return JsonResponse(status = 400, data = response_message)

    @action(detail=False, methods=['post'])
    def send_money(self, request):
        serializer = SendMoneySerializer(data=request.data)
        if serializer.is_valid():
            response_data, status_code = self.client.send_money(
                serializer.validated_data, 
                merchant_code=serializer.validated_data['merchant_code'],
            )
            return JsonResponse(status=status_code, data=response_data)
        else:
            response_message = {
                "status": False,
                "message": serializer.errors}
            return JsonResponse(status = 400, data = response_message)

class TransactionDetailsView(viewsets.ModelViewSet):
    serializer_class = TransactionDetailSerializer
    queryset = Transaction.objects.all()

    @action(detail=False, methods=['get'])
    def transactions(self, request):
        try:
            transactions = Transaction.objects.filter(created_by=request.user).filter(is_successful=True).all()
            print(transactions)
            serializer = self.serializer_class(transactions, many=True)
            return JsonResponse(
                status=200,
                data={
                    "status": True,
                    "message": "Transaction Details",
                    "data": serializer.data
                }
            )
        except Exception as e:
            return JsonResponse(
                status=400,
                data={
                    "status": False,
                    "message": "Error fetching transaction details",
                    "data": None,
                    "issues": str(e)
                }
            )

    @action(detail=False, methods=['post'])
    def get_transaction_details(self, request):
        serializer = TransactionLookupSerializer(data=request.data)
        if serializer.is_valid():
            transaction = serializer.validated_data['transaction']
            order = Order.objects.filter(transaction=transaction).first()
            order_items = OrderItem.objects.filter(order=order).all()
            response_data = {"total_amount": transaction.amount, "order_items": []}
            for item in order_items: 
                response_data["order_items"].append(
                    {
                        "product_name": item.product.name,
                        "quantity": item.quantity,
                        "price": item.product.price,
                        "total": item.quantity * item.product.price
                    }
                )
            return JsonResponse(status=200, data=response_data)
        else:
            return JsonResponse(
                status=400,
                data={
                    "status": False,
                    "message": serializer.errors,
                }
            )