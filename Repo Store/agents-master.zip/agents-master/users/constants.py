ROLES = (
    ('ADMIN', 'Admin'),
    ('AGENT', 'Agent'),
)