from django.http import JsonResponse
from rest_framework import status

from users.models import User


class AddUserService:

    def __init__(self, payload, request):
        self.payload = payload
        self.request = request

    def register(self):

        email_check = User.objects.find_by_email(self.payload.get('email'))
        username_check = User.objects.find_by_username(self.payload.get('username'))

        if email_check:
            return JsonResponse(
                status=status.HTTP_400_BAD_REQUEST, data={'message': 'Email Already Exists'}

            )

        if username_check:
            return JsonResponse(
                status=status.HTTP_400_BAD_REQUEST, data={'message': 'Username Already Exists'}
            )

        user = User.objects.register_agent(self.payload, self.request.user)

        if user:
            return JsonResponse(
                status=status.HTTP_201_CREATED, data={
                    'message': f'Successfully Created User: {user.username}',
                    'id': user.ID}
            )

        return JsonResponse(
            status=status.HTTP_400_BAD_REQUEST, data={
                'message': f'Failed To Create User'
            }
        )
