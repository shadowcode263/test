from django.contrib.auth.models import AbstractUser
from company.models import Branch
from users.constants import ROLES
from django.db import models
import datetime
import random

class User(AbstractUser):
    first_name = models.CharField(max_length=30, blank=False)
    last_name = models.CharField(max_length=30, blank=False)
    email = models.EmailField(unique=True)
    id_number = models.CharField(max_length=30, blank=False)
    is_verified = models.BooleanField(default=False)
    is_active = models.BooleanField(default=False)
    branch = models.ForeignKey(Branch, on_delete=models.CASCADE, null=True, blank=True, related_name='user_branch')
    is_deleted = models.BooleanField(default=False)
    address = models.CharField(max_length=150)
    phone_number = models.CharField(max_length=20, blank=True, null=True)
    agent_code = models.CharField(max_length=20, blank=True, null=True)
    is_prepaid = models.BooleanField(default=False)
    is_superadmin = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.first_name} {self.last_name}"

    class Meta:
        ordering = ["last_name"]
        verbose_name = "User"
        verbose_name_plural = "Users"

    @classmethod
    def getUser(cls, id):
        return cls.objects.filter(id=id).first()
    
    @classmethod
    def get_agents_branch(cls, branch_id):
        return cls.objects.filter().first()
    
    @classmethod
    def update_agent(cls, payload: dict):
        try:
            User.objects.filter(id=payload.pop('user_id')).update(**payload)
            return True
        except Exception as e:
            print(e)
            return False
    
    @classmethod
    def get_all_agents(cls):
        return cls.objects.exclude(is_superuser=True).exclude(is_staff=True).exclude(is_deleted=True)

    def validate_approval(self, amount):
        balance = self.branch.running_balance
        if balance == 0:
            return False
        elif balance > amount:
            return True
        else:
            return False

    def save(self, *args, **kwargs):
        if self.is_superuser:
            self.is_verified = True
            self.is_active = True
        super(User, self).save(*args, **kwargs)


class AppVersion(models.Model):
    """
        Version
    """
    build_number = models.CharField(max_length=30, blank=False)
    version_number = models.CharField(max_length=30, blank=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.build_number}-{self.version_number}"

class AuthorizationManagers(models.Model):
    name = models.CharField(max_length=255,null=False,blank=False,default='Tumai')
    pin = models.CharField(max_length=100,null=False,blank=False)

    def __str__(self):
        return f"{self.name}"

    @classmethod
    def authorize(cls,pin):
        manager = cls.objects.filter(pin=pin).first()
        if manager:
            return True
        else:
            return False
    
    @classmethod
    def authorize_withdrawal(cls,pin):
        manager = cls.objects.filter(pin=pin,name='mudiwahambira').first()
        if manager:
            manager.reset_pin()
            return True
        else:
            return False

    @classmethod
    def full_name(cls,pin):
        return cls.objects.filter(pin=pin).first().name
    
    def reset_pin(self):
        self.pin = self.generate_pin()
        self.save()
    
    def generate_pin(self):
        # generate random number between 100000 and 999999
        return str(random.randint(1000, 4000))
    