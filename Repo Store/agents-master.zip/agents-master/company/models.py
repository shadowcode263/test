from django.db import models
# from users.models import User
from datetime import datetime

# Create your models here.
class Company(models.Model):
    name = models.CharField(max_length=100, unique=True)
    code = models.CharField(max_length=100, unique=True)
    contact_person = models.CharField(max_length=100)
    contact_phone = models.CharField(max_length=100)
    upper_limit = models.FloatField(default=0, blank=False, null=False)
    is_prepaid= models.BooleanField(default=False)

    def __str__(self):
        return self.name
    class Meta:
        ordering = ["name"]
        verbose_name = "Company"
        verbose_name_plural = "Companies"
    
    def get_cash_in_hand(self):
        return self.allocation

    def save(self, *args, **kwargs):
        if not self.code:
            self.code = 'TUMAI-' + str(Company.objects.count() + 1)
        super(Company, self).save(*args, **kwargs)

class Branch(models.Model):
    name = models.CharField(max_length=100, null=False, blank=False)
    code = models.CharField(max_length=100, unique=True)
    running_balance = models.FloatField(max_length=100,default=0)
    location = models.TextField()
    company = models.ForeignKey(Company, on_delete=models.CASCADE, related_name='branch_company')
    is_active = models.BooleanField(default=True)
    is_prepaid = models.BooleanField(default=False)
    city= models.ForeignKey('remittance.ActiveCities', on_delete=models.CASCADE, related_name='active_city',blank=True,null=True)

    def __str__(self):
        return self.name
    class Meta:
        ordering = ["name"]
        verbose_name = "Branch"
        verbose_name_plural = "Branches"

    @classmethod
    def tumai_branches(cls):
        return cls.objects.filter(is_prepaid=False)

    # generate branch code and save it
    def save(self, *args, **kwargs):
        if not self.code:
            self.code = 'BR-' + str(Branch.objects.count() + 1)
        super(Branch, self).save(*args, **kwargs)

    @classmethod
    def filter_by_name(cls, name):
        return cls.objects.filter(name=name).filter(is_active=True).first()
    
    @classmethod
    def filter_by_code(cls, code):
        return cls.objects.filter(code=code).filter(is_active=True).first()
    
    @classmethod
    def filter_by_id(cls, id):
        return cls.objects.filter(id=id).filter(is_active=True).first()
    
    @classmethod
    def filter_by_cash(cls, id):
        return cls.objects.filter(id=id).first()
    
        
    @classmethod
    def filter_by_company_id(cls, company_id):
        return cls.objects.filter(company__id=company_id)
    
    def increment_balance(self, amount):
        self.running_balance += amount
        self.save()
    
    def decrement_balance(self, amount):
        self.running_balance -= amount
        self.save()

    @classmethod
    def filter_branches(cls):
        return cls.objects.filter(is_prepaid=False)
    
    @classmethod
    def filter_kiosk(cls):
        return cls.objects.filter(is_prepaid=False,is_active=True)


