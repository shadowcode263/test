import datetime
from gc import get_referents
from sys import prefix
from django.db import models
from utils.utils import Utils
from users.models import AuthorizationManagers, User
from company.models import Branch
import random

"""
    TRANSACTIONS
"""


class Rate(models.Model):
    """
        RATE
    """
    interbank = models.DecimalField(
        max_digits=10, decimal_places=2, blank=True, null=True)
    midmarket = models.DecimalField(
        max_digits=10, decimal_places=2, blank=True, null=True)
    blackmarket = models.DecimalField(
        max_digits=10, decimal_places=2, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.interbank}-{self.midmarket}-{self.blackmarket}"


class Balances(models.Model):
    """
        Balance
    """
    econet = models.FloatField(default=10000000)
    netone = models.FloatField(default=100000)
    zb_usd = models.FloatField(default=1000)
    zb_rtgs = models.FloatField(default=100000)
    telecel = models.FloatField(default=10000)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.econet}-{self.netone}-{self.zb_usd}-{self.zb_rtgs}-{self.telecel}"

    @classmethod
    def deduct_balance(cls, amount, type):
        if type in ['001', '0010']:
            cls.objects.filter(id=1).update(
                econet=models.F('econet')-(amount*100))
        if type in ['002', '0020']:
            cls.objects.filter(id=1).update(netone=models.F('netone')-amount)
        if type in ['003', '0030']:
            cls.objects.filter(id=1).update(zb_usd=models.F('zb_usd')-amount)
        if type in ['004', '005']:
            cls.objects.filter(id=1).update(zb_rtgs=models.F('zb_rtgs')-amount)
        if type in ['006']:
            cls.objects.filter(id=1).update(telecel=models.F('telecel')-amount)


class TransactionTypes(models.Model):
    code = models.CharField(max_length=255, unique=True)
    transaction_type = models.CharField(max_length=255)
    description = models.CharField(max_length=255, null=True)

    def __str__(self):
        return f'{self.transaction_type}'

    class Meta:
        ordering = ["transaction_type"]
        verbose_name = "Transaction Type"
        verbose_name_plural = "Transaction Types"

    @classmethod
    def filter_by_code(cls, code):
        return cls.objects.filter(code=code).first()

    @classmethod
    def filter_code(cls, code):
        return cls.objects.filter(code=code).first()


class Transactions(models.Model):
    transaction_type = models.ForeignKey(
        TransactionTypes, on_delete=models.PROTECT, null=True, related_name='type')
    branch = models.ForeignKey(
        Branch, on_delete=models.PROTECT, null=True, related_name='branch')
    amount = models.FloatField()
    status = models.BooleanField(null=True)
    reference = models.CharField(max_length=255, unique=True)
    user = models.ForeignKey(
        User, on_delete=models.PROTECT, null=True, related_name='transacting_user'
    )
    bill_type = models.CharField(max_length=255, null=True)
    payload = models.TextField(null=True)
    extras = models.IntegerField(default=0)
    date_created = models.DateTimeField(auto_now_add=True)
    last_updated = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f'{self.transaction_type.transaction_type} Transaction {self.reference} - {self.amount}'

    def save(self, *args, **kwargs):
        self.last_updated = datetime.datetime.today()
        if not self.reference:
            self.reference = Utils.get_transaction_reference()
        self.reference = Utils.get_transaction_reference()
        super().save(*args, **kwargs)

    class Meta:
        ordering = ['-date_created']
        verbose_name = 'Transactions'
        verbose_name_plural = 'Transactions'

    @classmethod
    def create_transaction(cls, user, amount, transaction_type, extras=0, status=False, payload=None, bill_type=None):
        transaction = cls(
            user=user,
            branch=user.branch,
            status=status,
            amount=amount,
            transaction_type=transaction_type,
            extras=extras,
            payload=payload,
            bill_type=bill_type
        )
        transaction.save()
        if transaction_type.code.upper() == 'TA08':
            CashFlowLedger.create_record(transaction, user, amount, True)
            user.branch.increment_balance(amount)
        if transaction_type.code.upper() == 'TA58':
            CashFlowLedger.create_record(transaction, user, amount, False)
            user.branch.decrement_balance(amount)
        return transaction

    @classmethod
    def create_withdrawal(cls, user, amount, transaction_type, extras=0, status=False, payload=None, bill_type=None):
        transaction = cls(
            user=user,
            branch=Branch.filter_by_code('BR-22'),
            status=status,
            amount=amount,
            transaction_type=transaction_type,
            extras=extras,
            payload=payload,
            bill_type=bill_type
        )
        transaction.save()
        if transaction_type.code.upper() == 'TA09':
            CashFlowLedger.create_withdrawal(transaction, user, amount, False)
            transaction.branch.decrement_balance(amount)
        transaction.status = True
        transaction.save()
        return transaction

    @classmethod
    def filter_all(cls):
        return cls.objects.all()

    @classmethod
    def filter_latest(cls):
        return cls.objects.filter(date_created__gte=datetime.datetime.now()-datetime.timedelta(days=1))

    @classmethod
    def filter_transaction_by_reference(cls,reference):
        return cls.objects.filter(reference=reference).first()

class BillPayment(models.Model):
    transaction = models.ForeignKey(
        Transactions, on_delete=models.PROTECT, null=True,related_name='bill_transaction'
    )
    narration = models.CharField(max_length=255, null=True,)
    currency = models.CharField(max_length=255, default="USD")
    email = models.EmailField(null=True, blank=True)
    upstream_response_message = models.TextField(blank=True, null=True)
    extras = models.JSONField(null=True, blank=True)

    def __str__(self):
        return f'{self.transaction}'

    class Meta:
        ordering = ["-id"]
        verbose_name = "Bill Payment"
        verbose_name_plural = "Bill Payments"

    @classmethod
    def create_bill_payment(cls, transaction, currency, email=None):
        rate = Rate.objects.first()
        print("rate", transaction.amount)
        if rate:
            extras = {
                "amount": float(transaction.amount),
                "ib_rate": float(rate.interbank),
                "bm_rate": float(rate.blackmarket)
            }
        else:
            extras = {
                "amount": float(transaction.amount)
            }
        bill = cls(
            transaction=transaction,
            currency=currency,
            email=email,
            extras=extras
        )
        bill.save()
        return bill


class CashFlowLedger(models.Model):
    transaction = models.ForeignKey(
        Transactions, on_delete=models.PROTECT, null=True, related_name="transaction")
    branch = models.ForeignKey(
        Branch, on_delete=models.PROTECT, null=True, related_name="requesting_agent_branch")
    agent = models.ForeignKey(
        User, on_delete=models.PROTECT, null=True, related_name='agent_requesting')
    amount = models.FloatField(default=0)
    date = models.DateTimeField(auto_now_add=True, null=True, blank=True)
    is_credit = models.BooleanField(default=False)
    current_balance = models.FloatField(default=0)
    new_balance = models.FloatField(default=0)
    current_company_balance = models.FloatField(default=0)
    new_company_balance = models.FloatField(default=0)

    def __str__(self):
        return f'{self.agent} - {self.amount}'

    class Meta:
        ordering = ["-id"]

    @classmethod
    def create_record(cls, transaction: Transactions, agent: User, amount: float, is_credit: bool):
        cash_flow_record = cls(
            transaction=transaction,
            agent=agent,
            branch=agent.branch,
            amount=amount,
            is_credit=is_credit,
            current_balance=agent.branch.running_balance,
            current_company_balance=sum(
                [branch.running_balance for branch in Branch.tumai_branches()]),
            new_balance=agent.branch.running_balance +
            amount if is_credit else agent.branch.running_balance - amount
        )
        cash_flow_record.save()
        cash_flow_record.new_company_balance = sum([branch.running_balance for branch in Branch.tumai_branches(
        )]) + amount if is_credit else sum([branch.running_balance for branch in Branch.tumai_branches()]) - amount
        cash_flow_record.save()
        return cash_flow_record
    
    @classmethod
    def create_withdrawal(cls, transaction: Transactions, agent: User, amount: float, is_credit: bool):
        cash_flow_record = cls(
            transaction=transaction,
            agent=agent,
            branch=transaction.branch,
            amount=amount,
            is_credit=False,
            current_balance=transaction.branch.running_balance,
            current_company_balance=sum(
                [branch.running_balance for branch in Branch.tumai_branches()]),
            new_balance=transaction.branch.running_balance +
            amount if is_credit else transaction.branch.running_balance - amount
        )
        cash_flow_record.save()
        cash_flow_record.new_company_balance = sum([branch.running_balance for branch in Branch.tumai_branches(
        )]) + amount if is_credit else sum([branch.running_balance for branch in Branch.tumai_branches()]) - amount
        cash_flow_record.save()
        return cash_flow_record


class WithdrawalLedger(models.Model):
    """
        Withdrawal Ledger
    """
    amount = models.FloatField(default=0)
    approved_by = models.CharField(max_length=255, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.amount}-{self.approved_by}"

    @classmethod
    def create_withdrawal(cls, amount):
        cls(
            amount=amount,
            approved_by='Mudiwa Hambira').save()
        return True
