import csv
from django.db.models import Sum
from transaction.models import Balances, Rate, TransactionTypes, Transactions
from django.http import JsonResponse
from rest_framework import status
from decouple import config
import requests
import requests
import json
import datetime
from utils.utils import Utils

def map_payload(payload):
    print('incoming payload: ', payload)
    result_payload = {
        'initiator_name': payload.get('initiator_name') if 'initiator_name' in payload else payload.get('initiatorName'),
        'initiator_phone_number': payload.get('initiator_phone_number') if 'initiator_phone_number' in payload else payload.get('initiatorPhoneNumber'),
        'initiator_email': payload.get('initiator_email') if 'initiator_email' in payload else payload.get('initiatorEmail'),
        'initiator_id_number': payload.get('initiator_id_number') if 'initiator_id_number' in payload else payload.get('initiatorIdNumber'),
        # recipient
        'recipient_name': payload.get('recipient_name') if 'recipient_name' in payload else payload.get('recipientName'),
        'recipient_phone_number': payload.get('recipient_phone_number') if 'recipient_phone_number' in payload else payload.get('recipientPhoneNumber'),
        'recipient_id_number': payload.get('recipient_id_number') if 'recipient_id_number' in payload else payload.get('recipientIdNumber'),
        'recipient_address': payload.get('recipient_address') if 'recipient_address' in payload else payload.get('recipientAddress'),
        'recipient_identification_type': payload.get('recipient_identification_type') if 'recipient_identification_type' in payload else payload.get('recipientIdentificationType'),
        # order details
        'source': payload.get('source'),
        'amount': payload.get('amount'),
        'narration': payload.get('narration'),
        'currency': payload.get('currency'),
        'city': payload.get('city')
    }
    print('outgoing payload: ', result_payload)
    return result_payload


def zb_balance(currency):
    if currency in ['ZWL', 'USD']:
        balance = Balances.objects.all().first()
        return balance.zb_rtgs if currency == 'ZWL' else balance.zb_usd
    else:
        return 0


def mno_balance(mno):
    print('checking mno balance', mno)
    biller = 'ECONET_BALANCE' if mno in ['001', '0010'] else 'NETONE_BALANCE' if mno in [
        '002', '0020'] else 'TELECEL_BALANCE' if mno in ['003', '0030'] else ''
    print('biller: ', biller)
    if biller in ['ECONET_BALANCE', 'NETONE_BALANCE', 'TELECEL_BALANCE']:
        balance = Balances.objects.all().first()
        return balance.econet if biller == 'ECONET_BALANCE' else balance.netone if biller == 'NETONE_BALANCE' else balance.telecel if biller == 'TELECEL_BALANCE' else 0
    else:
        return 0


def get_balaces():
    # function will return balances for all mnos and zb
    biller = ['ECONET_BALANCE', 'NETONE_BALANCE']
    for b in biller:
        url = config("BPA_PYTHON_URL")
        payload = json.dumps({
            "vendor_reference": Utils.get_transaction_reference('TA'),
            "biller_code": b,
            "transaction_type": "010",
            "target_account": "263774231343",
            "amount": 1,
            "currency_code": "ZWL",
            "product_id": "A",
            "extras": {}
        })
        headers = {
            'api-password': config("BPA_PYTHON_PASS"),
            'api-username': config("BPA_PYTHON_USER"),
            'key': config("BPA_PYTHON_KEY"),
            'Content-Type': 'application/json'
        }

        response = requests.request("POST", url, headers=headers, data=payload)
        if response.status_code == 200:
            print(response.text, response.json()[
                  'upstream_response']['amount'])
            if b == 'ECONET_BALANCE':
                econet = float(response.json()[
                               'upstream_response']['amount'])/100
            if b == 'NETONE_BALANCE':
                netone = float(response.json()['upstream_response']['amount'])
        else:
            econet = 'Balance could not be retrieved'
            netone = 'Balance could not be retrieved'
    # get balance for telecel
    url_java = config("BPA_JAVA_URL")
    payload = json.dumps({
        "vendorReference": Utils.get_transaction_reference('TA'),
        "biller": "TELECEL",
        "type": "TELECEL_AGENT_BALANCE",
        "channel": "INTERNET"
    })
    headers = {
        'api-password': config("BPA_JAVA_PASS"),
        'api-username': config("BPA_JAVA_USER"),
        'key': config("BPA_JAVA_KEY"),
        'Content-Type': 'application/json'
    }

    response = requests.request(
        "POST", url_java, headers=headers, data=payload)
    if response.status_code == 200:
        print(response.text, response.json()[
              'additionalData']['telecelBalanceResponse']['amount'])
        balance = response.json(
        )['additionalData']['telecelBalanceResponse']['amount']
        telecel = float(balance.replace(',', '').strip())
    else:
        telecel = 'Balance could not be retrieved'

    currency = ['USD', 'ZWL']
    for c in currency:
        url = config("ZB_INQUIRY_URL")
        print('checking zb balance ', currency)
        payload = json.dumps({
            "api_secret": config("ZB_INQUIRY_KEY"),
            "account_number": config("ZB_USD") if c == 'USD' else config("ZB_ZWL")
        })
        headers = {
            'Content-Type': 'application/json'
        }

        response = requests.request("POST", url, headers=headers, data=payload)
        if response.status_code == 200:
            try:
                balance = float(response.json()['balance'].split(
                    "ZWL")[1].strip().replace(',', ''))
                print('balance: ', balance)
                if c == 'ZWL':
                    zb_rtgs = balance
                if c == 'USD':
                    zb_usd = balance
            except Exception as e:
                try:
                    balance = float(response.json()['balance'].split(
                        "USD")[1].strip().replace(',', ''))
                    print('balance: ', balance)
                    if c == 'ZWL':
                        zb_rtgs = balance
                    if c == 'USD':
                        zb_usd = balance
                except Exception as e:
                    print(e)
                    if c == 'ZWL':
                        zb_rtgs = 'Balance could not be retrieved'
                    if c == 'USD':
                        zb_usd = 'Balance could not be retrieved'
        else:
            if c == 'ZWL':
                zb_rtgs = 'Balance could not be retrieved'
            if c == 'USD':
                zb_usd = 'Balance could not be retrieved'
    return {
        "econet": econet,
        "netone": netone,
        "telecel": telecel,
        "zb_rtgs": zb_rtgs,
        "zb_usd": zb_usd
    }


def generate_csv(transactions):
    with open('transactions.csv', 'w') as csv_file:
        fieldnames = ['date', 'branch', 'amount', 'description']
        writer = csv.DictWriter(csv_file, fieldnames=fieldnames)
        writer.writeheader()
        for transaction in transactions:
            writer.writerow({'date': transaction.date, 'branch': transaction.branch.name,
                            'amount': transaction.amount, 'description': transaction.description})


def get_transactions_by_date_range(start_date, end_date, branch):
    transactions = Transactions.objects.filter(date__range=(
        start_date, end_date)).filter(branch=branch).all()
    generate_csv(transactions)
    return transactions

# send email with attachment


def clean_zesa_response(message):
    message_list = message.split('|')
    token = message_list[9]
    meter_number = message_list[3]
    kwH = message_list[13]
    energy = message_list[11]
    amount = float(message_list[12]) / 100
    return f"Token: {token}\nMeter: {meter_number}\nKwH: {kwH}\nEnergy: {energy}\nAmount: {amount}\nThank you for using Tumai."


class TransactionService:
    def __init__(self, payload, user=None):
        self.payload = payload
        self.api_username = config("API_USERNAME")
        self.api_key = config("API_KEY")
        self.url = config("BPA_URL")
        self.user = user

    @staticmethod
    def get_headers(self):
        return {"apiUsername": self.api_username, "apiKey": self.api_key}

    def verify(self):
        response = requests.post(
            url=f"{self.url}transactions/verify/",
            json=self.payload,
            headers=self.get_headers(self),
        )
        if response:
            return JsonResponse(
                status=status.HTTP_200_OK, data={"data": response.json()}
            )
        else:
            return JsonResponse(
                status=status.HTTP_400_BAD_REQUEST,
                data=response.json(),
            )

    def process(self):
        print("CHUFFFFFF : ", self.payload)
        rate = Rate.objects.first()
        bm_rate = 450 if self.user.branch.id in [
            4, 6, 12] else rate.blackmarket
        if rate:
            ib_amount = float(self.payload.get('amount')) * \
                float(rate.interbank)
            bm_amount = float(self.payload.get('amount')) * float(bm_rate)
            discount = float(((bm_amount - ib_amount)/ib_amount)*100)
            amount = round(float(self.payload.get('amount')) *
                           float(rate.interbank)*(1+discount/100), 2)
        else:
            return False, {"message": "Transaction Could not be processed"}

        payload = {
            "vendorReference": self.payload.get("vendorReference"),
            "amount": self.payload.get('amount') if self.payload.get('transactionType') in ['006', '0010', '0020'] else amount,
            "transactionType": self.payload.get('transactionType'),
            "currency": 'USD' if self.payload.get('transactionType') in ['006', '0010', '0020'] else 'ZWL',
            "extras": self.payload.get('extras')
        }
        print('payload amount', payload.get('amount'))
        if payload.get('transactionType') in ['006', '005']:
            response = requests.post(
                url=f"{self.url}transactions/verify/",
                json={
                    "accountNumber": payload.get("extras").get("accountNumber"),
                    "billerId": payload.get("extras").get("billerId"),
                },
                headers=self.get_headers(self),
            )
            if response.status_code == 200:
                payload["extras"]["fullName"] = response.json().get(
                    "message").get('response').get('customerName')
            else:
                return False, response.json()
        response = requests.post(
            url=f"{self.url}transactions/post/",
            json=payload,
            headers=self.get_headers(self),
        )
        print(response.content)
        if response.status_code == 200 and response.json()['successful']:
            Balances.deduct_balance(payload.get(
                'amount'), self.payload.get('transactionType'))
            return True, response.json()
        else:
            return False, response.json()


def get_balaces_provider(provider):
    # function will return balances for all mnos and zb
    if provider.lower() in ['econet', 'netone']:
        b = 'ECONET_BALANCE' if provider.lower() == 'econet' else 'NETONE_BALANCE'
        url = config("BPA_PYTHON_URL")
        payload = json.dumps({
            "vendor_reference": Utils.get_transaction_reference('TA'),
            "biller_code": b,
            "transaction_type": "010",
            "target_account": "263774231343",
            "amount": 1,
            "currency_code": "ZWL",
            "product_id": "A",
            "extras": {}
        })
        headers = {
            'api-password': config("BPA_PYTHON_PASS"),
            'api-username': config("BPA_PYTHON_USER"),
            'key': config("BPA_PYTHON_KEY"),
            'Content-Type': 'application/json'
        }

        response = requests.request("POST", url, headers=headers, data=payload)
        if response.status_code == 200:
            print(response.json())
            return {'balance': float(response.json()['upstream_response']['amount'])/100} if provider.lower() == 'econet' else {'balance': float(response.json()['upstream_response']['amount'])}
        else:
            return {'balance': "No Balance Found"}

    if provider.lower() == 'telecel':
        # get balance for telecel
        url_java = config("BPA_JAVA_URL")
        payload = json.dumps({
            "vendorReference": Utils.get_transaction_reference('TA'),
            "biller": "TELECEL",
            "type": "TELECEL_AGENT_BALANCE",
            "channel": "INTERNET"
        })
        headers = {
            'api-password': config("BPA_JAVA_PASS"),
            'api-username': config("BPA_JAVA_USER"),
            'key': config("BPA_JAVA_KEY"),
            'Content-Type': 'application/json'
        }

        response = requests.request(
            "POST", url_java, headers=headers, data=payload)
        if response.status_code == 200:
            print(response.text, response.json()[
                  'additionalData']['telecelBalanceResponse']['amount'])
            balance = response.json(
            )['additionalData']['telecelBalanceResponse']['amount']
            telecel = float(balance.replace(',', '').strip())
        else:
            telecel = 'Balance could not be retrieved'
        return {'balance': telecel}
    if provider.lower() in ['zb_rtgs', 'zb_usd']:
        c = 'USD' if provider.lower() == 'zb_usd' else 'ZWL'
        url = config("ZB_INQUIRY_URL")
        print('checking zb balance ', c)
        payload = json.dumps({
            "api_secret": config("ZB_INQUIRY_KEY"),
            "account_number": config("ZB_USD") if c == 'USD' else config("ZB_ZWL")
        })
        headers = {
            'Content-Type': 'application/json'
        }

        response = requests.request(
            "POST", url, headers=headers, data=payload)
        if response.status_code == 200:
            try:
                balance = float(response.json()['balance'].split(
                    "ZWL")[1].strip().replace(',', ''))
                print('balance: ', balance)
            except Exception as e:
                try:
                    balance = float(response.json()['balance'].split(
                        "USD")[1].strip().replace(',', ''))
                    print('balance: ', balance)
                except Exception as e:
                    print(e)
                    balance = 'Balance could not be retrieved'

        else:
            balance = 'Balance could not be retrieved'
    return {"balance": balance}


def get_statement_provider(provider):
    url = f"http://52.54.114.84:8011/api/v1/transactions/dashboard/filter/?transaction_biller={provider}"

    payload = {}
    headers = {}

    response = requests.request("GET", url, headers=headers, data=payload)
    if response.status_code == 200:
        return response.json()
    else:
        return {}


def get_insights():
    weekly_revenue_bills = Transactions.objects.filter(date_created__week=datetime.datetime.now(
    ).isocalendar()[1], transaction_type=TransactionTypes.filter_code('TA06'), status=True)
    weekly_revenue_charges = Transactions.objects.filter(date_created__week=datetime.datetime.now(
    ).isocalendar()[1], transaction_type=TransactionTypes.filter_code('TA04'), status=True)
    days_list = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun']
    weekly_revenue = {}
    for day in days_list:
        weekly_revenue[day] = {
            "revenue": 0,
            "bills_count": 0,
            "bills_total": 0,
            "charges_count": 0,
            "charges_total": 0
        }
    for bill in weekly_revenue_bills:
        weekly_revenue[bill.date_created.strftime(
            '%a').lower()]['revenue'] += bill.amount
        weekly_revenue[bill.date_created.strftime(
            '%a').lower()]['bills_count'] += 1
        weekly_revenue[bill.date_created.strftime(
            '%a').lower()]['bills_total'] += bill.amount
    for charge in weekly_revenue_charges:
        weekly_revenue[charge.date_created.strftime(
            '%a').lower()]['revenue'] += charge.amount
        weekly_revenue[charge.date_created.strftime(
            '%a').lower()]['charges_count'] += 1
        weekly_revenue[charge.date_created.strftime(
            '%a').lower()]['charges_total'] += charge.amount
    week_stats = weekly_revenue

    monthly_revenue_bills = Transactions.objects.filter(date_created__month=datetime.datetime.now(
    ).month, transaction_type=TransactionTypes.filter_code('TA06'), status=True)
    monthly_revenue_charges = Transactions.objects.filter(date_created__month=datetime.datetime.now(
    ).month, transaction_type=TransactionTypes.filter_code('TA04'), status=True)
    months_list = ['jan', 'feb', 'mar', 'apr', 'may',
                   'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec']
    monthly_revenue = {}
    for month in months_list:
        monthly_revenue[month] = {
            "revenue": 0,
            "bills_count": 0,
            "bills_total": 0,
            "charges_count": 0,
            "charges_total": 0
        }
    for bill in monthly_revenue_bills:
        monthly_revenue[bill.date_created.strftime(
            '%b').lower()]['revenue'] += bill.amount
        monthly_revenue[bill.date_created.strftime(
            '%b').lower()]['bills_count'] += 1
        monthly_revenue[bill.date_created.strftime(
            '%b').lower()]['bills_total'] += bill.amount
    for charge in monthly_revenue_charges:
        monthly_revenue[charge.date_created.strftime(
            '%b').lower()]['revenue'] += charge.amount
        monthly_revenue[charge.date_created.strftime(
            '%b').lower()]['charges_count'] += 1
        monthly_revenue[charge.date_created.strftime(
            '%b').lower()]['charges_total'] += charge.amount
    month_stats = monthly_revenue

    weekly_bill_payments = Transactions.objects.filter(date_created__week=datetime.datetime.now(
    ).isocalendar()[1], transaction_type=TransactionTypes.filter_code('TA06'), status=True)
    days_list = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun']
    weekly_revenue_bill_payments = {}
    for day in days_list:
        weekly_revenue_bill_payments[day] = {
            "econet": {"count": 0, "total": 0},
            "netone": {"count": 0, "total": 0},
            "telecel": {"count": 0, "total": 0},
            "dstv": {"count": 0, "total": 0},
            "zetdc": {"count": 0, "total": 0},
            "billers": {"count": 0, "total": 0},
            "fees": {"count": 0, "total": 0}
        }
    for bill in weekly_bill_payments:
        weekly_revenue_bill_payments[bill.date_created.strftime(
            '%a').lower()]['econet']["total"] += bill.amount if bill.bill_type in ['001', '0010'] else 0
        weekly_revenue_bill_payments[bill.date_created.strftime(
            '%a').lower()]['econet']["count"] += 1 if bill.bill_type in ['001', '0010'] else 0
        weekly_revenue_bill_payments[bill.date_created.strftime(
            '%a').lower()]['netone']["total"] += bill.amount if bill.bill_type in ['002', '0020'] else 0
        weekly_revenue_bill_payments[bill.date_created.strftime(
            '%a').lower()]['netone']["count"] += 1 if bill.bill_type in ['002', '0020'] else 0
        weekly_revenue_bill_payments[bill.date_created.strftime(
            '%a').lower()]['telecel']["total"] += bill.amount if bill.bill_type in ['003', '0030'] else 0
        weekly_revenue_bill_payments[bill.date_created.strftime(
            '%a').lower()]['telecel']["count"] += 1 if bill.bill_type in ['003', '0030'] else 0
        weekly_revenue_bill_payments[bill.date_created.strftime(
            '%a').lower()]['fees']["total"] += bill.amount if bill.bill_type == '004' else 0
        weekly_revenue_bill_payments[bill.date_created.strftime(
            '%a').lower()]['fees']["count"] += 1 if bill.bill_type == '004' else 0
        weekly_revenue_bill_payments[bill.date_created.strftime(
            '%a').lower()]['zetdc']["total"] += bill.amount if bill.bill_type == '005' else 0
        weekly_revenue_bill_payments[bill.date_created.strftime(
            '%a').lower()]['zetdc']["count"] += 1 if bill.bill_type == '005' else 0
        weekly_revenue_bill_payments[bill.date_created.strftime(
            '%a').lower()]['dstv']["total"] += bill.amount if bill.bill_type == '006' else 0
        weekly_revenue_bill_payments[bill.date_created.strftime(
            '%a').lower()]['dstv']["count"] += 1 if bill.bill_type == '006' else 0
        weekly_revenue_bill_payments[bill.date_created.strftime(
            '%a').lower()]['billers']["total"] += bill.amount if bill.bill_type == '007' else 0
        weekly_revenue_bill_payments[bill.date_created.strftime(
            '%a').lower()]['billers']["count"] += 1 if bill.bill_type == '007' else 0

    monthly_bills_payments = Transactions.objects.filter(date_created__month=datetime.datetime.now(
    ).month, transaction_type=TransactionTypes.filter_code('TA06'), status=True)
    months_list = ['jan', 'feb', 'mar', 'apr', 'may',
                   'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec']
    monthly_revenue_bill_payments = {}
    for month in months_list:
        monthly_revenue_bill_payments[month] = {
            "econet": {"count": 0, "total": 0},
            "netone": {"count": 0, "total": 0},
            "telecel": {"count": 0, "total": 0},
            "dstv": {"count": 0, "total": 0},
            "zetdc": {"count": 0, "total": 0},
            "billers": {"count": 0, "total": 0},
            "fees": {"count": 0, "total": 0}
        }
    for bill_payment in monthly_bills_payments:
        monthly_revenue_bill_payments[bill_payment.date_created.strftime(
            '%b').lower()]['econet']["total"] += bill_payment.amount if bill_payment.bill_type in ['001', '0010'] else 0
        monthly_revenue_bill_payments[bill_payment.date_created.strftime(
            '%b').lower()]['econet']["count"] += 1 if bill_payment.bill_type in ['001', '0010'] else 0
        monthly_revenue_bill_payments[bill_payment.date_created.strftime(
            '%b').lower()]['netone']["total"] += bill_payment.amount if bill_payment.bill_type in ['002', '0020'] else 0
        monthly_revenue_bill_payments[bill_payment.date_created.strftime(
            '%b').lower()]['netone']["count"] += 1 if bill_payment.bill_type in ['002', '0020'] else 0
        monthly_revenue_bill_payments[bill_payment.date_created.strftime(
            '%b').lower()]['telecel']["total"] += bill_payment.amount if bill_payment.bill_type in ['003', '0030'] else 0
        monthly_revenue_bill_payments[bill_payment.date_created.strftime(
            '%b').lower()]['telecel']["count"] += 1 if bill_payment.bill_type in ['003', '0030'] else 0
        monthly_revenue_bill_payments[bill_payment.date_created.strftime(
            '%b').lower()]['fees']["total"] += bill_payment.amount if bill_payment.bill_type == '004' else 0
        monthly_revenue_bill_payments[bill_payment.date_created.strftime(
            '%b').lower()]['fees']["count"] += 1 if bill_payment.bill_type == '004' else 0
        monthly_revenue_bill_payments[bill_payment.date_created.strftime(
            '%b').lower()]['zetdc']["total"] += bill_payment.amount if bill_payment.bill_type == '005' else 0
        monthly_revenue_bill_payments[bill_payment.date_created.strftime(
            '%b').lower()]['zetdc']["count"] += 1 if bill_payment.bill_type == '005' else 0
        monthly_revenue_bill_payments[bill_payment.date_created.strftime(
            '%b').lower()]['dstv']["total"] += bill_payment.amount if bill_payment.bill_type == '006' else 0
        monthly_revenue_bill_payments[bill_payment.date_created.strftime(
            '%b').lower()]['dstv']["count"] += 1 if bill_payment.bill_type == '006' else 0
        monthly_revenue_bill_payments[bill_payment.date_created.strftime(
            '%b').lower()]['billers']["total"] += bill_payment.amount if bill_payment.bill_type == '007' else 0
        monthly_revenue_bill_payments[bill_payment.date_created.strftime(
            '%b').lower()]['billers']["count"] += 1 if bill_payment.bill_type == '007' else 0

    week_bill = weekly_revenue_bill_payments
    month_bill = monthly_revenue_bill_payments
    return{
        "week": week_stats,
        "year": month_stats,
        "week_bill": week_bill,
        "year_bill": month_bill
    }


def get_insights_by_month(month):
    # group by day in a month
    transactions = Transactions.objects.filter(
        date_created__month=month, status=True)
    # grouped = itertools.groupby(transactions, lambda record: record.date_created.strftime("%Y-%m-%d"))
    dates = sorted(set([x.date_created.date() for x in transactions]))
    # dates = sorted(set([x.date_created for x in transactions]))
    print('==========>>>>', dates)
    return {
            "month": {
             date.strftime("%Y-%m-%d"):
                {
                    "bills_count": transactions.filter(transaction_type__code='TA06', date_created__date=date).count(),
                    "bills_total": transactions.filter(transaction_type__code='TA06', date_created__date=date).aggregate(Sum('amount'))['amount__sum'],
                    "econet": {
                        "count": transactions.filter(transaction_type__code='TA06',date_created__date=date,bill_type__in=['001', '0010']).count(), 
                        "total": transactions.filter(transaction_type__code='TA06',date_created__date=date,bill_type__in=['001', '0010']).aggregate(Sum('amount'))['amount__sum']},
                    "netone": {
                        "count": transactions.filter(transaction_type__code='TA06',date_created__date=date,bill_type__in=['002', '0020']).count(), 
                        "total": transactions.filter(transaction_type__code='TA06',date_created__date=date,bill_type__in=['002', '0020']).aggregate(Sum('amount'))['amount__sum']},
                    "telecel": {
                        "count": transactions.filter(transaction_type__code='TA06',date_created__date=date,bill_type__in=['003', '0030']).count(), 
                        "total": transactions.filter(transaction_type__code='TA06',date_created__date=date,bill_type__in=['003', '0030']).aggregate(Sum('amount'))['amount__sum']},
                    "dstv": {
                        "count": transactions.filter(transaction_type__code='TA06',date_created__date=date,bill_type='006').count(), 
                        "total": transactions.filter(transaction_type__code='TA06',date_created__date=date,bill_type='006').aggregate(Sum('amount'))['amount__sum']},
                    "zetdc": {
                        "count": transactions.filter(transaction_type__code='TA06',date_created__date=date,bill_type='005').count(), 
                        "total": transactions.filter(transaction_type__code='TA06',date_created__date=date,bill_type='005').aggregate(Sum('amount'))['amount__sum']},
                    "billers": {
                        "count": transactions.filter(transaction_type__code='TA06',date_created__date=date,bill_type='007').count(), 
                        "total": transactions.filter(transaction_type__code='TA06',date_created__date=date,bill_type='007').aggregate(Sum('amount'))['amount__sum']},
                    "fees": {
                        "count": transactions.filter(transaction_type__code='TA06',date_created__date=date,bill_type='004').count(), 
                        "total": transactions.filter(transaction_type__code='TA06',date_created__date=date,bill_type='004').aggregate(Sum('amount'))['amount__sum']},
                    "charges_count": transactions.filter(transaction_type__code='TA04', date_created__date=date).count(),
                    "charges_total": transactions.filter(transaction_type__code='TA04', date_created__date=date).aggregate(Sum('amount'))['amount__sum'],
                    "revenue": transactions.filter(transaction_type__code__in=['TA06', 'TA04'], date_created__date=date).aggregate(Sum('amount'))['amount__sum'],
                } for date in dates}
        }
    
def get_insights_branch(branch):
    weekly_revenue_bills = Transactions.objects.filter(branch__id=branch,date_created__week=datetime.datetime.now(
    ).isocalendar()[1], transaction_type=TransactionTypes.filter_code('TA06'), status=True)
    weekly_revenue_charges = Transactions.objects.filter(branch__id=branch,date_created__week=datetime.datetime.now(
    ).isocalendar()[1], transaction_type=TransactionTypes.filter_code('TA04'), status=True)
    days_list = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun']
    weekly_revenue = {}
    for day in days_list:
        weekly_revenue[day] = {
            "revenue": 0,
            "bills_count": 0,
            "bills_total": 0,
            "charges_count": 0,
            "charges_total": 0
        }
    for bill in weekly_revenue_bills:
        weekly_revenue[bill.date_created.strftime(
            '%a').lower()]['revenue'] += bill.amount
        weekly_revenue[bill.date_created.strftime(
            '%a').lower()]['bills_count'] += 1
        weekly_revenue[bill.date_created.strftime(
            '%a').lower()]['bills_total'] += bill.amount
    for charge in weekly_revenue_charges:
        weekly_revenue[charge.date_created.strftime(
            '%a').lower()]['revenue'] += charge.amount
        weekly_revenue[charge.date_created.strftime(
            '%a').lower()]['charges_count'] += 1
        weekly_revenue[charge.date_created.strftime(
            '%a').lower()]['charges_total'] += charge.amount
    week_stats = weekly_revenue

    monthly_revenue_bills = Transactions.objects.filter(branch__id=branch,date_created__month=datetime.datetime.now(
    ).month, transaction_type=TransactionTypes.filter_code('TA06'), status=True)
    monthly_revenue_charges = Transactions.objects.filter(branch__id=branch,date_created__month=datetime.datetime.now(
    ).month, transaction_type=TransactionTypes.filter_code('TA04'), status=True)
    months_list = ['jan', 'feb', 'mar', 'apr', 'may',
                   'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec']
    monthly_revenue = {}
    for month in months_list:
        monthly_revenue[month] = {
            "revenue": 0,
            "bills_count": 0,
            "bills_total": 0,
            "charges_count": 0,
            "charges_total": 0
        }
    for bill in monthly_revenue_bills:
        monthly_revenue[bill.date_created.strftime(
            '%b').lower()]['revenue'] += bill.amount
        monthly_revenue[bill.date_created.strftime(
            '%b').lower()]['bills_count'] += 1
        monthly_revenue[bill.date_created.strftime(
            '%b').lower()]['bills_total'] += bill.amount
    for charge in monthly_revenue_charges:
        monthly_revenue[charge.date_created.strftime(
            '%b').lower()]['revenue'] += charge.amount
        monthly_revenue[charge.date_created.strftime(
            '%b').lower()]['charges_count'] += 1
        monthly_revenue[charge.date_created.strftime(
            '%b').lower()]['charges_total'] += charge.amount
    month_stats = monthly_revenue

    weekly_bill_payments = Transactions.objects.filter(branch__id=branch,date_created__week=datetime.datetime.now(
    ).isocalendar()[1], transaction_type=TransactionTypes.filter_code('TA06'), status=True)
    days_list = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun']
    weekly_revenue_bill_payments = {}
    for day in days_list:
        weekly_revenue_bill_payments[day] = {
            "econet": {"count": 0, "total": 0},
            "netone": {"count": 0, "total": 0},
            "telecel": {"count": 0, "total": 0},
            "dstv": {"count": 0, "total": 0},
            "zetdc": {"count": 0, "total": 0},
            "billers": {"count": 0, "total": 0},
            "fees": {"count": 0, "total": 0}
        }
    for bill in weekly_bill_payments:
        weekly_revenue_bill_payments[bill.date_created.strftime(
            '%a').lower()]['econet']["total"] += bill.amount if bill.bill_type in ['001', '0010'] else 0
        weekly_revenue_bill_payments[bill.date_created.strftime(
            '%a').lower()]['econet']["count"] += 1 if bill.bill_type in ['001', '0010'] else 0
        weekly_revenue_bill_payments[bill.date_created.strftime(
            '%a').lower()]['netone']["total"] += bill.amount if bill.bill_type in ['002', '0020'] else 0
        weekly_revenue_bill_payments[bill.date_created.strftime(
            '%a').lower()]['netone']["count"] += 1 if bill.bill_type in ['002', '0020'] else 0
        weekly_revenue_bill_payments[bill.date_created.strftime(
            '%a').lower()]['telecel']["total"] += bill.amount if bill.bill_type in ['003', '0030'] else 0
        weekly_revenue_bill_payments[bill.date_created.strftime(
            '%a').lower()]['telecel']["count"] += 1 if bill.bill_type in ['003', '0030'] else 0
        weekly_revenue_bill_payments[bill.date_created.strftime(
            '%a').lower()]['fees']["total"] += bill.amount if bill.bill_type == '004' else 0
        weekly_revenue_bill_payments[bill.date_created.strftime(
            '%a').lower()]['fees']["count"] += 1 if bill.bill_type == '004' else 0
        weekly_revenue_bill_payments[bill.date_created.strftime(
            '%a').lower()]['zetdc']["total"] += bill.amount if bill.bill_type == '005' else 0
        weekly_revenue_bill_payments[bill.date_created.strftime(
            '%a').lower()]['zetdc']["count"] += 1 if bill.bill_type == '005' else 0
        weekly_revenue_bill_payments[bill.date_created.strftime(
            '%a').lower()]['dstv']["total"] += bill.amount if bill.bill_type == '006' else 0
        weekly_revenue_bill_payments[bill.date_created.strftime(
            '%a').lower()]['dstv']["count"] += 1 if bill.bill_type == '006' else 0
        weekly_revenue_bill_payments[bill.date_created.strftime(
            '%a').lower()]['billers']["total"] += bill.amount if bill.bill_type == '007' else 0
        weekly_revenue_bill_payments[bill.date_created.strftime(
            '%a').lower()]['billers']["count"] += 1 if bill.bill_type == '007' else 0

    monthly_bills_payments = Transactions.objects.filter(branch__id=branch,date_created__month=datetime.datetime.now(
    ).month, transaction_type=TransactionTypes.filter_code('TA06'), status=True)
    months_list = ['jan', 'feb', 'mar', 'apr', 'may',
                   'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec']
    monthly_revenue_bill_payments = {}
    for month in months_list:
        monthly_revenue_bill_payments[month] = {
            "econet": {"count": 0, "total": 0},
            "netone": {"count": 0, "total": 0},
            "telecel": {"count": 0, "total": 0},
            "dstv": {"count": 0, "total": 0},
            "zetdc": {"count": 0, "total": 0},
            "billers": {"count": 0, "total": 0},
            "fees": {"count": 0, "total": 0}
        }
    for bill_payment in monthly_bills_payments:
        monthly_revenue_bill_payments[bill_payment.date_created.strftime(
            '%b').lower()]['econet']["total"] += bill_payment.amount if bill_payment.bill_type in ['001', '0010'] else 0
        monthly_revenue_bill_payments[bill_payment.date_created.strftime(
            '%b').lower()]['econet']["count"] += 1 if bill_payment.bill_type in ['001', '0010'] else 0
        monthly_revenue_bill_payments[bill_payment.date_created.strftime(
            '%b').lower()]['netone']["total"] += bill_payment.amount if bill_payment.bill_type in ['002', '0020'] else 0
        monthly_revenue_bill_payments[bill_payment.date_created.strftime(
            '%b').lower()]['netone']["count"] += 1 if bill_payment.bill_type in ['002', '0020'] else 0
        monthly_revenue_bill_payments[bill_payment.date_created.strftime(
            '%b').lower()]['telecel']["total"] += bill_payment.amount if bill_payment.bill_type in ['003', '0030'] else 0
        monthly_revenue_bill_payments[bill_payment.date_created.strftime(
            '%b').lower()]['telecel']["count"] += 1 if bill_payment.bill_type in ['003', '0030'] else 0
        monthly_revenue_bill_payments[bill_payment.date_created.strftime(
            '%b').lower()]['fees']["total"] += bill_payment.amount if bill_payment.bill_type == '004' else 0
        monthly_revenue_bill_payments[bill_payment.date_created.strftime(
            '%b').lower()]['fees']["count"] += 1 if bill_payment.bill_type == '004' else 0
        monthly_revenue_bill_payments[bill_payment.date_created.strftime(
            '%b').lower()]['zetdc']["total"] += bill_payment.amount if bill_payment.bill_type == '005' else 0
        monthly_revenue_bill_payments[bill_payment.date_created.strftime(
            '%b').lower()]['zetdc']["count"] += 1 if bill_payment.bill_type == '005' else 0
        monthly_revenue_bill_payments[bill_payment.date_created.strftime(
            '%b').lower()]['dstv']["total"] += bill_payment.amount if bill_payment.bill_type == '006' else 0
        monthly_revenue_bill_payments[bill_payment.date_created.strftime(
            '%b').lower()]['dstv']["count"] += 1 if bill_payment.bill_type == '006' else 0
        monthly_revenue_bill_payments[bill_payment.date_created.strftime(
            '%b').lower()]['billers']["total"] += bill_payment.amount if bill_payment.bill_type == '007' else 0
        monthly_revenue_bill_payments[bill_payment.date_created.strftime(
            '%b').lower()]['billers']["count"] += 1 if bill_payment.bill_type == '007' else 0

    week_bill = weekly_revenue_bill_payments
    month_bill = monthly_revenue_bill_payments
    return{
        "week": week_stats,
        "year": month_stats,
        "week_bill": week_bill,
        "year_bill": month_bill
    }


def get_insights_by_month_branch(month,branch):
    # group by day in a month
    transactions = Transactions.objects.filter(branch__id=branch,
        date_created__month=month, status=True)
    # grouped = itertools.groupby(transactions, lambda record: record.date_created.strftime("%Y-%m-%d"))
    dates = sorted(set([x.date_created.date() for x in transactions]))
    # dates = sorted(set([x.date_created for x in transactions]))
    print('==========>>>>', dates)
    return {
            "month": {
             date.strftime("%Y-%m-%d"):
                {
                    "bills_count": transactions.filter(transaction_type__code='TA06', date_created__date=date).count(),
                    "bills_total": transactions.filter(transaction_type__code='TA06', date_created__date=date).aggregate(Sum('amount'))['amount__sum'],
                    "econet": {
                        "count": transactions.filter(transaction_type__code='TA06',date_created__date=date,bill_type__in=['001', '0010']).count(), 
                        "total": transactions.filter(transaction_type__code='TA06',date_created__date=date,bill_type__in=['001', '0010']).aggregate(Sum('amount'))['amount__sum']},
                    "netone": {
                        "count": transactions.filter(transaction_type__code='TA06',date_created__date=date,bill_type__in=['002', '0020']).count(), 
                        "total": transactions.filter(transaction_type__code='TA06',date_created__date=date,bill_type__in=['002', '0020']).aggregate(Sum('amount'))['amount__sum']},
                    "telecel": {
                        "count": transactions.filter(transaction_type__code='TA06',date_created__date=date,bill_type__in=['003', '0030']).count(), 
                        "total": transactions.filter(transaction_type__code='TA06',date_created__date=date,bill_type__in=['003', '0030']).aggregate(Sum('amount'))['amount__sum']},
                    "dstv": {
                        "count": transactions.filter(transaction_type__code='TA06',date_created__date=date,bill_type='006').count(), 
                        "total": transactions.filter(transaction_type__code='TA06',date_created__date=date,bill_type='006').aggregate(Sum('amount'))['amount__sum']},
                    "zetdc": {
                        "count": transactions.filter(transaction_type__code='TA06',date_created__date=date,bill_type='005').count(), 
                        "total": transactions.filter(transaction_type__code='TA06',date_created__date=date,bill_type='005').aggregate(Sum('amount'))['amount__sum']},
                    "billers": {
                        "count": transactions.filter(transaction_type__code='TA06',date_created__date=date,bill_type='007').count(), 
                        "total": transactions.filter(transaction_type__code='TA06',date_created__date=date,bill_type='007').aggregate(Sum('amount'))['amount__sum']},
                    "fees": {
                        "count": transactions.filter(transaction_type__code='TA06',date_created__date=date,bill_type='004').count(), 
                        "total": transactions.filter(transaction_type__code='TA06',date_created__date=date,bill_type='004').aggregate(Sum('amount'))['amount__sum']},
                    "charges_count": transactions.filter(transaction_type__code='TA04', date_created__date=date).count(),
                    "charges_total": transactions.filter(transaction_type__code='TA04', date_created__date=date).aggregate(Sum('amount'))['amount__sum'],
                    "revenue": transactions.filter(transaction_type__code__in=['TA06', 'TA04'], date_created__date=date).aggregate(Sum('amount'))['amount__sum'],
                } for date in dates}
        }
    
