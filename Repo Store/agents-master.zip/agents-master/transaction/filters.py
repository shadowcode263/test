from transaction.models import Transactions
from django.utils.timezone import make_aware
import django_filters
from django.db.models import Q
from django.conf import settings

import datetime
import pytz
import json

class CustomFilter(django_filters.FilterSet):
    q = django_filters.CharFilter(method='custom_filter')

    class Meta:
        model = Transactions
        fields = ['q']

    @staticmethod
    def custom_filter(query_data=None):
        make_date = lambda data: make_aware(datetime.datetime.strptime(data, '%Y-%m-%d'), pytz.timezone(settings.TIME_ZONE))
        q_set = {
            'amount': Q(amount=query_data.get('amount')) if query_data.get('amount') else None,
            'branch': Q(branch__code=query_data.get('branch')) if query_data.get('branch') else None,
            'transaction_type': Q(transaction_type__code=query_data.get('transaction_type')) if query_data.get('transaction_type') else None,
            'reference': Q(reference__icontains=query_data.get('reference')) if query_data.get('reference') else None,
            'user': Q(user=query_data.get('user')) if query_data.get('user') else None,
            'status': Q(status=json.loads(query_data.get('status').lower())) if query_data.get('status') else None,
            'start_date': Q(date_created__gte=make_date(query_data.get('start_date'))) if query_data.get('start_date') else None,
            'end_date': Q(date_created__lte=make_date(query_data.get('end_date'))) if query_data.get('end_date') else None
        }
        query = None
        for item in q_set.values():
            if item:
                if not query:
                    query = item
                else:
                    query &= item
        return Transactions.objects.filter(query) if query else Transactions.objects.filter.all()
