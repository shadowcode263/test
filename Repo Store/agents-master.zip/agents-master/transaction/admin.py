from django.contrib import admin

# Register your models here.
from transaction.models import Balances, CashFlowLedger, BillPayment, TransactionTypes, Transactions, Rate, WithdrawalLedger

@admin.register(Transactions, TransactionTypes, BillPayment, CashFlowLedger, Rate, Balances,WithdrawalLedger)
class UniversalAdmin(admin.ModelAdmin):
    def get_list_display(self, request):
        return [field.name for field in self.model._meta.concrete_fields]

    