
import datetime
import random

class Utils:

    @staticmethod
    def get_transaction_reference(prefix='T'):
        """generating vendor reference
        Args:
            prefix: Prefix to vendor reference
        Returns:
            response: Generated vendor number
        """
        MN = ["JA", 'FB', 'MA', 'AP', 'MY', 'JN', 'JL', 'AG', 'SP', 'OC', 'NV', 'DC']
        created = datetime.datetime.now()
        return f"{prefix if prefix else ''}{created.year}{MN[created.month - 1]}{created.day}{created.second}{random.randint(20000, 99999)}"

    @staticmethod
    def generate_reference_number(prefix='R'):
        """generating reference number/order number
        Returns:
            response: Generated reference number
        """
        created = datetime.datetime.now()
        return f"{prefix if prefix else ''}{created.day}{created.second}{random.randint(20000, 99999)}"