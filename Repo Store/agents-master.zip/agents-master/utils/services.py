from django.core.mail import send_mail
from django.conf import settings
from django.template.loader import render_to_string
from django.core.mail.message import EmailMultiAlternatives, BadHeaderError

class EmailService:

    def __init__(self, user_fullname,to_address=None,message=None, subject=None):

        self.user_fullname=user_fullname
        self.to_address=to_address
        self.message=message
        self.subject=subject

    def send_password_reset_plainttext_email(self):
        msg = f'''
        Greetings {self.user_fullname}\n\n
        Your password has been reset. Contact your administrator for your new credentials.
        \n\n\n
        Regards \n
        Tumai Agents Team
        '''
        
        try:
            send_mail(
                f'{self.user_fullname} PASSWORD RESET',
                msg,
                settings.DEFAULT_FROM_EMAIL,
                [self.to_address,]
            )
        except Exception as e:
            print(f'Error =======> {e}')

    def setup_template(self):

        template_path = render_to_string(
            "personnel/email.html",
            {
                "template_title": self.subject,
                "template_message": self.message,
            },
        )

        return template_path


    def send_template_email(self):

        self.message = f'''
        Greetings {self.user_fullname}\n\n
        Your password has been reset. Contact your administrator for your new credentials.
        \n\n\n
        Regards \n
        Tumai Agents Team
        '''

        self.subject = f'{self.user_fullname} PASSWORD RESET'

        try:
            msg = EmailMultiAlternatives(self.subject, self.message, settings.DEFAULT_FROM_EMAIL, [self.to_address])
            msg.attach_alternative(self.setup_template(), "text/html")
            msg.send()
            # if error occurs
        except BadHeaderError:
            return



    def send_welcome_template_email(self, pwd):

        self.message = f'''
        Greetings {self.user_fullname}\n\n
        Your Tumai Agent account has been activated. Your current password is {pwd}. You can
        reset this at a time of your convenience.

        For more information kindly contact your administrator.
        \n\n\n
        Regards \n
        Tumai Agents Team
        '''

        self.subject = f'{self.user_fullname} Welcome To TUMAI AGENTS'

        try:
            msg = EmailMultiAlternatives(self.subject, self.message, settings.DEFAULT_FROM_EMAIL, [self.to_address])
            msg.attach_alternative(self.setup_template(), "text/html")
            msg.send()
            # if error occurs
        except BadHeaderError:
            return

    
