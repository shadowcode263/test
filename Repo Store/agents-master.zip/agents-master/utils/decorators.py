from django.http.response import JsonResponse
from rest_framework import status
import requests
from decouple import config
from api.serializers.transaction import (
    TransactionExtrasDataSerializer,
    TransactionExtrasReloadlySerializer,
    TransactionExtrasElectricitySerializer,
    TransactionExtrasAirtimeSerializer,
    TransactionExtrasFeesSerializer,
    TransactionGenericSerializer,
    TransactionWalletReloadSerializer,
    DstvTransactionPayloadSerializer,
    NyaradzoPayloadSerializer,
    NRichardsExtrasSerializer,
    TelcoSerializer
)

class SwitchExtrasSerializer:
    def __init__(self, service):
        self.service = service

    def __call__(self, *args, **kwargs):
        serializers = {
            "001": TransactionExtrasAirtimeSerializer,
            "002": TransactionExtrasAirtimeSerializer,
            "003": TransactionExtrasAirtimeSerializer,
            "004": TransactionExtrasElectricitySerializer,
            "005": TransactionExtrasFeesSerializer,
            "006": DstvTransactionPayloadSerializer,
            "012": TransactionWalletReloadSerializer,
            "013": TelcoSerializer,
            "014": NyaradzoPayloadSerializer,
            "015": TransactionExtrasReloadlySerializer,
            "016": NRichardsExtrasSerializer,

            "0010": TransactionExtrasDataSerializer,
            "0020": TransactionExtrasDataSerializer,
            "0020": TransactionExtrasDataSerializer,
        }
        serializer = serializers.get(self.service)
        return serializer if serializer else TransactionGenericSerializer
