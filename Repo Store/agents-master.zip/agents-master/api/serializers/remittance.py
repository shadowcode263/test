from random import choices
from rest_framework import serializers
from remittance.models import Order

from utils.utils import Utils


class CreateOrderSerializer(serializers.Serializer):
    
    initiator_name = serializers.CharField(required=True, max_length=255, label="initiator_name")
    initiator_phone_number = serializers.CharField(required=True, max_length=255, label="initiator_phone_number")
    initiator_email = serializers.CharField(required=False, max_length=255, label="initiator_email")
    initiator_id_number = serializers.CharField(required=True, max_length=255, label="initiator_id_number")
    # recipient
    recipient_name = serializers.CharField(required=True, max_length=255, label="recipient_name")
    recipient_phone_number = serializers.CharField(required=True, max_length=255, label="recipient_phone_number")
    recipient_id_number = serializers.CharField(required=True, max_length=255, label="recipient_id_number")
    recipient_address = serializers.CharField(required=True, max_length=255, label="recipient_address")
    # order details
    source = serializers.CharField(required=True, max_length=255, label="source")
    amount = serializers.FloatField(required=True, label="amount", max_value=200)

    narration = serializers.CharField(required=True, max_length=255, label="narration")
    currency = serializers.CharField(required=True, max_length=255, label="currency")
    # vendor_reference = serializers.CharField(required=True, max_length=255, label="vendor_reference")

    def create(self, validated_data):
        return CreateOrderSerializer(**validated_data)


class UpdateOrderSerializer(serializers.Serializer):

    def create(self, validated_data):
        return UpdateOrderSerializer(**validated_data)


class CollectOrderSerializer(serializers.Serializer):
    reference_number = serializers.CharField(required=True, max_length=255, label="reference_number")
    order_number = serializers.CharField(required=True, max_length=255, label="order_number")
    confirmation_file = serializers.FileField(required=False, label="confirmation_file")
    
    def create(self, validated_data):
        return CollectOrderSerializer(**validated_data)
    
class RetrieveOrderSerializer(serializers.Serializer):
    reference_number = serializers.CharField(required=True, max_length=255, label="reference_number")
    def create(self, validated_data):
        return RetrieveOrderSerializer(**validated_data)
    


class ValidateOrderSerializer(serializers.Serializer):
    reference_number = serializers.CharField(required=True, max_length=255, label="reference_number")
    order_number = serializers.CharField(required=True, max_length=255, label="order_number")
    def create(self, validated_data):
        return ValidateOrderSerializer(**validated_data)
    
class ZbStatementSerializer(serializers.Serializer):
    days = serializers.IntegerField(required=True, label="days")
    account_type = serializers.CharField(required=True,label="account type")
    from_date = serializers.CharField(required=False)
    from_date = serializers.CharField(required=False)

    def create(self, validated_data):
        return ZbStatementSerializer(**validated_data)

    def validate(self, attrs):
        if not attrs['account_type'].lower() in ['zb_rtgs','zb_usd']:
            raise serializers.ValidationError("Invalid account type")
        return super().validate(attrs)


class OrdersSerializer(serializers.ModelSerializer):
    class Meta:
        model = Order
        fields = '__all__'
        
        
    def to_representation(self, obj):
        rep = super(OrdersSerializer, self).to_representation(obj)
        rep['ordering_agent'] = f'{obj.ordering_agent.first_name}-{obj.ordering_agent.branch.name}'   
        rep['collection_agent'] = f'{obj.collection_agent.first_name}-{obj.collection_agent.branch.name}'  if obj.collection_agent else None
        return rep
    
class GetChargeSerializer(serializers.Serializer):
    amount = serializers.IntegerField(required=True, label="amount")
    
    def create(self, validated_data):
        return GetChargeSerializer(**validated_data)
    
class CreateAgentSerializer(serializers.Serializer):
    phone_number = serializers.CharField(required=True, label="phone_number")
    
    def create(self, validated_data):
        return CreateAgentSerializer(**validated_data)