from rest_framework import serializers
from company.models import Branch
from remittance.models import Agents, AllocationRequest, DailyProcesses, Order
from rest_framework.validators import UniqueValidator
from transaction.models import TransactionTypes, Transactions
from users.models import AuthorizationManagers, User
import random
from django.contrib.auth.hashers import make_password
import datetime
from django.db.models import Sum
from django.db.models.functions import ExtractDay, ExtractWeek, ExtractMonth, ExtractYear


class CashAllocationRequestSerializer(serializers.Serializer):
    amount = serializers.FloatField(
        required=True, min_value=1, max_value=5000,
        label="amount"
    )
    type = serializers.CharField(required=True)
    narration = serializers.CharField(required=False,label="narration")
    denominations = serializers.JSONField(required=False,label="denominations")
    signature = serializers.CharField(required=False,label="signature")
    pin = serializers.CharField(required=False,label="pin")

    def create(self, validated_data):
        return CashAllocationRequestSerializer(**validated_data)

    def validate(self, attrs):
        if attrs["type"].lower()=='debit':
            if not attrs['signature']:
                raise serializers.ValidationError("Signature is required when dispatching money")
            if not attrs['pin']:
                raise serializers.ValidationError("Pin is required when dispatching money")
            if not attrs['denominations']:
                raise serializers.ValidationError("Denominations are required when dispatching money")
            if not AuthorizationManagers.authorize(attrs['pin']):
                raise serializers.ValidationError("Invalid Manager Code")
        return super().validate(attrs)

class CashPointSerializer(serializers.Serializer):
    branch = serializers.CharField(max_length=255)
    amount = serializers.CharField(max_length=255)

    def validate(self, attrs):
        print('validate', attrs)
        branch = Branch.filter_by_cash(attrs.get('branch'))
        if not branch:
            raise serializers.ValidationError("Invalid Branch ID")
        else:
            attrs['branch'] = branch
        print('everything is valid')
        return super().validate(attrs)

    def create(self, validated_data):
        return CashPointSerializer(**validated_data)


class AcknowlegdeAllocationRequestSerializer(serializers.Serializer):
    allocation_request = serializers.CharField(max_length=255)
    cash_points = serializers.ListField(
        required=True, child=serializers.CharField(max_length=255))
    type = serializers.CharField(required=True)

    def validate(self, attrs):
        print('validating cash point')
        allocation_request = AllocationRequest.objects.filter(
            id=attrs.get('allocation_request')).first()
        if not allocation_request:
            raise serializers.ValidationError("Invalid Allocation Request ID")
        if attrs['type'].lower() not in ['approve', 'decline']:
            raise serializers.ValidationError("Invalid Type")
        attrs['allocation_request'] = allocation_request
        return super().validate(attrs)

    def create(self, validated_data):
        return CashPointSerializer(**validated_data)


class AllocateAllocationRequestSerializer(serializers.Serializer):
    allocation_request = serializers.CharField(max_length=255)
    cash_points = serializers.ListField(required=True)

    def validate(self, attrs):
        allocation_request = AllocationRequest.objects.filter(
            id=attrs.get('allocation_request')).first()
        if not allocation_request:
            raise serializers.ValidationError("Invalid Allocation Request ID")
        attrs['allocation_request'] = allocation_request
        print('cash points', attrs['cash_points'])
        for cash_point in attrs.get('cash_points'):
            cash_point = CashPointSerializer(data=cash_point)
            if cash_point.is_valid():
                pass
            else:
                raise serializers.ValidationError("Invalid Cash Point")
        return attrs

    def create(self, validated_data):
        return AllocateAllocationRequestSerializer(**validated_data)

class ApproveAllocationRequestSerializer(serializers.Serializer):
    request_id = serializers.IntegerField(required=True)
    denominations = serializers.JSONField(required=True,label="denominations")
    signature = serializers.CharField(required=True,label="signature")
    pin = serializers.CharField(required=True,label="pin")

    def create(self, validated_data):
        return CashAllocationRequestSerializer(**validated_data)

    def validate(self, attrs):
        cash_request = AllocationRequest.filter_by_id(attrs['request_id'])
        if not cash_request:
            raise serializers.ValidationError("Allocation request id not valid")
        if not cash_request.stage == 'DISPATCHED':
            raise serializers.ValidationError("Allocation request is not on dispatched stage")
        if not AuthorizationManagers.authorize(attrs['pin']):
            raise serializers.ValidationError("Invalid Manager Code")
        attrs['request_id']=cash_request
        return super().validate(attrs)

class GetAllocationRequestsSerializer(serializers.ModelSerializer):
    branch_id = serializers.SerializerMethodField()

    class Meta:
        model = AllocationRequest
        fields = '__all__'

    def get_branch_id(self, obj):
        return obj.branch.id

    def to_representation(self, obj):
        rep = super(GetAllocationRequestsSerializer,
                    self).to_representation(obj)
        rep['agent'] = f'{obj.agent.first_name}-{obj.agent.last_name}' if obj.agent else None
        rep['branch'] = f'{obj.branch.name}-{obj.branch.code}'
        rep['approved_by'] = f'{obj.approved_by.first_name}-{obj.approved_by.last_name}' if obj.approved_by else None
        rep['status'] = obj.is_approved
        rep['entry_type'] = "Credit"
        return rep


class UserSerializer(serializers.ModelSerializer):
    phone_number = serializers.CharField(
        required=True,
        validators=[UniqueValidator(
            queryset=User.objects.all(), message="phone number already exists")]
    )
    email = serializers.EmailField(
        required=True,
        validators=[UniqueValidator(
            queryset=User.objects.all(), message="email already exists")]
    )
    id_number = serializers.CharField(
        required=True,
        validators=[UniqueValidator(
            queryset=User.objects.all(), message="national id already exists")]
    )
    branch = serializers.CharField(max_length=255, required=True)
    qr_code = serializers.SerializerMethodField()

    class Meta:
        model = User
        fields = ['id', 'first_name', 'last_name', 'email', 'id_number',
                  'branch', 'address', 'phone_number', 'agent_code', 'qr_code']
        read_only_fields = ['agent_code']

    def validate(self, attrs):
        branch = Branch.filter_by_code(attrs.get('branch'))
        if branch:
            attrs['branch'] = branch
        else:
            raise serializers.ValidationError("Invalid Branch Code")
        attrs['username'] = attrs['phone_number']
        attrs['agent_code'] = f'A{random.randint(10000,99999)}{User.objects.count()+1}'
        attrs['password'] = make_password(
            f"{attrs['first_name'][0:1]}{attrs['last_name']}")
        attrs['is_active'] = True
        return attrs

    def get_qr_code(self, obj):
        if Agents.filter_phone_number(obj.phone_number):
            return Agents.filter_phone_number(obj.phone_number).qr_code
        else:
            return None


class AgentStatisticsSerializer(serializers.ModelSerializer):
    number_of_orders = serializers.SerializerMethodField()
    number_of_bill_payments = serializers.SerializerMethodField()
    total_amount_bill_payments = serializers.SerializerMethodField()
    branch_balance = serializers.SerializerMethodField()
    check_in_status = serializers.SerializerMethodField()
    daily_statistics = serializers.SerializerMethodField()
    weekly_statistics = serializers.SerializerMethodField()
    monthly_statistics = serializers.SerializerMethodField()
    yearly_statistics = serializers.SerializerMethodField()
    check_in_statistics = serializers.SerializerMethodField()

    class Meta:
        model = User
        fields = ['id', 'first_name', 'last_name',
                  'email', 'id_number', 'branch',
                  'address', 'phone_number',
                  'check_in_status',
                  'number_of_orders', 'number_of_bill_payments',
                  'total_amount_bill_payments', 'branch_balance',
                  'daily_statistics', 'weekly_statistics',
                  'monthly_statistics', 'yearly_statistics',
                  'check_in_statistics']

    def get_number_of_orders(self, obj):
        return Order.objects.filter(ordering_agent=obj).count()

    def get_number_of_bill_payments(self, obj):
        return Transactions.objects.filter(transaction_type=TransactionTypes.filter_code('TA06'), user=obj, status=True).count()

    def get_total_amount_bill_payments(self, obj):
        return Transactions.objects.filter(transaction_type=TransactionTypes.filter_code('TA06'), user=obj, status=True).aggregate(Sum('amount'))['amount__sum']

    def get_branch_balance(self, obj):
        return obj.branch.running_balance

    def get_daily_statistics(self, obj):
        return {
            "orders_total": Transactions.objects.filter(date_created__date=datetime.datetime.now().date(), transaction_type=TransactionTypes.filter_code('TA05'), user=obj, status=True).aggregate(Sum('amount'))['amount__sum'],
            "orders_count": Transactions.objects.filter(date_created__date=datetime.datetime.now().date(), transaction_type=TransactionTypes.filter_code('TA05'), user=obj, status=True).count(),
            "bills_total": Transactions.objects.filter(date_created__date=datetime.datetime.now().date(), transaction_type=TransactionTypes.filter_code('TA06'), user=obj, status=True).aggregate(Sum('amount'))['amount__sum'],
            "bills_count": Transactions.objects.filter(date_created__date=datetime.datetime.now().date(), transaction_type=TransactionTypes.filter_code('TA06'), user=obj, status=True).count(),
            "charges_total": Transactions.objects.filter(date_created__date=datetime.datetime.now().date(), transaction_type=TransactionTypes.filter_code('TA04'), user=obj, status=True).aggregate(Sum('amount'))['amount__sum'],
        }

    def get_monthly_statistics(self, obj):
        return {
            "orders_total": Transactions.objects.filter(date_created__month=datetime.datetime.now().month, transaction_type=TransactionTypes.filter_code('TA05'), user=obj, status=True).aggregate(Sum('amount'))['amount__sum'],
            "orders_count": Transactions.objects.filter(date_created__month=datetime.datetime.now().month, transaction_type=TransactionTypes.filter_code('TA05'), user=obj, status=True).count(),
            "bills_total": Transactions.objects.filter(date_created__month=datetime.datetime.now().month, transaction_type=TransactionTypes.filter_code('TA06'), user=obj, status=True).aggregate(Sum('amount'))['amount__sum'],
            "bills_count": Transactions.objects.filter(date_created__month=datetime.datetime.now().month, transaction_type=TransactionTypes.filter_code('TA06'), user=obj, status=True).count(),
            "charges_total": Transactions.objects.filter(date_created__month=datetime.datetime.now().month, transaction_type=TransactionTypes.filter_code('TA04'), user=obj, status=True).aggregate(Sum('amount'))['amount__sum'],
        }

    def get_weekly_statistics(self, obj):
        return {
            "orders_total": Transactions.objects.filter(date_created__week=datetime.datetime.now().isocalendar()[1], transaction_type=TransactionTypes.filter_code('TA05'), user=obj, status=True).aggregate(Sum('amount'))['amount__sum'],
            "orders_count": Transactions.objects.filter(date_created__week=datetime.datetime.now().isocalendar()[1], transaction_type=TransactionTypes.filter_code('TA05'), user=obj, status=True).count(),
            "bills_total": Transactions.objects.filter(date_created__week=datetime.datetime.now().isocalendar()[1], transaction_type=TransactionTypes.filter_code('TA06'), user=obj, status=True).aggregate(Sum('amount'))['amount__sum'],
            "bills_count": Transactions.objects.filter(date_created__week=datetime.datetime.now().isocalendar()[1], transaction_type=TransactionTypes.filter_code('TA06'), user=obj, status=True).count(),
            "charges_total": Transactions.objects.filter(date_created__week=datetime.datetime.now().isocalendar()[1], transaction_type=TransactionTypes.filter_code('TA04'), user=obj, status=True).aggregate(Sum('amount'))['amount__sum'],
        }

    def get_yearly_statistics(self, obj):
        return {
            "orders_total": Transactions.objects.filter(date_created__year=datetime.datetime.now().year, transaction_type=TransactionTypes.filter_code('TA05'), user=obj, status=True).aggregate(Sum('amount'))['amount__sum'],
            "orders_count": Transactions.objects.filter(date_created__year=datetime.datetime.now().year, transaction_type=TransactionTypes.filter_code('TA05'), user=obj, status=True).count(),
            "bills_total": Transactions.objects.filter(date_created__year=datetime.datetime.now().year, transaction_type=TransactionTypes.filter_code('TA06'), user=obj, status=True).aggregate(Sum('amount'))['amount__sum'],
            "bills_count": Transactions.objects.filter(date_created__year=datetime.datetime.now().year, transaction_type=TransactionTypes.filter_code('TA06'), user=obj, status=True).count(),
            "charges_total": Transactions.objects.filter(date_created__year=datetime.datetime.now().year, transaction_type=TransactionTypes.filter_code('TA04'), user=obj, status=True).aggregate(Sum('amount'))['amount__sum'],
        }

    def get_check_in_status(self, obj):
        # get user check in time
        check_in = DailyProcesses.objects.filter(
            agent=obj).order_by('-id').first()
        if check_in:
            if check_in.check_in_time.date() == datetime.date.today() and check_in.check_out_time == None:
                return True
            else:
                return False
        else:
            False

    def get_check_in_statistics(self, obj):
        check_ins = [check_in_date.check_in_time for check_in_date in DailyProcesses.objects.filter(agent=obj,check_in_time__week=datetime.datetime.now().isocalendar()[1])]
        if check_ins:     
            average = self.average_time(check_ins)     
            return {
                "average_in": average
            }
        return {
            # 'average_in_out': average_in_out,
            'average_in': None,
        }
    
    def average_time(self,datetimeList): 
        sumOfTime=sum(map(datetime.datetime.timestamp,datetimeList))
        length=len(datetimeList) 

        averageTimeInTimeStampFormat=datetime.datetime.fromtimestamp(sumOfTime/length)
        timeInHumanReadableForm=datetime.datetime.strftime(averageTimeInTimeStampFormat,"%I:%M:%S")
        return timeInHumanReadableForm

    def to_representation(self, obj):
        rep = super(AgentStatisticsSerializer,
                    self).to_representation(obj)
        rep['branch'] = f'{obj.branch.name}-{obj.branch.code}'
        rep['user'] = f'{obj.first_name}-{obj.last_name}'
        return rep


class UserPasswordSerializer(serializers.Serializer):
    old_password = serializers.CharField(
        required=True, max_length=255, label="old_password")
    new_password = serializers.CharField(
        required=True, max_length=255, label="new_password")
    new_password2 = serializers.CharField(
        required=True, max_length=255, label="new_password2")

    def create(self, validated_data):
        return UserPasswordSerializer(**validated_data)

    def validate(self, attrs):
        if attrs['new_password'] != attrs['new_password2']:
            raise serializers.ValidationError("new passwords do not match")
        if len(attrs['new_password']) < 8:
            raise serializers.ValidationError(
                "new password must be at least 8 characters")
        if len(attrs['new_password']) > 20:
            raise serializers.ValidationError(
                "new password must be less than 20 characters")
        if attrs['new_password'] == attrs['old_password']:
            raise serializers.ValidationError(
                "new password cannot be the same as the old password")
        if not self.context['request'].user.check_password(attrs['old_password']):
            raise serializers.ValidationError("old password is incorrect")
        return super().validate(attrs)

class DailyProcessSerializer(serializers.Serializer):
    denominations = serializers.JSONField(required=True)
    variance = serializers.FloatField(required=True, label="variance")
    pin = serializers.CharField(required=True,max_length=10,label="pin")
    signature = serializers.CharField(required=True,label="signature")

    def create(self, validated_data):
        return DailyProcessSerializer(**validated_data)
    
    def validate(self, attrs):
        if not AuthorizationManagers.authorize(attrs['pin']):
            raise serializers.ValidationError("Invalid Manager Code")
        return super().validate(attrs)


class DailyProcessesSerializer(serializers.ModelSerializer):
    class Meta:
        model = DailyProcesses
        fields = '__all__'

    def to_representation(self, obj):
        rep = super(DailyProcessesSerializer, self).to_representation(obj)
        rep['branch'] = f'{obj.branch.name}-{obj.branch.code}'
        rep['agent'] = f'{obj.agent.first_name}-{obj.agent.last_name}'
        return rep


class UpdateUserSerializer(serializers.Serializer):
    user_id = serializers.IntegerField(required=True)
    is_deleted = serializers.BooleanField(required=False)
    branch = serializers.CharField(max_length=255, required=False)

    def create(self, validated_data):
        return UserPasswordSerializer(**validated_data)

    def validate(self, attrs):
        print(attrs)
        if attrs.get('branch'):
            branch = Branch.filter_by_code(attrs.get('branch'))
            if branch:
                attrs['branch'] = branch.id
            else:
                raise serializers.ValidationError("Invalid Branch Code")

        return super().validate(attrs)
