from rest_framework import serializers
from remittance.models import DailyProcesses
from transaction.models import Branch, TransactionTypes, Transactions
from users.models import AuthorizationManagers, User
from utils.utils import Utils
import datetime

class TransactionsSerializer(serializers.Serializer):
    reference = serializers.CharField(
        required=False, max_length=255, label="reference")
    transaction_type = serializers.CharField(
        required=False, max_length=255, label="transaction_type")
    amount = serializers.FloatField(required=False, label="amount")
    brach = serializers.CharField(
        required=False, max_length=255, label="branch")
    status = serializers.CharField(
        required=False, max_length=255, label="status")
    start_date = serializers.CharField(
        required=False, max_length=255, label="start_date")
    user = serializers.CharField(required=False, max_length=255, label="user")
    end_date = serializers.CharField(
        required=False, max_length=255, label="start_date")
    date_created = serializers.CharField(
        required=False, max_length=255, label="date_created")

    def validate(self, data):
        if data.get('user'):
            data['user'] = User.getUser(data.get('user'))
        if data.get('brach'):
            data['brach'] = Branch.filter_by_code(data.get('brach'))
        return data

    def create(self, validated_data):
        return TransactionsSerializer(**validated_data)

    def to_representation(self, obj):
        rep = super(TransactionsSerializer, self).to_representation(obj)
        rep['transaction_type'] = f'{obj.transaction_type.transaction_type}' if obj.transaction_type else ''
        rep['user'] = f'{obj.user.first_name}-{obj.user.last_name}' if obj.user else ''
        rep['bill_type'] = 'Econet' if obj.bill_type in ['001', '0010'] else 'Netone' if obj.bill_type in [
            '002', '0020'] else 'Telecel' if obj.bill_type == '003' else 'ZETDC' if obj.bill_type == '005' else 'DSTV' if obj.bill_type == '006' else 'None'
        rep['branch'] = f'{obj.branch.name}' if obj.branch else ''
        return rep


class TransactionTypesSerializer(serializers.ModelSerializer):
    class Meta:
        model = TransactionTypes
        fields = ('id', 'code', 'transaction_type', 'description')


class RetrieveTransactionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Transactions
        fields = ['transaction_type', 'branch', 'amount', 'status',
                  'reference', 'user', 'bill_type', 'date_created', 'payload']

    def to_representation(self, obj):
        rep = super(RetrieveTransactionSerializer, self).to_representation(obj)
        rep['transaction_type'] = f'{obj.transaction_type.transaction_type}' if obj.transaction_type else ''
        rep['user'] = f'{obj.user.first_name}-{obj.user.last_name}' if obj.user else ''
        rep['bill_type'] = 'Econet' if obj.bill_type in ['001', '0010'] else 'Netone' if obj.bill_type in [
            '002', '0020'] else 'Telecel' if obj.bill_type == '003' else 'ZETDC' if obj.bill_type == '005' else 'DSTV' if obj.bill_type == '006' else 'None'
        rep['branch'] = f'{obj.branch.name}' if obj.branch else ''
        return rep


class VerifyTransactionSerializer(serializers.Serializer):
    billerId = serializers.CharField(
        required=True, max_length=255, label="Biller ID")
    accountNumber = serializers.CharField(
        required=True, max_length=20, label="Transaction Type"
    )

    def create(self, validated_data):
        return VerifyTransactionSerializer(**validated_data)

    def validate(self, attrs):
        check_in = DailyProcesses.objects.filter(
            agent=self.context['request'].user).order_by('-id').first()
        if check_in:
            if check_in.check_in_time.date() == datetime.date.today() and check_in.check_out_time == None:
                pass
            else:
               raise serializers.ValidationError({"errors": "You cannot process transactions before you start your day"})
        else:
            raise serializers.ValidationError({"errors": "You cannot process transactions before you start your day"})
        return super().validate(attrs)


class PostTransactionSerializer(serializers.Serializer):
    vendorReference = serializers.CharField(
        required=False,
        default=Utils().get_transaction_reference,
        max_length=255,
        label="Vendor Reference",
    )
    transactionType = serializers.CharField(
        required=True, max_length=20, label="Transaction Type"
    )
    amount = serializers.FloatField(required=True, label="Amount", min_value=1)
    currency = serializers.CharField(default="USD")
    paymentType = serializers.CharField(default="Cash")
    source = serializers.CharField(default="Agents")
    sender_email = serializers.EmailField(required=False, label="Email")
    extras = serializers.JSONField(required=False, label="Extras")

    def validate(self, attrs):
        check_in = DailyProcesses.objects.filter(
            agent=self.context['request'].user).order_by('-id').first()
        if check_in:
            if check_in.check_in_time.date() == datetime.date.today() and check_in.check_out_time == None:
                pass
            else:
               raise serializers.ValidationError({"errors": "You cannot process transactions before you start your day"})
        else:
            raise serializers.ValidationError({"errors": "You cannot process transactions before you start your day"})
        from utils.decorators import SwitchExtrasSerializer

        serializer = SwitchExtrasSerializer(
            attrs["transactionType"]).__call__()
        print("USING SERIALIZER : ", serializer)

        if attrs["transactionType"] == "008":
            attrs["extras"] = attrs.get("extras")

        if (
            not serializer(data=attrs["extras"]).is_valid()
            and attrs["transactionType"] != "008"
        ):
            print("ERROOOOOR", attrs, serializer.errors)
            raise serializers.ValidationError({"errors": "Invalid Extras!"})

        if attrs["transactionType"] == "016":
            attrs["extras"] = {
                "CustomerMSISDN": attrs["extras"]["recepient_phone_number"],
                "billerId": attrs["extras"].pop("billerId"),
                "CustomerData": ",".join([str(i) for i in attrs["extras"].values()]),
            }
        print("FINAL ATTR ::::::::::::", attrs)
        return attrs

    def create(self, validated_data):
        return PostTransactionSerializer(**validated_data)


class DstvTransactionPayloadSerializer(serializers.Serializer):
    bouquet = serializers.CharField(required=True)
    currency = serializers.CharField(default="USD")
    addons = serializers.JSONField(required=False, label="Extras")

    def create(self, validated_data):
        return DstvTransactionPayloadSerializer(**validated_data)


class NyaradzoPayloadSerializer(serializers.Serializer):
    billerId = serializers.CharField(required=True)
    numberOfMonths = serializers.CharField(
        required=False, label="Number Of Months")
    monthlyPremium = serializers.CharField(
        required=False, label="Monthly Premium")
    sourceReference = serializers.CharField(
        required=False, label="Monthly Premium")
    accountNumber = serializers.CharField(
        required=False, label="Account Number")

    def create(self, validated_data):
        return NyaradzoPayloadSerializer(**validated_data)


class TransactionGenericSerializer(serializers.Serializer):
    ID = serializers.CharField(required=False, label="ID")
    transaction_type = serializers.CharField(
        required=False, label="Transaction Type")
    amount = serializers.CharField(required=False, label="Amount")
    status = serializers.CharField(required=False, label="Status")
    narration = serializers.CharField(required=False, label="Account Number")
    extras = serializers.JSONField(required=False)

    def create(self, validated_data):
        return TransactionGenericSerializer(**validated_data)


class TransactionOutSerializer(serializers.ModelSerializer):
    class Meta:
        model = Transactions
        fields = ['vendor_reference', 'transaction_type', 'paymentType', 'source', 'amount', 'status', 'narration',
                  'currency', 'email', 'upstream_response_message', 'extras', 'user', 'date_created', 'last_updated']


class TransactionExtrasElectricitySerializer(serializers.Serializer):
    phoneNumber = serializers.CharField(
        required=True, max_length=255, label="PhoneNumber"
    )
    accountNumber = serializers.CharField(
        required=True, max_length=20, label="AccountNumber"
    )
    billerId = serializers.CharField(
        required=True, max_length=20, label="Biller Id")
    fullName = serializers.CharField(
        required=True, max_length=255, label="FullName")

    def create(self, validated_data):
        return TransactionExtrasElectricitySerializer(**validated_data)


class TransactionWalletReloadSerializer(serializers.Serializer):
    phoneNumber = serializers.CharField(
        required=True, max_length=255, label="PhoneNumber"
    )

    def create(self, validated_data):
        return TransactionWalletReloadSerializer(**validated_data)


class TransactionExtrasAirtimeSerializer(serializers.Serializer):
    phoneNumber = serializers.CharField(
        required=True, max_length=255, label="PhoneNumber"
    )

    def create(self, validated_data):
        return TransactionExtrasAirtimeSerializer(**validated_data)


class TransactionExtrasReloadlySerializer(serializers.Serializer):
    phoneNumber = serializers.CharField(
        required=True, max_length=255, label="PhoneNumber"
    )
    country = serializers.CharField(
        required=True, max_length=255, label="Country")
    billerId = serializers.CharField(
        required=True, max_length=20, label="Biller Id")

    def create(self, validated_data):
        return TransactionExtrasReloadlySerializer(**validated_data)


class TransactionExtrasDataSerializer(serializers.Serializer):
    phoneNumber = serializers.CharField(
        required=True, max_length=255, label="PhoneNumber"
    )
    billerProduct = serializers.CharField(
        required=True, max_length=20, label="Biller Product"
    )

    def create(self, validated_data):
        return TransactionExtrasDataSerializer(**validated_data)


class TransactionExtrasFeesSerializer(serializers.Serializer):
    phoneNumber = serializers.CharField(
        required=True, max_length=255, label="PhoneNumber"
    )

    def create(self, validated_data):
        return TransactionExtrasFeesSerializer(**validated_data)


class NRichardsExtrasSerializer(serializers.Serializer):
    recepient_phone_number = serializers.CharField(
        required=True, max_length=255, label="Recepient Phone Number"
    )
    amount = serializers.FloatField(
        required=False, label="Amount", min_value=1)
    currency = serializers.CharField(default="USD", label="Currency")
    recepient_national_id = serializers.CharField(
        required=True, max_length=20, label="Recepient"
    )
    recepient_first_name = serializers.CharField(
        required=True, max_length=255, label="Recepient First Name"
    )
    recepient_last_name = serializers.CharField(
        required=True, max_length=255, label="Recepient Last Name"
    )
    billerId = serializers.CharField(
        required=True, max_length=20, label="Biller Id")

    def create(self, validated_data):
        return NRichardsExtrasSerializer(**validated_data)


class TelcoSerializer(serializers.Serializer):
    customer_id = serializers.CharField(required=True, label="Customer Id")
    service_id = serializers.CharField(
        required=True, max_length=255, label="Phone Number"
    )
    product_id = serializers.CharField(
        required=True, max_length=255, label="Product Id"
    )
    type = serializers.CharField(required=True, max_length=255, label="Type")

    def create(self, validated_data):
        return TelcoSerializer(**validated_data)


class WithdrawalSerializer(serializers.Serializer):
    amount = serializers.FloatField(required=True, label="amount")
    pin = serializers.CharField(required=True, max_length=10, label="pin")

    def create(self, validated_data):
        return WithdrawalSerializer(**validated_data)

    def validate(self, attrs):
        if attrs['amount'] > Branch.filter_by_code('BR-22').running_balance:
            raise serializers.ValidationError("Insufficient Balance")
        if not AuthorizationManagers.authorize_withdrawal(attrs['pin']):
            raise serializers.ValidationError("Failed to authorise withdrawal. Incorrect Pin.")
        return super().validate(attrs)

class GeneratePOPSerializer(serializers.Serializer):
    phone_number = serializers.CharField(
        required=True, max_length=255, label="PhoneNumber"
    )
    transaction_reference = serializers.CharField(required=True,max_length=255,label="transaction_reference")

    def create(self, validated_data):
        return GeneratePOPSerializer(**validated_data)

    def validate(self, attrs):
        transaction = Transactions.objects.filter(reference=attrs['transaction_reference']).first()
        if not transaction:
            raise serializers.ValidationError("Transaction could not be found")
        if transaction.bill_type not in ['004','005','006','007']:
            raise serializers.ValidationError("Proof of payment document not available for this transaction")
        if not transaction.status:
            raise serializers.ValidationError("Proof of payment document not available for this transaction, transaction was not successful")
        return super().validate(attrs)

