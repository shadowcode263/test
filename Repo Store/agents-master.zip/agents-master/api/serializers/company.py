from rest_framework import serializers
from company.models import Branch, Company
from remittance.models import Order
from transaction.models import TransactionTypes, Transactions
from users.models import User
from rest_framework.validators import UniqueValidator
from django.db.models import Q, Sum


class CompanySerializer(serializers.ModelSerializer):
    name = serializers.CharField(
        required=True,
        validators=[UniqueValidator(
            queryset=Company.objects.all(), message="name already exists")]
    )

    class Meta:
        model = Company
        fields = ('id', 'name', 'contact_person',
                  'contact_phone', 'code', 'upper_limit')
        read_only_fields = ('code',)


class BranchSerializer(serializers.ModelSerializer):
    company = serializers.CharField(
        required=True, max_length=255, label="company")

    class Meta:
        model = Branch
        fields = ('id', 'name', 'code', 'location',
                  'company', 'running_balance')
        read_only_fields = ('code', 'running_balance')

    def validate(self, attrs):
        company = Company.objects.filter(code=attrs.get('company')).first()
        if company:
            attrs['company'] = company
        else:
            raise serializers.ValidationError("Invalid Company Code")
        return super().validate(attrs)

class KioskSerializer(serializers.ModelSerializer):
    class Meta:
        model = Branch
        fields = ('id', 'name', 'code', 'location','city')

class UpdateBranchSerializer(serializers.Serializer):
    branch = serializers.CharField(required=True)
    user_id = serializers.CharField(required=True)

    def validate(self, attrs):
        branch = Branch.filter_by_code(code=attrs.get('branch'))
        if branch:
            attrs['branch'] = branch
        else:
            raise serializers.ValidationError("Invalid Branch Code")
        user = User.objects.filter(id=attrs.get('user_id')).first()
        if user and not user.is_superuser:
            attrs['user'] = user
        else:
            raise serializers.ValidationError("Invalid User ID")
        return super().validate(attrs)


class BalanceSerializer(serializers.Serializer):
    from_branch = serializers.CharField(
        required=True, max_length=255, label="from_branch")
    to_branch = serializers.CharField(
        required=True, max_length=255, label="to_branch")
    amount = serializers.FloatField(required=True, label="amount")

    def validate(self, attrs):
        from_branch = Branch.filter_by_code(attrs.get('from_branch'))
        to_branch = Branch.filter_by_code(attrs.get('to_branch'))
        if from_branch and to_branch:
            attrs['from_branch'] = from_branch
            attrs['to_branch'] = to_branch
        else:
            raise serializers.ValidationError("Invalid Branch Code")
        if from_branch.running_balance < attrs.get('amount'):
            raise serializers.ValidationError(
                "Branch has insufficient balance")
        if from_branch == to_branch:
            raise serializers.ValidationError(
                "Branch cannot transfer to itself")
        return super().validate(attrs)


class AllocationSerializer(serializers.Serializer):
    branch = serializers.CharField(
        required=True, max_length=255, label="branch")
    amount = serializers.FloatField(required=True, label="amount")
    mode = serializers.CharField(required=True, max_length=255, label="mode")

    def validate(self, attrs):
        branch = Branch.filter_by_code(attrs.get('branch'))
        if branch:
            attrs['branch'] = branch
        else:
            raise serializers.ValidationError("Invalid Branch Code")
        return super().validate(attrs)


class CompanyStatisticsSerializer(serializers.ModelSerializer):
    branches = serializers.SerializerMethodField()
    branch_orders = serializers.SerializerMethodField()
    branch_bill_payments = serializers.SerializerMethodField()
    branch_charges_total = serializers.SerializerMethodField()

    class Meta:
        model = Company
        fields = '__all__'

    def get_branches(self, obj):
        branches = Branch.objects.filter(company=obj)
        serializer = BranchSerializer(branches, many=True)
        return serializer.data

    def get_branch_orders(self, obj):
        for branch in Branch.objects.filter(company=obj):
            return {
                "branch": branch.name,
                "total_orders_amount": Order.objects.filter(Q(ordering_agent__branch=branch), (~Q(status="PENDING"))).aggregate(Sum('amount')),
                "total_orders": Order.objects.filter(Q(ordering_agent__branch=branch), (~Q(status="PENDING"))).count()
            }
        return {}

    def get_branch_bill_payments(self, obj):
        for branch in Branch.objects.filter(company=obj):
            return {
                "branch": branch.name,
                "total_bill_amount": Transactions.objects.filter(branch=branch, status=True, transaction_type=TransactionTypes.filter_code('TA06')).aggregate(Sum('amount')),
                "total_bills": Transactions.objects.filter(branch=branch, status=True, transaction_type=TransactionTypes.filter_code('TA06')).count()
            }
        return {}

    def get_branch_charges_total(self, obj):
        for branch in Branch.objects.filter(company=obj):
            return {
                "branch": branch.name,
                "total_charges_amount": Transactions.objects.filter(branch=branch, status=True, transaction_type=TransactionTypes.filter_code('TA04')).aggregate(Sum('amount')),
                "total_charges": Transactions.objects.filter(branch=branch, status=True, transaction_type=TransactionTypes.filter_code('TA04')).count()
            }
        return {}
