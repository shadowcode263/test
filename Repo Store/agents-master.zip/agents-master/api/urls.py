from django.urls import path, include
from rest_framework_simplejwt.views import (
    TokenObtainPairView,
    TokenRefreshView,
)

# from api.views.personnel import (
#     GetAgentCashBalancesView, PersonnelAdd, PersonnelListView, PersonnelDetailView, PersonnelPasswordResetView, AgentTransactionsListView,
#     PersonnelSelfPasswordResetView, AgentSelfTransactionsListView, AgentProfileView, AgentProfileVerifyOtp
# )
# from api.views.remittance import ApproveCashRequestView, ApproveOrderView, CollectOrderView, CreateOrderView, CreatePaymentOrderView, GetCashRequestsView, GetChargeView, GetMyOrdersView, GetOrdersView, GetSetCashRequestsView, RemittanceDetailsView, RetrieveOrderView, SetCashView, ValidateOrderView

# from api.views.transactions import VerifyTransactionView, PostTransactionView
# from api.views.auth import AuthTokenObtainPairView
# from api.views.wallets import A2PView, GetWallet, GetWallets, LookUpView

from api.views.company import CompanyViewSet
from api.views.transactions import CheckAccountBalance, DailyInsightBranchView, DailyInsightView, GeneratePOPView, GetBalancesView, GetLatestTransactions, GetStatementsView, InsightBranchView, InsightView, PostTransactionView, TransactionsView, UserBalanceView, VerifyTransactionView,TransactionTypeViewset,GetRateView, ViewBillPayments, ViewCurrentBillPayments, ViewCurrentOrders, ViewTransactionTypes, WithdrawOtpView, WithdrawalView

from rest_framework import routers
from api.views.auth import AuthTokenObtainPairView
from api.views.remittance import ( 
    ApproveOrderView,
    ApproveRgtsOrderView,
    CollectOrderView,
    CreateAgentView, 
    CreateOrderView, 
    CreatePaymentOrderView,
    CreateRtgsOrderView,
    GetActiveCities,
    GetCashOutlets,
    GetChargeView,
    GetConversion,
    GetKioskView,
    GetPendingOrdersView,
    RemittanceDetailsView, 
    RetrieveOrderView, 
    ValidateOrderView, 
    GetOrdersView,
    GetMyOrdersView,
    ZbStatementView,
    GetAllOrdersView,
)

from api.views.users import (
    AcknowledgeAllocationRequestView,
    AllocateAllocationRequestView,
    AppVersionView,
    DailyProcessesViewset,
    DeclineCashAllocationRequestView,
    ApproveCashAllocationRequestView,
    CashAllocationRequestView,
    GetAllPendingAllocations,
    GetAllocationRequestsHistory,
    GetAllocationRequestsView,
    AllocationView,
    GetMyAllocatedAllocationRequests,
    GetMyAllocationRequestsHistory,
    PasswordChange,
    UserViewSet,
    StartDayView,
    EndDayView, 
    GetBalances,
    GetAgentCashRequestsView
)
from users.models import AppVersion

router = routers.DefaultRouter()
router.register('company', CompanyViewSet, basename='company')
router.register('users', UserViewSet, basename='users')
router.register('transaction_types', TransactionTypeViewset, basename='users')
router.register('daily_processes', DailyProcessesViewset, basename='daily_processes')


urlpatterns = [
    # JWT TOKEN URLS
    path('token/fetch/', AuthTokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    
    path('password/change/', PasswordChange.as_view(), name='password_change'),

    #Daily processes urls
    path('daily/processes/start/', StartDayView.as_view(), name='start_day'),
    path('daily/processes/end/', EndDayView.as_view(), name='end_day'),
    path('daily/processes/balance/', GetBalances.as_view(), name='start_day'),
    
    
    # Cash Allocation Requests
    path('remittance/add/cash/', CashAllocationRequestView.as_view(), name='set_cash'),
    path('remittance/acknowledge/allocation/request/', AcknowledgeAllocationRequestView.as_view(), name='acknowledge_request'),
    path('remittance/allocate/allocation/request/', AllocateAllocationRequestView.as_view(), name='allocate_request'),
    path('remittance/view/all/requests/', GetAllocationRequestsHistory.as_view(), name='get_all_requests'),
    path('remittance/view/pending/allocations/', GetAllPendingAllocations.as_view(), name='get_all_pending_requests'),
    path('remittance/pending/allocated/allocations/', GetMyAllocatedAllocationRequests.as_view(), name='get_my_pending_requests'),
    path('remittance/view/personal/requests/', GetMyAllocationRequestsHistory.as_view(), name='get_personal_requests'),
    path('remittance/view/cash/requests/', GetAllocationRequestsView.as_view(), name='get_cash_requests'),
    path('remittance/approve/cash/requests/', ApproveCashAllocationRequestView.as_view(), name='approve_cash_requests'),
    path('remittance/decline/cash/requests/<str:request_id>/', DeclineCashAllocationRequestView.as_view(), name='decline_cash_requests'),
    path('remittance/cash/outlets/', GetCashOutlets.as_view(), name='cash_outlets'),
    path('remittance/all/kiosk/',GetKioskView.as_view(),name="all_kiosk"),
    # create order
    path('remittance/create/order/', CreateOrderView.as_view(), name='create_order'),
    path('remittance/create/order/rtgs/', CreateRtgsOrderView.as_view(), name='create_order_rtgs'),
    path('remittance/approve/order/rtgs/', ApproveRgtsOrderView.as_view(), name='approve_order_rtgs'),
    path('remittance/create/payment/order/', CreatePaymentOrderView.as_view(), name='create_payment_order'),
    path('remittance/retrieve/order/', RetrieveOrderView.as_view(), name='retrieve_order'),
    path('remittance/approve/order/', ApproveOrderView.as_view(), name='approve_order'),
    path('remittance/validate/order/', ValidateOrderView.as_view(), name='validate_order'),
    path('remittance/collect/order/', CollectOrderView.as_view(), name='collect_order'),
    path('zb/statement/', ZbStatementView.as_view(), name='zb_statement'),
    path('create/agent/', CreateAgentView.as_view(), name='create_agent'),
    path('remittance/cities/', GetActiveCities.as_view(), name='active_cities'),
    path('remittance/get/charge/', GetChargeView.as_view(), name='get_order_charge'),
    path('remittance/pending/collection/', GetPendingOrdersView.as_view(), name='get_pending_order'),
    path('remittance/get/conversion/', GetConversion.as_view(), name='get_conversion'),
    path('rate/conversion/', GetRateView.as_view(), name='get_rate_conversion'),
    path('make/adjustments/', AllocationView.as_view(), name='make_adjustments'),
    path('provider/balance/<str:provider>/', CheckAccountBalance.as_view(), name='provider_balance'),
    path('merchant/balance/', UserBalanceView.as_view(), name='user_balance'),
    path('withdraw/balance/', WithdrawalView.as_view(), name='withdraw_balance'),
    path('withdraw/otp/', WithdrawOtpView.as_view(), name='withdraw_otp'),
    path('', include(router.urls)),

    # Transactions
    path('transactions/', TransactionsView.as_view(), name='transactions'),
    path('transactions/latest/', GetLatestTransactions.as_view(), name='transactions_latest'),
    path('transactions/withdrawal/', WithdrawalView.as_view(), name='withdraw_transactions'),
    path('remittance/view/orders/', GetAllOrdersView.as_view(), name='view_orders'),
    path('remittance/personal/orders/', GetMyOrdersView.as_view(), name='view_my_orders'),
    path('remittance/view/all/requests/', GetAgentCashRequestsView.as_view(), name='get_all_requests'),
    path('remittance/statistics/', RemittanceDetailsView.as_view(), name='order_details'),
    path('account/balances/', GetBalancesView.as_view(), name='account_balances'),
    path('app/version/', AppVersionView.as_view(), name='app_version'),
    path('transactions/current/billpayments/', ViewCurrentBillPayments.as_view(), name='current_bill_payments'),
    path('remitance/current/orders/', ViewCurrentOrders.as_view(), name='current_orders'),


    # Transactions Posting
    path('transaction/types/', ViewTransactionTypes.as_view(), name='transaction_types'),
    path('transactions/verify/', VerifyTransactionView.as_view(), name='transaction_verify'),
    path('transactions/post/', PostTransactionView.as_view(), name='transaction_post'),
    path('transactions/bill/payments/', ViewBillPayments.as_view(), name='transaction_types'),
    path('provider/statement/<str:provider>/', GetStatementsView.as_view(), name='provider_statement'),
    path('transaction/pop/', GeneratePOPView.as_view(), name='transaction_pop'),
    path('transactions/insights/', InsightView.as_view(), name='transactions_insights'),
    path('transactions/daily/insights/<str:month>/', DailyInsightView.as_view(), name='transactions_daily_insights'),
    path('transactions/branch/insights/<str:branch>/', InsightBranchView.as_view(), name='transactions_branch_insights'),
    path('transactions/daily/branch/insights/<str:month>/<str:branch>/', DailyInsightBranchView.as_view(), name='transactions_daily_branch_insights'),

    # User Management
    # path('personnel/add/', PersonnelAdd.as_view(), name='personnel_add'),
    # path('view/personnel/', PersonnelListView.as_view(), name='personnel_list'),
    # path('view/personnel/<uuid:ID>/', PersonnelDetailView.as_view(), name='personnel_list'),
    # path('personnel/reset_password/<uuid:ID>/', PersonnelPasswordResetView.as_view(), name='personnel_password_reset'),
    # path('agent/reset_password/<uuid:ID>/', PersonnelSelfPasswordResetView.as_view(), name='agent_password_reset'),
    # path('agent/profile/<uuid:ID>/', AgentProfileView.as_view(), name='agent_profile'),
    # path('verify/otp/', AgentProfileVerifyOtp.as_view(), name='agent_profile_verify_otp'),

    # # My Transactions
    # path('personnel/fetch/transactions/<uuid:ID>/', AgentTransactionsListView.as_view(), name='personnel_transactions_list'),
    # path('agent/fetch/transactions/', AgentSelfTransactionsListView.as_view(), name='agent_transactions_list'),
    # path('agent/balances/', GetAgentCashBalancesView.as_view(), name='agent_balances'),


    
    # # remittance service
    # path('remittance/create/order/', CreateOrderView.as_view(), name='create_order'),
    
    # path('remittance/statistics/', RemittanceDetailsView.as_view(), name='order_details'),
     
    
    # path('remittance/get/charge/', GetChargeView.as_view(), name='get_order_charge'),
    
    # path('remittance/approve/cash/requests/', ApproveCashRequestView.as_view(), name='approve_cash_requests'),
    
    # # wallet service
    # path('wallet/lookup/', LookUpView.as_view(), name='wallet_lookup'),
    # path('wallet/agent/info/', GetWallet.as_view(), name='wallet_info'),
    # path('wallet/agents/info/', GetWallets.as_view(), name='wallets_info'),
    # path('wallet/loadbalance/', A2PView.as_view(), name='wallet_loadbalance'),
    

   
]
