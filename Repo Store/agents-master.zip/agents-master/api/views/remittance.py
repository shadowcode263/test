from curses.ascii import US
import json
from pyexpat import model
from api.serializers.company import KioskSerializer
from api.serializers.users import CashPointSerializer
from rest_framework.views import APIView
from rest_framework.renderers import JSONRenderer
from rest_framework.parsers import JSONParser
from django.http import JsonResponse
from rest_framework import status, generics
from api.serializers.remittance import CreateAgentSerializer, ZbStatementSerializer
from api.serializers.transaction import RetrieveTransactionSerializer
from remittance.filters import CustomFilterOrders
from remittance.helper_function import create_agent
from remittance.models import ActiveCities, Agents, AllocationRequest, CashOutlets, ConversionRate, DailyProcesses, Order, RTGSOrder
from remittance.serializers import (CashOutletSerializer, CitySerializer, CollectOrderSerializer, CreateOrderSerializer, CreateRtgsOrderSerializer, GetChargeSerializer,
                                    OrderSerializer, OrdersReportCSVSerializer, OrdersReportSerializer, RetrieveOrderSerializer,
                                    ValidateOrderSerializer,
                                    OrdersSerializer, OrderValidateSerializer)
from rest_framework.permissions import IsAuthenticated
from django.core.exceptions import ObjectDoesNotExist
from django.db.models import Q
from rest_framework.response import Response
from agents.tasks import notify
from transaction.helper_functions import map_payload
from users.models import User
from utils.utils import Utils
from transaction.models import CashFlowLedger, TransactionTypes, Transactions
from company.models import Branch
import datetime
from django.utils.timezone import make_aware
import pytz
from django.conf import settings
import requests
from django.db.models import Sum
from decouple import config


class CreateOrderView(APIView):
    parser_classes = [JSONParser]
    renderer_classes = [JSONRenderer]
    serializer_class = CreateOrderSerializer
    permission_classes = ()

    def post(self, request):
        try:
            serializer = self.serializer_class(data=request.data)
            if serializer.is_valid():
                amount = serializer.validated_data['amount']
                if amount <= 60:
                    charge = 2
                elif amount > 60 and amount <= 150:
                    charge = 3
                elif amount > 150:
                    charge = 4
                else:
                    charge = amount*0.03
                serializer.validated_data['reference_number'] = Utils.generate_reference_number(
                )
                serializer.validated_data['charge'] = charge
                serializer.validated_data['date_created'] = make_aware(
                    datetime.datetime.now(), timezone=pytz.timezone(settings.TIME_ZONE))
                order = serializer.save()
                # todo send sms
                notify.delay(user=serializer.validated_data['initiator_phone_number'],
                             message=f"Your order of ${order.amount} has been initiated with reference number {order.reference_number}. Please take your reference number to the nearest Tumai agent. Thank you.")
                return JsonResponse(status=status.HTTP_200_OK, data={
                    "reference_number": order.reference_number,
                    "total_amount": order.amount + order.charge,
                    "message": "Order created successfully",
                })
            else:
                return JsonResponse(
                    status=status.HTTP_400_BAD_REQUEST, data={
                        'message': serializer.errors}
                )
        except Exception as e:
            return JsonResponse(
                status=status.HTTP_500_INTERNAL_SERVER_ERROR, data={
                    'message': f'{e}'}
            )


class CreatePaymentOrderView(APIView):
    parser_classes = [JSONParser]
    renderer_classes = [JSONRenderer]
    permission_classes = (IsAuthenticated,)
    serializer_class = CreateOrderSerializer

    def post(self, request):
        data = map_payload(request.data)
        try:
            serializer = self.serializer_class(data=data)
            if serializer.is_valid():
                # check log in status
                if request.user.is_prepaid:
                    pass
                else:
                    check_in = DailyProcesses.objects.filter(
                        agent=request.user).order_by('-id').first()
                    if check_in:
                        if check_in.check_in_time.date() == datetime.date.today() and check_in.check_out_time == None:
                            pass
                        else:
                            return JsonResponse(
                                status=status.HTTP_400_BAD_REQUEST, data={
                                    'message': 'You cannot process orders before you start your day'}
                            )
                    else:
                        return JsonResponse(
                                status=status.HTTP_400_BAD_REQUEST, data={
                                    'message': 'You cannot process orders before you start your day'}
                            )
                # end check
                amount = serializer.validated_data['amount']
                if amount <= 60:
                    charge = 2
                elif amount > 60 and amount <= 150:
                    charge = 3
                elif amount > 150:
                    charge = 4
                else:
                    charge = amount*0.03
                serializer.validated_data['reference_number'] = Utils.generate_reference_number(
                    prefix='R')
                serializer.validated_data['charge'] = charge
                serializer.validated_data['status'] = 'APPROVED'
                serializer.validated_data['ordering_agent'] = request.user
                serializer.validated_data['order_number'] = Utils.generate_reference_number(
                    prefix='T')
                serializer.validated_data['date_created'] = make_aware(
                    datetime.datetime.now(), timezone=pytz.timezone(settings.TIME_ZONE))
                serializer.validated_data['date_approved'] = make_aware(
                    datetime.datetime.now(), timezone=pytz.timezone(settings.TIME_ZONE))
                order = serializer.save()
                main_txn = Transactions.create_transaction(
                    request.user, order.amount, TransactionTypes.filter_code("TA05"), extras=order.id, status=True)
                charge_txn = Transactions.create_transaction(
                    request.user, order.charge, TransactionTypes.filter_code("TA04"), extras=order.id, status=True)

                CashFlowLedger.create_record(
                    main_txn, request.user, order.amount, True)
                CashFlowLedger.create_record(
                    charge_txn, request.user, order.charge, True)
                request.user.branch.increment_balance(
                    order.amount+order.charge)
                # todo send sms
                notify.delay(user=serializer.validated_data['initiator_phone_number'],
                             message=f"Your order of ${order.amount} has been created with reference number {order.reference_number},  order number  {order.order_number}. Thank you for using Tumai.")
                notify.delay(user=serializer.validated_data['recipient_phone_number'],
                             message=f"You have received ${order.amount} from {order.initiator_name} with reference no {order.reference_number},  order no  {order.order_number}. Take your ID to the nearest Tumai agent to collect. Thank you.")

                return JsonResponse(status=status.HTTP_200_OK, data={
                    "reference_number": order.reference_number,
                    "total_amount": order.amount + order.charge,
                    "order_number": f"{order.order_number[:2]}*******{order.order_number[8:]}",
                    "message": "Order created successfully",
                })
            else:
                print('errors', serializer.errors)
                return JsonResponse(
                    status=status.HTTP_400_BAD_REQUEST, data={
                        'message': serializer.errors}
                )
        except Exception as e:
            return JsonResponse(
                status=status.HTTP_500_INTERNAL_SERVER_ERROR, data={
                    'message': f'{e}'}
            )


class RetrieveOrderView(APIView):
    parser_classes = [JSONParser]
    renderer_classes = [JSONRenderer]
    permission_classes = (IsAuthenticated,)
    serializer_class = RetrieveOrderSerializer

    def post(self, request):
        try:
            serializer = self.serializer_class(data=request.data)
            if serializer.is_valid():
                # check log in status
                if request.user.is_prepaid:
                    pass
                else:
                    check_in = DailyProcesses.objects.filter(
                        agent=request.user).order_by('-id').first()
                    if check_in:
                        if check_in.check_in_time.date() == datetime.date.today() and check_in.check_out_time == None:
                            pass
                        else:
                            return JsonResponse(
                                status=status.HTTP_400_BAD_REQUEST, data={
                                    'message': 'You cannot process orders before you start your day'}
                            )
                    else:
                        return JsonResponse(
                                status=status.HTTP_400_BAD_REQUEST, data={
                                    'message': 'You cannot process orders before you start your day'}
                            )
                # end check
                try:
                    order = Order.objects.get(
                        reference_number=serializer.data['reference_number'])
                except ObjectDoesNotExist:
                    try:
                        order = Order.objects.get(
                            reference_number=f"R{serializer.data['reference_number']}")
                    except ObjectDoesNotExist:
                        return JsonResponse(status=status.HTTP_404_NOT_FOUND, data={'message': 'Order could not be found'})
                    return JsonResponse(status=status.HTTP_404_NOT_FOUND, data={'message': 'Order could not be found'})
                serializer = OrderSerializer(order)
                return JsonResponse(data=serializer.data, status=status.HTTP_200_OK, safe=False)
            else:
                return JsonResponse(
                    status=status.HTTP_400_BAD_REQUEST, data={
                        'message': serializer.errors}
                )
        except Exception as e:
            return JsonResponse(
                status=status.HTTP_500_INTERNAL_SERVER_ERROR, data={
                    'message': f'{e}'}
            )


class ApproveOrderView(APIView):
    parser_classes = [JSONParser]
    renderer_classes = [JSONRenderer]
    permission_classes = (IsAuthenticated,)
    serializer_class = RetrieveOrderSerializer

    def post(self, request):
        try:
            serializer = self.serializer_class(data=request.data)
            if serializer.is_valid():
                # check log in status
                if request.user.is_prepaid:
                    pass
                else:
                    check_in = DailyProcesses.objects.filter(
                        agent=request.user).order_by('-id').first()
                    if check_in:
                        if check_in.check_in_time.date() == datetime.date.today() and check_in.check_out_time == None:
                            pass
                        else:
                            return JsonResponse(
                                status=status.HTTP_400_BAD_REQUEST, data={
                                    'message': 'You cannot process orders before you start your day'}
                            )
                    else:
                        return JsonResponse(
                                status=status.HTTP_400_BAD_REQUEST, data={
                                    'message': 'You cannot process orders before you start your day'}
                            )
                # end check
                try:
                    order = Order.objects.get(
                        reference_number=serializer.data['reference_number'])
                except ObjectDoesNotExist:
                    try:
                        order = Order.objects.get(
                            reference_number=f"R{serializer.data['reference_number']}")
                    except ObjectDoesNotExist:
                        return JsonResponse(status=status.HTTP_404_NOT_FOUND, data={'message': 'Order could not be found'})
                    return JsonResponse(status=status.HTTP_404_NOT_FOUND, data={'message': 'Order could not be found'})
                try:
                    if order.status == 'PENDING':
                        validate = request.user.validate_approval(
                            order.amount + order.charge)
                        if validate:
                            print('Approving Order after validation')
                            order.approve(request.user)

                            # adding line to legder
                            # todo send sms
                            notify.delay(user=order.initiator_phone_number,
                                         message=f"Your order of ${order.amount} has been created with reference number {order.reference_number},  order number  {order.order_number}. Tumai, Thank you.")
                            notify.delay(user=order.recipient_phone_number,
                                         message=f"You have received ${order.amount} from {order.initiator_name} with reference no. {order.reference_number},  order no.  {order.order_number}. Take your ID to the nearest Tumai agent to collect. Thank you.")

                        else:
                            return JsonResponse(status=status.HTTP_400_BAD_REQUEST, data={'message': 'Insufficient Balance to approve order'})
                    else:
                        return JsonResponse(status=status.HTTP_400_BAD_REQUEST, data={'message': 'Order Already Approved'})

                except Exception as e:
                    print(e)
                    return JsonResponse(status=status.HTTP_400_BAD_REQUEST, data={'message': 'Failed to approve order'})
                return JsonResponse(status=status.HTTP_200_OK, data={'message': 'Order approved',
                                                                     'order_number': order.order_number})
            else:
                return JsonResponse(
                    status=status.HTTP_400_BAD_REQUEST, data={
                        'message': serializer.errors}
                )
        except Exception as e:
            return JsonResponse(
                status=status.HTTP_500_INTERNAL_SERVER_ERROR, data={
                    'message': f'{e}'}
            )


class ValidateOrderView(APIView):
    parser_classes = [JSONParser]
    renderer_classes = [JSONRenderer]
    permission_classes = (IsAuthenticated,)
    serializer_class = ValidateOrderSerializer

    def post(self, request):
        try:
            print('validating order', request.data)
            serializer = self.serializer_class(data=request.data)
            if serializer.is_valid():
                # check log in status
                if request.user.is_prepaid:
                    pass
                else:
                    check_in = DailyProcesses.objects.filter(
                        agent=request.user).order_by('-id').first()
                    if check_in:
                        if check_in.check_in_time.date() == datetime.date.today() and check_in.check_out_time == None:
                            pass
                        else:
                            return JsonResponse(
                                status=status.HTTP_400_BAD_REQUEST, data={
                                    'message': 'You cannot process orders before you start your day'}
                            )
                    else:
                        return JsonResponse(
                                status=status.HTTP_400_BAD_REQUEST, data={
                                    'message': 'You cannot process orders before you start your day'}
                            )
                # end check
                try:
                    order = Order.objects.get(
                        reference_number=serializer.data['reference_number'])
                    order_no = Order.objects.get(
                        order_number=serializer.data['order_number'])
                except ObjectDoesNotExist:
                    try:
                        order = Order.objects.get(
                            reference_number=f"R{serializer.data['reference_number']}")
                        order_no = Order.objects.get(
                            order_number=f"T{serializer.data['order_number']}")
                    except ObjectDoesNotExist:
                        return JsonResponse(status=status.HTTP_404_NOT_FOUND, data={'message': 'Order could not be found'})
                    return JsonResponse(status=status.HTTP_404_NOT_FOUND, data={'message': 'Order could not be found'})
                serializer = OrderValidateSerializer(order)
                return JsonResponse(data=serializer.data, status=status.HTTP_200_OK, safe=False)
            else:
                return JsonResponse(
                    status=status.HTTP_400_BAD_REQUEST, data={
                        'message': serializer.errors}
                )
        except Exception as e:
            return JsonResponse(
                status=status.HTTP_500_INTERNAL_SERVER_ERROR, data={
                    'message': f'{e}'}
            )


class CollectOrderView(APIView):
    permission_classes = (IsAuthenticated,)
    serializer_class = CollectOrderSerializer

    def post(self, request):
        try:
            serializer = self.serializer_class(data=request.data)
            if serializer.is_valid():
                # check log in status
                if request.user.is_prepaid:
                    pass
                else:
                    check_in = DailyProcesses.objects.filter(
                        agent=request.user).order_by('-id').first()
                    if check_in:
                        if check_in.check_in_time.date() == datetime.date.today() and check_in.check_out_time == None:
                            pass
                        else:
                            return JsonResponse(
                                status=status.HTTP_400_BAD_REQUEST, data={
                                    'message': 'You cannot process orders before you start your day'}
                            )
                    else:
                        return JsonResponse(
                                status=status.HTTP_400_BAD_REQUEST, data={
                                    'message': 'You cannot process orders before you start your day'}
                            )
                # end check
                try:
                    print('collecting order ',serializer.data['order_number'])
                    order = Order.objects.get(
                        reference_number=serializer.data['reference_number'])
                    order_no = Order.objects.get(
                        order_number=serializer.data['order_number'])
                except ObjectDoesNotExist:
                    try:
                        order = Order.objects.get(
                            reference_number=f"R{serializer.data['reference_number']}")
                        order_no = Order.objects.get(
                            order_number=f"T{serializer.data['order_number']}")
                    except ObjectDoesNotExist:
                        return JsonResponse(status=status.HTTP_404_NOT_FOUND, data={'message': 'Order could not be found'})
                    return JsonResponse(status=status.HTTP_404_NOT_FOUND, data={'message': 'Order could not be found'})
                try:
                    if order.status == 'APPROVED':
                        # check balance
                        if request.user.branch.running_balance < order.amount:
                            return JsonResponse(status=status.HTTP_400_BAD_REQUEST, data={"message": "Branch does not have balance to perfom transaction"})
                        order.collect(request.user)
                        # todo add ledger line
                        # send collection sms
                        notify.delay(user=order.initiator_phone_number,
                                     message=f"Your order of ${order.amount} with reference number {order.reference_number} and  order number  {order.order_number} has been collected at {order.collection_agent.branch.location}.  Thank you for using our service, Tumai.")
                    else:
                        return JsonResponse(status=status.HTTP_400_BAD_REQUEST, data={'message': 'Order Already Collected'})
                except Exception as e:
                    return JsonResponse(status=status.HTTP_400_BAD_REQUEST, data={'message': f'Failed to collect order - {e}'})
                return JsonResponse(status=status.HTTP_200_OK, data={'message': 'Order collected',
                                                                     'order_number': order.order_number})
            else:
                return JsonResponse(
                    status=status.HTTP_400_BAD_REQUEST, data={
                        'message': serializer.errors}
                )
        except Exception as e:
            return JsonResponse(
                status=status.HTTP_500_INTERNAL_SERVER_ERROR, data={
                    'message': f'{e}'}
            )


class GetOrdersView(generics.ListAPIView):
    renderer_classes = [JSONRenderer]
    permission_classes = (IsAuthenticated,)
    serializer_class = OrdersSerializer

    def get_queryset(self):
        return Order.objects.all()

    def list(self, request):
        queryset = self.get_queryset()
        page = self.paginate_queryset(queryset)
        serializer = self.serializer_class(queryset, many=True)
        response_list = serializer.data
        return JsonResponse(data={"orders": response_list}, status=status.HTTP_200_OK, safe=False)

class GetAllOrdersView(APIView):
    serializer_class = OrdersSerializer
    parser_classes = (JSONParser, )
    filter = CustomFilterOrders
    model = Order

    def post(self, request, *args, **kwargs):
        payload = json.loads(request.body)
        orders = OrdersSerializer(
            data=self.apply_filter(payload=payload, user=request.user),
            many=True
        )
        orders.is_valid()
        return JsonResponse(status=200, data={'orders': orders.data})

    def get(self, request, *args, **kwargs):
        orders = OrdersSerializer(
            data=self.model.objects.all(),
            many=True
        )
        orders.is_valid()
        return JsonResponse(status=200, data={'orders': orders.data})

    def apply_filter(self, payload: dict, user=None):
        query = {
            field: payload.get(field)
            for field in [
                'reference_number',
                'order_number',
                'recipient_phone_number',
                'initiator_phone_number',
                'recipient_id_number',
                'initiator_id_number',
                'recipient_name',
                'initiator_name',
                'amount',
                'status',
                'branch',
                'ordering_agent',
                'start_date',
                'end_date'
            ] if payload.get(field)
        }
        if user:
            query['ordering_agent'] = User.getUser(id=payload.get("ordering_agent"))
        object_list = self.filter.custom_filter(query)
        return object_list


class GetPendingOrdersView(generics.ListAPIView):
    renderer_classes = [JSONRenderer]
    permission_classes = (IsAuthenticated,)
    serializer_class = OrdersSerializer

    def get_queryset(self):
        return Order.objects.filter(status='APPROVED')

    def list(self, request):
        queryset = self.get_queryset()
        page = self.paginate_queryset(queryset)
        serializer = self.serializer_class(queryset, many=True)
        response_list = serializer.data
        return JsonResponse(data={"orders": response_list}, status=status.HTTP_200_OK, safe=False)


class GetMyOrdersView(generics.ListAPIView):
    renderer_classes = [JSONRenderer]
    permission_classes = (IsAuthenticated,)
    serializer_class = OrdersSerializer

    def get_queryset(self):
        return Order.objects.filter(Q(ordering_agent=self.request.user) | Q(collection_agent=self.request.user))

    def list(self, request):
        queryset = self.get_queryset()
        print(":::::::::::::: ", queryset)
        page = self.paginate_queryset(queryset)
        serializer = self.serializer_class(queryset, many=True)
        response_list = serializer.data
        return JsonResponse(data={"orders": response_list}, status=status.HTTP_200_OK, safe=False)


class RemittanceDetailsView(APIView):
    permission_classes = (IsAuthenticated,)
    renderer_classes = [JSONRenderer]

    def get(self, request, *args, **kwargs):
        try:
            tellers = User.get_all_agents()
            count = 0
            for teller in tellers:
                check_in = DailyProcesses.objects.filter(
                    agent=teller).order_by('-id').first()
                if check_in:
                    if check_in.check_in_time.date() == datetime.date.today() and check_in.check_out_time == None:
                        count += 1

            statistics = {
                "all_time":
                    {
                        "name": request.user.username,
                        "allocation": 0,
                        "orders": Order.objects.all().count(),
                        "processed_orders": Order.objects.filter(~Q(status='PENDING')).count(),
                        "processed_orders_total": Order.objects.filter(~Q(status='PENDING')).aggregate(Sum('amount'))['amount__sum'],
                        "pending_orders": Order.objects.filter(status='APPROVED').count(),
                        "collections_pending": Order.objects.filter(status='APPROVED').aggregate(Sum('amount')),
                        "collected_orders": Order.objects.filter(status='COLLECTED').count(),
                        "cash_balance": sum([branch.running_balance for branch in Branch.tumai_branches()]),
                        "pending_requests": AllocationRequest.objects.filter(is_approved=False, approved_date=None).count(),
                        "bill_payments_total": Transactions.objects.filter(status=True, transaction_type=TransactionTypes.filter_code('TA06')).aggregate(Sum('amount')),
                        "charges_total": Transactions.objects.filter(status=True, transaction_type=TransactionTypes.filter_code('TA04')).aggregate(Sum('amount')),
                        "failed_transactions": Transactions.objects.filter(status=False, transaction_type=TransactionTypes.filter_code('TA06')).count(),
                        "successful_transactions": Transactions.objects.filter(status=True, transaction_type=TransactionTypes.filter_code('TA06')).count(),
                        "total_pending_allocations": AllocationRequest.objects.filter(is_approved=False, approved_date=None).count(),
                        "check_in": f"{count}/{tellers.count()}"
                    },
                "latest":
                    {
                        "name": request.user.username,
                        "allocation": 0,
                        "orders": Order.objects.filter(date_created__date=datetime.datetime.now().date()).count(),
                        "processed_orders": Order.objects.filter(~Q(status='PENDING'), Q(date_created__date=datetime.datetime.now().date())).count(),
                        "processed_orders_total": Order.objects.filter(~Q(status='PENDING'), Q(date_created__date=datetime.datetime.now().date())).aggregate(Sum('amount'))['amount__sum'],
                        "pending_orders": Order.objects.filter(status='APPROVED', date_created__date=datetime.datetime.now().date()).count(),
                        "collections_pending": Order.objects.filter(status='APPROVED', date_created__date=datetime.datetime.now().date()).aggregate(Sum('amount')),
                        "collected_orders": Order.objects.filter(status='COLLECTED', date_created__date=datetime.datetime.now().date()).count(),
                        "cash_balance": sum([branch.running_balance for branch in Branch.tumai_branches()]),
                        "pending_requests": AllocationRequest.objects.filter(is_approved=False, approved_date=None, requested_date__date=datetime.datetime.now().date()).count(),
                        "bill_payments_total": Transactions.objects.filter(status=True, transaction_type=TransactionTypes.filter_code('TA06'), date_created__date=datetime.datetime.now().date()).aggregate(Sum('amount')),
                        "charges_total": Transactions.objects.filter(status=True, transaction_type=TransactionTypes.filter_code('TA04'), date_created__date=datetime.datetime.now().date()).aggregate(Sum('amount')),
                        "failed_transactions": Transactions.objects.filter(status=False, transaction_type=TransactionTypes.filter_code('TA06'), date_created__date=datetime.datetime.now().date()).count(),
                        "successful_transactions": Transactions.objects.filter(status=True, transaction_type=TransactionTypes.filter_code('TA06'), date_created__date=datetime.datetime.now().date()).count(),
                        "total_pending_allocations": AllocationRequest.objects.filter(is_approved=False, approved_date=None, requested_date__date=datetime.datetime.now().date()).count(),
                        "check_in": f"{count}/{tellers.count()}"
                    }
            }
            return JsonResponse(data=statistics, status=status.HTTP_200_OK, safe=False)
        except Exception as e:
            return JsonResponse(status=status.HTTP_500_INTERNAL_SERVER_ERROR, data={'message': f'{e}'})


class GetChargeView(APIView):
    parser_classes = [JSONParser]
    renderer_classes = [JSONRenderer]

    def post(self, request, *args, **kwargs):
        try:
            print(request)
            if not request.body:
                return JsonResponse(
                    status=status.HTTP_400_BAD_REQUEST, data={
                        'message': f'No Payload Received.'}
                )
            print('Incoming Info', request.body)
            serializer = GetChargeSerializer(data=json.loads(request.body))

            if serializer.is_valid():
                amount = serializer.validated_data['amount']
                if amount <= 60:
                    charge = 2
                elif amount > 60 and amount <= 150:
                    charge = 3
                elif amount > 150:
                    charge = 4
                else:
                    charge = amount*0.03
                try:
                    return JsonResponse(status=status.HTTP_200_OK, data={
                        'amount': amount,
                        'charge': charge,
                        'total': amount + charge
                    })
                except Exception as e:
                    print(e)
                    return JsonResponse(status=status.HTTP_404_NOT_FOUND, data={'message': 'Transaction could not be processed'})
            else:
                return JsonResponse(
                    status=status.HTTP_400_BAD_REQUEST, data={
                        'message': serializer.errors}
                )
        except Exception as e:
            return JsonResponse(
                status=status.HTTP_500_INTERNAL_SERVER_ERROR, data={
                    'message': f'{e}'}
            )


class ViewTransactionView(APIView):
    permission_classes = (IsAuthenticated,)
    parser_classes = [JSONParser]
    serializer_class = RetrieveTransactionSerializer

    def get(self, request, *args, **kwargs):
        try:
            transaction = Transactions.objects.get(id=kwargs['transaction_id'])
        except ObjectDoesNotExist:
            return JsonResponse(status=status.HTTP_404_NOT_FOUND, data={'message': 'Transaction does not exist'})
        return JsonResponse(status=status.HTTP_200_OK, data={'transaction': self.serializer_class(transaction).data})


class GetConversion(APIView):
    parser_classes = [JSONParser]
    renderer_classes = [JSONRenderer]

    def post(self, request, *args, **kwargs):
        try:
            print(request)
            if not request.body:
                return JsonResponse(
                    status=status.HTTP_400_BAD_REQUEST, data={
                        'message': f'No Payload Received.'}
                )
            print('Incoming Info', request.body)
            serializer = GetChargeSerializer(data=json.loads(request.body))

            if serializer.is_valid():
                amount = serializer.validated_data['amount']
                rate = ConversionRate.objects.all().first()
                try:
                    if rate:
                        bm_rate = rate.bm_rate
                        return JsonResponse(status=status.HTTP_200_OK, data={
                            'amount': amount,
                            'rate': rate.rate,
                            'total':  amount * 450 if request.user.branch.id in [4, 6, 12] else amount * bm_rate,
                            'bm_rate': 450 if request.user.branch.id in [4, 6, 12] else bm_rate
                        })

                    else:
                        return JsonResponse(status=status.HTTP_404_NOT_FOUND, data={'message': 'Transaction could not be processed'})
                except Exception as e:
                    print(e)
                    return JsonResponse(status=status.HTTP_404_NOT_FOUND, data={'message': 'Transaction could not be processed'})
            else:
                return JsonResponse(
                    status=status.HTTP_400_BAD_REQUEST, data={
                        'message': serializer.errors}
                )
        except Exception as e:
            return JsonResponse(
                status=status.HTTP_500_INTERNAL_SERVER_ERROR, data={
                    'message': f'{e}'}
            )


class CreateRtgsOrderView(APIView):
    parser_classes = [JSONParser]
    renderer_classes = [JSONRenderer]
    serializer_class = CreateRtgsOrderSerializer
    permission_classes = ()

    def post(self, request):
        try:
            serializer = self.serializer_class(data=request.data)
            if serializer.is_valid():
                amount = serializer.validated_data['amount']
                serializer.validated_data['reference_number'] = Utils.generate_reference_number(
                )
                rate = ConversionRate.objects.all().first()
                serializer.validated_data['rtgs'] = amount * rate.bm_rate
                serializer.validated_data['date_created'] = make_aware(
                    datetime.datetime.now(), timezone=pytz.timezone(settings.TIME_ZONE))
                order = serializer.save()
                # todo send sms
                notify.delay(user=serializer.validated_data['initiator_phone_number'],
                             message=f"Your order of ${order.amount} has been initiated with reference number {order.reference_number}. Please take your reference number to the nearest Tumai agent. Thank you.")
                return JsonResponse(status=status.HTTP_200_OK, data={
                    "reference_number": order.reference_number,
                    "total_amount": order.amount,
                    "total_rtgs": order.rtgs,
                    "message": "Order created initiated successfully",
                })
            else:
                return JsonResponse(
                    status=status.HTTP_400_BAD_REQUEST, data={
                        'message': serializer.errors}
                )
        except Exception as e:
            return JsonResponse(
                status=status.HTTP_500_INTERNAL_SERVER_ERROR, data={
                    'message': f'{e}'}
            )


class ApproveRgtsOrderView(APIView):
    parser_classes = [JSONParser]
    renderer_classes = [JSONRenderer]
    permission_classes = (IsAuthenticated,)
    serializer_class = RetrieveOrderSerializer

    def post(self, request):

        try:
            serializer = self.serializer_class(data=request.data)
            if serializer.is_valid():
                try:
                    order = RTGSOrder.objects.get(
                        reference_number=serializer.data['reference_number'])
                except ObjectDoesNotExist:
                    try:
                        order = RTGSOrder.objects.get(
                            reference_number=f"R{serializer.data['reference_number']}")
                    except ObjectDoesNotExist:
                        return JsonResponse(status=status.HTTP_404_NOT_FOUND, data={'message': 'Order could not be found'})
                    return JsonResponse(status=status.HTTP_404_NOT_FOUND, data={'message': 'Order could not be found'})
                if order.status == 'PENDING':
                    # create a new order
                    new_order = Order.objects.create(
                        initiator_name=order.initiator_name,
                        initiator_phone_number=order.initiator_phone_number,
                        initiator_email=order.initiator_email,
                        initiator_id_number=order.initiator_id_number,
                        # recipient
                        recipient_name=order.student_name,
                        recipient_identification_type=order.student_identification_type,
                        recipient_phone_number=order.student_phone_number,
                        recipient_id_number=order.student_id_number,
                        recipient_address=order.student_number,
                        # order details
                        source='RTGS',
                        amount=order.amount,
                        charge=0,
                        status='APPROVED',
                        narration=order.narration,
                        currency='USD',
                        ordering_agent=request.user,
                        reference_number=order.reference_number,
                        order_number=Utils.generate_reference_number(
                            prefix='T'),
                        extras={},
                        # timestamps
                        date_created=make_aware(
                            datetime.datetime.now(), timezone=pytz.timezone(settings.TIME_ZONE)),
                        date_approved=make_aware(datetime.datetime.now(), timezone=pytz.timezone(settings.TIME_ZONE)))
                    new_order.save()
                    order.status = 'APPROVED'
                    order.payment_status = True
                    order.save()
                    Transactions.create_transaction(request.user, new_order.amount, TransactionTypes.filter_code(
                        "TA05"), extras=new_order.id, status=True)
                    # todo send sms
                    notify.delay(user=new_order.initiator_phone_number,
                                 message=f"Your order of ${new_order.amount} has been created with reference number {new_order.reference_number},  order number  {new_order.order_number}. Please send this to your recipient for them to collect. Thank you.")
                    notify.delay(user=new_order.recipient_phone_number,
                                 message=f"You have received ${new_order.amount} from {new_order.initiator_name} with reference number {new_order.reference_number},  order number  {new_order.order_number}. Please take your School ID to the nearest Tumai agent to collect. Thank you.")

                    return JsonResponse(status=status.HTTP_200_OK, data={
                        "reference_number": new_order.reference_number,
                        "total_amount": new_order.amount,
                        "order_number": f"{new_order.order_number[:2]}*******{new_order.order_number[8:]}",
                        "message": "Order created successfully",
                    })
                else:
                    return JsonResponse(status=status.HTTP_400_BAD_REQUEST, data={'message': 'Order could not be approved, as it has already been approved'})

            else:
                return JsonResponse(
                    status=status.HTTP_400_BAD_REQUEST, data={
                        'message': serializer.errors}
                )
        except Exception as e:
            return JsonResponse(
                status=status.HTTP_500_INTERNAL_SERVER_ERROR, data={
                    'message': f'{e}'}
            )


class ZbStatementView(APIView):
    parser_classes = [JSONParser]
    renderer_classes = [JSONRenderer]
    permission_classes = (IsAuthenticated,)
    serializer_class = ZbStatementSerializer

    def post(self, request):
        try:
            serializer = self.serializer_class(data=request.data)
            if serializer.is_valid():
                try:
                    url = "https://zbnet.zb.co.zw/whatsapp/statement"

                    payload = json.dumps({
                        "days": serializer.data['days'],
                        "account_number": config("ZB_USD") if serializer.data['account_type'].lower() == 'zb_usd' else config("ZB_ZWL")
                    })
                    headers = {
                        'Content-Type': 'application/json'
                    }

                    response = requests.request(
                        "POST", url, headers=headers, data=payload)
                    if response.status_code == 200:
                        return JsonResponse(status=status.HTTP_200_OK, data={"message": response.json()})
                    else:
                        return JsonResponse(status=status.HTTP_400_BAD_REQUEST, data={"message": 'Failed to get statement'})

                except Exception as e:
                    print(e)
                    return JsonResponse(status=status.HTTP_400_BAD_REQUEST, data={'message': 'Statement could not be retrieved'})
            else:
                return JsonResponse(
                    status=status.HTTP_400_BAD_REQUEST, data={
                        'message': serializer.errors}
                )
        except Exception as e:
            return JsonResponse(
                status=status.HTTP_500_INTERNAL_SERVER_ERROR, data={
                    'message': f'{e}'}
            )


class CreateAgentView(APIView):
    parser_classes = [JSONParser]
    renderer_classes = [JSONRenderer]
    permission_classes = (IsAuthenticated,)
    serializer_class = CreateAgentSerializer

    def post(self, request):
        try:
            serializer = self.serializer_class(data=request.data)
            if serializer.is_valid():
                try:
                    user = User.objects.filter(
                        phone_number=serializer.data['phone_number']).first()
                    if user:
                        response = create_agent(user)
                        if response:
                            return JsonResponse(status=status.HTTP_200_OK, data={"message": 'Agent successfully added'})
                        else:
                            return JsonResponse(status=status.HTTP_400_BAD_REQUEST, data={"message": 'Failed to add agent'})
                    else:
                        return JsonResponse(status=status.HTTP_400_BAD_REQUEST, data={"message": 'User does not exist'})
                except Exception as e:
                    return JsonResponse(
                        status=status.HTTP_400_BAD_REQUEST, data={
                            'message': f'{e}'}
                    )
            else:
                return JsonResponse(
                    status=status.HTTP_400_BAD_REQUEST, data={
                        'message': serializer.errors}
                )
        except Exception as e:
            return JsonResponse(
                status=status.HTTP_500_INTERNAL_SERVER_ERROR, data={
                    'message': f'{e}'}
            )


class GetActiveCities(generics.ListAPIView):
    renderer_classes = [JSONRenderer]
    permission_classes = ()
    serializer_class = CitySerializer

    def get_queryset(self):
        return ActiveCities.objects.all()

    def list(self, request):
        queryset = self.get_queryset()
        page = self.paginate_queryset(queryset)
        serializer = self.serializer_class(queryset, many=True)
        response_list = serializer.data
        return JsonResponse(data={"cities": response_list}, status=status.HTTP_200_OK, safe=False)


class GetCashOutlets(generics.ListAPIView):
    renderer_classes = [JSONRenderer]
    permission_classes = ()
    serializer_class = CashOutletSerializer

    def get_queryset(self):
        return CashOutlets.objects.all()

    def list(self, request):
        queryset = self.get_queryset()
        page = self.paginate_queryset(queryset)
        serializer = self.serializer_class(queryset, many=True)
        response_list = serializer.data
        return JsonResponse(data={"outlets": response_list}, status=status.HTTP_200_OK, safe=False)

class GetKioskView(generics.ListAPIView):
    renderer_classes = [JSONRenderer]
    permission_classes = ()
    serializer_class = KioskSerializer

    def get_queryset(self):
        return Branch.filter_kiosk()

    def list(self, request):
        queryset = self.get_queryset()
        page = self.paginate_queryset(queryset)
        serializer = self.serializer_class(queryset, many=True)
        response_list = serializer.data
        return JsonResponse(data={"outlets": response_list}, status=status.HTTP_200_OK, safe=False)

class OrdersReportView(APIView):
    parser_classes = [JSONParser]
    renderer_classes = [JSONRenderer]
    permission_classes = (IsAuthenticated,)
    serializer_class = OrdersReportSerializer
    model = Order

    def post(self, request):
        try:
            serializer = self.serializer_class(data=request.data)
            if serializer.is_valid():
                try:
                    orders = self.model.objects.filter(date_created__range=(serializer.data['start_date'], serializer.data['end_date']))
                    if orders:
                        serializer = OrdersReportCSVSerializer(orders, many=True)
                        return JsonResponse(status=status.HTTP_200_OK, data={"orders": serializer.data})
                except Exception as e:
                    print(e)
                    return JsonResponse(status=status.HTTP_400_BAD_REQUEST, data={'message': 'Report could not be retrieved'})
            else:
                return JsonResponse(
                    status=status.HTTP_400_BAD_REQUEST, data={
                        'message': serializer.errors}
                )
        except Exception as e:
            return JsonResponse(
                status=status.HTTP_500_INTERNAL_SERVER_ERROR, data={
                    'message': f'{e}'}
            )
