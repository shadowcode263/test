from django.http import JsonResponse
from rest_framework import viewsets, status
from rest_framework.permissions import (
    IsAuthenticated,
    IsAdminUser
)
from rest_framework.decorators import action
from api.serializers.company import (
    BranchSerializer, 
    CompanySerializer,
    CompanyStatisticsSerializer,
    KioskSerializer, 
    UpdateBranchSerializer,
    BalanceSerializer
)
from api.serializers.users import UserSerializer
from company.models import Company, Branch
from users.models import User
from transaction.models import Transactions, TransactionTypes, CashFlowLedger


class CompanyViewSet(viewsets.ModelViewSet):
    queryset = Company.objects.all()
    serializer_class = CompanySerializer
    permission_classes = (IsAuthenticated,IsAdminUser,)

    @action(detail=False, methods=['post'])
    def create_company(self, request):
        serializer = self.serializer_class(data=request.data)
        if serializer.is_valid():
            serializer.save(created_by=request.user)
            return JsonResponse(serializer.data, status=status.HTTP_201_CREATED)
        return JsonResponse(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=False, methods=['post'])
    def create_branch(self, request):
        serializer = BranchSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return JsonResponse(serializer.data, status=status.HTTP_201_CREATED)
        return JsonResponse(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=False, methods=['get'], url_path='all/branches')
    def fetch_all_branches(self, request):
        serializer = BranchSerializer(
            data=Branch.filter_branches(), 
            many=True
        )
        serializer.is_valid()
        return JsonResponse({'branches': serializer.data}, status=status.HTTP_200_OK)

    
    @action(detail=False, methods=['get'], url_path='branches')
    def get_company_branches(self, request):
        branches = BranchSerializer(
            data=Branch.filter_by_company_id(
                request.query_params.get('id')
            ), 
            many=True
        )
        branches.is_valid()
        return JsonResponse(status=status.HTTP_200_OK, data={'branches': branches.data})

    @action(detail=False, methods=['get'], url_path='statistics')
    def get_company_statistics(self, request):
        companies = CompanyStatisticsSerializer(
            data=Company.objects.all(), many=True
        )
        companies.is_valid()
        
        return JsonResponse(status=200, data={'companies': companies.data})

    @action(detail=False, methods=['post'])
    def assign_user_branch(self, request):
        serializer = UpdateBranchSerializer(data=request.data)
        if serializer.is_valid():
            serializer.validated_data['user'].branch = serializer.validated_data['branch']
            serializer.validated_data['user'].save()
            return JsonResponse(serializer.data, status=status.HTTP_201_CREATED)
        else:
            return JsonResponse(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=False,methods=['get'],url_path='overall/statistics')
    def get_overall_statistics(self,request):
        companies = CompanyStatisticsSerializer(
            data=Company.objects.all(), many=True
        )
        companies.is_valid()
        
        return JsonResponse(status=200, data={'companies': companies.data})


    @action(detail=False, methods=['post'], url_path='move/balance')
    def move_balance(self, request):
        serializer = BalanceSerializer(data=request.data)
        if serializer.is_valid():
            serializer.validated_data['to_branch'].running_balance += serializer.validated_data['amount']
            credit_type = TransactionTypes.objects.filter(code='TA07').first()
            debit_type = TransactionTypes.objects.filter(code='TA57').first()
            credit_transaction = Transactions(transaction_type=credit_type, amount=serializer.validated_data['amount'], 
                            status=True, branch=serializer.validated_data['to_branch'], user=self.request.user)
            debit_transaction = Transactions(transaction_type=debit_type, amount=serializer.validated_data['amount'], 
                            status=True, branch=serializer.validated_data['to_branch'], user=self.request.user)
            credit_transaction.save()
            debit_transaction.save()
            credit_ledger = CashFlowLedger(transaction=credit_transaction, branch=serializer.validated_data['to_branch'],
                                    amount=serializer.validated_data['amount'], is_credit=True,
                                    agent=self.request.user)
            debit_ledger = CashFlowLedger(transaction=debit_transaction, branch=serializer.validated_data['from_branch'],
                                    amount=serializer.validated_data['amount'], is_credit=False,
                                    agent=self.request.user)
            credit_ledger.save()
            debit_ledger.save()
            serializer.validated_data['from_branch'].running_balance -= serializer.validated_data['amount']
            serializer.validated_data['to_branch'].save()
            serializer.validated_data['from_branch'].save()
            return JsonResponse(serializer.data, status=status.HTTP_200_OK)
        else:
            return JsonResponse(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

