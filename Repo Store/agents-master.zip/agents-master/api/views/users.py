from rest_framework.permissions import IsAuthenticated, IsAdminUser
from api.serializers.company import AllocationSerializer
from rest_framework.renderers import JSONRenderer
from rest_framework.parsers import JSONParser
from company.models import Branch
from remittance.models import AllocationRequest
from rest_framework import status, generics
from remittance.models import DailyProcesses
from rest_framework.decorators import action
from rest_framework.views import APIView
from django.http import JsonResponse
from rest_framework import viewsets
from django.db.models import Q

from api.serializers.users import (
    AcknowlegdeAllocationRequestSerializer,
    AgentStatisticsSerializer,
    AllocateAllocationRequestSerializer,
    ApproveAllocationRequestSerializer,
    CashAllocationRequestSerializer,
    DailyProcessSerializer,
    DailyProcessesSerializer,
    GetAllocationRequestsSerializer,
    UserPasswordSerializer,
    UpdateUserSerializer,
    UserSerializer
)

from agents.tasks import notify
from transaction.models import(
    TransactionTypes,
    Transactions,
    CashFlowLedger
)
from users.models import AppVersion, AuthorizationManagers, User


class UserViewSet(viewsets.ModelViewSet):
    serializer_class = UserSerializer
    permission_classes = [IsAuthenticated, IsAdminUser]
    queryset = User.objects.all()
    parser_classes = (JSONParser,)
    http_method_names = ['post', 'get']

    @action(detail=False, methods=['post'])
    def create_user(self, request):
        serializer = self.serializer_class(data=request.data)
        if serializer.is_valid():
            serializer.save()
            notify.delay(
                user=serializer.data['phone_number'],
                message=f"Your account has been created, your password is: {serializer.data['first_name'][0:1]}{serializer.data['last_name']}. Please login to continue."
            )
            return JsonResponse(serializer.data, status=status.HTTP_201_CREATED)
        return JsonResponse(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=False, methods=['get'], url_path='agents')
    def get_agents(self, request):
        agents = UserSerializer(
            data=User.get_all_agents(), many=True
        )
        agents.is_valid()
        return JsonResponse(
            status=status.HTTP_200_OK,
            data={
                'agents': agents.data
            }
        )

    @action(detail=False, methods=['post'], url_path='update')
    def update_agent(self, request):
        agent = UpdateUserSerializer(data=request.data)
        if agent.is_valid():
            if User.update_agent(payload=agent.data):
                return JsonResponse(status=status.HTTP_200_OK, data={'message': "Agent updated successfully"})
            return JsonResponse(status=status.HTTP_400_BAD_REQUEST, data={'message': "Agent not updated"})
        return JsonResponse(status=status.HTTP_400_BAD_REQUEST, data={'errors': agent.errors})

    @action(detail=False, methods=['get'], url_path='teller/statistics')
    def get_tellers(self, request):
        agents = AgentStatisticsSerializer(
            data=User.get_all_agents(), many=True
        )
        agents.is_valid()
        print('agents', agents.data)
        return JsonResponse(
            status=status.HTTP_200_OK,
            data={
                'agents': agents.data
            }
        )


class GetBalances(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        balance = DailyProcesses.get_balances(request.user)
        if balance:
            print('balance found')
            response_data = {
                "current_balance": request.user.branch.running_balance if request.user.branch else None,
                "yesterday_balance": balance.yesterday_closing_balance,
                "starting_balance": balance.opening_balance,
                "check_in_time": balance.check_in_time,
            }
            return JsonResponse(status=status.HTTP_200_OK, data=response_data)
        else:
            response_data = {
                "current_balance": 0.00,
                "yesterday_balance": 0.00,
                "today_balance": 0.00,
                "check_in_time": "Not Yet Checked In",
            }
            return JsonResponse(status=status.HTTP_200_OK, data=response_data)


class StartDayView(APIView):
    permission_classes = [IsAuthenticated]
    serializer_class = DailyProcessSerializer
    parser_classes = [JSONParser]
    # def get(self, request):
    #     try:
    #         start_day, message = DailyProcesses.start_day(request.user)
    #         if start_day:
    #             return JsonResponse(status=status.HTTP_200_OK, data={
    #                 "message": message,
    #             }
    #             )
    #         else:
    #             return JsonResponse(
    #                 status=status.HTTP_400_BAD_REQUEST,
    #                 data={
    #                     "message": message
    #                 }
    #             )
    #     except Exception as e:
    #         print("START DAY ERROR ", e)
    #         return JsonResponse({'error': str(e)}, status=400)

    def post(self,request):
        print('Request >>>',request.data)
        serializer = self.serializer_class(data=request.data)
        if serializer.is_valid():
            # process start day
            try:
                start_day, message = DailyProcesses.start_day(request.user,serializer.validated_data)
                if start_day:
                    return JsonResponse(status=status.HTTP_200_OK, data={
                        "message": message,
                    }
                    )
                else:
                    return JsonResponse(
                        status=status.HTTP_400_BAD_REQUEST,
                        data={
                            "message": message
                        }
                    )
            except Exception as e:
                print("START DAY ERROR ", e)
                return JsonResponse({'error': str(e)}, status=400)
        else:
            return JsonResponse(status=status.HTTP_400_BAD_REQUEST, data={'errors': serializer.errors})


class EndDayView(APIView):
    permission_classes = [IsAuthenticated]
    serializer_class = DailyProcessSerializer
    parser_classes = [JSONParser]

    # def get(self, request):
    #     try:
    #         end_day, message = DailyProcesses.end_day(request.user)
    #         if end_day:
    #             return JsonResponse(status=status.HTTP_200_OK, data={"message": message})
    #         else:
    #             return JsonResponse(status=status.HTTP_400_BAD_REQUEST, data={"message": message})
    #     except Exception as e:
    #         return JsonResponse({'error': str(e)}, status=400)

    def post(self,request):
        print('Request >>>',request.data)
        serializer = self.serializer_class(data=request.data)
        if serializer.is_valid():
            # process start day
            try:
                end_day, message = DailyProcesses.end_day(request.user,serializer.validated_data)
                if end_day:
                    return JsonResponse(status=status.HTTP_200_OK, data={"message": message})
                else:
                    return JsonResponse(status=status.HTTP_400_BAD_REQUEST, data={"message": message})
            except Exception as e:
                return JsonResponse({'error': str(e)}, status=400)
        else:
            return JsonResponse(status=status.HTTP_400_BAD_REQUEST, data={'errors': serializer.errors})



class DailyProcessesViewset(viewsets.ModelViewSet):
    serializer_class = DailyProcessesSerializer
    queryset = DailyProcesses.objects.all()
    http_methods = ['get']


class CashAllocationRequestView(APIView):
    serializer_class = CashAllocationRequestSerializer
    permission_classes = (IsAuthenticated,)
    renderer_classes = [JSONRenderer]
    parser_classes = [JSONParser]
    model = AllocationRequest

    def post(self, request, *args, **kwargs):
        print('payload', request.data)
        user = request.user
        serializer_class = self.serializer_class(data=request.data)
        if serializer_class.is_valid():
            if serializer_class.validated_data.get('type').lower() == 'debit':
                if user.branch.running_balance < serializer_class.validated_data.get('amount'):
                    return JsonResponse(status=status.HTTP_400_BAD_REQUEST, data={"message": "You cannot deduct more than available in Balance"})
            if self.model.save_allocation_request(serializer_class.validated_data, user):
                return JsonResponse(status=status.HTTP_200_OK, data={"message": "Allocation Request Submitted"})
            else:
                return JsonResponse(status=status.HTTP_400_BAD_REQUEST, data={"message": "Allocation Request Not Submitted"})
        else:
            return JsonResponse(status=status.HTTP_400_BAD_REQUEST, data=serializer_class.errors, safe=False)


class GetAllocationRequestsView(generics.ListAPIView):
    renderer_classes = [JSONRenderer]
    permission_classes = (IsAuthenticated, IsAdminUser)
    serializer_class = GetAllocationRequestsSerializer

    def get_queryset(self):
        return AllocationRequest.objects.filter(is_approved=False, approved_date=None)

    def list(self, request):
        queryset = self.get_queryset().order_by('-id')
        page = self.paginate_queryset(queryset)
        serializer = self.serializer_class(queryset, many=True)
        response_list = serializer.data
        return JsonResponse(data={"cash_requests": response_list}, status=status.HTTP_200_OK, safe=False)


class GetAllocationRequestsHistory(generics.ListAPIView):
    renderer_classes = [JSONRenderer]
    permission_classes = (IsAuthenticated, IsAdminUser)
    serializer_class = GetAllocationRequestsSerializer

    def get_queryset(self):
        return AllocationRequest.objects.all()

    def list(self, request):
        queryset = self.get_queryset().order_by('-id')
        page = self.paginate_queryset(queryset)
        serializer = self.serializer_class(queryset, many=True)
        response_list = serializer.data
        return JsonResponse(data={"cash_requests": response_list}, status=status.HTTP_200_OK, safe=False)


class GetAllPendingAllocations(generics.ListAPIView):
    renderer_classes = [JSONRenderer]
    permission_classes = (IsAuthenticated, IsAdminUser)
    serializer_class = GetAllocationRequestsSerializer

    def get_queryset(self):
        return AllocationRequest.objects.filter(~Q(stage='RECEIVED'),~Q(stage='REJECTED'),~Q(stage='ALLOCATED'),~Q(stage='VOID'))

    def list(self, request):
        queryset = self.get_queryset().order_by('-id')
        page = self.paginate_queryset(queryset)
        serializer = self.serializer_class(queryset, many=True)
        response_list = serializer.data
        return JsonResponse(data={"cash_requests": response_list}, status=status.HTTP_200_OK, safe=False)


class GetMyAllocatedAllocationRequests(generics.ListAPIView):
    renderer_classes = [JSONRenderer]
    permission_classes = (IsAuthenticated,)
    serializer_class = GetAllocationRequestsSerializer

    def get_queryset(self):
        return AllocationRequest.objects.filter(agent=self.request.user, stage='DISPATCHED')

    def list(self, request):
        queryset = self.get_queryset().order_by('-id')
        page = self.paginate_queryset(queryset)
        serializer = self.serializer_class(queryset, many=True)
        response_list = serializer.data
        return JsonResponse(data={"cash_requests": response_list}, status=status.HTTP_200_OK, safe=False)


class GetMyAllocationRequestsHistory(generics.ListAPIView):
    renderer_classes = [JSONRenderer]
    permission_classes = (IsAuthenticated,)
    serializer_class = GetAllocationRequestsSerializer

    def get_queryset(self):
        return AllocationRequest.objects.filter(agent=self.request.user)

    def list(self, request):
        queryset = self.get_queryset().order_by('id')
        page = self.paginate_queryset(queryset)
        serializer = self.serializer_class(queryset, many=True)
        response_list = serializer.data
        return JsonResponse(data={"cash_requests": response_list}, status=status.HTTP_200_OK, safe=False)


class AcknowledgeAllocationRequestView(APIView):
    permission_classes = (IsAuthenticated, IsAdminUser, )
    renderer_classes = [JSONRenderer]
    serializer_class = AcknowlegdeAllocationRequestSerializer

    def post(self, request, *args, **kwargs):
        serializer = self.serializer_class(data=request.data)
        if serializer.is_valid():
            print('serializer_class.validated_data', serializer.validated_data)
            cash_request = serializer.validated_data['allocation_request']
            if cash_request.acknowledge_request(request.user, serializer.validated_data):
                if cash_request.stage == 'REJECTED':
                    return JsonResponse(status=status.HTTP_200_OK, data={"message": "Allocation Request Rejected"})
                if serializer.validated_data['type'].lower() == 'decline':
                    return JsonResponse(status=status.HTTP_200_OK, data={"message": "Allocation Request Rejected Successfully"})
                # deduct balance is transaction is dispatch
                try:
                    if cash_request.is_credit:
                        pass
                    else:
                        Transactions.create_transaction(
                            user=cash_request.agent,
                            amount=cash_request.amount,
                            transaction_type=TransactionTypes.filter_code(
                                'TA58'),
                            extras=cash_request.id,
                            status=True
                        )
                        cash_request.new_company_balance = sum([branch.running_balance for branch in Branch.tumai_branches()])
                        cash_request.save()
                except Exception as e:
                    print(str(e))
                    return JsonResponse(status=status.HTTP_400_BAD_REQUEST, data={"message": "Transaction Failed"})
                return JsonResponse(status=status.HTTP_200_OK, data={"message": "Allocation Request Acknowledged"})
            else:
                return JsonResponse(status=status.HTTP_400_BAD_REQUEST, data={"message": "Allocation Request Not Acknowledged"})
        else:
            return JsonResponse(status=status.HTTP_400_BAD_REQUEST, data=serializer.errors, safe=False)


class AllocateAllocationRequestView(APIView):
    permission_classes = (IsAuthenticated, IsAdminUser, )
    renderer_classes = [JSONRenderer]
    serializer_class = AllocateAllocationRequestSerializer

    def post(self, request, *args, **kwargs):
        serializer = self.serializer_class(data=request.data)
        if serializer.is_valid():
            try:
                print('serializer is valid')
                serializer.validated_data['allocation_request'].allocate_request(
                    request.user, serializer.validated_data)
                return JsonResponse(status=status.HTTP_200_OK, data={"message": "Allocation Request Allocated"})
            except Exception as e:
                print('error in allocate_request', e)
                return JsonResponse(status=status.HTTP_400_BAD_REQUEST, data={"message": "Allocation could not be processed"})
        else:
            return JsonResponse(status=status.HTTP_400_BAD_REQUEST, data=serializer.errors, safe=False)


class ApproveCashAllocationRequestView(APIView):
    permission_classes = (IsAuthenticated,)
    renderer_classes = [JSONRenderer]
    model = AllocationRequest
    serializer_class = ApproveAllocationRequestSerializer

    def post(self, request):
        serializer = self.serializer_class(data=request.data)
        if serializer.is_valid():
            # TO-DO : Persist transaction to database
            try:
                cash_request = serializer.validated_data['request_id']
                cash_request.denominations = serializer.validated_data['denominations']
                cash_request.approval_signature = serializer.validated_data['signature']
                cash_request.approving_manager = AuthorizationManagers.full_name(serializer.validated_data['pin'])
                cash_request.current_company_balance = sum([branch.running_balance for branch in Branch.tumai_branches()])
                cash_request.save()
                if cash_request.is_credit:
                    transaction = Transactions.create_transaction(
                        user=cash_request.agent,
                        amount=cash_request.amount,
                        transaction_type=TransactionTypes.filter_code('TA08'),
                        extras=cash_request.id,
                        status=True
                    )
                else:
                    transaction = Transactions.create_transaction(
                        user=cash_request.agent,
                        amount=cash_request.amount,
                        transaction_type=TransactionTypes.filter_code('TA58'),
                        extras=cash_request.id,
                        status=True
                    )
            except Exception as e:
                print(str(e))
                return JsonResponse(status=status.HTTP_400_BAD_REQUEST, data={"message": "Transaction Failed"})
            if cash_request.approve_allocation_request(request.user):
                return JsonResponse(status=status.HTTP_200_OK, data={"message": "Allocation Request Approved"})
            return JsonResponse(status=status.HTTP_500_INTERNAL_SERVER_ERROR, data={"message": "Unexpected Error!! Allocation Request Not Approved"})
        return JsonResponse(status=status.HTTP_404_NOT_FOUND, data={"message": "Allocation Request Not Found!!"})


class AllocationView(APIView):
    serializer_class = AllocationSerializer
    permission_classes = (IsAuthenticated, IsAdminUser, )
    renderer_classes = [JSONRenderer]
    model = CashFlowLedger

    def post(self, request, *args, **kwargs):
        serializer = self.serializer_class(data=request.data)
        if serializer.is_valid():
            if serializer.validated_data['mode'] == 'POSITIVE':
                transaction_type = 'TA01'
                serializer.validated_data['branch'].running_balance += serializer.validated_data['amount']
                is_credit = True
            elif serializer.validated_data['mode'] == 'NEGATIVE':
                transaction_type = 'TA02'
                serializer.validated_data['branch'].running_balance -= serializer.validated_data['amount']
                is_credit = False
            elif serializer.validated_data['mode'] == 'DIRECT':
                is_credit = True
                transaction_type = 'TA03'
                serializer.validated_data['branch'].running_balance += serializer.validated_data['amount']
            print("THE PAYLOAD : ", serializer.validated_data, self.request.user)
            transaction_type = TransactionTypes.filter_code(transaction_type)
            transaction = Transactions(transaction_type=transaction_type, user=self.request.user, amount=serializer.validated_data['amount'],
                                       branch=serializer.validated_data['branch'], status=True)
            transaction.save()
            ledger_entry = CashFlowLedger(transaction=transaction, amount=serializer.validated_data['amount'],
                                          is_credit=is_credit, branch=serializer.validated_data['branch'], agent=request.user)
            ledger_entry.save()
            serializer.validated_data['branch'].save()
            return JsonResponse(status=status.HTTP_200_OK, data={"message": "Allocation Successful"})
        else:
            return JsonResponse(status=status.HTTP_400_BAD_REQUEST, data=serializer.errors)


class DeclineCashAllocationRequestView(APIView):
    permission_classes = (IsAuthenticated,)
    renderer_classes = [JSONRenderer]
    model = AllocationRequest

    def get(self, request, *args, **kwargs):
        cash_request = self.model.filter_by_id(id=kwargs.get('request_id'))
        if cash_request:
            if cash_request.decline_allocation_request(request.user):
                return JsonResponse(status=status.HTTP_200_OK, data={"message": "Allocation Request Declined"})
            return JsonResponse(status=status.HTTP_500_INTERNAL_SERVER_ERROR, data={"message": "Unexpected Error!! Allocation Request Decline Failed"})
        return JsonResponse(status=status.HTTP_404_NOT_FOUND, data={"message": "Allocation Request Not Found!!"})


class PasswordChange(APIView):
    """
    Verify Pin and Change Pin
    """
    serializer_class = UserPasswordSerializer
    parser_classes = [JSONParser]
    renderer_classes = [JSONRenderer]

    def post(self, request, *args, **kwargs):
        try:
            user_serializer = self.serializer_class(
                data=request.data, context={'request': request})
            """
                VALIDATE DATA
            """
            if user_serializer.is_valid():
                user = request.user
                user.set_password(
                    user_serializer.validated_data.get('new_password'))
                user.save()
                return JsonResponse(
                    {"message": "Password changed successfully"},
                    status=status.HTTP_200_OK,
                )
            else:
                print(user_serializer.errors)
                return JsonResponse(
                    {"message": user_serializer.errors},
                    status=status.HTTP_400_BAD_REQUEST,
                )
        except Exception as e:
            """
            EXCEPTION
            """
            print(f"Exception : {e}")
            return JsonResponse(data={"message": "Password Change Failed"}, status=status.HTTP_400_BAD_REQUEST)


class GetAgentCashRequestsView(generics.ListAPIView):
    renderer_classes = [JSONRenderer]
    permission_classes = (IsAuthenticated, )
    serializer_class = GetAllocationRequestsSerializer

    def get_queryset(self):
        return AllocationRequest.objects.filter(agent=self.request.user)

    def list(self, request):
        queryset = self.get_queryset().order_by('-id')
        page = self.paginate_queryset(queryset)
        serializer = self.serializer_class(queryset, many=True)
        response_list = serializer.data
        return JsonResponse(data={"cash_requests": response_list}, status=status.HTTP_200_OK, safe=False)

class AppVersionView(APIView):
    renderer_classes = [JSONRenderer]

    def get(self,request,*args,**kwargs):
        version= AppVersion.objects.all().first()
        if version:
            return JsonResponse(data={
                'build_number':version.build_number,
                'version_number':version.version_number
            },status=status.HTTP_200_OK)
        else:
            return JsonResponse(data={"message":"version not found"},status=status.HTTP_400_BAD_REQUEST)