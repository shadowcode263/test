from rest_framework import viewsets
from agents.tasks import notify, send_transaction_notification, send_whatsapp_caption_message, send_whatsapp_message
from remittance.models import Order
from remittance.serializers import GetChargeSerializer, OrdersSerializer
from transaction.helper_functions import TransactionService, clean_zesa_response, get_balaces, get_balaces_provider, get_insights_branch, get_insights_by_month, get_insights_by_month_branch, get_statement_provider, mno_balance, zb_balance,get_insights
from transaction.models import BillPayment, CashFlowLedger, Rate, Transactions, TransactionTypes, WithdrawalLedger
from api.serializers.transaction import (
    GeneratePOPSerializer,
    PostTransactionSerializer,
    RetrieveTransactionSerializer,
    TransactionsSerializer,
    TransactionTypesSerializer,
    VerifyTransactionSerializer,
    WithdrawalSerializer
)
import datetime
from rest_framework.permissions import IsAuthenticated, IsAdminUser
from django.core.exceptions import ObjectDoesNotExist
from transaction.filters import CustomFilter
from rest_framework.parsers import JSONParser
from rest_framework.views import APIView
from django.http import JsonResponse
from users.models import AuthorizationManagers, User
from rest_framework import status, generics
from rest_framework.renderers import JSONRenderer
import json
from utils.utils import Utils
from decouple import config


class TransactionsView(APIView):
    serializer_class = TransactionsSerializer
    parser_classes = (JSONParser, )
    filter = CustomFilter
    model = Transactions

    def post(self, request, *args, **kwargs):
        payload = json.loads(request.body)
        transactions = TransactionsSerializer(
            data=self.apply_filter(payload=payload, user=request.user),
            many=True
        )
        transactions.is_valid()
        return JsonResponse(status=200, data={'transactions': transactions.data})

    def get(self, request, *args, **kwargs):
        transactions = TransactionsSerializer(
            data=self.model.filter_all(),
            many=True
        )
        transactions.is_valid()
        return JsonResponse(status=200, data={'transactions': transactions.data})

    def apply_filter(self, payload: dict, user=None):
        query = {
            field: payload.get(field)
            for field in [
                'reference',
                'transaction_type',
                'amount',
                'status',
                'branch',
                'user',
                'start_date',
                'end_date'
            ] if payload.get(field)
        }
        if user:
            query['user'] = User.getUser(id=payload.get("user"))
        object_list = self.filter.custom_filter(query)
        return object_list


class TransactionTypeViewset(viewsets.ModelViewSet):
    serializer_class = TransactionTypesSerializer
    queryset = TransactionTypes.objects.all()


class VerifyTransactionView(APIView):
    parser_classes = [JSONParser]
    renderer_classes = [JSONRenderer]
    permission_classes = (IsAuthenticated,)
    serializer_class = VerifyTransactionSerializer

    def post(self, request):
        try:
            if not request.body:
                return JsonResponse(
                    status=status.HTTP_400_BAD_REQUEST, data={
                        'message': f'No Payload Received.'}
                )

            data = json.loads(request.body)
            serializer = self.serializer_class(
                data=data, context={'request': request})

            if serializer.is_valid():
                service = TransactionService(payload=data)
                return service.verify()
            else:
                return JsonResponse(
                    status=status.HTTP_400_BAD_REQUEST, data={
                        'message': serializer.errors}
                )
        except Exception as e:
            return JsonResponse(
                status=status.HTTP_500_INTERNAL_SERVER_ERROR, data={
                    'message': f'{e}'}
            )


class PostTransactionView(APIView):
    parser_classes = [JSONParser]
    renderer_classes = [JSONRenderer]
    permission_classes = (IsAuthenticated,)
    serializer_class = PostTransactionSerializer

    def post(self, request):
        try:
            if not request.body:
                return JsonResponse(
                    status=status.HTTP_400_BAD_REQUEST, data={
                        'message': f'No Payload Received.'}
                )

            data = json.loads(request.body)
            serializer = self.serializer_class(
                data=data, context={'request': request})

            data['vendorReference'] = Utils().get_transaction_reference()
            if serializer.is_valid():
                # check balances
                if serializer.validated_data.get('transactionType') in ['004', '005', '006', '007']:
                    balance = zb_balance('USD') if serializer.validated_data.get(
                        'transactionType') == '006' else zb_balance('ZWL')
                    if serializer.validated_data['amount'] > balance:
                        return JsonResponse(
                            status=status.HTTP_400_BAD_REQUEST, data={
                                'message': f'Insufficient Balance.'}
                        )
                if serializer.validated_data.get('transactionType') in ['001', '002', '003', '0020', '0010']:
                    balance = mno_balance(
                        serializer.validated_data.get('transactionType'))
                    if serializer.validated_data['amount'] > balance:
                        return JsonResponse(
                            status=status.HTTP_400_BAD_REQUEST, data={
                                'message': f'Insufficient Balance.'}
                        )
                # end check balance
                print('creating transaction')
                transaction = Transactions.create_transaction(request.user, serializer.validated_data.get('amount'), TransactionTypes.filter_code(
                    "TA06"), extras=1, status=False, payload=data, bill_type=serializer.validated_data.get('transactionType'))
                if transaction:
                    # create bill payment
                    print('creating bill payment')
                    bill = BillPayment.create_bill_payment(transaction=transaction, currency=serializer.validated_data.get(
                        'currency'), email=serializer.validated_data.get('email'))
                    if bill:
                        print('running transaction')
                        success, response = TransactionService(
                            payload=serializer.validated_data, user=request.user).process()
                        print('transaction complete')
                        transaction.status = success
                        transaction.extras = bill.id
                        transaction.save()
                        print('transaction saved')
                        print('response', response)
                        bill.narration = 'Successful' if success else 'Failed'
                        bill.extras['response'] = response
                        bill.upstream_response_message = response.get('message').get(
                            'response').get('narration') if success else response.get('message')
                        bill.save()
                        print('bill saved')
                        if success:
                            # adding to cash balance
                            try:
                                CashFlowLedger.create_record(
                                    transaction, request.user, transaction.amount, True)
                                request.user.branch.increment_balance(
                                    transaction.amount)
                            except Exception as e:
                                print('failed to create cash flow line')
                            if serializer.validated_data.get('transactionType') == '005':
                                try:
                                    print('trying to send sms')
                                    notify.delay(serializer.validated_data.get('extras').get('phoneNumber'), clean_zesa_response(
                                        response.get('message').get('response').get('narration').get('Transaction Narration')))
                                except Exception as e:
                                    print('sms sending failed')
                                    print('error', e)
                                    pass
                            if serializer.validated_data.get('transactionType') == '006':
                                try:
                                    print('trying to send sms')
                                    notify.delay(serializer.validated_data.get('extras').get(
                                        'phoneNumber'), "Thank you for using Tumai. Your DStv payment has been processed. To clear an E-16 error, SMS the word RESET + smartcard number to 33788. Note - decoder must be switched on.")
                                except Exception as e:
                                    print('sms sending failed')
                                    print('error', e)
                                    pass
                            if serializer.validated_data.get('transactionType') in ['004', '007']:
                                try:
                                    print('trying to send sms')
                                    notify.delay(serializer.validated_data.get('extras').get('phoneNumber'), response.get(
                                        'message').get('response').get('narration').get('Transaction Narration')+" \nYour transaction reference is "+transaction.reference+'\nYou can use this reference on our chatbot to get your proof of payment\nTumi:0788448617\nThank you for using Tumai')
                                except Exception as e:
                                    print('sms sending failed')
                                    print('error', e)
                                    pass
                            return JsonResponse(status=status.HTTP_200_OK, data={'message': bill.upstream_response_message})
                        else:
                            return JsonResponse(status=status.HTTP_400_BAD_REQUEST, data={'message': bill.upstream_response_message})
                    else:
                        print('bill could not be saved')
                        return JsonResponse(
                            status=status.HTTP_400_BAD_REQUEST, data={
                                'message': 'Failed to save bill payment'}
                        )
                else:
                    return JsonResponse(
                        status=status.HTTP_400_BAD_REQUEST, data={
                            'message': 'Failed to save transaction'}
                    )

            else:
                return JsonResponse(
                    status=status.HTTP_400_BAD_REQUEST, data={
                        'message': serializer.errors}
                )
        except Exception as e:
            return JsonResponse(
                status=status.HTTP_400_BAD_REQUEST, data={'message': f'{e}'}
            )


class GetRateView(APIView):
    parser_classes = [JSONParser]
    renderer_classes = [JSONRenderer]

    def post(self, request, *args, **kwargs):
        try:
            print(request)
            if not request.body:
                return JsonResponse(
                    status=status.HTTP_400_BAD_REQUEST, data={
                        'message': f'No Payload Received.'}
                )
            print('Incoming Info', request.body)
            serializer = GetChargeSerializer(data=json.loads(request.body))

            if serializer.is_valid():
                try:
                    rate = Rate.objects.first()
                    bm_rate = 450 if request.user.branch.id in [
                        4, 6, 12] else rate.blackmarket
                    if rate:
                        ib_amount = serializer.validated_data.get(
                            'amount') * rate.interbank
                        bm_amount = serializer.validated_data.get(
                            'amount') * bm_rate
                        discount = ((bm_amount - ib_amount)/ib_amount)*100

                        return JsonResponse(status=status.HTTP_200_OK, data={
                            'rate': rate.interbank,
                            'amount': round(serializer.validated_data.get('amount') * rate.interbank*(1+discount/100), 2),
                            'discount': round(discount, 2)
                        })
                    else:
                        return JsonResponse(status=status.HTTP_400_BAD_REQUEST, data={'message': 'No Rate Found'})
                except Exception as e:
                    print(e)
                    return JsonResponse(status=status.HTTP_404_NOT_FOUND, data={'message': 'Transaction could not be processed'})
            else:
                return JsonResponse(
                    status=status.HTTP_400_BAD_REQUEST, data={
                        'message': serializer.errors}
                )
        except Exception as e:
            return JsonResponse(
                status=status.HTTP_500_INTERNAL_SERVER_ERROR, data={
                    'message': f'{e}'}
            )


class GetLatestTransactions(APIView):
    serializer_class = RetrieveTransactionSerializer
    parser_classes = (JSONParser, )
    filter = CustomFilter
    model = Transactions

    def post(self, request, *args, **kwargs):
        payload = json.loads(request.body)
        transactions = RetrieveTransactionSerializer(
            data=self.apply_filter(payload=payload, user=request.user),
            many=True
        )
        transactions.is_valid()
        return JsonResponse(status=200, data={'transactions': transactions.data})

    def get(self, request, *args, **kwargs):
        transactions = RetrieveTransactionSerializer(
            data=self.model.filter_latest(),
            many=True
        )
        transactions.is_valid()
        return JsonResponse(status=200, data={'transactions': transactions.data})

    def apply_filter(self, payload: dict, user=None):
        query = {
            field: payload.get(field)
            for field in [
                'reference',
                'transaction_type',
                'amount',
                'status',
                'branch',
                'user',
                'start_date',
                'end_date'
            ] if payload.get(field)
        }
        if user:
            query['user'] = User.getUser(id=payload.get("user"))
        object_list = self.filter.custom_filter(query)
        return object_list


class ViewBillPayments(generics.ListAPIView):
    permission_classes = (IsAuthenticated,)
    serializer_class = TransactionsSerializer
    queryset = Transactions.objects.filter(
        transaction_type=TransactionTypes.filter_code('TA06'), status=True)


class GetBalancesView(APIView):
    permission_classes = (IsAuthenticated,)
    parser_classes = [JSONParser]

    def get(self, request, *args, **kwargs):
        balances = get_balaces()
        if balances:
            return JsonResponse(status=200, data={'balances': balances})
        else:
            return JsonResponse(status=400, data={'message': 'Balances could not be retrieved'})


class ViewTransactionTypes(generics.ListAPIView):
    permission_classes = (IsAuthenticated,)
    serializer_class = TransactionTypesSerializer
    queryset = TransactionTypes.objects.all()


class CheckAccountBalance(APIView):
    permission_classes = (IsAuthenticated,)
    renderer_classes = [JSONRenderer]

    def get(self, request, *args, **kwargs):
        provider = kwargs.get('provider')
        if provider:
            balance = get_balaces_provider(provider)
            return JsonResponse(status=status.HTTP_200_OK, data=balance)
        else:
            return JsonResponse(status=status.HTTP_404_NOT_FOUND, data={"message": "Provider not set!!"})


class GetStatementsView(APIView):
    permission_classes = (IsAuthenticated, IsAdminUser)
    renderer_classes = [JSONRenderer]

    def get(self, request, *args, **kwargs):
        provider = kwargs.get('provider')
        if not provider in ['econet', 'netone', 'telecel']:
            return JsonResponse(status=status.HTTP_404_NOT_FOUND, data={"message": "Provider not set!!"})
        else:
            mno = 'ECONET_AIRTIME' if provider.lower(
            ) == 'econet' else 'NETONE_AIRTIME' if provider.lower() == 'netone' else 'TELECEL_AIRTIME'
            transactions = get_statement_provider(mno)
            return JsonResponse(status=status.HTTP_200_OK, data=transactions)


class UserBalanceView(APIView):
    permission_classes = (IsAuthenticated,)
    renderer_classes = [JSONRenderer]

    def get(self, request, *args, **kwargs):
        balance = request.user.branch.running_balance if request.user.is_prepaid else None
        return JsonResponse(status=status.HTTP_200_OK, data={'balance': balance})


class ViewCurrentBillPayments(generics.ListAPIView):
    permission_classes = (IsAuthenticated,)
    serializer_class = TransactionsSerializer
    queryset = Transactions.objects.filter(transaction_type=TransactionTypes.filter_code(
        'TA06'), status=True, date_created__date=datetime.datetime.now().date())


class ViewCurrentOrders(generics.ListAPIView):
    permission_classes = (IsAuthenticated,)
    serializer_class = OrdersSerializer
    queryset = Order.objects.filter(
        date_created__date=datetime.datetime.now().date())


class WithdrawalView(APIView):
    parser_classes = [JSONParser]
    renderer_classes = [JSONRenderer]
    permission_classes = (IsAuthenticated, IsAdminUser,)
    serializer_class = WithdrawalSerializer

    def post(self, request):
        try:
            if not request.body:
                return JsonResponse(
                    status=status.HTTP_400_BAD_REQUEST, data={
                        'message': f'No Payload Received.'}
                )

            data = json.loads(request.body)
            serializer = self.serializer_class(data=data)

            if serializer.is_valid():
                print('serializer is valid')
                print("passed here")
                try:
                    if request.user.is_superadmin:
                        print("trying")
                        transaction = Transactions.create_withdrawal(
                            request.user, serializer.validated_data['amount'], TransactionTypes.filter_code("TA09"), extras=0, status=False)
                        print("tried")
                        if transaction:
                            print('transaction saved')
                            withdrawal = WithdrawalLedger.create_withdrawal(
                                transaction.amount)
                            print('done')
                            if withdrawal:
                                return JsonResponse(status=status.HTTP_200_OK, data={'message': 'Withdrawal Successful'})
                            else:
                                return JsonResponse(status=status.HTTP_400_BAD_REQUEST, data={'message': 'Withdrawal Failed'})
                        else:
                            print("no such transaction")
                            return JsonResponse(status=status.HTTP_400_BAD_REQUEST, data={'message': 'Withdrawal Failed'})
                    else:
                        return JsonResponse(status=status.HTTP_403_FORBIDDEN, data={'message': 'You are not authorized to perform this action'})
                except Exception as e:
                    print(e)
                    return JsonResponse(status=status.HTTP_400_BAD_REQUEST, data={'message': 'Withdrawal Failed'})
            else:
                return JsonResponse(
                    status=status.HTTP_400_BAD_REQUEST, data={
                        'message': serializer.errors}
                )
        except Exception as e:
            return JsonResponse(
                status=status.HTTP_500_INTERNAL_SERVER_ERROR, data={
                    'message': f'{e}'}
            )


class WithdrawOtpView(APIView):
    permission_classes = (IsAuthenticated,)
    renderer_classes = [JSONRenderer]

    def get(self, request, *args, **kwargs):
        notify.delay(config("withdrawal_phone_number"),f"Your one time password for authorization on Tumai is {AuthorizationManagers.objects.filter(name=config('withdrawal_name')).first().pin}.")
        return JsonResponse(status=status.HTTP_200_OK, data={'message': 'sms sent'})


class GeneratePOPView(APIView):
    permission_classes = ()
    serializer_class = GeneratePOPSerializer

    def post(self, request):
        print('Request Data', request.data)
        serializer = self.serializer_class(data=request.data)
        pass
        if serializer.is_valid():
            """Transaction notification
            Args:
                validated_data: validated_data
            """
            validated_data = serializer.validated_data
            transaction = Transactions.filter_transaction_by_reference(
                validated_data["transaction_reference"]
            )
            save_pop = send_transaction_notification(
                transaction)
            if save_pop:
                send_whatsapp_message(
                    validated_data["phone_number"], "Thank you for transacting on Tumai, find attached your proof of payment")
                send_whatsapp_caption_message(validated_data['phone_number'], 'Proof of payment', config(
                    'base_url')+'generated-pdf/'+transaction.reference+'.pdf')
                return JsonResponse(
                    status=status.HTTP_200_OK, data={
                        'message': 'file'}
                )
            else:
                return JsonResponse(
                    status=status.HTTP_400_BAD_REQUEST, data={
                        'message': 'file could not be generated'}
                )
        else:
            return JsonResponse(
                    status=status.HTTP_400_BAD_REQUEST, data={
                        'message': serializer.errors}
                )

class InsightView(APIView):
    permission_classes = (IsAuthenticated,)
    renderer_classes = [JSONRenderer]

    def get(self, request, *args, **kwargs):
        try:
            insights = get_insights()
            print(insights)
            return JsonResponse(status=status.HTTP_200_OK, data={'message': insights})
        except Exception as e:
            return JsonResponse(
                status=status.HTTP_500_INTERNAL_SERVER_ERROR, data={
                    'message': f'{e}'}
            )

class DailyInsightView(APIView):
    permission_classes = (IsAuthenticated,)
    renderer_classes = [JSONRenderer]

    def get(self, request, *args, **kwargs):
        month = kwargs.get('month')
        if month in ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12']:
            try:
                insights = get_insights_by_month(month)
                print(insights)
                return JsonResponse(status=status.HTTP_200_OK, data={'message': insights})
            except Exception as e:
                return JsonResponse(
                    status=status.HTTP_500_INTERNAL_SERVER_ERROR, data={
                        'message': f'{e}'}
                )
        else:
            return JsonResponse(status=status.HTTP_400_BAD_REQUEST, data={'message': 'Invalid month'})
        
    
class InsightBranchView(APIView):
    permission_classes = (IsAuthenticated,)
    renderer_classes = [JSONRenderer]

    def get(self, request, *args, **kwargs):
        branch = kwargs.get('branch')
        try:
            insights = get_insights_branch(branch)
            print(insights)
            return JsonResponse(status=status.HTTP_200_OK, data={'message': insights})
        except Exception as e:
            return JsonResponse(
                status=status.HTTP_500_INTERNAL_SERVER_ERROR, data={
                    'message': f'{e}'}
            )

class DailyInsightBranchView(APIView):
    permission_classes = (IsAuthenticated,)
    renderer_classes = [JSONRenderer]

    def get(self, request, *args, **kwargs):
        month = kwargs.get('month')
        branch = kwargs.get('branch')
        if month in ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12']:
            try:
                insights = get_insights_by_month_branch(month,branch)
                print(insights)
                return JsonResponse(status=status.HTTP_200_OK, data={'message': insights})
            except Exception as e:
                return JsonResponse(
                    status=status.HTTP_500_INTERNAL_SERVER_ERROR, data={
                        'message': f'{e}'}
                )
        else:
            return JsonResponse(status=status.HTTP_400_BAD_REQUEST, data={'message': 'Invalid month'})
        
