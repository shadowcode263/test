from intelli_gateway.gateway_client import GatewayClient
from django_rq import job
from decouple import config
from urllib.request import urlopen
from urllib.parse import quote
import json
import requests
from services.notifications.pop.GeneratePOP import GeneratePOP
from services.notifications.pop.Gen_pop_bill import GeneratePOPBill


def phone_number_formatter(phone_number):
    if phone_number[0] == '0':
        phone_number = '263' + phone_number[1:]
    if phone_number[0] == '+':
        phone_number = phone_number[1:]
    if phone_number[0] == '7':
        phone_number = '263' + phone_number
    if phone_number[0] == '2':
        phone_number = phone_number
    return phone_number.replace(" ", "")


def send_whatsapp_message(phone_number, message):
    url = "https://api.chat-api.com/instance398414/sendMessage?token=off_kmor6Du9xXh7Qw7lUKuloQ8wAK"

    payload = json.dumps({
        "phone": phone_number,
        "body": message
    })
    headers = {
        'Content-Type': 'application/json'
    }

    response = requests.get(url, headers=headers, data=payload)
    # print(response.json())
    return True


def send_whatsapp_caption_message(phone_number, message, file):
    payload = json.dumps({
        "phone": phone_number,
        "body": file,
        "filename": 'pop.pdf',
        "caption": message
    })
    print(payload)
    headers = {
        'Content-Type': 'application/json'
    }
    url = "https://api.chat-api.com/instance398414/sendFile?token=off_kmor6Du9xXh7Qw7lUKuloQ8wAK"
    response = requests.post(url=url, headers=headers, data=payload)
    print(response.status_code)
    if response.status_code == 200:
        print(response.json())
    return True


def sendsms(message, phone_number):
    username = "nigelreign"

    token = "671ae6cc1bd9981e5d9082b582e7bc9c"

    bulksms_ws = "http://portal.bulksmsweb.com/index.php?app=ws"

    destinations = phone_number

    ws_str = bulksms_ws + "&u=" + username + "&h=" + token + "&op=pv"
    ws_str = ws_str + "&to=" + quote(destinations) + "&msg=" + quote(message)

    http_response = urlopen(ws_str).read()

    print(http_response)


@job('agents_notifications')
def notify(user, message):
    print('sending whatsapp message')
    send_whatsapp_message(phone_number_formatter(user), message)
    print(f'Notifying {user} with message {message}')
    if user.startswith('26371') or user.startswith('071'):
        print('sending to netone')
        sendsms(message, user)
    else:
        client = GatewayClient(config("SMS_USERNAME"), config("SMS_PASSWORD"))
        client.authenticate()
        try:
            client.send_sms(message=message, receiver=phone_number_formatter(
                user), sender_id="Tumai")
        except Exception as e:
            try:
                print('retrying sms')
                client.send_sms(message=message, receiver=phone_number_formatter(
                    user), sender_id="Tumai")
                print('send sms success')
            except Exception as e:
                print('failed to send sms')
            print(e)
        pass


# @job('proof_of_payment')
def send_transaction_notification(transaction):
    payload = transaction.payload.replace(
        "'", '"').replace('None', json.dumps(None))
    payload = json.loads(payload)
    if transaction.bill_type == "004":
        transaction_type = "School Fees"
        # dt = datetime.fromisoformat('2021-01-05T23:19:30.685658Z'[:-1])
        trans_date = transaction.date_created.strftime('%Y-%m-%d')

        create_pop = GeneratePOP()
        create_pop.create_pdf(
            payload["fullName"],
            payload["accountNumber"],
            payload["billerId"],
            payload["academicSemester"],
            transaction.amount*transaction.bill_transaction.get().extras.get('bm_rate'),
            trans_date,
            transaction_type,
            transaction.reference,
            transaction.payload["purpose"],
        )

    elif transaction.bill_type in  ["007","006"]:
        transaction_type = "Bill Payments" if transaction.bill_type == "007" else "DSTV"
        trans_date = transaction.date_created.strftime('%Y-%m-%d')
        create_pop = GeneratePOPBill()
        create_pop.create_pdf(
            bill_name=payload.get('extras').get('billerId'),
            account_number=payload.get(
                'extras').get('accountNumber'),
            account_name=payload.get('extras').get('fullName'),
            currency='ZWL' if transaction.bill_type == "007" else 'USD',
            transaction_amount=transaction.amount*transaction.bill_transaction.get().extras.get('bm_rate') if transaction.bill_type == "007" else transaction.amount,
            transaction_date=trans_date,
            transaction_reference=transaction.reference,
            bank_reference=str(transaction.bill_transaction.get().extras.get('response').get('message').get('response').get('narration').get('Gateway Reference')),
            narration="Transaction Processed Successfully",
        )
        return True
    elif transaction.bill_type == "005":
        transaction_type = "Bill Payments"
        # dt = datetime.fromisoformat('2021-01-05T23:19:30.685658Z'[:-1])
        trans_date = transaction.date_created.strftime('%Y-%m-%d')
        # print('gggggggg',type(extras['fullName']))
        create_pop = GeneratePOPBill()
        create_pop.create_pdf(
            bill_name="ZETDC",
            account_number=payload.get(
                'extras').get('accountNumber'),
            account_name=payload.get('extras').get('fullName'),
            currency='ZWL',
            transaction_amount=transaction.amount*transaction.bill_transaction.get().extras.get('bm_rate'),
            transaction_date=trans_date,
            transaction_reference=transaction.reference,
            bank_reference=str(transaction.bill_transaction.get().extras.get('response').get('message').get('response').get('narration').get('Gateway Reference')),
            narration=str(transaction.bill_transaction.get().extras.get('response').get('message').get('response').get('narration').get('Token'))
        )
        return True
