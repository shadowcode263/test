from random import choices
from rest_framework import serializers
from remittance.models import ActiveCities, CashOutlets, DailyProcesses, Order, Limits, RTGSOrder, SenderDetails
import datetime
from utils.utils import Utils


class CreateOrderSerializer(serializers.ModelSerializer):

    initiator_name = serializers.CharField(
        required=True, max_length=255, label="initiator_name")
    initiator_phone_number = serializers.CharField(
        required=True, max_length=255, label="initiator_phone_number")
    initiator_email = serializers.CharField(
        required=False, max_length=255, label="initiator_email")
    initiator_id_number = serializers.CharField(
        required=True, max_length=255, label="initiator_id_number")
    # recipient
    recipient_name = serializers.CharField(
        required=True, max_length=255, label="recipient_name")
    recipient_phone_number = serializers.CharField(
        required=True, max_length=255, label="recipient_phone_number")
    recipient_id_number = serializers.CharField(
        required=True, max_length=255, label="recipient_id_number")
    recipient_address = serializers.CharField(
        required=True, max_length=255, label="recipient_address")
    recipient_identification_type = serializers.CharField(
        required=False, max_length=255, label="recipient_identification_type")
    # order details
    source = serializers.CharField(
        required=True, max_length=255, label="source")
    amount = serializers.FloatField(required=True, label="amount")
    city = serializers.CharField(required=True, max_length=255, label="city")
    narration = serializers.CharField(
        required=True, max_length=255, label="narration")
    currency = serializers.CharField(
        required=True, max_length=255, label="currency")

    class Meta:
        model = Order
        fields = ['initiator_name', 'initiator_phone_number', 'initiator_email', 'initiator_id_number', 'recipient_name', 'recipient_phone_number',
                  'recipient_id_number', 'recipient_identification_type', 'recipient_address', 'source', 'amount', 'narration', 'currency', 'city']

    def validate(self, attrs):
        limit = Limits.get_limit()
        if limit:
            if attrs['amount'] > limit.upper_limit:
                raise serializers.ValidationError("Amount exceeds limit")
            if attrs['amount'] < limit.lower_limit:
                raise serializers.ValidationError("Amount is below limit")
        # if attrs['amount']%10 != 0:
        #     raise serializers.ValidationError("Amount should be a multiple of 10 e.g 10,20,30,70...")
        # check limit
        if not SenderDetails.create_or_update(sender_name=attrs['initiator_name'], national_id=attrs['initiator_id_number'], amount=attrs['amount']):
            raise serializers.ValidationError(
                "You have reached the monthly limit, order could not be created")
        return super().validate(attrs)


class CreateRtgsOrderSerializer(serializers.ModelSerializer):

    initiator_name = serializers.CharField(
        required=True, max_length=255, label="initiator_name")
    initiator_phone_number = serializers.CharField(
        required=True, max_length=255, label="initiator_phone_number")
    initiator_email = serializers.CharField(
        required=False, max_length=255, label="initiator_email")
    initiator_id_number = serializers.CharField(
        required=True, max_length=255, label="initiator_id_number")
    # recipient
    student_name = serializers.CharField(
        required=True, max_length=255, label="recipient_name")
    student_phone_number = serializers.CharField(
        required=True, max_length=255, label="recipient_phone_number")
    student_id_number = serializers.CharField(
        required=True, max_length=255, label="recipient_id_number")
    student_number = serializers.CharField(
        required=True, max_length=255, label="recipient_address")
    student_identification_type = serializers.CharField(
        required=False, max_length=255, label="recipient_identification_type")
    # order details
    source = serializers.CharField(
        required=True, max_length=255, label="source")
    amount = serializers.FloatField(required=True, label="amount")

    narration = serializers.CharField(
        required=True, max_length=255, label="narration")
    currency = serializers.CharField(
        required=True, max_length=255, label="currency")

    class Meta:
        model = RTGSOrder
        fields = ['initiator_name', 'initiator_phone_number', 'initiator_email', 'initiator_id_number', 'student_name', 'student_phone_number',
                  'student_id_number', 'student_identification_type', 'student_number', 'source', 'amount', 'narration', 'currency']

    def validate(self, attrs):
        limit = Limits.get_limit()
        if limit:
            if attrs['amount'] > limit.upper_limit:
                raise serializers.ValidationError("Amount exceeds limit")
            if attrs['amount'] < limit.lower_limit:
                raise serializers.ValidationError("Amount is below limit")
        if attrs['amount'] % 10 != 0:
            raise serializers.ValidationError(
                "Amount should be a multiple of 10 e.g 10,20,30,70...")
        return super().validate(attrs)


class UpdateOrderSerializer(serializers.Serializer):

    def create(self, validated_data):
        return UpdateOrderSerializer(**validated_data)


class CollectOrderSerializer(serializers.Serializer):
    reference_number = serializers.CharField(
        required=True, max_length=255, label="reference_number")
    order_number = serializers.CharField(
        required=True, max_length=255, label="order_number")
    confirmation_file = serializers.FileField(
        required=False, label="confirmation_file")

    def create(self, validated_data):
        return CollectOrderSerializer(**validated_data)


class RetrieveOrderSerializer(serializers.Serializer):
    reference_number = serializers.CharField(
        required=True, max_length=255, label="reference_number")

    def create(self, validated_data):
        return RetrieveOrderSerializer(**validated_data)


class ApproveCashSerializer(serializers.Serializer):
    request_id = serializers.CharField(
        required=True, max_length=255, label="request_id")
    type = serializers.CharField(required=True, max_length=255, label="type")
    amount = serializers.CharField(
        required=True, max_length=255, label="amount")

    def create(self, validated_data):
        return ApproveCashSerializer(**validated_data)


class OrderSerializer(serializers.ModelSerializer):
    class Meta:
        model = Order
        fields = '__all__'

    def to_representation(self, obj):
        rep = super(OrderSerializer, self).to_representation(obj)
        rep['ordering_agent'] = f'{obj.ordering_agent.first_name}-{obj.ordering_agent.branch.name}' if obj.ordering_agent else None
        rep['collection_agent'] = f'{obj.collection_agent.first_name}-{obj.collection_agent.branch.name}' if obj.collection_agent else None
        rep['order_number'] = obj.order_number[:2]+'*'*6 + \
            obj.order_number[8:] if obj.order_number else ""
        return rep


class OrderValidateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Order
        fields = '__all__'


class ValidateOrderSerializer(serializers.Serializer):
    reference_number = serializers.CharField(
        required=True, max_length=255, label="reference_number")
    order_number = serializers.CharField(
        required=True, max_length=255, label="order_number")

    def create(self, validated_data):
        return ValidateOrderSerializer(**validated_data)


class OrdersSerializer(serializers.ModelSerializer):
    branch = serializers.SerializerMethodField()
    class Meta:
        model = Order
        fields = '__all__'

    def get_branch(self, obj):
        if obj.ordering_agent:
            return obj.ordering_agent.branch.name if obj.ordering_agent.branch else None
        else:
            return None
    def to_representation(self, obj):
        rep = super(OrdersSerializer, self).to_representation(obj)
        if obj.ordering_agent:
            rep['ordering_agent'] = f'{obj.ordering_agent.first_name}-{obj.ordering_agent.branch.name}' if obj.ordering_agent.branch else f'{obj.ordering_agent.first_name}'
        rep['collection_agent'] = f'{obj.collection_agent.first_name}-{obj.collection_agent.branch.name}' if obj.collection_agent else None
        return rep


class CitySerializer(serializers.ModelSerializer):
    class Meta:
        model = ActiveCities
        fields = '__all__'


class CashOutletSerializer(serializers.ModelSerializer):
    class Meta:
        model = CashOutlets
        fields = '__all__'


class GetChargeSerializer(serializers.Serializer):
    amount = serializers.IntegerField(required=True, label="amount")

    def create(self, validated_data):
        return GetChargeSerializer(**validated_data)


class OrdersReportSerializer(serializers.Serializer):
    start_date = serializers.DateField(required=True, label="start_date")
    end_date = serializers.DateField(required=True, label="end_date")

    def create(self, validated_data):
        return OrdersReportSerializer(**validated_data)


class OrdersReportCSVSerializer(serializers.ModelSerializer):
    class Meta:
        model = Order
        fields = '__all__'
