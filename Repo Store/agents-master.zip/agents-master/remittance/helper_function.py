import requests
import json

def create_agent(user):
    from remittance.models import Agents
    success,agent = Agents.create_agent(user)
    if success:
        # post to bot
        print(agent)
        print('posting to bot')
        url = 'https://bot.tumai.to/api/v1/create/agent/'
        payload = json.dumps({
        "phone_number": agent.phone_number,
        "identifier": agent.identifier
        })
        print('payload',payload)
        headers = {
        'Content-Type': 'application/json'
        }

        response = requests.request("POST", url, headers=headers, data=payload)
        
        if response.status_code == 200:
            print('agent cretead successfully')
            return True
        else:
            print('failed from bot',response.json())
            return False

def clean_national_id(national_id):
    """
    Clean the national id to remove all non-numeric characters
    """
    
    cleaned = national_id.replace('-', '').replace(' ', '').upper()
    return cleaned