from remittance.models import Order
from django.utils.timezone import make_aware
import django_filters
from django.db.models import Q
from django.conf import settings

import datetime
import pytz
import json


class CustomFilterOrders(django_filters.FilterSet):
    q = django_filters.CharFilter(method='custom_filter')

    class Meta:
        model = Order
        fields = ['q']

    @staticmethod
    def custom_filter(query_data=None):
        def make_date(data): return make_aware(datetime.datetime.strptime(
            data, '%Y-%m-%d'), pytz.timezone(settings.TIME_ZONE))
        q_set = {
            'amount': Q(amount=query_data.get('amount')) if query_data.get('amount') else None,
            'branch': Q(branch__code=query_data.get('branch')) if query_data.get('branch') else None,
            'order_number': Q(order_number__icontains=query_data.get('order_number')) if query_data.get('order_number') else None,
            'reference_number': Q(reference_number__icontains=query_data.get('reference_number')) if query_data.get('reference_number') else None,
            'recipient_phone_number': Q(recipient_phone_number__icontains=query_data.get('recipient_phone_number')) if query_data.get('recipient_phone_number') else None,
            'initiator_phone_number': Q(initiator_phone_number__icontains=query_data.get('initiator_phone_number')) if query_data.get('initiator_phone_number') else None,
            'recipient_id_number': Q(recipient_id_number__icontains=query_data.get('recipient_id_number')) if query_data.get('recipient_id_number') else None,
            'initiator_id_number': Q(initiator_id_number__icontains=query_data.get('initiator_id_number')) if query_data.get('initiator_id_number') else None,
            'recipient_name': Q(recipient_name__icontains=query_data.get('recipient_name')) if query_data.get('recipient_name') else None,
            'initiator_name': Q(initiator_name__icontains=query_data.get('initiator_name')) if query_data.get('initiator_name') else None,
            'ordering_agent': Q(ordering_agent=query_data.get('user')) if query_data.get('ordering_agent') else None,
            'status': Q(status=json.loads(query_data.get('status').lower())) if query_data.get('status') else None,
            'start_date': Q(date_created__gte=make_date(query_data.get('start_date'))) if query_data.get('start_date') else None,
            'end_date': Q(date_created__lte=make_date(query_data.get('end_date'))) if query_data.get('end_date') else None
        }
        query = None
        for item in q_set.values():
            if item:
                if not query:
                    query = item
                else:
                    query &= item
        return Order.objects.filter(query) if query else Order.objects.filter.all()
