from django.utils.timezone import make_aware
from company.models import Branch
from django.conf import settings
from remittance.helper_function import clean_national_id
from users.models import AuthorizationManagers, User
from datetime import datetime
from utils.utils import Utils
from tabnanny import verbose
from django.db import models
from transaction.models import CashFlowLedger, Transactions, TransactionTypes
import pytz
import pyotp

class CashOutlets(models.Model):
    name = models.CharField(max_length=100,unique=True)
    type = models.CharField(max_length=100,blank=True, null= True, default='Booth')
    status = models.BooleanField(default=True)
    
    class Meta:
        verbose_name = 'Cash Outlets'
        verbose_name_plural = 'Cash Outlets'

class FailedMessages(models.Model):
    message = models.CharField(max_length=100,null=False)
    phone_number = models.CharField(max_length=100,blank=False, null= False)
    status = models.BooleanField(default=False)
    retries = models.IntegerField(default=0)
    
    class Meta:
        ordering = ["-id"]
        verbose_name = 'Failed Message'
        verbose_name_plural = 'Failed Messages'

class ActiveCities(models.Model):   
    name = models.CharField(max_length=100, unique=True)
    district = models.CharField(max_length=100,blank=True,null=True)
    class Meta:
        ordering = ["name"]
        verbose_name = "Active City"
        verbose_name_plural = "Active Cities"
    
class Agents(models.Model):
    phone_number = models.CharField(max_length=15, unique=True)
    identifier = models.CharField(max_length=255,unique=True)
    date_created = models.DateTimeField(auto_now_add=True)
    qr_code = models.TextField(null=True, blank=True)  
    
    class Meta:
        verbose_name = 'Agent'
        verbose_name_plural = 'Agents'
        ordering = ['id']

    @classmethod
    def filter_phone_number(cls, phone_number):
        return cls.objects.filter(phone_number=phone_number).first()
    
    @classmethod
    def get_user_qr(cls,phone_number):
        user = cls.objects.filter(phone_number=phone_number).first()
        return user.qr_code

    @classmethod
    def create_agent(cls,user):
        try:
            print('creating agent agents')
            uniqueId = pyotp.random_base32()
            url = pyotp.totp.TOTP(uniqueId).provisioning_uri(name=f"{user.phone_number}", issuer_name='Tumai Agent')
            qrCode = f"https://www.google.com/chart?chs=200x200&chld=M|0&cht=qr&chl={url}"
            agent = cls.objects.create(phone_number=user.phone_number,identifier=uniqueId,qr_code=qrCode)
            agent.save()
            return True,agent
        except Exception as e:
            print(e)
            return False,None
    
class ConversionRate(models.Model):
    rate = models.FloatField()
    bm_rate = models.FloatField(default=0)
    last_updated = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ["-last_updated"]
        verbose_name = "Conversion Rate"
        verbose_name_plural = "Conversion Rates"

class SenderDetails(models.Model):
    national_id = models.CharField(max_length=100, unique=True)
    sender_name = models.CharField(max_length=100)
    processed_amount = models.FloatField(default=0)
    number_of_transactions = models.IntegerField(default=0)
    date_created = models.DateTimeField(auto_now_add=True)
    class Meta:
        ordering = ["-id"]
        verbose_name = 'Sender Limit'
        verbose_name_plural = 'Sender Limits'
        
    @classmethod
    def create_or_update(cls,sender_name,national_id,amount):
        sender = cls.objects.filter(national_id=clean_national_id(national_id)).first()
        limits = Limits.objects.all().first()
        if sender:
            if limits:
                total_amount = sender.processed_amount + amount                
                if limits.monthly_limit >= total_amount:
                    sender.processed_amount = sender.processed_amount + amount
                    sender.save()
                    return True
                else:
                    return False
            else:
                return False
        else:
            sender = cls.objects.create(national_id=clean_national_id(national_id),sender_name=sender_name,processed_amount=amount)
            sender.save()
            return True
        
# Create your models here.
class Order(models.Model):
    # initiator
    initiator_name = models.CharField(max_length=255,blank=False,null=False)
    initiator_phone_number = models.CharField(max_length=255,blank=True,null=True)
    initiator_email = models.EmailField(blank=True, null=True)
    initiator_id_number = models.CharField(max_length=255,blank=True,null=True)
    # recipient
    recipient_name = models.CharField(max_length=255, null=False, blank=False) 
    recipient_identification_type =models.CharField(max_length=244,null=True,blank=True)
    recipient_phone_number = models.CharField(max_length=255, null=False, blank=False, default="26377581057") 
    recipient_id_number = models.CharField(max_length=255, null=False, blank=False) 
    recipient_address = models.CharField(max_length=255, null=True, blank=True) 
    # order details
    source = models.CharField(max_length=150, blank=True, default="Unknown")
    amount = models.FloatField()
    charge = models.FloatField(blank=True, null=True)
    status = models.CharField(max_length=255,default='PENDING')
    narration = models.CharField(max_length=255)
    currency = models.CharField(max_length=255, default="")
    city = models.CharField(max_length=255, blank=True, null=True)
    # ordering agent
    ordering_agent = models.ForeignKey(
        User, on_delete=models.PROTECT, null=True, related_name="agent_ordering"
    )
    reference_number = models.CharField(max_length=255, unique=True)
    # collection point
    order_number = models.CharField(max_length=255, blank=True, null=True)
    verification_file = models.FileField(blank=True, null=True)
    collection_agent = models.ForeignKey(
        User, on_delete=models.PROTECT, null=True, related_name="agent_collecting"
    )
    extras = models.JSONField(null=True, blank=True)
    # timestamps
    date_created = models.DateTimeField(auto_now_add=True)
    date_approved = models.DateTimeField(blank=True, null=True)
    date_collected = models.DateTimeField(blank=True, null=True)

    def __str__(self):
        return f'{self.reference_number} - {self.initiator_name}'
    
    def approve(self,user):
        print('approving order')
        self.status = 'APPROVED'
        self.ordering_agent = user
        self.order_number = Utils.generate_reference_number(prefix='T')
        self.date_approved = make_aware(datetime.now(), timezone=pytz.timezone(settings.TIME_ZONE))
        # todo send sms for order
        self.save()
        main_txn = Transactions.create_transaction(user, self.amount, TransactionTypes.filter_code("TA05"), extras=self.id, status=True)
        charge_txn = Transactions.create_transaction(user, self.charge, TransactionTypes.filter_code("TA04"), extras=self.id, status=True)

        CashFlowLedger.create_record(main_txn, user, self.amount, True)
        CashFlowLedger.create_record(charge_txn, user, self.charge, True)
        user.branch.increment_balance(self.amount+self.charge)
        
    def collect(self,user):
        self.status = 'COLLECTED'
        self.collection_agent = user
        self.date_collected = make_aware(datetime.now(), timezone=pytz.timezone(settings.TIME_ZONE))
        # todo send sms for order
        self.save()
        main_txn = Transactions.create_transaction(user, self.amount, TransactionTypes.filter_code("TA55"), extras=self.id, status=True)
        CashFlowLedger.create_record(main_txn, user, self.amount, False)
        user.branch.decrement_balance(self.amount)

    def get_orders(self,user):
        return self.objects.filter(ordering_agent=user,collection_agent=user)
        
    def save(self, *args, **kwargs):
        self.last_updated = datetime.today()
        super().save(*args, **kwargs)

    class Meta:
        ordering = ['-date_created']
        verbose_name = 'Order'
        verbose_name_plural = 'Orders'        


# class OrderCharge(models.Model):
#     agent = models.ForeignKey(
#         User, on_delete=models.PROTECT, null=True, related_name="order_charge"
#     )
#     amount = models.FloatField(default=0)
#     order = models.ForeignKey(Order, on_delete=models.PROTECT, null=True, related_name="order_charge")
    
#     def __str__(self):
#         return f'{self.agent} - {self.amount}'
#     class Meta:
#         verbose_name = 'Order Charge'
#         verbose_name_plural = 'Order Charges'
#     @classmethod
#     def record_charge(cls,amount,user,order):
#         try:
#             cls(agent=user,amount=amount,order=order).save()
#             return True
#         except Exception as e:
#             print(e)
#             return False
        
class AllocationRequest(models.Model):
    branch = models.ForeignKey(Branch, on_delete=models.PROTECT, null=True, related_name="branch_allocation")
    agent = models.ForeignKey(User, on_delete=models.PROTECT, null=True, related_name='requesting_agents')
    amount = models.FloatField(default=0)
    requested_date = models.DateTimeField(auto_now_add = True, null=True, blank=True)
    approved_date = models.DateTimeField(null=True, blank=True)
    approved_by = models.ForeignKey(User, on_delete=models.PROTECT, null=True, related_name='approving_user')
    stage = models.CharField(max_length=255, default='REQUESTED')
    cash_points = models.JSONField(null=True, blank=True, default=dict)
    allocated_date = models.DateTimeField(null=True, blank=True)
    allocation_date = models.DateTimeField(null=True, blank=True)
    denominations = models.JSONField(null=True,blank=True,default=dict)
    approval_signature= models.TextField(null=True,blank=True)
    approving_manager = models.CharField(max_length=255,null=True,blank=True)
    current_company_balance = models.FloatField(default=0)
    new_company_balance = models.FloatField(default=0)
    is_approved = models.BooleanField(default=False)    
    is_credit = models.BooleanField(default=True)
    narration = models.CharField(max_length=255,null=True,blank=True)
    # change status
    
    def __str__(self):
        return f'{self.agent} - {self.amount}'
    class Meta:
        ordering = ["-id"]
        verbose_name = 'AllocationRequest'
        verbose_name_plural = 'AllocationRequests'
        
    @classmethod
    def save_allocation_request(cls,validated_data, user):
        print("REQUEST FROM : ", user)
        print("BRANCH : ", user.branch)
        try:
            credit_type = True if validated_data.get('type').lower() =='credit' else False
            cls(
                branch=user.branch, 
                agent=user,
                is_credit = credit_type, 
                amount=validated_data.get('amount'),
                narration=validated_data.get("narration"),
                requested_date=make_aware(datetime.now(), timezone=pytz.timezone(settings.TIME_ZONE)),
                stage = 'REQUESTED',
                denominations = validated_data.get('denominations'),
                approval_signature= validated_data.get("signature"),
                approving_manager = AuthorizationManagers.full_name(validated_data.get('pin')) if not credit_type else None,
                current_company_balance = sum([branch.running_balance for branch in Branch.tumai_branches()])
                ).save()
            return True
        except Exception as e:
            print(e)
            return False
        
    def acknowledge_request(self,user,data):
        if self.stage == 'REQUESTED':
            self.stage = 'ACKNOWLEDGED' if data.get('type').lower() =='approve' else 'REJECTED'
            self.cash_points = {"points":data.get('cash_points')} if data.get('cash_points') else {}
            self.approved_date = make_aware(datetime.now(), timezone=pytz.timezone(settings.TIME_ZONE))
            self.approved_by = user
            self.save()
            return True
        else:
            return False
    
    def allocate_request(self,user,data):
        if self.stage == 'ACKNOWLEDGED':
            print('Request Data',data)
            for point in data.get('cash_points'):
                branch = Branch.objects.get(id=point['branch'])
                user = branch.user_branch.first()
                print('User',user)
                AllocationRequest(
                    branch= branch, 
                    agent=branch.user_branch.first(),
                    is_credit = True, 
                    amount=point.get('amount'),
                    narration=f'From allocation id {self.id}',
                    requested_date=make_aware(datetime.now(), timezone=pytz.timezone(settings.TIME_ZONE)),
                    stage = 'DISPATCHED',
                    approved_date = make_aware(datetime.now(), timezone=pytz.timezone(settings.TIME_ZONE)),
                    approved_by = user,
                    cash_points = {'branch':branch.name,'amount':point.get('amount')},
                    allocation_date = make_aware(datetime.now(), timezone=pytz.timezone(settings.TIME_ZONE)),
                    current_company_balance = sum([branch.running_balance for branch in Branch.tumai_branches()]),
                    is_approved = True   
                    ).save()
            self.stage = 'ALLOCATED'
            self.allocation_date = make_aware(datetime.now(), timezone=pytz.timezone(settings.TIME_ZONE))
            self.save()
            return True
        else:
            return False
    
    def approve_allocation_request(self, user):
        #TO DO:  Check allocation limit against all branches 
        if self.stage != 'DISPATCHED':
            return False
        try:
            self.received_date = make_aware(datetime.now(), timezone=pytz.timezone(settings.TIME_ZONE))
            self.stage='RECEIVED'
            self.save()
            return True
        except Exception as e:
            print(e)
            return False
        
    def decline_allocation_request(self, user):
        try:
            self.stage='REJECTED'
            self.approved_date = make_aware(datetime.now(), timezone=pytz.timezone(settings.TIME_ZONE))
            self.approved_by = user
            self.is_approved = False
            self.save()
            return True
        except Exception as e:
            print(e)
            return False
    
    @classmethod
    def filter_by_branch(cls, branch):
        return cls.objects.filter(branch=branch)
        
    @classmethod
    def filter_approved_from_branch(cls, branch):
        return cls.objects.filter(branch=branch, is_approved=True)
        
    @classmethod
    def filter_by_agent(cls, agent):
        return cls.objects.filter(agent=agent)
    
    @classmethod
    def filter_requested_by_date_range(cls, start_date, end_date):
        return cls.objects.filter(requested_date__range=[start_date, end_date])
    
    @classmethod
    def filter_approved_by_date_range(cls, start_date, end_date):
        return cls.objects.filter(approved_date__range=[start_date, end_date])
    
    @classmethod
    def filter_by_amount(self, amount):
        return self.objects.filter(amount=amount)
    
    @classmethod
    def filter_by_id(self, id):
        return self.objects.filter(id=id).first()
    
    @classmethod
    def filter_by_amount_range(self, lower_limit, upper_limit):
        return self.objects.filter(amount__range=[lower_limit, upper_limit])


class DailyProcesses(models.Model):
    agent = models.ForeignKey(User, on_delete=models.PROTECT, null=False, related_name='teller_agent')
    branch = models.ForeignKey(Branch, on_delete=models.PROTECT, null=False, related_name='teller_branch') 
    check_in_time = models.DateTimeField(null=True, blank=True)
    check_out_time = models.DateTimeField(null=True, blank=True)
    opening_balance = models.FloatField(default=0)
    closing_balance = models.FloatField(default=0)
    yesterday_closing_balance = models.FloatField(default=0)
    denominations = models.JSONField(null=True,blank=True,default=dict)
    variance = models.JSONField(null=True,blank=True,default=dict)
    start_day_approved_by = models.CharField(max_length=255,null=True,blank=True)
    start_day_signature = models.TextField(null=True,blank=True)
    end_day_approved_by = models.CharField(max_length=255,null=True,blank=True)
    end_day_signature = models.TextField(null=True,blank=True)
    is_current = models.BooleanField(default=True)
    closed = models.BooleanField(default=False)
    current_company_balance = models.FloatField(default=0)
    
    def __str__(self):
        return f'{self.agent} - {self.check_in_time}'
    
    class Meta:
        ordering = ["-id"]
        verbose_name = 'Daily Process'
        verbose_name_plural = 'Daily Processes'
        
    @classmethod
    def start_day(cls, user,data):
        if not cls.objects.filter(agent=user):
            cls(agent=user, check_in_time=make_aware(datetime.now(), timezone=pytz.timezone(settings.TIME_ZONE)), branch=user.branch,
                opening_balance=user.branch.running_balance,
                denominations={"startday":data.get('denominations')},
                variance={"startday":data.get('variance')},
                yesterday_closing_balance = 0, is_current=True,
                start_day_signature=data.get('signature'),
                start_day_approved_by=AuthorizationManagers.full_name(data.get('pin'))).save() 
            return True, 'Successfully started day'
            
        # if not cls.objects.filter(agent=user, closed=True, check_in_time__date=datetime.now()).exists():
        if  cls.objects.filter(agent=user, closed=True, is_current=True):
            # cls.objects.filter(agent=user).update(**{"is_current": False})
            yesterday = cls.objects.filter(agent=user).filter(is_current=True).first()
            print("YESTERDAY : ", yesterday.closing_balance)
            cls.objects.filter(agent=user).update(is_current=False)
            cls(agent=user,  check_in_time=make_aware(datetime.now(), timezone=pytz.timezone(settings.TIME_ZONE)), branch=user.branch, opening_balance=user.branch.running_balance,
            yesterday_closing_balance = yesterday.closing_balance, 
            is_current=True,denominations={"start_day":data.get('denominations')},
            start_day_signature=data.get('signature'),
            variance={"startday":data.get('variance')},
            start_day_approved_by=AuthorizationManagers.full_name(data.get('pin'))).save()            
            return True, 'Successfully started day'
        else:
            return False, 'Day already started'

    @classmethod
    def end_day(cls,user,data):
        # if cls.objects.filter(agent=user,  check_in_time__date=datetime.now().date()).exists():  
        if cls.objects.filter(agent=user,closed=False, is_current=True).exists():  
            # day = cls.objects.filter(agent=user,is_current=True, check_in_time__date=datetime.now().date()).first()        
            day = cls.objects.filter(agent=user,is_current=True, closed=False).first()        
            if not day.check_out_time:
                day.check_out_time = make_aware(datetime.now(), timezone=pytz.timezone(settings.TIME_ZONE))
                day.closed= True
                day.closing_balance = user.branch.running_balance
                day.denominations['endday']=data.get('denominations'),
                day.end_day_signature=data.get('signature')
                day.variance["endday"]=data.get('variance')
                day.end_day_approved_by=AuthorizationManagers.full_name(data.get('pin'))
                day.save()
                return True, 'Successfully ended day'
            else:
                return False, 'Day already ended'
        else:
            return False, 'No day to end'

    @classmethod
    def get_balances(self, user):
        return self.objects.filter(agent=user).filter(is_current=True).first()


class Limits(models.Model):
    # branch = models.ForeignKey(Branch, on_delete=models.PROTECT, null=False, related_name='limits_branch')
    upper_limit = models.FloatField(default=0)
    lower_limit = models.FloatField(default=0)
    monthly_limit = models.FloatField(default=0)
    daily_limit = models.FloatField(default=0)
    is_current = models.BooleanField(default=True)
    
    def __str__(self):
        return f'Upper limit {self.upper_limit} - Lower Limit {self.lower_limit}'
    
    class Meta:
        verbose_name = 'Limit'
        verbose_name_plural = 'Limits'
        
    @classmethod
    def get_limit(cls):
        return cls.objects.filter(is_current=True).first()
    
class Charges(models.Model):
    upper_limit = models.FloatField(default=0)
    lower_limit = models.FloatField(default=0)
    charge = models.FloatField(default=0)
    charge_type = models.CharField(max_length=200)
    
    def __str__(self):
        return f'Upper limit {self.upper_limit} - Lower Limit {self.lower_limit}'
    
    class Meta:
        verbose_name = 'Charge'
        verbose_name_plural = 'Charges'
        
    @classmethod
    def get_charge(cls,amount):
        # todo::check if amount falls within upper and lower limit
        return cls.objects.filter(upper_limit=True).first()

    
class RTGSOrder(models.Model):
    # initiator
    initiator_name = models.CharField(max_length=255,blank=False,null=False)
    initiator_phone_number = models.CharField(max_length=255,blank=True,null=True)
    initiator_email = models.EmailField(blank=True, null=True)
    initiator_id_number = models.CharField(max_length=255,blank=True,null=True)
    # recipient
    student_name = models.CharField(max_length=255, null=False, blank=False) 
    student_identification_type =models.CharField(max_length=244,null=True,blank=True)
    student_phone_number = models.CharField(max_length=255, null=False, blank=False, default="26377581057") 
    student_id_number = models.CharField(max_length=255, null=False, blank=False) 
    student_number = models.CharField(max_length=255, null=True, blank=True) 
    # order details
    source = models.CharField(max_length=150, blank=True, default="Unknown")
    city = models.CharField(max_length=255, blank=True, null=True)
    amount = models.FloatField()
    rtgs = models.FloatField(blank=True, null=True)
    status = models.CharField(max_length=255,default='PENDING')
    narration = models.CharField(max_length=255)
    currency = models.CharField(max_length=255, default="")
    reference_number = models.CharField(max_length=255, unique=True)
    # timestamps
    date_created = models.DateTimeField(auto_now_add=True)
    payment_status = models.BooleanField(default=False)

    def __str__(self):
        return f'{self.reference_number} - {self.student_number}'
      
    def save(self, *args, **kwargs):
        self.last_updated = datetime.today()
        super().save(*args, **kwargs)

    class Meta:
        ordering = ['-date_created']
        verbose_name = 'RTGS Order'
        verbose_name_plural = 'RTGS Orders'   
        
class AllocationLedger(models.Model):
    allocation_line = models.FloatField(default=0)
    type = models.CharField(max_length=100,blank=True, null= True, default='Booth')
    amount = models.FloatField(default=0)
    branch = models.ForeignKey(Branch, on_delete=models.PROTECT, null=False, related_name='allocation_ledger_branch')
    status = models.BooleanField(default=False)
    agent = models.ForeignKey(User, on_delete=models.PROTECT, null=True, blank=True, related_name='allocation_ledger_agent',)
    date_created = models.DateTimeField(auto_now_add=True)    
    current_company_balance = models.FloatField(default=0)
    new_company_balance = models.FloatField(default=0)
    
    class Meta:
        verbose_name = 'Allocation Points'
        verbose_name_plural = 'Allocation Points'

