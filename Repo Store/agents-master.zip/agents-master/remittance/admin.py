from django.contrib import admin

from remittance.models import ActiveCities, Agents, AllocationRequest, CashOutlets, ConversionRate, DailyProcesses, FailedMessages, Order, Limits, Charges, RTGSOrder, SenderDetails

@admin.register(Order, AllocationRequest, DailyProcesses, Limits, Charges, ConversionRate, RTGSOrder, Agents, ActiveCities, CashOutlets,FailedMessages,SenderDetails)
class UniversalAdmin(admin.ModelAdmin):
    def get_list_display(self, request):
        return [field.name for field in self.model._meta.concrete_fields]
