from PyPDF2 import PdfFileWriter, PdfFileReader
import io
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter
from reportlab.lib.colors import HexColor

class GeneratePOPBill:
    def create_pdf(
        self,
        bill_name: str,
        account_number: str,
        account_name: str,
        currency:str,
        transaction_amount: str,
        transaction_date: str,
        transaction_reference: str,
        bank_reference: str,
        narration: str,
        ):
            packet = io.BytesIO()

            can = canvas.Canvas(packet, pagesize=letter)
            can.setFillColor(HexColor('#244c6c'))
            can.drawString(300, 541, bill_name)
            can.drawString(300, 515, account_number)
            can.drawString(300, 489, account_name)
            can.drawString(300, 461, currency+' ' + str(transaction_amount))
            can.drawString(300, 434, transaction_date)
            can.drawString(300, 407, transaction_reference)
            can.drawString(300, 380, bank_reference)
            can.drawString(300, 353, narration)
            can.save()
            import os
            packet.seek(0)
            new_pdf = PdfFileReader(packet)
            # getting the existing pdf file
            existing_pdf = PdfFileReader(
                open(f"{os.path.dirname(os.path.abspath(__file__))}/assets/original_bills.pdf", "rb")
            )
            output = PdfFileWriter()

            # add our text to the pdf
            page = existing_pdf.getPage(0)
            page.mergePage(new_pdf.getPage(0))
            output.addPage(page)
            path = f"{os.path.dirname(os.path.abspath(__file__))}/generated-pdf/{transaction_reference}.pdf"
            print(path)
            # genertate a new pdf
            outputStream = open(
                path,
                "wb",
            )
            output.write(outputStream)
            outputStream.close()

# extras = {"fullName": "Cletus Ngwerume", "naration": "true", "accountNumber": "23232322", "bank_reference": "5687912"}
# create_pdf(
#             extras["fullName"],
#             extras["accountNumber"],
#             "City Of Harare",
#             "123344",
#             "667676",
#             "0908989080989",
#             extras["bank_reference"],
#             extras["naration"]
#         )