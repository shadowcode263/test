from PyPDF2 import PdfFileWriter, PdfFileReader
import io
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter
from reportlab.lib.colors import HexColor


class GeneratePOP:
    def create_pdf(
        student_name: str,
        registration_number: str,
        school_name: str,
        year: str,
        transaction_amount: str,
        transaction_date: str,
        transaction_type: str,
        transaction_reference: str,
        transaction_purpose: str,
    ):
        packet = io.BytesIO()

        can = canvas.Canvas(packet, pagesize=letter)
        can.setFillColor(HexColor("#244c6c"))
        can.drawString(300, 541, student_name)
        can.drawString(300, 515, registration_number)
        can.drawString(300, 489, transaction_purpose)
        can.drawString(300, 461, school_name)
        can.drawString(300, 434, year)
        can.drawString(300, 407, "$" + str(transaction_amount))
        can.drawString(300, 380, transaction_date)
        can.drawString(300, 353, transaction_type)
        can.drawString(300, 326, transaction_reference)
        can.drawString(300, 299, transaction_purpose)
        can.drawString(300, 272, transaction_purpose)
        can.save()
        import os
        packet.seek(0)
        new_pdf = PdfFileReader(packet)
        # getting the existing pdf file
        existing_pdf = PdfFileReader(
            open(f"{os.path.dirname(os.path.abspath(__file__))}/assets/assets/original_fees.pdf", "rb")
        )
        output = PdfFileWriter()

        # add our text to the pdf
        page = existing_pdf.getPage(0)
        page.mergePage(new_pdf.getPage(0))
        output.addPage(page)
        path = f"{os.path.dirname(os.path.abspath(__file__))}/generated-pdf/{transaction_reference}.pdf"
        # genertate a new pdf
        outputStream = open(
            path,
            "wb",
        )
        output.write(outputStream)
        outputStream.close()

    def create_voucher_pdf(
        self,
        amount: str,
        voucher_number: str,
        transaction_reference: str,
    ):
        """Create PDF

        Args:
            amount: amount
            voucher: voucher

        """
        packet = io.BytesIO()

        can = canvas.Canvas(packet, pagesize=letter)

        # can.setFillColor("#144f5d")  #
        # can.setFont("Helvetica-Bold", 35)
        # can.drawString(40, 150, amount)

        # can.setFillColor("#144f5d")  #
        # can.setFont("Helvetica-Bold", 10)
        # can.drawString(600, 250, voucher_number)

        # voucher number
        can.setFillColor("#144f5d")  #
        can.setFont("Helvetica-Bold", 35)
        can.drawString(40, 130, amount)

        can.setFillColor("#144f5d")  #
        can.setFont("Helvetica-Bold", 10)
        can.drawString(600, 250, voucher_number)

        can.setFillColor("#144f5d")  #
        can.setFont("Helvetica-Bold", 20)
        can.drawString(320, 120, voucher_number)
        can.save()
        # end voucher number
        import os
        packet.seek(0)
        new_pdf = PdfFileReader(packet)
        # getting the existing pdf file
        existing_pdf = PdfFileReader(
            open(f"{os.path.dirname(os.path.abspath(__file__))}/assets/voucher.pdf", "rb")
        )
        output = PdfFileWriter()

        # add our text to the pdf
        page = existing_pdf.getPage(0)
        page.mergePage(new_pdf.getPage(0))
        output.addPage(page)

        # genertate a new pdf
        path = f"{os.path.dirname(os.path.abspath(__file__))}/generated-pdf/{transaction_reference}.pdf"
        # genertate a new pdf
        outputStream = open(
            path,
            "wb",
        )
        output.write(outputStream)
        outputStream.close()

        # email_controller.send_pop_as_email(transaction_reference)
    def create_voucher_gain_pdf(
        self,
        amount: str,
        voucher_number: str,
        transaction_reference: str,
    ):
        """Create PDF

        Args:
            amount: amount
            voucher: voucher

        """
        packet = io.BytesIO()

        can = canvas.Canvas(packet, pagesize=letter)

        # can.setFillColor("#144f5d")  #
        # can.setFont("Helvetica-Bold", 35)
        # can.drawString(40, 150, amount)

        # can.setFillColor("#144f5d")  #
        # can.setFont("Helvetica-Bold", 10)
        # can.drawString(600, 250, voucher_number)

        # voucher number
        can.setFillColor("#144f5d")  #
        can.setFont("Helvetica-Bold", 35)
        can.drawString(40, 130, amount)

        can.setFillColor("#144f5d")  #
        can.setFont("Helvetica-Bold", 10)
        can.drawString(600, 250, voucher_number)

        can.setFillColor("#144f5d")  #
        can.setFont("Helvetica-Bold", 20)
        can.drawString(320, 120, voucher_number)
        can.save()
        # end voucher number
        import os
        packet.seek(0)
        new_pdf = PdfFileReader(packet)
        # getting the existing pdf file
        existing_pdf = PdfFileReader(
            open(f"{os.path.dirname(os.path.abspath(__file__))}/assets/voucher_gain.pdf", "rb")
        )
        output = PdfFileWriter()

        # add our text to the pdf
        page = existing_pdf.getPage(0)
        page.mergePage(new_pdf.getPage(0))
        output.addPage(page)

        # genertate a new pdf
        path = f"{os.path.dirname(os.path.abspath(__file__))}/generated-pdf/{transaction_reference}.pdf"
        # genertate a new pdf
        outputStream = open(
            path,
            "wb",
        )
        output.write(outputStream)
        outputStream.close()

        # email_controller.send_pop_as_email(transaction_reference)