"""
    @author Marlvin Chihota
    Email marlvinchihota@gmail.com
    Created on 2021/11/28
"""
from django.db import models

"""
    COUNTRY MODEL MANAGER
"""


class CountryManager(models.Manager):

    def find_all(self):
        return self.all()


"""
    CURRENCY MODEL MANAGER
"""


class CurrencyManager(models.Manager):

    def find_all(self):
        return self.all()


"""
    PROVIDER MODEL MANAGER
"""


class ProviderManager(models.Manager):

    def find_all(self):
        return self.all()

    def find_by_name(self, name: str) -> object:
        return self.filter(name=name).first()


"""
    SYSTEM PROVIDER MANAGER
"""


class SystemProviderManager(models.Manager):

    def find_all(self):
        return self.all()

    def find_by_name(self, name: str) -> object:
        return self.filter(name=name).first()
