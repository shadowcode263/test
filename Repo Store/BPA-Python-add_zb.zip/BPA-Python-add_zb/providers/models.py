import uuid

from django.db import models

from providers.managers import SystemProviderManager, ProviderManager, CurrencyManager, CountryManager

"""
    COUNTRY MODEL
"""


class Country(models.Model):
    code = models.CharField(max_length=255, unique=True)
    name = models.CharField(max_length=255, unique=True)

    objects = CountryManager()

    class Meta:
        ordering = ['code', 'name']
        verbose_name = 'Country'
        verbose_name_plural = 'Countries'

    def __str__(self):
        return f'{self.name} - {self.code}'


"""
    CURRENCY MODEL
"""


class Currency(models.Model):
    iso_code = models.CharField(max_length=255, unique=True)
    name = models.CharField(max_length=255)

    objects = CurrencyManager()

    class Meta:
        ordering = ['name', 'iso_code']
        verbose_name = 'Currency'
        verbose_name_plural = 'Currencies'

    def __str__(self):
        return f'{self.name} - {self.iso_code}'


"""
    PROVIDER MODEL
"""


class Provider(models.Model):
    name = models.CharField(max_length=255, unique=True)
    email = models.EmailField()
    phone_number = models.CharField(max_length=255)
    api_documentation_url = models.URLField()

    objects = ProviderManager()

    class Meta:
        ordering = ['name']
        verbose_name = 'Provider'
        verbose_name_plural = 'Providers'

    def __str__(self):
        return self.name


"""
    SYSTEM PROVIDER
"""


class SystemProvider(models.Model):
    name = models.CharField(max_length=255, unique=True)
    email = models.EmailField()
    phone_number = models.CharField(max_length=255)


    objects = SystemProviderManager()

    class Meta:
        ordering = ['name']
        verbose_name = 'System Provider'
        verbose_name_plural = 'System Providers'

    def __str__(self):
        return self.name
