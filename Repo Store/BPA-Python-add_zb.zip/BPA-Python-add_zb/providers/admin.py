from django.contrib import admin

from providers.models import SystemProvider, Provider, Currency, Country

"""
    @author Marlvin Chihota
    Email marlvinchihota@gmail.com
    Created on 2021/11/28
"""

"""
    REGISTERING MODELS TO THE ADMIN 
"""


@admin.register(Country)
class CountryAdmin(admin.ModelAdmin):
    pass


@admin.register(Currency)
class CurrencyAdmin(admin.ModelAdmin):
    pass


@admin.register(Provider)
class ProviderAdmin(admin.ModelAdmin):
    pass


@admin.register(SystemProvider)
class SystemProviderAdmin(admin.ModelAdmin):
    pass
