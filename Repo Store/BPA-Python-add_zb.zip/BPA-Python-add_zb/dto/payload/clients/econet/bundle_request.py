"""
    @author Marlvin Chihota
    Email marlvinchihota@gmail.com
    Created on 2021/12/19
"""

from config import settings
from lxml import etree as et

from dto.payload.TransactionPayload import TransactionPayload
from rates.models import Rates


class BundleRequest:

    """
        ECONET BUNDLE PAYLOAD
    """

    def __init__(self, payload: TransactionPayload):
        self.username = settings.ECONET_USERNAME
        self.password = settings.ECONET_PASSWORD
        self.provider_code = '200'
        self.amount = int(payload.amount)
        self.phone = payload.target_account
        self.reference = payload.vendor_reference
        self.product_id = payload.product_id
        self.currency = payload.currency_code

    def map(self):
        root = et.Element('methodCall')

        # method name
        method_name = et.SubElement(root, 'methodName')
        method_name.text = 'load_bundle'
        params = et.SubElement(root, 'params')

        # username
        param_uv = et.SubElement(params, 'param')
        param_username = et.SubElement(param_uv, 'value')
        param_username_value = et.SubElement(param_username, 'string')
        param_username_value.text = self.username

        # password
        param_p = et.SubElement(params, 'param')
        param_password = et.SubElement(param_p, 'value')
        param_password_value = et.SubElement(param_password, 'string')
        param_password_value.text = self.password

        # data
        param_d = et.SubElement(params, 'param')
        param_data = et.SubElement(param_d, 'value')
        param_s = et.SubElement(param_data, 'struct')

        # msdin name
        m_msisdn = et.SubElement(param_s, 'member')
        m_msisdn_name = et.SubElement(m_msisdn, 'name')
        m_msisdn_name.text = 'MSISDN'
        # msdin value
        m_msisdn_name_v = et.SubElement(m_msisdn, 'value')
        m_msisdn_name_v_s = et.SubElement(m_msisdn_name_v, 'string')
        m_msisdn_name_v_s.text = self.phone

        # provider code
        m_provider = et.SubElement(param_s, 'member')
        m_provider_name = et.SubElement(m_provider, 'name')
        m_provider_name.text = 'ProviderCode'
        # amount value
        m_provider_name_v = et.SubElement(m_provider, 'value')
        m_provider_name_v_s = et.SubElement(m_provider_name_v, 'int')
        m_provider_name_v_s.text = self.provider_code

         # account transactionType name
        m_account = et.SubElement(param_s, 'member')
        m_account_name = et.SubElement(m_account, 'name')
        m_account_name.text = 'AccountType'
        # account transactionType value
        m_account_name_v = et.SubElement(m_account, 'value')
        m_account_v_s = et.SubElement(m_account_name_v, 'int')
        m_account_v_s.text = '0'

        # currency name
        m_currency = et.SubElement(param_s, 'member')
        m_m_currency_name = et.SubElement(m_currency, 'name')
        m_m_currency_name.text = 'Currency'
        # currency value
        m_currency_name_v = et.SubElement(m_currency, 'value')
        m_currency_name_v_s = et.SubElement(m_currency_name_v, 'int')
        m_currency_name_v_s.text = '932'

        # amount name
        m_amount = et.SubElement(param_s, 'member')
        m_amount_name = et.SubElement(m_amount, 'name')
        m_amount_name.text = 'Amount'
        # amount value
        m_amount_name_v = et.SubElement(m_amount, 'value')
        m_amount_name_v_s = et.SubElement(m_amount_name_v, 'int')
        # amount in cents
        m_amount_name_v_s.text = str(Rates.objects.zwl_amount(currency=self.currency, amount=self.amount) * 100)

       # product code
        m_product = et.SubElement(param_s, 'member')
        m_product_name = et.SubElement(m_product, 'name')
        m_product_name.text = 'ProductCode'
        # amount value
        m_product_name_v = et.SubElement(m_product, 'value')
        m_product_name_v_s = et.SubElement(m_product_name_v, 'string')
        m_product_name_v_s.text = self.product_id

        # reference name
        m_ref = et.SubElement(param_s, 'member')
        m_ref_name = et.SubElement(m_ref, 'name')
        m_ref_name.text = 'Reference'
        # reference value
        m_ref_name_v = et.SubElement(m_ref, 'value')
        m_ref_name_v_s = et.SubElement(m_ref_name_v, 'string')
        m_ref_name_v_s.text = self.reference

        # quantity name
        m_quantity = et.SubElement(param_s, 'member')
        m_quantity_name = et.SubElement(m_quantity, 'name')
        m_quantity_name.text = 'Quantity'
        # amount value
        m_quantity_name_v = et.SubElement(m_quantity, 'value')
        m_quantity_name_v_s = et.SubElement(m_quantity_name_v, 'int')
        m_quantity_name_v_s.text = '1'

        return et.tostring(root, pretty_print=True).decode("utf-8")
