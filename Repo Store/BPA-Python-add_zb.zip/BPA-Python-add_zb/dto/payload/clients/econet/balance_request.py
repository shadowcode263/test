"""
    @author Marlvin Chihota
    Email marlvinchihota@gmail.com
    Created on 2021/12/20
"""

from config import settings
from lxml import etree as et


class BalanceRequest:

    """
        ECONET BALANCE ENQUIRY PAYLOAD
    """

    def __init__(self):
        self.username = settings.ECONET_USERNAME
        self.password = settings.ECONET_PASSWORD

    def map(self):
        root = et.Element('methodCall')

        # method name
        method_name = et.SubElement(root, 'methodName')
        method_name.text = 'account_balance_enquiry'
        params = et.SubElement(root, 'params')

        # username
        param_uv = et.SubElement(params, 'param')
        param_username = et.SubElement(param_uv, 'value')
        param_username_value = et.SubElement(param_username, 'string')
        param_username_value.text = self.username

        # password
        param_p = et.SubElement(params, 'param')
        param_password = et.SubElement(param_p, 'value')
        param_password_value = et.SubElement(param_password, 'string')
        param_password_value.text = self.password

        return et.tostring(root, pretty_print=True).decode("utf-8")
