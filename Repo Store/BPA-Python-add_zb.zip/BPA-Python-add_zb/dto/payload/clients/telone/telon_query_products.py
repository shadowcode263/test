from dataclasses import dataclass
from django.conf import settings

@dataclass
class TeloneQueryBroadbandProductsPayload:

    """
        TELONE QUERY PRODUCTS
    """

    def __init__(self):
        self.AccountSid = settings.TELONE_ACCOUNT_SID
        self.APIKey = settings.TELONE_API_KEY