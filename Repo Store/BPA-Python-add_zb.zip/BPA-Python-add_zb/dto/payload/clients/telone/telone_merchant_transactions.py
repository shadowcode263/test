from dataclasses import dataclass
from django.conf import settings

@dataclass
class TeloneMerchantTransactionsPayload:

    """
        TELONE MERCHANT TRANSACTIONS CLASS
    """

    def __init__(self, payload: dict):
        self.AccountSid = settings.TELONE_ACCOUNT_SID
        self.APIKey = settings.TELONE_API_KEY
        self.startDate = payload['extras'].get('start_date')
        self.endDate = payload['extras'].get('end_date')