from dataclasses import dataclass
from django.conf import settings

@dataclass
class TeloneVoIPRechargePayload:

    """
        TELONE VoIP RECHARGE CLASS
    """

    def __init__(self, payload: dict):
        self.AccountSid = settings.TELONE_ACCOUNT_SID
        self.APIKey = settings.TELONE_API_KEY
        self.MerchantReference = payload.get('vendor_reference') if not settings.DEBUG else "REF1234"
        self.CustomerAccount = payload.get('target_account')
        self.VoiceAmount = payload.get('amount') 
        self.Currency = payload.get('currency_code')