from dataclasses import dataclass
from django.conf import settings


@dataclass
class TelonePurchaseBroadPayload:

    """
        TELONE PURCHASE BROADBAND CLASS
    """

    def __init__(self, payload: dict):
        self.AccountSid = settings.TELONE_ACCOUNT_SID
        self.APIKey = settings.TELONE_API_KEY
        self.MerchantReference = payload.get('vendor_reference') if not settings.DEBUG else "REF1234"
        self.OrderProducts = payload['extras'].get('order_products')
        self.Currency = payload.get('currency_code')
