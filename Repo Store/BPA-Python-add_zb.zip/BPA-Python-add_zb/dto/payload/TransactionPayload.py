"""
    @author Marlvin Chihota
    Email marlvinchihota@gmail.com
    Created on 2021/12/12
"""
from dataclasses import dataclass


@dataclass
class TransactionPayload:

    def __init__(self, payload: dict):
        for key, value in payload.items():
            setattr(self, key, value)
