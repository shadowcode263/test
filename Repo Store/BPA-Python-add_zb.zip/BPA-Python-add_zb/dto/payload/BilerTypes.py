"""
    @author Marlvin Chihota
    Email marlvinchihota@gmail.com
    Created on 2021/12/12
"""

from enum import Enum


class BillerTypes(Enum):

    """
            SYSTEM BILLER TYPES
            BillerTypes.__getitem__('econet'.lower())
    """

    econet = 'ECONET'
    netone = 'NETONE'
    telecel = 'TELECEL'
    telone = 'TELONE'
