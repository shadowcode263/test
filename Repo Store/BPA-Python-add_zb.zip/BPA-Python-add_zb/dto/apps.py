from django.apps import AppConfig


class DtoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'dto'
