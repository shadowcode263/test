"""
    @author Marlvin Chihota
    Email marlvinchihota@gmail.com
    Created on 2021/12/29
"""
from transactions.models import Transaction
import json

class TransactionResponse:
    """
        TRANSACTION RESPONSE AFTER
        COMMUNICATION WITH CLIENTS (ECONET, NETONE, TELECEL ...)
    """

    def __init__(self, transaction: Transaction):
        self.successful = transaction.is_successful
        self.biller = transaction.payload['biller_code']
        self.id = transaction.id
        self.reference =transaction.vendor_reference
        self.amount = transaction.amount
        self.vendorReference = transaction.vendor_reference
        self.mobileNumber = transaction.payload['target_account']
        self.upstreamResponseDescription = "Transaction Processed Successfully" if transaction.is_successful else "Transaction Processing Failed"
        self.responseDescription = "Transaction Processed Successfully" if transaction.is_successful else "Transaction Processing Failed"
        self.narration = "Transaction Processed Successfully" if transaction.is_successful else "Transaction Processing Failed"
        # self.payload = transaction.payload
        self.upstream_response = json.loads(transaction.response) if isinstance(transaction.response, str) else transaction.response
        self.upstream_code = transaction.response_code
        self.transaction_type = transaction.transactionType.code
        self.date_created = transaction.date_created

class BalanceResponse:
    """
        Balance RESPONSE AFTER
        COMMUNICATION WITH CLIENTS (ECONET, NETONE, TELECEL ...)
    """

    def __init__(self, transaction: Transaction):
        self.successful = transaction.is_successful
        self.id = transaction.id
        self.vendor_reference = transaction.vendor_reference
        
        self.upstream_response = json.loads(transaction.response) if isinstance(transaction.response, str) else transaction.response
        self.upstream_code = transaction.response_code
        self.transaction_type = transaction.transactionType.code
        self.date_created = transaction.date_created
