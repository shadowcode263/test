"""
    @author Marlvin Chihota
    Email marlvinchihota@gmail.com
    Created on 2021/11/28
"""
from dataclasses import dataclass


@dataclass
class ApiResponse:
    """
        BASE CLASS FOR API RESPONSES
    """

    def __init__(self, successful: bool, response: object):
        self.successful = successful
        self.response = response
