"""
    @author Marlvin Chihota
    Email marlvinchihota@gmail.com
    Created on 2021/12/19
"""
from dataclasses import dataclass


@dataclass
class TopUp:

    """
        TOPUP RESPONSE
    """

    def __init__(self, response: dict):
        self.state = response.get('state')
        self.pre_balance = response.get('pre_balance')
        self.post_balance = response.get('post_balance')
        self.validity = response.get('validity')
        self.result_code = response.get('resultcode')
        self.response_value = response.get('responseValue')
        self.comments = response.get('comments')
        self.request_cts = response.get('requestcts')
        self.response_cts = response.get('responsects')
        self.wallet_balance = response.get('walletBalance')

