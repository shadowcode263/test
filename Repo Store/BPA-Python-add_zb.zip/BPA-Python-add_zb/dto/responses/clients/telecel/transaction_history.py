"""
    @author Marlvin Chihota
    Email marlvinchihota@gmail.com
    Created on 2021/12/19
"""
from dataclasses import dataclass


@dataclass
class TransactionHistoryDetails:

    """
        TRANSACTION HISTORY ITEMS
    """

    def __init__(self, response: dict):
        self.amount = response.get('amount')
        self.vendor_trans_id = response.get('vendortransid')
        self.vendor_code = response.get('vendorcode')
        self.response_cts = response.get('responseCTS')
        self.result_code = response.get('resultcode')
        self.result_description = response.get('resultdescription')
        self.trans_id = response.get('transid')
        self.trans_type = response.get('transtype')
        self.cnt = response.get('cnt')
        self.destination = response.get('destination')


@dataclass
class TransactionHistory:

    """
        TRANSACTION HISTORY RESPONSE
    """

    def __init__(self, response: dict):
        self.record_count = response.get('recordCount')
        self.records = response.get('records')
        self.request_cts = response.get('requestcts')
        self.response_cts = response.get('responsects')
        self.result_code = response.get('resultcode')
        self.result_description = response.get('resultdescription')
        self.trans_id = response.get('transid')
        self.history = TransactionHistoryDetails(response.get('transHisDetailArray'))
