"""
    @author Marlvin Chihota
    Email marlvinchihota@gmail.com
    Created on 2021/12/19
"""
from dataclasses import dataclass


@dataclass
class WalletTransfer:

    """
        WALLET TRANSFER RESPONSE
    """

    def __init__(self, response: dict):
        self.request_cts = response.get('requestCts')
        self.response_cts = response.get('responseCts')
        self.result_code = response.get('resultCode')
        self.result_description = response.get('resultDescription')
        self.trans_id = response.get('transId')
        self.opr_wallet = response.get('oprWallet')
        self.pre_wallet_balance = response.get('prewalletBalance')
        self.wallet_balance = response.get('walletBalance')
        self.pre_opr_wallet = response.get('preoprwallet')
