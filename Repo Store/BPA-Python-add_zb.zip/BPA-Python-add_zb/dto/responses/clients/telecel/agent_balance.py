"""
    @author Marlvin Chihota
    Email marlvinchihota@gmail.com
    Created on 2021/12/19
"""
from dataclasses import dataclass


@dataclass
class AgentBalance:

    """
        AGENT BALANCE RESPONSE
    """

    def __init__(self, response: dict):
        self.response_value = response.get('responsevalue')
        self.request_cts = response.get('requestcts')
        self.response_cts = response.get('responsects')
        self.result_description = response.get('resultdescription')
        self.result_code = response.get('resultcode')
        self.trans_id = response.get('transid')
        self.amount = response.get('amount')
        self.source = response.get('source')


