"""
    @author Marlvin Chihota
    Email marlvinchihota@gmail.com
    Created on 2021/12/20
"""

from xml.dom import minidom


class BalanceResponse:

    """
        ECONET BALANCE RESPONSE

        : returns

        {
            'balance_1': [{'AccountType': '100'}, {'Currency': '840'}, {'Amount': '35186000'}],
            'balance_2': [{'AccountType': '101'}, {'Currency': '840'}, {'Amount': '35186000'}],
            'balance_3': [{'AccountType': '102'}, {'Currency': '840'}, {'Amount': '35186000'}]
          }

    """

    def __init__(self, api_response):
        # xml response
        self.raw_string = api_response
        # account balances
        self.acc1 = []
        self.acc2 = []
        self.acc3 = []
        self.list = {}

    def map(self) -> dict:
        msg = minidom.parseString(self.raw_string)
        members = msg.getElementsByTagName("member")

        for member in members:
            name = member.getElementsByTagName("name")
            amount = member.getElementsByTagName("int")

            key = name[0].firstChild.nodeValue
            value = amount[0].firstChild.nodeValue

            if len(self.acc1) != 3:
                self.list[key.lower()] = value
               
        self.acc1.append(self.list)

        return self.list
       
