"""
    @author Marlvin Chihota
    Email marlvinchihota@gmail.com
    Created on 2021/12/20
"""

from xml.dom import minidom


class TopUpResponse:
    """
        ECONET TOPUP RESPONSE

        : returns

        [
          {'name': 'Status', 'code': '1'},
          {'name': 'StatusCode', 'code': '0'},
          {'name': 'Serial', 'value': '8509-0596-07A3-A6CF'},
          {'name': 'ProviderReference', 'value': '263775580596'},
          {'name': 'Description', 'value': 'OK'}
        ]

    """

    def __init__(self, api_response):
        # xml response
        self.raw_string = api_response
        # response
        self.response = []

    def map(self) -> list:
        try:
            msg = minidom.parseString(self.raw_string)
            members = msg.getElementsByTagName("member")

            for member in members:
                name = member.getElementsByTagName("name")
                code = member.getElementsByTagName("int")
                value = member.getElementsByTagName("value")

                if code:
                    self.response.append({
                        'name': name[0].firstChild.nodeValue,
                        'code': code[0].firstChild.nodeValue
                    })
                else:
                    self.response.append({
                        'name': name[0].firstChild.nodeValue,
                        'value': value[0].firstChild.nodeValue
                    })
        except:
            self.response.append({
                'name': 'NONE',
                'value': 'NONE'
            })
        return self.response

    @classmethod
    def sort(cls, data: list):

        sorted_data = {
            'status_code': None,
            'reference': None,
            'description': None
        }

        for item in data:

            # status code
            if item.get('name') == 'StatusCode':
                sorted_data['status_code'] = item.get('code')

            # reference
            elif item.get('name') == 'Serial':
                sorted_data['reference'] = item.get('value')

            # description
            elif item.get('name') == 'Description':
                sorted_data['description'] = item.get('value')

        return sorted_data
