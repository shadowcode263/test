from dataclasses import dataclass
from django.conf import settings

@dataclass
class TeloneRechargeAdslResponse:

    """
        TELONE RECHARGE ADSL CLASS
    """

    def __init__(self, response: dict):
        self.reply_code = response.get('ResponseCode')
        self.reply_msg = response.get('ResponseDescription')
        self.merchant_ref = response.get('MerchantReference')
        self.order_number = response.get('OrderNumer')
        self.vouchers = response.get('Voucher')



