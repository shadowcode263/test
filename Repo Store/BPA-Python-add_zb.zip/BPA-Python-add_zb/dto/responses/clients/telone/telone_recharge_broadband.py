"""
    @author Takudzwa Sharara
    Email shararagarnet@gmail.com
    Created on 2022/01/31
"""

from dataclasses import dataclass


@dataclass
class TelonePurchaseBroadBand:

    """
        PURCHASE TELONE BROADBAND RESPONSE
    """

    def __init__(self, response: dict):
        self.reply_code = response.get('ResponseCode')
        self.reply_msg = response.get('ResponseDescription')
        self.merchant_ref = response.get('MerchantReference')
        self.order_number = response.get('OrderNumer')
        self.vouchers = response.get('Vouchers')
        self.final_balance = response.get('FinalBalance')
        self.recharge_id = response.get('RechargeID')


