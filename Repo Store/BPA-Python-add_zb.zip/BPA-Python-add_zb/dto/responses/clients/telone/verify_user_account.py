"""
    @author Takudzwa Sharara
    Email shararagarnet@gmail.com
    Created on 2022/01/31
"""

from dataclasses import dataclass


@dataclass
class VerifyUserAccountResponse:
    """
        VERIFY USER ACCOUNT RESPONSE
    {
        "AccountNumber": "0242576644",
        "CustomerName": "DANIEL CHAMUNORWA",
        "AccountAddress": null,
        "message": "Successful!"
    }

    """

    def __init__(self, response: dict):
        self.account_number = response.get('AccountNumber')
        self.customer_name = response.get('CustomerName')
        self.customer_address = response.get('AccountAddress')
        self.reply_msg = response.get('message')



