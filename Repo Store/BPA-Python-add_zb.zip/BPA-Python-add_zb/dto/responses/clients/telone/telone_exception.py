"""
    @author Takudzwa Sharara
    Email shararagarnet@gmail.com@gmail.com
    Created on 2022/01/31
"""
from dataclasses import dataclass


@dataclass
class TelOneException:

    """
        TELONE EXCEPTION RESPONSE
    """

    def __init__(self, response: dict):
        self.reply_code = 400 
        self.reply_msg = "Processing request!"
