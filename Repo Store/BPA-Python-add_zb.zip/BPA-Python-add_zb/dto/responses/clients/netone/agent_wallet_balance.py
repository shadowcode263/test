"""
    @author Marlvin Chihota
    Email marlvinchihota@gmail.com
    Created on 2021/12/13
"""

from dataclasses import dataclass


@dataclass
class AgentWalletBalance:

    """
        AGENT WALLET BALANCE RESPONSE
    """

    def __init__(self, response: dict):
        self.currency = "ZWL"
        self.account_type = '932'
        self.amount = response.get('WalletBalance')
