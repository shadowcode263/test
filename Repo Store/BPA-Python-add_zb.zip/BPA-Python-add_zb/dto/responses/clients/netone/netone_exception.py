"""
    @author Marlvin Chihota
    Email marlvinchihota@gmail.com
    Created on 2021/12/19
"""
from dataclasses import dataclass
from services.clients.utils.netone import error_codes


@dataclass
class NetOneException:

    """
        NETONE EXCEPTION RESPONSE
    """

    def __init__(self, response: dict):
        self.reply_code = response.get('ReplyCode')
        self.reply_msg = error_codes[response.get('ReplyCode')]
