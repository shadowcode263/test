"""
    @author Marlvin Chihota
    Email marlvinchihota@gmail.com
    Created on 2021/12/13
"""

from dataclasses import dataclass


@dataclass
class QueryTransactionRecon:

    """
        QUERY TRANSACTION STATUS RESPONSE
    """

    def __init__(self, response: dict):
        self.reply_code = response.get('ReplyCode')
        self.reply_msg = response.get('ReplyMsg')
        self.original_vendor_reference = response.get('OriginalAgentReference')
        self.raw_reply = response.get('RawReply')
