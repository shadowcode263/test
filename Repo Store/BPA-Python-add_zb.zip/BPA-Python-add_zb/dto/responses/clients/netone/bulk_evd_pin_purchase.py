"""
    @author Marlvin Chihota
    Email marlvinchihota@gmail.com
    Created on 2021/12/13
"""

from dataclasses import dataclass


@dataclass
class BulkEVDPinPurchase:

    """
        BULK EVD PIN PURCHASE RESPONSE
    """

    def __init__(self, response: dict):
        self.reply_code = response.get('ReplyCode')
        self.reply_msg = response.get('ReplyMsg')
        self.wallet_balance = response.get('WalletBalance')
        self.amount = response.get('Amount')
        self.initial_balance = response.get('InitialBalance')
        self.final_balance = response.get('FinalBalance')
        self.recharge_id = response.get('RechargeID')
        self.pins = response.get('Collection of PINs')
