"""
    @author Marlvin Chihota
    Email marlvinchihota@gmail.com
    Created on 2021/12/13
"""

from dataclasses import dataclass


@dataclass
class QueryEVD:

    """
        QUERY EVD RESPONSE
    """

    def __init__(self, response: dict):
        self.reply_code = response.get('ReplyCode')
        self.reply_msg = response.get('ReplyMsg')
        self.in_stock = response.get('InStock')
