"""
  @author Marlvin Chihota
  Email marlvinchihota@gmail.com
  Created on 11/1/2022
"""
from dataclasses import dataclass


@dataclass
class LoginResponse:
    """
        LOGIN RESPONSE CLASS
    """

    def __init__(self,
                 user: object,
                 vendor: object,
                 access: str,
                 refresh: str):
        self.successful = True
        self.response = {
            'access': access,
            'refresh': refresh,
            'username': user.username,
            'email': user.email,
            'first_name': user.first_name,
            'last_name': user.last_name,
            'role': user.role,
            'is_locked': user.is_locked,
            'vendor': {} if not vendor else {
                'api-password': vendor.api_password,
                'api-username': vendor.api_username,
                'key': vendor.api_key
            }
        }
