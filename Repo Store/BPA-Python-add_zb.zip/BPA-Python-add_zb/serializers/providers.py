"""
    @author Marlvin Chihota
    Email marlvinchihota@gmail.com
    Created on 2021/12/07
"""
from rest_framework import serializers

from providers.models import SystemProvider, Provider, Currency, Country


class CountrySerializer(serializers.ModelSerializer):
    """
        COUNTRY SERIALIZER
    """

    class Meta:
        model = Country
        exclude = ['id']


class CurrencySerializer(serializers.ModelSerializer):
    """
        CURRENCY SERIALIZER
    """

    class Meta:
        model = Currency
        exclude = ['id']


class ProviderSerializer(serializers.ModelSerializer):
    """
        PROVIDER SERIALIZER
    """

    class Meta:
        model = Provider
        fields = ()
        exclude = ['id']


class SystemProviderSerializer(serializers.ModelSerializer):
    """
        SYSTEM PROVIDER SERIALIZER
    """

    class Meta:
        model = SystemProvider
        exclude = ['id']

