"""
    @author Marlvin Chihota
    Email marlvinchihota@gmail.com
    Created on 2021/12/03
"""

from rest_framework import serializers


class AuthSerializer(serializers.Serializer):
    password = serializers.CharField(required=True, max_length=255, label='vendorReference')
    username = serializers.CharField(required=True, max_length=255, label='vendorReference')
    key = serializers.CharField(required=True, max_length=255, label='vendorReference')

    """
        VENDOR AUTH SERIALIZER
        
        {
            'api-password' : 'str',
            'api-username' : 'str',
            'key' :'str'
        }
        
    """

    def create(self, validated_data):
        return AuthSerializer(**validated_data)
