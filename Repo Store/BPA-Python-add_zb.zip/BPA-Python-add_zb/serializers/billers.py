"""
    @author Marlvin Chihota
    Email marlvinchihota@gmail.com
    Created on 2021/12/07
"""
from rest_framework import serializers
from rest_framework.fields import ReadOnlyField

from billers.models import Biller


class BillersSerializer(serializers.ModelSerializer):

    """
        BILLERS SERIALIZER
    """

    class Meta:
        model = Biller
        fields = ('name', 'biller_code')
