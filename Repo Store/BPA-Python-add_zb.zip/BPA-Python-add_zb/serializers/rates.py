"""
    @author Marlvin Chihota
    Email marlvinchihota@gmail.com
    Created on 2021/12/07
"""
from rest_framework import serializers

from rates.models import Rates


class RatesSerializer(serializers.ModelSerializer):

    """
        Exchange Rates Serializer
    """

    class Meta:
        model = Rates
        exclude = ['id']


class RatesUpdateSerializer(serializers.Serializer):

    """
        UPDATE SYSTEM EXCHANGE RATES
    """

    usd = serializers.FloatField(required=True, label='USD TO ZWL')
    zar = serializers.FloatField(required=True, label='ZAR TO ZWL')

    def create(self, validated_data):
        return RatesUpdateSerializer(**validated_data)


