"""
    @author Marlvin Chihota
    Email marlvinchihota@gmail.com
    Created on 2021/12/01
"""

from rest_framework import serializers
from rest_framework.fields import ReadOnlyField

from vendors.models import Vendor, VendorProfile


class VendorCreationSerializer(serializers.Serializer):
    """
         VENDOR CREATION SERIALIZER

        {
            'company_name'       : 'str',
            'email'              : 'str',
            'username'           : 'str',
            'first_name'         : 'str',
            'last_name'          : 'str',
            'password'           : 'str',
            'contact_email'      : 'str'
        }

    """

    # vendor details
    company_name = serializers.CharField(required=True, max_length=255, label='Company Name')
    email = serializers.EmailField(required=True, max_length=255, label='Email')

    # user details
    username = serializers.CharField(required=True, max_length=255, min_length=3, label='Username')
    first_name = serializers.CharField(required=True, max_length=255, label='First Name')
    last_name = serializers.CharField(required=True, max_length=255, label='Last Name')
    password = serializers.CharField(required=True, max_length=255, min_length=8, label='Password')
    contact_email = serializers.EmailField(required=True, label='Contact Email')

    def create(self, validated_data):
        return VendorCreationSerializer(**validated_data)


class VendorSerializer(serializers.ModelSerializer):
    """
        VENDOR SERIALIZER
    """

    providerName = ReadOnlyField(source='provider.name')
    companyName = ReadOnlyField(source='company_name')

    contactFirstName = ReadOnlyField(source='user.first_name')
    contactLastName = ReadOnlyField(source='user.last_name')
    contactEmail = ReadOnlyField(source='user.email')

    hasConfirmedEmail = ReadOnlyField(source='has_confirmed_email')
    isActive = ReadOnlyField(source='is_active')

    class Meta:
        model = Vendor
        fields = ('id', 'email', 'providerName', 'companyName',
                  'contactFirstName', 'contactLastName', 'contactEmail',
                  'hasConfirmedEmail', 'isActive')


class VendorProfileSerializer(serializers.ModelSerializer):
    """
        VENDOR PROFILE SERIALIZER
    """

    companyName = ReadOnlyField(source='vendor.company_name')
    vendorId = ReadOnlyField(source='vendor.id')

    class Meta:
        model = VendorProfile
        fields = ('id', 'vendorId', 'companyName',
                  'mode', 'permissions', 'currency', 'balance')


class VendorPermissionSerializer(serializers.Serializer):
    """
        VENDOR DISBALING / ENABLING
    """

    vendorId = serializers.UUIDField(required=True, label='Vendor Id')
    isActive = serializers.BooleanField(required=True, label='Is Active')

    def create(self, validated_data):
        return VendorPermissionSerializer(**validated_data)


class VendorBalanceSerializer(serializers.Serializer):
    """
        VENDOR BALANCE UPDATING SERIALIZER
    """

    profileId = serializers.UUIDField(required=True, label='Profile ID')
    balance = serializers.FloatField(required=True, label='Balance')
    mode = serializers.CharField(required=True, max_length=20, label='Mode')

    def create(self, validated_data):
        return VendorBalanceSerializer(**validated_data)


class VendorPermissionsSerializer(serializers.Serializer):
    """
        VENDOR PERMISSIONS SERIALIZER

        {
            'vendorId' : 'str',
            'permissions' : 'list',
            'isNewProfile' : 'bool',
            'profile': {
                'balance' : 'float',
                'mode' : 'str',
                'id' : 'str'
            }
        }

    """

    vendorId = serializers.UUIDField(required=True, label='Vendor ID')
    permissions = serializers.JSONField(required=True, label='Permissions')
    isNewProfile = serializers.BooleanField(required=True, label='Is New Profile')
    profile = serializers.JSONField(required=True, label='Profile')

    def create(self, validated_data):
        return VendorPermissionsSerializer(**validated_data)
