"""
    @author Marlvin Chihota
    Email marlvinchihota@gmail.com
    Created on 2022/01/08
"""

from rest_framework import serializers
from rest_framework.fields import ReadOnlyField

from users.models import User


class UserCreationSerializer(serializers.Serializer):
    """
        USER CREATION SERIALIZER
    """

    username = serializers.CharField(required=True, min_length=3, max_length=255, label='Username')
    email = serializers.EmailField(required=True, max_length=255, label='Email')
    first_name = serializers.CharField(required=True, min_length=2, max_length=255, label='First Name')
    last_name = serializers.CharField(required=True, min_length=2, max_length=255, label='Last Name')
    password = serializers.CharField(required=True, min_length=5, max_length=255, label='Password')

    def create(self, validated_data):
        return UserCreationSerializer(**validated_data)


class UserSerializer(serializers.ModelSerializer):
    """
        USER SERIALIZER
    """

    firstName = ReadOnlyField(source='first_name')
    lastName = ReadOnlyField(source='last_name')
    passwordRetry = ReadOnlyField(source='password_retry_chances')
    isLocked = ReadOnlyField(source='is_locked')
    hasResetPassword = ReadOnlyField(source='has_reset_password')

    class Meta:
        model = User
        fields = ('username', 'email', 'firstName', 'lastName',
                  'role', 'passwordRetry', 'isLocked', 'hasResetPassword')


class UserAuthSerializer(serializers.Serializer):
    """
        AUTHENTICATION SERIALIZER
    """

    username = serializers.CharField(required=True, min_length=3, max_length=255, label='Username')
    password = serializers.CharField(required=True, min_length=5, max_length=255, label='Password')

    def create(self, validated_data):
        return UserAuthSerializer(**validated_data)


class UserVerificationSerializer(serializers.Serializer):
    target_account = serializers.CharField(max_length=150, required=True)
    biller_code = serializers.CharField(required=True, max_length=20, label='Biller Id')
    provider = serializers.CharField(required=False, max_length=20, label='Provider')


    def create(self, validated_data):
        return UserVerificationSerializer(**validated_data)
