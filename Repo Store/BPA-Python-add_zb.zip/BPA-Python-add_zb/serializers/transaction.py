"""
    @author Marlvin Chihota
    Email marlvinchihota@gmail.com
    Created on 2021/12/03
"""

from billers.models import Biller
from products.models import Product
from rest_framework import serializers
import django_filters
from rest_framework.fields import ReadOnlyField

from transactions.models import TransactionType, Transaction


class SchoolFeesSerializer(serializers.Serializer):
    purpose = serializers.CharField(required=True, label='purpose', max_length=255)
    semester = serializers.CharField(required=True,label='semester', max_length=255)
    full_name = serializers.CharField(required=True, label='full_name', max_length=255)

class BillerExtrasSerializer(serializers.Serializer):
    full_name = serializers.CharField(required=True, label='full_name', max_length=255)

class DSTVSerializer(serializers.Serializer):
    bouquet = serializers.CharField(required=True, label='full_name', max_length=255)
    addons = serializers.CharField(label='phone_number', max_length=255)
    full_name = serializers.CharField(required=True, label='full_name', max_length=255)

class VoucherSerializer(serializers.Serializer):
    recipient_first_name = serializers.CharField(required=True, label='recipient_first_name', max_length=255)
    recipient_last_name = serializers.CharField(required=True,label='recipient_last_name', max_length=255)
    recipient_national_id = serializers.CharField(required=True,label='recipient_id', max_length=255)
    recipient_phone_number = serializers.CharField(required=True,label='recipient_phone_number', max_length=255)



class PostTransactionSerializer(serializers.Serializer):
    """
        POST TRANSACTION SERIALIZER

        {
            'vendorReference'           :  'str',
            'billerCode'                    :  'str' -> ECONET,
            'transactionType'                      :  '' -> ECONET_AIRTIME_TOPUP,
            'targetAccount'              :  'str',
            'amount'                    :  'double',
            'currencyCode'              :  'str'
            'extras'                    '  'json'
               -> 'extras' :
               {
               'billerProduct' : 'str',
               'brandId' : int
               'quantity' : int,

               'count' : int,
               'fromDate' : 'date str'
               'toDate' : 'date str'
               }
         }

    """

    vendor_reference = serializers.CharField(required=True, max_length=255, label='Vendor Reference')
    biller_code = serializers.CharField(required=True, max_length=20, label='Biller Code')
    transaction_type = serializers.CharField(required=True, max_length=255, label='Transaction Type')
    target_account = serializers.CharField(required=True, max_length=30, label='Target Account')
    amount = serializers.FloatField(required=True, label='Amount')
    currency_code = serializers.CharField(required=True, max_length=5, label='Currency Code')
    product_id = serializers.CharField(required=False, max_length=12, label='Product Id')
    extras = serializers.JSONField(required=False, label='Extras')

    def create(self, validated_data):
        return PostTransactionSerializer(**validated_data)
    
    def validate(self, attrs):
        biller = Biller.objects.filter(biller_code=attrs['biller_code'].upper()).first()
        if biller is None:
            raise serializers.ValidationError({"biller_code": 'Invalid Biller Code'})
        if biller.transaction_type.code == '002':
            validate_extra = SchoolFeesSerializer(data=attrs['extras'])
            if validate_extra.is_valid():
                return super().validate(attrs)
            else:
                raise serializers.ValidationError({"extras": validate_extra.errors})
        elif biller.transaction_type.code == '007' or biller.transaction_type.code=='003':
            validate_extra = BillerExtrasSerializer(data=attrs['extras'])
            if validate_extra.is_valid():
                return super().validate(attrs)
            else:
                raise serializers.ValidationError({"extras": validate_extra.errors})
        elif biller.transaction_type.code == '005' :
            validate_extra = DSTVSerializer(data=attrs['extras'])
            if validate_extra.is_valid():
                product = Product.objects.filter(code=attrs['extras']['bouquet']).first()
                if product is None:
                    raise serializers.ValidationError({"extras": "Invalid Bouquet"})
                return super().validate(attrs)
            else:
                raise serializers.ValidationError({"extras": validate_extra.errors})
        elif biller.transaction_type.code == '004' :
            validate_extra = VoucherSerializer(data=attrs['extras'])
            if validate_extra.is_valid():
                return super().validate(attrs)
            else:
                raise serializers.ValidationError({"extras": validate_extra.errors})

        return super().validate(attrs)
      


class TransactionTypeSerializer(serializers.ModelSerializer):
    """
        TRANSACTION TYPE SERIALIZER
    """

    full_name = ReadOnlyField(source='get_name_display')

    class Meta:
        model = TransactionType
        fields = ('code', 'full_name')



class TransactionsSerializer(serializers.ModelSerializer):
    """
        VENDOR TRANSACTIONS SERIALIZER
    """

    transaction_type = ReadOnlyField(source='transaction_type.code')

    vendor_name = ReadOnlyField(source='vendor.company_name')
    vendor_provider = ReadOnlyField(source='vendor.provider.name')

    vendor_reference = ReadOnlyField(source='vendor_reference')
    debit_reference = ReadOnlyField(source='debit_reference')
    is_successful = ReadOnlyField(source='is_successful')
    is_reversed = ReadOnlyField(source='is_reversed')

    response_code = ReadOnlyField(source='response_code')
    response_description = ReadOnlyField(source='response_description')

    date_created = ReadOnlyField(source='date_created')
    date_modified = ReadOnlyField(source='date_modified')

    class Meta:
        model = Transaction
        fields = ('id', 'vendor_provider', 'debit_reference',
                  'transaction_type', 'vendor_reference', 'vendor_name',
                  'amount', 'quantity', 'currencyCode', 'status',
                  'is_successful', 'is_reversed',
                  'response_code', 'response_description', 'payload', 'response',
                  'date_created', 'date_modified'
                  )


class VendorTransactionFilterSerializer(django_filters.FilterSet):
    transaction_type = django_filters.CharFilter(field_name='transaction_type.name', lookup_expr='icontains')
    currency = django_filters.CharFilter(field_name='currency', lookup_expr='icontains')
    biller = django_filters.CharFilter(field_name='transaction_type.biller.name', lookup_expr='icontains')
    status = django_filters.CharFilter(field_name='status', lookup_expr='icontains')
    from_date = django_filters.DateFilter(field_name='date_created', lookup_expr='gte')
    to_date = django_filters.DateFilter(field_name='date_created', lookup_expr='lte')

    class Meta:
        model = Transaction
        fields = ('transaction_type', 'currency', 'biller', 'status', 'from_date', 'to_date')


class AdminTransactionFilterSerializer(django_filters.FilterSet):
    vendor_id = django_filters.UUIDFilter(field_name='vendor__id', lookup_expr='exact')
    transaction_type = django_filters.CharFilter(field_name='type__name', lookup_expr='icontains')
    currency = django_filters.CharFilter(field_name='currency', lookup_expr='icontains')
    biller = django_filters.CharFilter(field_name='type__biller__name', lookup_expr='icontains')
    status = django_filters.CharFilter(field_name='status', lookup_expr='icontains')
    from_date = django_filters.DateFilter(field_name='date_created', lookup_expr='gte')
    to_date = django_filters.DateFilter(field_name='date_created', lookup_expr='lte')

    class Meta:
        model = Transaction
        fields = ('vendor_id', 'transaction_type', 'currency', 'biller', 'status', 'from_date', 'to_date')







class AdminOverviewTransactionsSerializer(serializers.ModelSerializer):
    """
        VENDOR TRANSACTIONS SERIALIZER
    """

    transaction_type = ReadOnlyField(source='transaction_type.code')

    vendor_name = ReadOnlyField(source='vendor.company_name')
    vendor_provider = ReadOnlyField(source='vendor.provider.name')

    class Meta:
        model = Transaction
        fields = ('id', 'vendor_provider', 'debit_reference',
                  'transaction_type', 'vendor_reference', 'vendor_name',
                  'amount', 'quantity', 'currencyCode', 'status',
                  'is_successful', 'is_reversed',
                  'response_code', 'response_description', 'payload', 'response',
                  'date_created', 'date_modified'
                  )

class DashboardTransactionFilterSerializer(django_filters.FilterSet):
    transaction_type = django_filters.CharFilter(field_name='transaction_type.name', lookup_expr='icontains')
    transaction_biller = django_filters.CharFilter(field_name='transaction_biller', lookup_expr='exact')
    to_date = django_filters.DateFilter(field_name='date_created', lookup_expr='lte')
    amount = django_filters.CharFilter(field_name='amount', lookup_expr='exact')
    currencyCode = django_filters.CharFilter(field_name='currencyCode', lookup_expr='exact')

    class Meta:
        model = Transaction
        fields = ('id','transaction_type', 'vendor_reference',
                  'amount', 'quantity', 'currencyCode', 'status',
                  'is_successful', 'is_reversed', 'transaction_biller',
                  'response_code', 'date_created', 'date_modified'
                  )