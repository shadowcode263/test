"""
    @author Marlvin Chihota
    Email marlvinchihota@gmail.com
    Created on 2021/12/07
"""
from rest_framework import serializers
from rest_framework.fields import ReadOnlyField

from products.models import Product


class ProductsSerializer(serializers.ModelSerializer):

    billerName = ReadOnlyField(source='transactionType.billerCode.name')
    providerName = ReadOnlyField(source='transactionType.billerCode.provider.name')
    transactionType = ReadOnlyField(source='transactionType.name')

    class Meta:
        model = Product
        fields = ('billerName', 'providerName', 'transactionType',
                  'code', 'name', 'price', 'currency')
