"""
    @author Takudzwa Sharara
    Email shararagarnet@gmail.com
    Created on 2021/11/28
"""
from django.urls import path
from django.views.decorators.csrf import csrf_exempt
from rest_framework_simplejwt.views import TokenRefreshView

from api.views.billers.views import ViewBillers, ViewProviderBillers
from api.views.vendor.views import VendorRegistration, VendorVerification, ViewVendorProfiles, \
    UpdateVendorBalance, UpdateVendorStatus, VendorPermissions, ViewVendors, ViewVendorProfiles
from api.views.products.views import ViewProducts, ViewProviderProducts
from api.views.providers.views import ViewCountries, ViewCurrencies, ViewSystemProviders, ViewProviders
from api.views.rates.views import ViewRates, UpdateRates
from api.views.transactions.views import GetTeloneBroadbandProducts, ViewTransactionTypes, PostTransaction, ViewVendorTransactions, \
    ViewAdminTransactions, FilterAdminTransactions, FilterVendorTransactions, VerifyCustomerDetails, FilterDashboardTransactions
from api.views.users.views import ViewUsers, RegisterAdmin, Login
from services.decorators.security.authentication_required import authentication_required

# todo : change password
# todo : reset password
# todo : on vendor balance update , add currencies
# todo :exception handling on clients (for non 200 responses & when they're down)
# todo : pending migration

urlpatterns = [
    # API AUTH
    path('profile/login/', Login.as_view(), name='login'),
    path('profile/refresh/', TokenRefreshView.as_view(), name='refresh'),

    # VENDOR ROUTES
    path('back-office/vendor/register/', csrf_exempt(VendorRegistration.as_view())),
    path('back-office/vendor/confirm-email/<str:vendor_id>/', VendorVerification.as_view()),
    path('vendor/profiles/', authentication_required(ViewVendorProfiles.as_view())),

    # TRANSACTIONS
    path('transactions/transaction-types/', ViewTransactionTypes.as_view()),
    path('transactions/billers/', ViewBillers.as_view()),
    path('transactions/billers/provider/<str:name>/', ViewProviderBillers.as_view()),

    path('transactions/vendor/', authentication_required(ViewVendorTransactions.as_view())),
    path('transactions/admin/', ViewAdminTransactions.as_view()),

    # url scheme -> transactions/vendor/filter/?status=successful
    path('transactions/vendor/filter/', FilterVendorTransactions.as_view()),
    path('transactions/admin/filter/', FilterAdminTransactions.as_view()),
    path('transactions/dashboard/filter/', FilterDashboardTransactions.as_view()),
    path('transactions/post/', csrf_exempt(authentication_required(PostTransaction.as_view()))),

    # ADMIN
    path('back-office/admin/register/', csrf_exempt(RegisterAdmin.as_view())),
    path('back-office/admin/users/', ViewUsers.as_view()),
    path('back-office/admin/vendor/', ViewVendors.as_view()),

    path('back-office/vendor/profile/<str:id>/', csrf_exempt(ViewVendorProfiles.as_view())),
    path('back-office/vendor/balance/', csrf_exempt(UpdateVendorBalance.as_view())),
    path('back-office/vendor/status/', csrf_exempt(UpdateVendorStatus.as_view())),
    path('back-office/vendor/permissions/', csrf_exempt(VendorPermissions.as_view())),

    # PRODUCTS
    path('products/billerCode/<str:name>/', ViewProducts.as_view()),  # changed name
    path('products/provider/<str:name>/', ViewProviderProducts.as_view()),
    path('products/telone/products/', authentication_required(GetTeloneBroadbandProducts.as_view())),

    # EXCHANGE RATES
    path('exchange-rates/', ViewRates.as_view()),
    path('exchange-rates/update/', csrf_exempt(UpdateRates.as_view())),

    # PROVIDERS
    path('providers/countries/', ViewCountries.as_view()),
    path('providers/currencies/', ViewCurrencies.as_view()),
    path('providers/system/', ViewSystemProviders.as_view()),
    path('providers/external/', ViewProviders.as_view()),

    # CUSTOMER VERIFICATION
    path('verify/customer/', csrf_exempt(authentication_required(VerifyCustomerDetails.as_view())))

]



# from permissions.models import VendorPermission
# from vendors.models import VendorProfile, Vendor
# from users.models import User

# v = Vendor.objects.all()
# vp = VendorProfile(vendor=v[1])
# vp.save()
# user = VendorProfile.objects.all()[0]

# for perm in VendorPermission.objects.all():
#     print(VendorProfile.objects.all(), '::::::::::::',  VendorPermission.objects.all())
#     user.permissions.add(perm)
#     user.save()
#     print(perm, User.objects.first())
