"""
    @author Marlvin Chihota
    Email marlvinchihota@gmail.com
    Created on 2022/01/08
"""
import json

from django.http import JsonResponse
from rest_framework import generics, status
from rest_framework.parsers import JSONParser
from rest_framework.permissions import IsAuthenticated
from rest_framework.renderers import JSONRenderer
from rest_framework.views import APIView

from dto.responses.api_response import ApiResponse
from serializers.users import UserSerializer, UserCreationSerializer, UserAuthSerializer
from services.users.UserLoginService import UserLoginService
from services.users.UserRegistrationService import UserRegistrationService
from services.utils.Logger import Logger
from services.utils.Utils import Utils
from users.models import User


class ViewUsers(generics.ListAPIView):
    """
        VIEW ADMIN USERS
    """

    renderer_classes = [JSONRenderer]
    permission_classes = (IsAuthenticated,)

    serializer_class = UserSerializer
    queryset = User.objects.find_users_by_role(role='ADMIN')


class RegisterAdmin(APIView):
    """
        ADMIN REGISTRATION VIEW
    """

    serializer_class = UserCreationSerializer
    parser_classes = [JSONParser]
    renderer_classes = [JSONRenderer]
    permission_classes = (IsAuthenticated,)

    def post(self, request):

        try:
            # Admin registration request body
            data = json.loads(request.body)

            """
                Logger
            """
            Logger.output(description='Admin Registration Payload', payload=data)

            # validation
            serializer = UserCreationSerializer(data=data)

            if serializer.is_valid():
                # register admin
                service = UserRegistrationService(payload=serializer.data, request=request)
                return service.register()
            else:
                """
                    Validation errors
                """
                response = ApiResponse(False, {'errors': serializer.errors})
                return JsonResponse(status=status.HTTP_406_NOT_ACCEPTABLE, data=response.__dict__)
        except Exception as e:
            """
                Error Log
            """
            Logger.output(description='Admin Registration Exception',
                          payload={'Exception': e})
            # response
            response = ApiResponse(successful=False, response=Utils.get_messages().__dict__.get('invalid_data'))
            return JsonResponse(status=status.HTTP_400_BAD_REQUEST, data=response.__dict__)


class Login(APIView):
    """
        LOGIN VIEW
    """

    serializer_class = UserAuthSerializer
    parser_classes = [JSONParser]
    renderer_classes = [JSONRenderer]

    def post(self, request):

        try:
            # login payload
            data = json.loads(request.body)
            """
                Logger
            """
            Logger.output(description='Login Payload', payload=data)

            # validation
            serializer = UserAuthSerializer(data=data)

            if serializer.is_valid():
                payload = serializer.data
                # find user with username
                user = User.objects.find_by_username(payload.get('username'))
                # user exists
                if user:
                    service = UserLoginService(payload=payload, user=user)
                    return service.authenticate()
                # user doesn't exist
                else:
                    response = ApiResponse(False, {'errors': Utils.get_messages().invalid_username})
                    return JsonResponse(status=status.HTTP_401_UNAUTHORIZED, data=response.__dict__)
            else:
                """
                    Validation errors
                """
                response = ApiResponse(False, {'errors': serializer.errors})
                return JsonResponse(status=status.HTTP_406_NOT_ACCEPTABLE, data=response.__dict__)

        except Exception as e:
            """
                Error Log
            """
            Logger.output(description='Login Exception',
                          payload={'Exception': e})
            # response
            response = ApiResponse(successful=False, response=Utils.get_messages().__dict__.get('invalid_data'))
            return JsonResponse(status=status.HTTP_400_BAD_REQUEST, data=response.__dict__)
