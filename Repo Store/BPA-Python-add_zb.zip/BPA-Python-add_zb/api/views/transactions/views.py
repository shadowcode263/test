"""
    @author Marlvin Chihota
    Email marlvinchihota@gmail.com
    Created on 2021/12/07
"""
import json
import traceback
import requests
from django.http import JsonResponse
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework import generics, status
from rest_framework.parsers import JSONParser
from rest_framework.permissions import IsAuthenticated
from rest_framework.renderers import JSONRenderer
from rest_framework.views import APIView

from dto.payload.TransactionPayload import TransactionPayload
from dto.responses.api_response import ApiResponse
from serializers.transaction import TransactionTypeSerializer, PostTransactionSerializer, TransactionsSerializer, \
    VendorTransactionFilterSerializer, AdminTransactionFilterSerializer, DashboardTransactionFilterSerializer, AdminOverviewTransactionsSerializer
from services.decorators.security.auth_payload import AuthPayload
from services.decorators.security.authentication_required import auth_required
from services.transactions.TransactionService import TransactionService
# from services.utils.Logger import Logger
from services.users.UserVerificationService import Call
from services.utils.Utils import Utils
from transactions.models import TransactionType, Transaction
from vendors.models import Vendor
from django.conf import settings

class ViewTransactionTypes(generics.ListAPIView):
    """
        VIEW SYSTEM TRANSACTION TYPES
    """

    renderer_classes = [JSONRenderer]
    serializer_class = TransactionTypeSerializer
    queryset = TransactionType.objects.find_all()


"""
    VALIDATE TRANSACTION PAYLOAD
"""


class VerifyCustomerDetails(APIView):
    """Validate payload based on transaction transactionType"""

    @Call(method='POST')
    def post(self, request):
        return request

class GetTeloneBroadbandProducts(APIView):
    """Get Telone Broadband Products"""
    parser_classes = [JSONParser]
    renderer_classes = [JSONRenderer]
    url = f'{settings.TELONE_LIVE_URL}getBroadbandProducts'

    def get(self, request):
        response = requests.post(
            url=self.url,
            data={
                "AccountSid": settings.TELONE_ACCOUNT_SID, 
                "APIKey": settings.TELONE_API_KEY
            }
        )
        print("PRODUCTS FROM TELONE  :", response.content, response.status_code)
        if response.status_code == 200:
            payload = {
                "status_code": response.status_code,
                "success": True,
                "data": response.json() if response.content else [],
                "errors": {

                }

            }
        else:
            payload = {
                "status_code": response.status_code,
                "success": True,
                "data": {},
                "errors": response.json() if response.content else {}

            }
        return JsonResponse(status=payload.pop("status_code"), data=payload)

class PostTransaction(APIView):
    """
        POST TRANSACTION
    """

    serializer_class = PostTransactionSerializer
    parser_classes = [JSONParser]
    renderer_classes = [JSONRenderer]

    def post(self, request):

        try:
            # Transaction posting request body
            data = json.loads(request.body)
            # validation
            serializer = PostTransactionSerializer(data=data)

            if serializer.is_valid():
                # transaction payload
                payload = TransactionPayload(serializer.data)
                # vendor
                vendor = Vendor.objects.authenticate(AuthPayload(request))
                # post transaction
                service = TransactionService(payload=payload, vendor=vendor)
                response = service.process()
                print('\n\nResponse Payload', response.content)
                return response
            else:
                """
                    Validation errors
                """
                response = ApiResponse(False, {'errors': serializer.errors})
                return JsonResponse(status=status.HTTP_406_NOT_ACCEPTABLE, data=response.__dict__)

        except Exception as e:
            """
                Error Log
            """
            # Logger.output(description='Transaction Posting Exception',
            #               payload={'Exception': traceback.format_exc()})
            # from pprint import pprint 
            # pprint(traceback.format_exc())
            # response
            response = ApiResponse(successful=False, response=Utils.get_messages().invalid_data)
            return JsonResponse(status=status.HTTP_400_BAD_REQUEST, data=response.__dict__)


class ViewAdminTransactions(generics.ListAPIView):
    """
        ADMIN VIEW ALL TRANSACTIONS
    """

    permission_classes = (IsAuthenticated,)
    renderer_classes = [JSONRenderer]
    serializer_class = TransactionsSerializer
    queryset = Transaction.objects.find_by_today()


class ViewVendorTransactions(generics.ListAPIView):
    """
        VENDOR VIEW ALL TRANSACTIONS
    """

    serializer_class = TransactionsSerializer

    def get_queryset(self):
        # get vendor from header
        vendor = Vendor.objects.authenticate(AuthPayload(self.request))
        # get today's transactions
        return Transaction.objects.find_by_vendor_and_today(vendor)


class FilterVendorTransactions(generics.ListAPIView):
    """
            FILTER VENDOR TRANSACTIONS
    """

    serializer_class = TransactionsSerializer
    filter_class = VendorTransactionFilterSerializer
    filter_backends = [DjangoFilterBackend]
    renderer_classes = [JSONRenderer]

    def get_queryset(self):
        # authenticate request
        auth_required(self.request)
        auth = AuthPayload(self.request)
        return Transaction.objects.find_by_vendor(Vendor.objects.authenticate(auth))


class FilterAdminTransactions(generics.ListAPIView):
    """
            FILTER ADMIN TRANSACTIONS
    """

    serializer_class = TransactionsSerializer
    filter_class = AdminTransactionFilterSerializer
    filter_backends = [DjangoFilterBackend]
    renderer_classes = [JSONRenderer]
    queryset = Transaction.objects.filter()
    permission_classes = (IsAuthenticated,)



class FilterDashboardTransactions(generics.ListAPIView):
    """
            FILTER DASHBOARD TRANSACTIONS
    """

    serializer_class = AdminOverviewTransactionsSerializer
    filter_class = DashboardTransactionFilterSerializer
    filter_backends = [DjangoFilterBackend]
    renderer_classes = [JSONRenderer]
    paginate_by = 2000


    def get_queryset(self):
        # authenticate request
        return Transaction.objects.find_by_vendor(Vendor.objects.get(id=3))


    