"""
    @author Marlvin Chihota
    Email marlvinchihota@gmail.com
    Created on 2021/12/07
"""
from rest_framework import generics

from providers.models import Country, Currency, Provider, SystemProvider
from serializers.providers import CountrySerializer, CurrencySerializer, ProviderSerializer, SystemProviderSerializer


class ViewCountries(generics.ListAPIView):
    """
        VIEW COUNTRIES
    """
    serializer_class = CountrySerializer
    queryset = Country.objects.find_all()


class ViewCurrencies(generics.ListAPIView):
    """
        VIEW CURRENCIES
    """
    serializer_class = CurrencySerializer
    queryset = Currency.objects.find_all()


class ViewProviders(generics.ListAPIView):
    """
        VIEW PROVIDERS
    """
    serializer_class = ProviderSerializer
    queryset = Provider.objects.find_all()


class ViewSystemProviders(generics.ListAPIView):
    """
        VIEW SYSTEM PROVIDERS
    """
    serializer_class = SystemProviderSerializer
    queryset = SystemProvider.objects.find_all()
