"""
    @author Marlvin Chihota
    Email marlvinchihota@gmail.com
    Created on 2021/12/07
"""
from rest_framework import generics

from billers.models import Biller
from serializers.billers import BillersSerializer


class ViewBillers(generics.ListAPIView):
    """
        VIEW SYSTEM BILLERS
    """

    serializer_class = BillersSerializer
    queryset = Biller.objects.find_all()


class ViewProviderBillers(generics.ListAPIView):
    """
        VIEW  BILLERS BY PROVIDER
    """

    serializer_class = BillersSerializer

    def get_queryset(self):
        query = Biller.objects.find_by_provider_name(self.kwargs.get('name'))
        return Biller.objects.none() if not query else query
