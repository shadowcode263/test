"""
    @author Marlvin Chihota
    Email marlvinchihota@gmail.com
    Created on 2021/12/07
"""
from rest_framework import generics

from products.models import Product
from serializers.products import ProductsSerializer


class ViewProducts(generics.ListAPIView):
    """
        VIEW BILLER PRODUCTS
    """

    serializer_class = ProductsSerializer

    def get_queryset(self):
        query = Product.objects.find_by_biller(self.kwargs.get('name'))
        return Product.objects.none() if not query else query


class ViewProviderProducts(generics.ListAPIView):
    """
        VIEW BILLER PRODUCTS
    """

    serializer_class = ProductsSerializer

    def get_queryset(self):
        query = Product.objects.find_by_provider(self.kwargs.get('name'))
        return Product.objects.none() if not query else query
