import json
from datetime import timedelta
from pathlib import Path
from corsheaders.defaults import default_headers

# FOR CONFIGURATIONS
with open('env/config.json') as config_file:
    config = json.load(config_file)

# Build paths inside the project like this: BASE_DIR / 'subdir'.
BASE_DIR = Path(__file__).resolve().parent.parent

SECRET_KEY = config["SECRET_KEY"]
DEBUG = config["DEBUG"]

ALLOWED_HOSTS = config["ALLOWED_HOSTS"]

# SMS

SMS_USERNAME = config["SMS_USERNAME"]
SMS_KEY = config["SMS_KEY"]
SMS_URL = config["SMS_URL"]

LOGGING = {
    "version": 1,
    "disable_existing_loggers": False,
    "handlers": {
        "file": {
            "level": "WARNING",
            "class": "logging.FileHandler",
            "filename": "application.log",
        },
    },
    "loggers": {
        "django": {
            "handlers": ["file"],
            "level": "WARNING",
            "propagate": True,
        },
    },
}

# Application definition

INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',

    'api.apps.ApiConfig',

    'billers.apps.BillersConfig',
    'products.apps.ProductsConfig',

    'services.apps.ServicesConfig',
    'transactions.apps.TransactionsConfig',
    'users.apps.UsersConfig',
    'vendors.apps.VendorsConfig',
    'providers.apps.ProvidersConfig',
    'serializers.apps.SerializersConfig',
    'dto.apps.DtoConfig',
    'rates.apps.RatesConfig',
    'permissions.apps.PermissionsConfig',

    'rest_framework',
    'rest_framework_simplejwt',
    'corsheaders',

    'django_filters'
]

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',

    'corsheaders.middleware.CorsMiddleware',

    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

REST_FRAMEWORK = {
    'DEFAULT_SCHEMA_CLASS': 'rest_framework.schemas.coreapi.AutoSchema',
    'DEFAULT_PERMISSION_CLASSES': ['rest_framework.permissions.AllowAny'],
    'DEFAULT_PARSER_CLASSES': ['rest_framework.parsers.JSONParser'],
    'DEFAULT_RENDERER_CLASSES': [
        'rest_framework.renderers.JSONRenderer',
        'rest_framework.renderers.BrowsableAPIRenderer',
    ],
    'DEFAULT_AUTHENTICATION_CLASSES': [
        'rest_framework_simplejwt.authentication.JWTAuthentication',
    ],
    'DEFAULT_PAGINATION_CLASS': 'rest_framework.pagination.LimitOffsetPagination',
    'PAGE_SIZE': config["PAGINATION_SIZE"],
}

ROOT_URLCONF = 'config.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

WSGI_APPLICATION = 'config.wsgi.application'

# Database
# https://docs.djangoproject.com/en/3.2/ref/settings/#databases

DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.mysql",
        "NAME": config["DATABASE_NAME"],
        "USER": config["DATABASE_USER"],
        "PASSWORD": config["DATABASE_PASSWORD"],
        "HOST": "localhost",
        "PORT": "3306",
    }
}

# User Model

AUTH_USER_MODEL = config["AUTH_USER_MODEL"]

# Password validation
# https://docs.djangoproject.com/en/3.2/ref/settings/#auth-password-validators

AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]

# EMAIL CONFIGS

EMAIL_BACKEND = "django.core.mail.backends.smtp.EmailBackend"

EMAIL_HOST = config["EMAIL_HOST"]
EMAIL_HOST_USER = config["EMAIL_HOST_USER"]
EMAIL_HOST_PASSWORD = config["EMAIL_HOST_PASSWORD"]
EMAIL_PORT = config["EMAIL_PORT"]
EMAIL_USE_TLS = True

DEFAULT_FROM_EMAIL = f"{config['PLATFORM_NAME']}{config['DEFAULT_FROM_EMAIL']}"

# Internationalization
# https://docs.djangoproject.com/en/3.2/topics/i18n/

LANGUAGE_CODE = 'en-us'

TIME_ZONE = 'Africa/Harare'

USE_I18N = True

USE_L10N = True

USE_TZ = True

# Static files (CSS, JavaScript, Images)
# https://docs.djangoproject.com/en/3.2/howto/static-files/

STATIC_URL = '/static/'

STATIC_ROOT = Path.joinpath(BASE_DIR, "static")

MEDIA_ROOT = Path.joinpath(BASE_DIR, "media")
MEDIA_URL = "/media/"

CORS_ALLOWED_ORIGINS = config["CORS_ALLOWED_ORIGINS"]
# CORS_ORIGIN_ALLOW_ALL = True

PLATFORM_NAME = config["PLATFORM_NAME"]

CORS_ALLOW_HEADERS = list(default_headers) + [
    'api-password', 'api-username', 'key'
]

# Default primary key field transactionType
# https://docs.djangoproject.com/en/3.2/ref/settings/#default-auto-field

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

# JWT

SIMPLE_JWT = {
    'ACCESS_TOKEN_LIFETIME': timedelta(days=config['ACCESS_TOKEN_LIFETIME']),
    'REFRESH_TOKEN_LIFETIME': timedelta(days=config['REFRESH_TOKEN_LIFETIME']),
    'AUTH_HEADER_TYPES': ('Bearer',),
    'AUTH_HEADER_NAME': 'HTTP_AUTHORIZATION',
    'USER_ID_FIELD': 'id'
}

# INTEGRATIONS

ECONET_USERNAME = config["ECONET_USERNAME"]
ECONET_PASSWORD = config["ECONET_PASSWORD"]
ECONET_MSISDN = config["ECONET_MSISDN"]
ECONET_PROVIDER_CODE = config["ECONET_PROVIDER_CODE"]
ECONET_API_URL = config["ECONET_API_URL"]

NETONE_URL = config["NETONE_URL"]
NETONE_USERNAME = config["NETONE_USERNAME"]
NETONE_PASSWORD = config["NETONE_PASSWORD"]

TELECEL_USERNAME = config["TELECEL_USERNAME"]
TELECEL_PASSWORD = config["TELECEL_PASSWORD"]
TELECEL_URL = config["TELECEL_URL"]

TELONE_ACCOUNT_SID = config["TELONE_ACCOUNT_SID"]
TELONE_API_KEY = config["TELONE_API_KEY"]
TELONE_LIVE_URL = config["TELONE_LIVE_URL"]
TELONE_SANDBOX_URL = config["TELONE_SANDBOX_URL"]

# ZB EGRESS
EGRESS_WSDL_URL = config["EGRESS_WSDL_URL"]
IAS_ZB_ACCOUNT = config["IAS_ZB_ACCOUNT"]
IAS_ZB_FCA_ACCOUNT = ["IAS_ZB_FCA_ACCOUNT"]
IAS_PHONE_NUMBER = ["IAS_PHONE_NUMBER"]


#NRICHARDS VOUCHERS
NRICHARDS_AGENT_CODE = config["NRICHARDS_AGENT_CODE"]
NRICHARDS_SERVICE_ID = config["NRICHARDS_SERVICE_ID"]
NRICHARDS_SERVICE_PROVIDER = config["NRICHARDS_SERVICE_PROVIDER"]
NRICHARDS_ACTION_ID = config["NRICHARDS_ACTION_ID"]
#GAIN CASH AND CARRY VOUCHERS
GAIN_AGENT_CODE = config["GAIN_AGENT_CODE"]
GAIN_SERVICE_ID = config["GAIN_SERVICE_ID"]
GAIN_SERVICE_PROVIDER = config["GAIN_SERVICE_PROVIDER"]
GAIN_ACTION_ID = config["GAIN_ACTION_ID"]
# YOAPP URL
YOAPP_URL = config["YOAPP_URL"]

#NYARADZO
NYARADZO_BANK_CODE = config["NYARADZO_BANK_CODE"]
NYARADZO_AUTH_KEY = config["NYARADZO_AUTH_KEY"]
NYARADZO_URL = config["NYARADZO_URL"]

#RELOADLY
RELOADLY_BASE_URL = config["RELOADLY_BASE_URL"]
RELOADLY_CLIENT_ID = config["RELOADLY_CLIENT_ID"]
RELOADLY_CLIENT_SECRET = config["RELOADLY_CLIENT_SECRET"]
RELOADLY_AUDIENCE_URL = config["RELOADLY_AUDIENCE_URL"]
