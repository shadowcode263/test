from django.contrib import admin
from django.urls import path, include
from rest_framework.documentation import include_docs_urls

from config import settings

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/v1/', include('api.urls')),

    # DOCUMENTATION
    path('api/v1/docs/',
         include_docs_urls(title=f'{settings.PLATFORM_NAME}', description=f'{settings.PLATFORM_NAME} API '
                                                                          f'Documentation')),
]
