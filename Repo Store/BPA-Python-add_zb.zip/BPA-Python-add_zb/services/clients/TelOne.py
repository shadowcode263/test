"""
    @author Garnet Sharara
    Email shararagarnet@gmail.com
    Created on 2022/01/27
"""
import requests

from config import settings
from dto.payload.TransactionPayload import TransactionPayload
from dto.payload.clients.telone.telon_query_products import TeloneQueryBroadbandProductsPayload
from dto.payload.clients.telone.telone_customer_balance import TeloneCustomerBalancePayload
from dto.payload.clients.telone.telone_merchant_transactions import TeloneMerchantTransactionsPayload
from dto.payload.clients.telone.telone_recharge_broadband import TelonePurchaseBroadPayload
from dto.payload.clients.telone.telone_recharge_adsl import TeloneRechargeAdslPayload
from dto.payload.clients.telone.telone_verify_account import TeloneVerifyAccountPayload
from dto.payload.clients.telone.telone_voip_recharge import TeloneVoIPRechargePayload
from dto.responses.clients.telone.telone_adsl_recharge import TeloneRechargeAdslResponse
from dto.responses.clients.telone.telone_exception import TelOneException
from dto.responses.clients.telone.verify_user_account import VerifyUserAccountResponse

class TelOne:
    """
        TELONE CLIENT
    """

    def __init__(self, payload: TransactionPayload):
        # client initialization
        self.TELONE_API_KEY = settings.TELONE_API_KEY
        self.TELONE_LIVE_URL = settings.TELONE_LIVE_URL
        self.url = self.TELONE_LIVE_URL
        self.default_payload = {"AccountSid": settings.TELONE_ACCOUNT_SID, "APIKey": settings.TELONE_API_KEY}
        self.payload = payload
        print(payload)

    @staticmethod
    def headers() -> dict:
        return {
            'Content-Type': 'application/json'
        }

    def verify(self):
        self.payload = TeloneVerifyAccountPayload(self.payload)
        print("POSTING ", self.payload.__dict__)
        request = requests.post(
                url=f"{self.url}verifyBroadbandAccount",
                data=self.payload.__dict__
            )
        print({"AccountSid": settings.TELONE_ACCOUNT_SID, "APIKey": settings.TELONE_API_KEY})
        print(request.content)
        res = request.json()
        if request.status_code == 200:
            if res.get('ResponseCode') == "00":
                response = {"success": True, "message": VerifyUserAccountResponse(res).__dict__}
            else:
                response = {"success": False, "message": TelOneException(request.json()).__dict__}
        else:
            response = {"success": False, "message": TelOneException(request.json()).__dict__} 
        return response

    def process(self) -> object:
        if self.payload['biller_id'].upper() == "TELONE_BROADBAND":
            self.payload = TelonePurchaseBroadPayload(self.payload)
            request = requests.post(
                url=f"{self.url}purchaseBroadband",
                headers=self.headers(),
                data=self.payload.__dict__
            )
            if request.status_code == 200:
                res = request.json()
                if res.get('ResponseCode') == "00":
                    response = {"success": True, "message": TelonePurchaseBroadPayload(res).__dict__}
                else:
                    response = {"success": False, "message": TelOneException(request.json()).__dict__}
            else:
                response = {"success": False, "message": TelOneException(request.json()).__dict__} 
                    
        elif self.payload['biller_id'].upper() == "TELONE_ADSL":
            self.payload = TeloneRechargeAdslPayload(self.payload)
            request = requests.post(
                url=f"{self.url}rechargeBroadband",
                headers=self.headers(),
                data=self.payload.__dict__
            )
            if request.status_code == 200:
                res = request.json()
                if res.get('ResponseCode') == "00":
                    response = {"success": True, "message": TeloneRechargeAdslResponse(res).__dict__}
                else:
                    response = {"success": False, "message": TelOneException(request.json()).__dict__}
            else:
                response = {"success": False, "message": TelOneException(request.json()).__dict__}

        elif self.payload['biller_id'].upper() == "TELONE_VOIP":
            self.payload = TeloneVoIPRechargePayload(self.payload)
            request = requests.post(
                url=f"{self.url}cashAccountRecharge",
                headers=self.headers(),
                data=self.payload.__dict__
            )
            if request.status_code == 200:
                res = request.json()
                if res.get('ResponseCode') == "00":
                    response = {"success": True, "message": res}
                else:
                    response = {"success": False, "message": TelOneException(request.json()).__dict__}
            else:
                response = {"success": False, "message": TelOneException(request.json()).__dict__}

        elif self.payload['biller_id'].upper() == "QUERY_PRODUCTS":
            self.payload = TeloneQueryBroadbandProductsPayload()
            print("POSTING TO ", f"{self.url}getBroadbandProducts")
            request = requests.post(
                url=f"{self.url}getBroadbandProducts",
                headers=self.headers(),
                data=self.payload.__dict__
            )
            if request.status_code == 200:
                res = request.json()
                response = {"success": True, "message": res}
            else:
                response = {"success": False, "message": TelOneException(request.json()).__dict__}
        
        elif self.payload['biller_id'].upper() == "ACCOUNT_DATA_BALANCE":
            self.payload = TeloneCustomerBalancePayload(self.payload)
            request = requests.post(
                    url=f"{self.url}QuerySubscriberFreeUnits",
                    data=self.payload.__dict__
                )
            res = request.json()
            if request.status_code == 200:
                res = request.json()
                response = {"success": True, "message": res}
            else:
                response = {"success": False, "message": TelOneException(request.json()).__dict__}

        elif self.payload['biller_id'].upper() == "ACCOUNT_VOICE_BALANCE":
            self.payload = TeloneCustomerBalancePayload(self.payload)
            request = requests.post(
                    url=f"{self.url}QuerySubscriberVoiceBalance",
                    data=self.payload.__dict__
                )
            res = request.json()
            if request.status_code == 200:
                res = request.json()
                response = {"success": True, "message": res}
            else:
                response = {"success": False, "message": TelOneException(request.json()).__dict__}

        elif self.payload['biller_id'].upper() == "MERCHANT_BALANCE":
            request = requests.post(
                    url=f"{self.url}QueryMerchantBalance",
                    data=self.default_payload 
                )
            res = request.json()
            if request.status_code == 200:
                res = request.json()
                response = {"success": True, "message": res}
            else:
                response = {"success": False, "message": TelOneException(request.json()).__dict__}
        
        elif self.payload['biller_id'].upper() == "MERCHANT_LOGS":
            self.default_payload["MerchantReference"] = self.payload.get('vendor_reference') if not settings.DEBUG else "REF1234"
            request = requests.post(
                    url=f"{self.url}QueryMerchantLogs",
                    data=self.default_payload
                )
            res = request.json()
            if request.status_code == 200:
                res = request.json()
                response = {"success": True, "message": res}
            else:
                response = {"success": False, "message": TelOneException(request.json()).__dict__}
        
        elif self.payload['biller_id'].upper() == "TELONE_MERCHANT_TRANSACTIONS_LOGS":
            self.payload = TeloneMerchantTransactionsPayload(self.payload)
            request = requests.post(
                    url=f"{self.url}QueryMerchantLogs",
                    data=self.default_payload
                )
            res = request.json()
            if request.status_code == 200:
                res = request.json()
                response = {"success": True, "message": res}
            else:
                response = {"success": False, "message": TelOneException(request.json()).__dict__}
        return response

