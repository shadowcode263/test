"""
    @author Nigel Zulu
    Email zulunigelb@gmail.com
    Created on 2022/02/22
"""
from django.http.response import JsonResponse
from rest_framework import status
from dto.responses.api_response import ApiResponse
from django.conf import settings
import requests
import json
import pytz

utc = pytz.UTC

from services.utils.Utils import Utils

"""
    RELOADLY TRANSACTION PROCESSOR CLIENT 
"""
        
class ReloadlyClient:
    
    def __init__(self, payload):
        self.payload = payload
        self.payload = payload
        self.access_token = self.get_token()
        self.base_url = settings["RELOADLY_BASE_URL"]
        self.client_id = settings["RELOADLY_CLIENT_ID"]
        self.client_secret = settings["RELOADLY_CLIENT_SECRET"]
        self.audience_url = settings["RELOADLY_AUDIENCE_URL"]

    def process(self):
        operator_id = self.reign_validatator(
                    self.payload["phoneNumber"],
                    self.payload["country"],
                )
        if operator_id:
            """
            Check if the available balance is greater than the requested amount
            """
            available_balance = self.check_balance()
            requested_amount = float(self.payload["amount"])
            if available_balance > requested_amount:
                """
                Topup Airtime
                """
                return self.airtime_topup(self.payload, operator_id)
            else:
                """
                INSUFFICIENT BALANCE
                """
                response = ApiResponse(
                    False,
                    {
                        "errors": "Insufficient balance",
                    },
                )
                return JsonResponse(
                    status=status.HTTP_401_UNAUTHORIZED, data=response.map()
                )
        else:
            """
            VALIDATOR ERRORS
            """
            response = ApiResponse(
                False,
                {
                    "errors": "Failed to validate phone number and country code",
                },
            )
            return JsonResponse(
                status=status.HTTP_401_UNAUTHORIZED, data=response.map()
            )


    def check_balance(self):
            check_balance_url = f"{self.base_url}accounts/balance"
            options = {
                "Content-Type": "application/json",
                "Authorization": "Bearer " + self.access_token,
            }
            print("getting the balance")
            response = requests.request("GET", check_balance_url, headers=options)
            return response.json()["balance"]

    def reign_validatator(self, phoneNumber, country):
        validator_url = f"{self.base_url}operators/auto-detect/phone/{phoneNumber}/countries/{country}?suggestedAmountsMap=true&SuggestedAmounts=true"
        options = {
            "Content-Type": "application/json",
            "Authorization": "Bearer " + self.access_token,
        }
        print(f"validating phone number {phoneNumber} and country code {country}")
        response = requests.request("GET", validator_url, headers=options)

        if response:
            print("operator found")
            return response.json()["operatorId"]
        else:
            print("operator not found")
            return False

    def airtime_topup(self, validated_data, operator_id):
        """
            Airtime Top Up Service
        Args:
            validated_data: payload with recipient data
        Returns:
            Successful response
        Raises:
            Failed airtime transaction
        """
        top_up_response = self.topup_request(validated_data, operator_id)

        if top_up_response:
            transaction_id = top_up_response.json()["transactionId"]
            status_response = self.check_topup_status(transaction_id)
            transaction_status = status_response.json()["status"]

            print("--=====", transaction_status)
            print("--=====Payload", validated_data)
            if transaction_status == "SUCCESSFUL":
                print("sending sms.....")
                # SMS.send(
                #     validated_data["amount"],
                #     validated_data["phoneNumber"],
                #     top_up_response.json()["requestedAmountCurrencyCode"],
                # )

                # response = {
                #     "successful": True,
                #     "reference": validated_data["reference"],
                #     "responseDescription": transaction_id,
                #     "upstreamResponseDescription": transaction_id,
                #     "narration": transaction_id,
                #     "mobileNumber": validated_data["phoneNumber"],
                # }
                # return Response(response)
                response = {
                "successful": True,
                "message": {
                    "Transaction Narration":"Airtime topped successfully",
                    'Gateway Reference':'TOPUP'
                    }
                }
                return JsonResponse(status=status.HTTP_200_OK, data=response, safe=False)
            else:
                response = ApiResponse(
                    True, Utils().get_messages()["400_Transaction_Failed"]
                )
                return JsonResponse(
                    status=status.HTTP_400_BAD_REQUEST, data=response.map()
                )
        else:
            response = ApiResponse(
                True, Utils().get_messages()["400_Transaction_Failed"]
            )
            return JsonResponse(status=status.HTTP_400_BAD_REQUEST, data=response.map())

    def check_topup_status(self, transaction_id):
        topup_status_url = f"{self.base_url}topups/{transaction_id}/status"

        options = {
            "Content-Type": "application/json",
            "Authorization": "Bearer " + self.access_token,
        }
        status_response = requests.request("GET", topup_status_url, headers=options)

        return status_response

    def topup_request(self, validated_data, operator_id):

        topup_url = f"{self.base_url}topups"
        payload = {
            "operatorId": operator_id,
            "amount": validated_data["amount"],
            "recipientPhone": {
                "countryCode": validated_data["country"],
                "number": validated_data["phoneNumber"],
            },
        }

        options = {
            "Content-Type": "application/json",
            "Authorization": "Bearer " + self.access_token,
        }
        print("topup")
        top_up_response = requests.request(
            "POST", topup_url, headers=options, data=json.dumps(payload)
        )
        return top_up_response

    def get_token(self):
        """
        Reloadly issues access tokens (also called bearer tokens) that are used to authorize API requests.
        this method retrieves the access token that would be used to authenticate
        """
        auth_url = f"{self.base_url}oauth/token"

        payload = json.dumps(
            {
                "client_id": self.client_id,
                "client_secret": self.client_secret,
                "grant_type": "client_credentials",
                "audience": self.audience_url,
            }
        )
        headers = {"Content-Type": "application/json"}

        response = requests.request("POST", auth_url, headers=headers, data=payload)
        access_token = response.json()["access_token"]

        return access_token
