"""
    @author Cletus Ngwerume
    Email cletuzz@gmail.com
    Created on 2022/02/14
"""
from django.http.response import JsonResponse
from rest_framework import status
from billers.models import Biller

from dto.responses.api_response import ApiResponse
from services.utils.Logger import Logger
from django.conf import settings
import datetime
import requests
import json

from services.utils.Utils import Utils


"""
    VOUCHER TRANSACTION PROCESSOR CLIENT 
"""
        
class VoucherClient:
    
    def __init__(self, payload):
        self.payload = payload

    def process(self):
        """
            TRANSACTION TYPE : FEES / ZESA
            ('004', 'VOUCHERS')
        """
        if self.payload.biller_code in ['NRICHARDS','GAIN']:
            payload = {}
            if self.payload.biller_code == 'NRICHARDS':
                payload['AgentCode'] = settings.NRICHARDS_AGENT_CODE
                payload["ServiceId"] = settings.NRICHARDS_SERVICE_ID
                payload["ActionId"] = settings.NRICHARDS_ACTION_ID
                payload["ServiceProvider"] = settings.NRICHARDS_SERVICE_PROVIDER
            if self.payload.biller_code == 'GAIN':
                payload['AgentCode'] = settings.GAIN_AGENT_CODE
                payload["ServiceId"] = settings.GAIN_SERVICE_ID
                payload["ActionId"] = settings.GAIN_ACTION_ID
                payload["ServiceProvider"] = settings.GAIN_SERVICE_PROVIDER
            payload["MTI"] = "0200"
            payload["TransactionType"] = 2
            payload["CustomerName"] = "INTELLI AFRICA"
            payload["ProcessingCode"] = "360000"
            payload['CustomerMSISDN'] = "263774231343"
            customer_data = f"{self.payload.extras['recipient_phone_number']},{self.payload.amount},{self.payload.extras['recipient_first_name']},{self.payload.extras['recipient_last_name']},{self.payload.extras['recipient_national_id']},USD"
            print(str(customer_data))
            payload['CustomerData']= str(customer_data)
            res = {
                "ResponseCode": "00000",
                "Description": None,
                "Balance": None,
                "TransactionCode": None,
                "vouchers": None,
                "AgentCode": None,
                "ServiceProvider": None,
                "Mpin": None,
                "Amount": 0,
                "MaxSale": 0,
                "MinSale": 0,
                "TransactionBranch": None,
                "CustomerMSISDN": None,
                "ServiceId": 0,
                "MTI": None,
                "TerminalId": None,
                "TransactionRef": None,
                "TransactionType": 0,
                "CustomerAccount": None,
                "CustomerData": None,
                "Currency": None,
                "Product": None,
                "Quantity": 0,
                "Action": None,
                "ProcessingCode": None,
                "Note": "Purchase",
                "Narrative": '[]',
                "HasProducts": False,
                "IsActive": False,
            }
            print("payload",payload)
            try:
                response_data = requests.request(
                    "POST", url=settings.YOAPP_URL,
                    headers={
                        'Content-Type': 'application/json',
                        'Cookie': 'AspxAutoDetectCookieSupport=1'
                    },
                    data=json.dumps(payload))
                res = response_data.json()
                print('YOAPP RESPONSE: ', res)
                res['response']={}
                if response_data.status_code == 200:
                    if res['Narrative']:
                        res['Narrative'] = json.loads(res['Narrative'])
                        res['Error'] = None
                        res['response']={}
                        extras = {
                            "reference":res['Narrative']['TransactionCode'],
                            "narration":{
                                "Transaction Narration":res['Description']
                                }
                        }
                        res['response']=extras
                        response = ApiResponse(True, res)
                    else:
                        res['Error'] = 400
                        res['response']['reference'] = 'Failed'
                        res['response']['narration'] = res['Description']
                        extras = {
                            "reference": None,
                            "narration":{
                                "Transaction Narration":res['Description']
                                }
                        }
                        res['response']=extras
                        response = ApiResponse(False, res)

                else:
                    res['Error'] = response_data.status_code
                    res['response']['reference'] = 'Failed'
                    res['response']['narration'] = 'Transaction Failed'
                    extras = {
                        "reference": None,
                        "narration":{
                            "Transaction Narration":res['Description']
                        }
                    }
                    res['response']=extras
                    response = ApiResponse(False, res)
            except Exception as e:
                print(e)
                res['Error'] = 500
                res['response']={}
                res['response']['reference'] = 'Failed'
                res['response']['narration'] = 'transaction Failed'
                extras = {
                    "reference": None,
                    "narration":{
                        "Transaction Narration": "Internal error"
                    }
                }
                res['response']=extras
                response = ApiResponse(False, res)                
            return response
        else:
            """
                Invalid Biller ID
            """
            response = ApiResponse(False, Utils().get_messages()['403_Invalid_Transaction'])
            return response
