"""
    @author Marlvin Chihota
    Email marlvinchihota@gmail.com
    Created on 2021/11/25
"""
from requests import Session
from zeep import Client
from zeep.transports import Transport

from config import settings
from dto.payload.TransactionPayload import TransactionPayload
from dto.responses.clients.telecel.agent_balance import AgentBalance
from dto.responses.clients.telecel.topup import TopUp
from dto.responses.clients.telecel.transaction_history import TransactionHistory
from dto.responses.clients.telecel.wallet_transfer import WalletTransfer
from rates.models import Rates
from services.clients.utils.telecel import TelecelAPI


class Telecel:
    """
        TELECEL CLIENT
    """

    def __init__(self,
                 payload: TransactionPayload):
        # client initialization
        self.url = settings.TELECEL_URL
        self.password = settings.TELECEL_PASSWORD
        self.username = settings.TELECEL_USERNAME
        # payload
        self.payload = payload
        # authorization
        self.session = Session()
        self.session.cert = 'properties/telecel/telecel.crt'
        self.session.verify = False

        self.transport = Transport(session=self.session, operation_timeout=50000)
        self.client = Client(wsdl='https://teleceletopup.telecelzimbabwe.co.zw/EstelTprServices/services/EstelTprServices?wsdl', transport=self.transport)

    def process(self) -> object:

        # telecel response
        response = None

        if self.payload.type.upper() == TelecelAPI.TELECEL_AGENT_BALANCE.value:
            request = self.client.service.BalanceRequest(agentCode=self.username, mpin=self.password)
            response = AgentBalance(request)

        elif self.payload.transaction_type.upper() == '001':
            request = self.client.service.TopupRequest(agentCode=self.username, mpin=self.password,
                                                       agenttransid=self.payload.vendor_reference,
                                                       destination=self.payload.target_account.strip('263'),
                                                       amount=Rates.objects.zwl_amount(
                                                           currency='932', amount=self.payload.amount),
                                                       productCode=self.payload.extras.get('product_id'),
                                                       comments='',
                                                       type=''
                                                       )
            response = TopUp(request)
            print(response)
        elif self.payload.type.upper() == TelecelAPI.TELECEL_TRANSACTION_HISTORY.value:
            request = self.client.service.TransHistoryRequest(agentCode=self.username, mpin=self.password,
                                                              agenttransid=self.payload.vendorReference,
                                                              count=self.payload.extras.get('count'),
                                                              fromdate=self.payload.extras.get('fromDate'),
                                                              todate=self.payload.extras.get('toDate')
                                                              )
            response = TransactionHistory(request)

        elif self.payload.type.upper() == TelecelAPI.TELECEL_WALLET_TRANSFER.value:
            request = self.client.service.WalletTransferInfoRequest(agentCode=self.username, mpin=self.password,
                                                                    amount=self.payload.amount,
                                                                    destination=self.payload.mobileNumber.strip('263'),
                                                                    agenttransid=self.payload.vendorReference,
                                                                    comments='')
            response = WalletTransfer(request)

        return response
