"""
    @author Marlvin Chihota
    Email marlvinchihota@gmail.com
    Created on 2021/11/25
"""
import requests

from config import settings
from dto.payload.TransactionPayload import TransactionPayload
from dto.payload.clients.econet.balance_request import BalanceRequest
from dto.payload.clients.econet.bundle_request import BundleRequest
from dto.payload.clients.econet.topup_request import TopUpRequest
from dto.responses.clients.econet.balance_response import BalanceResponse
from dto.responses.clients.econet.topup_response import TopUpResponse
from services.clients.utils.econet import EconetAPI


class Econet:

    """
        ECONET CLIENT
    """

    def __init__(self, payload: TransactionPayload):
        # client initialization
        self.url = settings.ECONET_API_URL
        self.headers = {'Content-Type': 'application/xml'}
        # payload
        self.payload = payload

    def process(self) -> object:

        # todo : exception handling
        # todo : handle non 200 responses

        response = None
        # Data Purchase
        
        print(self.payload.transaction_type)
        if self.payload.transaction_type.upper() == '002':
            payload = BundleRequest(self.payload)
            print(payload.map())
            request = requests.post(url=self.url, data=payload.map(), headers=self.headers)
            if request.status_code == 200:
                bundles_response = TopUpResponse(request.content)
                response = bundles_response.map()
        # Balance Enquiry 
        elif self.payload.transaction_type.upper() == '010':
            payload = BalanceRequest()
            request = requests.post(url=self.url, data=payload.map(), headers=self.headers)

            if request.status_code == 200:
                balance_response = BalanceResponse(request.content)
                response = balance_response.map()
        # Airtime Purchase
        elif self.payload.transaction_type.upper() == '001':
            print("NDAPINDA MU 001")
            payload = TopUpRequest(self.payload)
            print(payload)
            request = requests.post(url=self.url, data=payload.map(), headers=self.headers)
            print(request.content)

            if request.status_code == 200:
                top_up_response = TopUpResponse(request.content)
                response = top_up_response.map()

        return response
    
   
