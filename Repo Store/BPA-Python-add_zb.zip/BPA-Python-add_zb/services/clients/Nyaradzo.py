"""
    @author Nigel Zulu
    Email zulunigelb@gmail.com
    Created on 2022/02/22
"""
from django.http.response import JsonResponse
from rest_framework import status
import datetime
from dto.responses.api_response import ApiResponse
from django.conf import settings
import requests

from services.utils.Utils import Utils

"""
    NYARADZO TRANSACTION PROCESSOR CLIENT 
"""
        
class NyaradzoClient:
    
    def __init__(self, payload):
        print('Now in INIT')
        self.payload = payload
        self.url = settings.NYARADZO_URL
        self.headers = {
            "Content-Type":"application/json",
            "Accept": "application/json",
            "bankCode": settings.NYARADZO_BANK_CODE,
            "authKey": settings.NYARADZO_AUTH_KEY
            }
        print('Done with init')

    def verify(self):
        print("Got in here 1")
        customerAccount=self.payload.get('target_account')
        
        reference = Utils.get_vendor_reference(12)
        url = f"{self.url}account_enquiry?policyNumber={customerAccount}&numberOfMonths=1&sourceReference={reference}"
        print(reference)
        print(url)
        nyaradzo_response = requests.get(url, headers=self.headers)
        print("Got in here")
        print(nyaradzo_response.content)
        if nyaradzo_response.json()["responseCode"] == "200":
            response = ApiResponse(True, {
                        'accountNumber': nyaradzo_response.json()['policyNumber'],
                        'customerName': nyaradzo_response.json()["policyHolder"],
                        'customerExtraDetails': nyaradzo_response.json()
                })
            
            return JsonResponse(status=status.HTTP_200_OK, data=response.__dict__, safe=False)
        else:
            response = ApiResponse(False,
                                {'message': Utils.get_messages()['403_Invalid_Client_Details'],
                                    'response': "Details not found"})
            return JsonResponse(status=status.HTTP_406_NOT_ACCEPTABLE, data=response.__dict__, safe=False)

    
    def process(self):
        payload = {
            "sourceReference": self.payload['extras']["sourceReference"].replace(".", ""),
            "date": datetime.datetime.now(),
            "policyNumber": self.payload['extras']["accountNumber"],
            "amountPaid": self.payload['extras']["amount"],
            "numberOfMonths": self.payload['extras']["numberOfMonths"],
            "monthlyPremium": self.payload['extras']["monthlyPremium"]
        }

        nyaradzo_url = f"{self.url}payment_processing"

        nyaradzo_response = requests.post(url=nyaradzo_url, json=payload, headers=self.headers)

        if nyaradzo_response.status_code == 200:
            print('response',nyaradzo_response.json())
            response = {
                "successful": True,
                "message": nyaradzo_response.json()['message']
            }

            response = ApiResponse(True, {
                        "message": nyaradzo_response.json()['message']
                })
            
            return JsonResponse(status=status.HTTP_200_OK, data=response.map()['message'], safe=False)
        else:
            print("failed")
            response = {
                "successful": False,
                "message": nyaradzo_response.json()['message']
            }
            return JsonResponse(status=status.HTTP_400_BAD_REQUEST, data=response, safe=False)
        