"""
    @author Cletus Ngwerume
    Email cletuzz@gmail.com
    Created on 2022/02/14
"""
from django.http.response import JsonResponse
from rest_framework import status
from billers.models import Biller

from dto.responses.api_response import ApiResponse
from services.utils.Logger import Logger
from django.conf import settings
from requests import Session
from zeep import Client
from zeep.transports import Transport
import urllib3
import datetime

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

"""
    ZB TRANSACTION PROCESSOR CLIENT 
"""
        
class ZBClient:
    
    def __init__(self, payload):
        self.payload = payload
        self.wsdl_url = settings.EGRESS_WSDL_URL
        self.ias_zb_account = settings.IAS_ZB_ACCOUNT
        self.ias_zb_fca_account = settings.IAS_ZB_FCA_ACCOUNT
        self.ias_phone_number = settings.IAS_PHONE_NUMBER
        self.source = 'INTELLIAFRICA1'

        # initialisation
        self.session = Session()
        self.session.cert = 'properties/zb/intelli.pem'
        self.session.verify = False

        self.transport = Transport(session=self.session, operation_timeout=50000)
        self.client = Client(wsdl='properties/zb/egress.wsdl', transport=self.transport)

    def verify(self):
        response = self.client.service.validateCustomerAccount(
            source=self.source, billerId=self.payload.get('biller_code'),
            customerAccount=self.payload.get('account_number'))
        # print(response.content)
        print(response)
        # successful verification
        if response['successful']:
            data = response['responseDetails'].split('|')
            print("DATA",data)
            print("Response len",len(data))
            if len(data)<3:
                response = ApiResponse(True, {
                    'accountNumber': data[0],
                    'customerName': data[1]
                })
            elif len(data)>2:
                response = ApiResponse(True, {
                'accountNumber': data[0],
                'customerName': data[1],
                'customerExtraDetails': data[2]
                })
            else:
                response = ApiResponse(True, {
                'accountNumber': data[0]
                })
            return JsonResponse(status=status.HTTP_200_OK, data=response.__dict__, safe=False)
        else:
            print('Failed')
            response = ApiResponse(False, {'reason': response['responseDetails']})
            return JsonResponse(status=400, data=response.__dict__, safe=False)
    
    def process(self):
        """
            TRANSACTION TYPE : FEES / ZESA
            ('002', 'SCHOOL FEES PAYMENT'),
            ('003', 'ELECTRICITY'),
            ('005', 'TELEVISION'),
            ('007', 'BILLERS'),
        """

        # todo : check which transaction type the billerid belongs to
        biller = Biller.objects.filter(biller_code=self.payload.biller_code.upper()).first()
        transaction_type= biller.transaction_type.code
        print(transaction_type)
        if transaction_type == '009':
            """
                FEES
            """
            payload = {
                'billerId': self.payload.biller_code,
                'paymentReference': self.payload.vendor_reference,
                'source': self.source,
                'amount': self.payload.amount * 100,

                'customerPaymentDetails1': f"{self.payload.extras['purpose']}|{self.payload.extras['semester']}"
                                           f"|{self.payload.target_account}",
                # (Payment Purpose|Semester|Student Reg) -> 100|4.2|H180681F

                'customerPaymentDetails2': '',  # N/A
                'customerPaymentDetails3': '',  # N/A

                'customerPaymentDetails4': f"{self.payload.target_account}|{self.payload.extras['full_name']}",
                # (CustomerAccount|FullName) -> H180681F|Marlvin Chihota

                'customerPrimaryAccountNumber': self.ias_zb_account,
                'customerAccount': self.payload.target_account,  # (Meter/Student No)
                'paymentDate': datetime.datetime.now(),
                'currency': 'ZWL',
                'customerName': self.payload.extras['full_name'],
                'customerMobile': '263774231343',
                'paymentMethod': 'ACCOUNT',
                'paymentType': 'IB'
            }
            
        elif transaction_type == '003':
            """
                ZESA
            """
            payload = {
                'billerId': self.payload.biller_code,
                'paymentReference': self.payload.vendor_reference,
                'source': self.source,
                'amount': self.payload.amount * 100,

                'customerPaymentDetails1': "",
                'customerPaymentDetails2': '',
                'customerPaymentDetails3': '',

                'customerPaymentDetails4': f"{self.payload.target_account}|{self.payload.extras['full_name']}",
                # (CustomerAccount|FullName) -> H180681F|Marlvin Chihota

                'customerPaymentDetails5': '',

                'customerPrimaryAccountNumber': self.ias_zb_account,
                'customerAccount': self.payload.target_account,  # (Meter No)
                'paymentDate': datetime.datetime.now(),
                'currency': 'ZWL',
                'customerName': self.payload.extras['full_name'],
                'customerMobile': '263774231343',
                'paymentMethod': 'ACCOUNT',
                'paymentType': 'IB'
            }

        elif transaction_type == '005':
            """
                DSTV
            """
            payload = {
                'billerId': self.payload.biller_code,
                'paymentReference': self.payload.vendor_reference,
                'source': self.source,
                'amount': self.payload.amount * 100,
                
                'customerPaymentDetails1': self.payload.extras['bouquet'],
                # todo addons
                'customerPaymentDetails2': '',
                
                'customerPaymentDetails3': '',
                'customerPaymentDetails4': f"{self.payload.target_account}|{self.payload.extras['full_name']}",
                # 'customerPaymentDetails4': '',

                'customerPaymentDetails5': '',

                'customerPrimary_n': self.ias_zb_fca_account,
                'customerAccount': self.payload.target_account,  # (Meter No)
                'paymentDate': datetime.datetime.now(),
                'currency': 'USD',
                'customerName': self.payload.extras['full_name'],
                'customerMobile': '263774231343',
                'paymentMethod': 'ACCOUNT',
                'paymentType': 'IB'
            }
            
        elif transaction_type == '007':
            """
                COH
            """
            payload = {
                'billerId': self.payload.biller_code,
                'paymentReference': self.payload.vendor_reference,
                'source': self.source,
                'amount': self.payload.amount * 100,
                'customerPaymentDetails1': '',
                'customerPaymentDetails2': '',
                'customerPaymentDetails3': '',

                'customerPaymentDetails4': f"{self.payload.target_account}|{self.payload.extras['full_name']}",

                'customerPaymentDetails5': '',

                'customerPrimaryAccountNumber': self.ias_zb_account,
                'customerAccount': self.payload.target_account,  # (Account Number)
                'paymentDate': datetime.datetime.now(),
                'currency': 'ZWL',
                'customerName': self.payload.extras['full_name'],
                'customerMobile': '263774231343',
                'paymentMethod': 'ACCOUNT',
                'paymentType': 'IB'
            }
        print(payload)
        try:
            response = self.client.service.postPayment(payload)
        except:
            response_data = {'transaction_narration':'Transaction Failed'}
        print("EGRESS->",response)
        if transaction_type == '003':
            response_data = {'transaction_narration': response['receiptDetails'],'gateway_reference': response['payment']['gatewayReference']}
            response_data.update(self.zesa(response['receiptDetails']))
        else:
            response_data = {'transaction_narration': response['receiptDetails'],'gateway_reference': response['payment']['gatewayReference']}
        # response
        response = ApiResponse(response['successful'], response_data)

        Logger.output("RESPONSE DATA", response.__dict__)
        Logger.output('EGRESS RESPONSE', response_data)

        return response
        
    def zesa(self, message: str):
        message_list = message.split('|')
        return {
            'Token': message_list[9] if len(message_list) > 9 else None
        }