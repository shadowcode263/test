"""
    @author Marlvin Chihota
    Email marlvinchihota@gmail.com
    Created on 2021/11/25
"""
import requests

from config import settings
from dto.payload.TransactionPayload import TransactionPayload
from dto.responses.clients.netone.agent_recharge_pinless import AgentRechargePinless
from dto.responses.clients.netone.agent_wallet_balance import AgentWalletBalance
from dto.responses.clients.netone.bulk_evd_pin_purchase import BulkEVDPinPurchase
from dto.responses.clients.netone.end_user_balance import EndUserBalance
from dto.responses.clients.netone.netone_exception import NetOneException
from dto.responses.clients.netone.query_evd import QueryEVD
from dto.responses.clients.netone.query_transaction_recon import QueryTransactionRecon
from rates.models import Rates
from services.clients.utils.netone import NetOneAPI, NetOneAPIType


class NetOne:
    """
        NETONE CLIENT
    """

    def __init__(self, payload: TransactionPayload):
        # client initialization
        self.url = settings.NETONE_URL
        self.username = settings.NETONE_USERNAME
        self.password = settings.NETONE_PASSWORD
        # payload
        self.payload = payload

    def headers(self) -> dict:
        return {
            'x-access-code': self.username,
            'x-access-password': self.password,
            'x-agent-reference': self.payload.vendor_reference
        }

    def process(self) -> object:

        # netone response
        response = None

        if self.payload.transaction_type.upper() == '001':
            phone_number = self.payload.target_account.replace("+", "").strip()
            phone_number = f"0{phone_number[3:]}".strip() if phone_number[0:3] == '263' else phone_number
            print(phone_number)
            request = requests.post(self.url + NetOneAPIType.NETONE_AGENT_RECHARGE_PINLESS.value,
                                    headers=self.headers(), verify=False,
                                    json={'amount': Rates.objects.zwl_amount(
                                        currency='932', amount=self.payload.amount),
                                        'targetMobile': phone_number})
            print(request.json())
            if request.status_code == 200:
                response = AgentRechargePinless(request.json())
            else:
                response = NetOneException(request.json())

        elif self.payload.transaction_type.upper() == '010':
            request = requests.get(self.url + NetOneAPIType.NETONE_AGENT_WALLET_BALANCE.value,
                                    headers=self.headers(), verify=False)
            print(request.content)
            if request.status_code == 200:
                response = AgentWalletBalance(request.json())
            else:
                response = NetOneException(request.json())

        elif self.payload.type.upper() == '002':
            request = requests.post(self.url + NetOneAPI.NETONE_BULK_EVD_PIN_PURCHASE.value,
                                    json={'BrandId': self.payload.get('product_id'),
                                          'Denomination': Rates.objects.zwl_amount(
                                              currency='932', amount=self.payload.amount),
                                          'Quantity': '1'},
                                    verify=False, headers=self.headers())
            if request.status_code == 200:
                response = BulkEVDPinPurchase(request.json())
            else:
                response = NetOneException(request.json())

        elif self.payload.type.upper() == NetOneAPI.NETONE_END_USER_BALANCE.value:
            request = requests.get(self.url +
                                   str(NetOneAPIType.NETONE_END_USER_BALANCE.value).replace('[mobile number]',
                                                                                            f"0{self.payload.mobileNumber.strip('263')}"),
                                   headers=self.headers(),
                                   verify=False)
            if request.status_code == 200:
                response = EndUserBalance(request.json())
            else:
                response = NetOneException(request.json())

        elif self.payload.type.upper() == NetOneAPI.NETONE_QUERY_EVD.value:
            request = requests.get(self.url + NetOneAPIType.NETONE_QUERY_EVD.value, verify=False,
                                   headers=self.headers())
            if request.status_code == 200:
                response = QueryEVD(request.json())
            else:
                response = NetOneException(request.json())

        elif self.payload.type.upper() == NetOneAPI.NETONE_QUERY_TRANSACTION_RECON.value:
            request = requests.get(self.url + NetOneAPIType.NETONE_QUERY_TRANSACTION_RECON, headers=self.headers(),
                                   verify=False)
            if request.status_code == 200:
                response = QueryTransactionRecon(request.json())
            else:
                response = NetOneException(request.json())

        return response
