"""
    @author Marlvin Chihota
    Email marlvinchihota@gmail.com
    Created on 2021/12/13
"""

from enum import Enum


class NetOneAPI(Enum):

    """
        NETONE API CALLS
    """

    NETONE_AGENT_RECHARGE_PINLESS = 'NETONE_AGENT_RECHARGE_PINLESS'
    NETONE_AGENT_WALLET_BALANCE = 'NETONE_AGENT_WALLET_BALANCE'
    NETONE_BULK_EVD_PIN_PURCHASE = 'NETONE_BULK_EVD_PIN_PURCHASE'
    NETONE_END_USER_BALANCE = 'NETONE_END_USER_BALANCE'
    NETONE_QUERY_EVD = 'NETONE_QUERY_EVD'
    NETONE_QUERY_TRANSACTION_RECON = 'NETONE_QUERY_TRANSACTION_RECON'

error_codes={
    '217': 'Invalid Mobile Number',
    '222': 'Recharge Amount is too little',
    '208': 'Insufficient Balance',
    '206': 'Netone Platform is down',
    '209': 'Not enough stock',
    
}


class NetOneAPIType(Enum):

    """
        NETONE API TYPES
    """

    NETONE_AGENT_RECHARGE_PINLESS = '/agents/recharge-pinless'
    NETONE_AGENT_WALLET_BALANCE = '/agents/wallet-balance'
    NETONE_BULK_EVD_PIN_PURCHASE = '/agents/bulk-evd'
    NETONE_END_USER_BALANCE = '/agents/enduser-balance?targetMobile=[mobile number]'
    NETONE_QUERY_EVD = '/agents/query-evd'
    NETONE_QUERY_TRANSACTION_RECON = '/agents/query-transaction?agentReference=[reference]'