"""
    @author Marlvin Chihota
    Email marlvinchihota@gmail.com
    Created on 2021/12/18
"""

from enum import Enum


class TelecelAPI(Enum):

    """
        TELECEL API CALLS
    """

    TELECEL_AGENT_BALANCE = 'TELECEL_AGENT_BALANCE'
    TELECEL_TOPUP = 'TELECEL_TOPUP'
    TELECEL_TRANSACTION_HISTORY = 'TELECEL_TRANSACTION_HISTORY'
    TELECEL_WALLET_TRANSFER = 'TELECEL_WALLET_TRANSFER'
