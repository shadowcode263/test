from dataclasses import dataclass


@dataclass
class ZbCustomerVerification:
    """
        ZB CUSTOMER VERIFICATION CLASS
    """

    def __init__(self, payload: dict):
        self.url = "https://integrators.tumai.to/api/v1/payment/verify/"
        self.accountNumber = payload.get('account_number')
        self.billerId = payload.get('biller_id')
        self.from_zb = True
