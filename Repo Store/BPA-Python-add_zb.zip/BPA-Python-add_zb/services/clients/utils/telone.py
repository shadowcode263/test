"""
    @author Garnet Sharara
    Email shararagarnet@gmail.com
    Created on 2022/01/27
"""
from enum import Enum
from dataclasses import dataclass
from django.conf import settings


class TelOneAPI(Enum):
    """
        TelOne API CALLS
    """

    TELONE_CUSTOMER_ACCOUNT_VERIFICATION = 'TELONE_CUSTOMER_ACCOUNT_VERIFICATION'
    TELONE_QUERY_BROADBAND_PRODUCTS = 'TELONE_QUERY_BROADBAND_PRODUCTS'
    TELONE_PURCHASE_BROADBAND_PRODUCTS = 'TELONE_PURCHASE_BROADBAND_PRODUCTS'
    TELONE_RECHARGE_ADSL_ACCOUNT = 'TELONE_RECHARGE_ADSL_ACCOUNT'
    TELONE_MERCHANT_BALANCE = 'TELONE_MERCHANT_BALANCE'
    TELONE_PAY_BILL = 'TELONE_PAY_BILL'


class TelOneAPIType(Enum):
    """
        TelOne API TYPES
    """

    TELONE_CUSTOMER_ACCOUNT_VERIFICATION = 'verifyBroadbandAccount'
    TELONE_QUERY_BROADBAND_PRODUCTS = 'getBroadbandProducts'
    TELONE_PURCHASE_BROADBAND_PRODUCTS = 'purchaseBroadband'
    TELONE_RECHARGE_ADSL_ACCOUNT = 'rechargeBroadband'
    TELONE_MERCHANT_BALANCE = 'QueryMerchantBalance'
    TELONE_PAY_BILL = 'payBill'


@dataclass
class TeloneCustomerVerification:

    """
        TELONE CUSTOMER VERIFICATION CLASS
    """

    def __init__(self, payload: dict):
        self.url = f'{settings.TELONE_LIVE_URL}{TelOneAPIType.TELONE_CUSTOMER_ACCOUNT_VERIFICATION.value}'
        self.CustomerAccount = payload.get('target_account')
        self.AccountSid = settings.TELONE_ACCOUNT_SID
        self.APIKey = settings.TELONE_API_KEY
        self.from_zb = False

