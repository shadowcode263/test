"""
    @author Marlvin Chihota
    Email marlvinchihota@gmail.com
    Created on 2021/12/03
"""
from dataclasses import dataclass


@dataclass
class EmailPayload:

    """
        EMAIL PAYLOAD
    """

    def __init__(self, to: list, message: str, title: str,
                 file=None, link=None, button_title=None):
        self.to = to
        self.message = message
        self.title = title
        self.file = file
        self.link = link
        self.button_title = button_title
