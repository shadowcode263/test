"""
    @author Marlvin Chihota
    Email marlvinchihota@gmail.com
    Created on 2021/11/25
"""

"""
    SMS UTILITY
"""


class SMS:
    pass
