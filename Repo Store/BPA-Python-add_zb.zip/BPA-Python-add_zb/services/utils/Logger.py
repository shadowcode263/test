"""
    @author Marlvin Chihota
    Email marlvinchihota@gmail.com
    Created on 2021/11/25
"""

"""
    LOGGER UTIL
"""


class Logger:

    @staticmethod
    def output(description: str, payload: dict):
        print(f'{description} : {payload}')
