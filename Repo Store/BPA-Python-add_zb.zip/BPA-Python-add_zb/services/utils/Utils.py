from services.utils.Messages import Messages
from random import randint
class Utils:

    @staticmethod
    def get_messages():
        messages = Messages()
        return messages


    @staticmethod
    def get_vendor_reference(n):
        """generating vendor reference
        Args:
            n: total number
        Returns:
            response: randomly generated vendor number
        """
        range_start = 10 ** (n - 1)
        range_end = (10 ** n) - 1
        return randint(range_start, range_end)
