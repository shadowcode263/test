"""
    @author Marlvin Chihota
    Email marlvinchihota@gmail.com
    Created on 2021/12/03
"""

from celery import task
from django.core.mail import EmailMultiAlternatives, BadHeaderError
from django.template.loader import render_to_string

from config import settings
from services.utils.EmailPayload import EmailPayload
from services.utils.Logger import Logger


@task
def plain_text_email(to: str, message: str, title: str):
    """
        EMAIL LOGGER
    """

    Logger.output('OUTGOING EMAIL', {
        'to': to,
        'title': title,
        'message': message
    })
    sender = f'{settings.PLATFORM_NAME} Accounts<{settings.EMAIL_HOST_USER}>'
    html_content = render_to_string('services/plain_email.html', {'link': None,
                                                                  'message': message.replace('\n', '<br/>'),
                                                                  'button': False,
                                                                  'title': None
                                                                  })
    # send email
    try:
        msg = EmailMultiAlternatives(title, message, sender, to)
        msg.attach_alternative(html_content, "text/html")
        msg.send()
    # if error occurs
    except BadHeaderError as e:
        Logger.output('Email Exception', {'exception': e})


@task
def plain_text_with_button_email(to: str, message: str, title: str, button_title: str, link: str):
    """
        EMAIL LOGGER
    """
    Logger.output('OUTGOING EMAIL', {
        'to': to,
        'title': title,
        'message': message,
        'link': link,
        'button_title': button_title
    })
    sender = f'{settings.PLATFORM_NAME} Accounts<{settings.EMAIL_HOST_USER}>'
    html_content = render_to_string('services/plain_email.html', {'link': link,
                                                                  'message': message.replace('\n',
                                                                                             '<br/>'),
                                                                  'button': True,
                                                                  'title': title
                                                                  })
    # send email
    try:
        msg = EmailMultiAlternatives(title, message, sender, to)
        msg.attach_alternative(html_content, "text/html")
        msg.send()
    # if error occurs
    except BadHeaderError as e:
        Logger.output('Email Exception', {'exception': e})
