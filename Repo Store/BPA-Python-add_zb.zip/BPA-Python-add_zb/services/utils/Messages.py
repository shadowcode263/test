"""
    @author Marlvin Chihota
    Email marlvinchihota@gmail.com
    Created on 2021/12/01
"""
from dataclasses import dataclass

from users.models import User
from vendors.models import Vendor


@dataclass
class Messages:

    """
        COMMON APPLICATION MESSAGES
    """

    def __init__(self):
        self.non_or_empty = ['', None]
        self.invalid_vendor = 'Vendor not found'
        self.invalid_vendor_profile = 'Vendor profile not found'
        self.email_confirmed = 'Email has been confirmed already'
        self.numeric_password = 'Numeric password'
        self.email_exists = 'Email exists'
        self.username_exists = 'Username exists'
        self.unauthorized = 'Unauthorized'
        self.missing_headers = 'Add required authorization headers'
        self.invalid_data = 'System Malfunctioned'  # changed to system malfunctioned
        self.success = 'Success'
        self.invalid_transaction_type = 'Invalid transaction transactionType'
        self.invalid_biller = 'Invalid billerCode'
        self.exception = 'System malfunctioned'
        self.invalid_permissions = 'Permissions not set for that transaction'
        self.invalid_currency = 'Invalid currency'
        self.invalid_provider = 'Invalid provider'
        self.inactive_biller = 'Biller currently inactive'
        self.low_balance = 'Insufficient balance to perform the transaction'
        self.confirm_email = 'Kindly confirm your email to complete the registration process'
        self.inactive_vendor = 'Vendor is currently inactive'
        self.duplicate_vendor_reference = 'Duplicate vendor reference'
        self.invalid_password = 'Bad credentials'
        self.invalid_username = "Username doesn't exist"
        self.transaction_failed = "Transaction Processing Failed on MNO side"
        self.invalid_product_code = "Invalid Product Code"
        self.biller_permission_mismatch = 'Biller with the given billerCode does not have the given transactionType'

    @classmethod
    def api_message(cls, vendor: Vendor) -> str:
        return f'API KEY : {vendor.api_key} \n ' \
               f'API USERNAME : {vendor.api_username} \n ' \
               f'API PASSWORD : {vendor.api_password}'

    @classmethod
    def admin_message(cls, user: User) -> str:
        return f'USERNAME : {user.username} \n ' \
               f'EMAIL : {user.email} \n ' \
               f'ROLE : {user.role}'

    @classmethod
    def confirmation_url(cls, vendor_id: str, request: object) -> str:
        return f'https://{request.get_host()}/api/v1/back-office/vendor/confirm-email/{vendor_id}/'
