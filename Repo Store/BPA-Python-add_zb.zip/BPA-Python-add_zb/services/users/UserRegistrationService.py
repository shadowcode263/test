"""
    @author Marlvin Chihota
    Email marlvinchihota@gmail.com
    Created on 2022/01/08
"""
from django.http import JsonResponse
from rest_framework import status

from dto.responses.api_response import ApiResponse
from services.utils.EmailService import plain_text_email
from services.utils.Messages import Messages
from services.utils.Utils import Utils
from users.models import User


class UserRegistrationService:
    """
        USER REGISTRATION SERVICE
    """

    def __init__(self, payload: dict, request: object):
        self.payload = payload
        self.request = request

    def register(self):
        # email should not exist
        if not User.objects.find_by_email(email=self.payload.get('email')):
            # username should not exist
            if not User.objects.find_by_username(username=self.payload.get('username')):
                # numeric password
                if not self.payload.get('password').isnumeric():
                    # register user
                    user = User.objects.register_admin(self.payload)
                    # broadcast email
                    plain_text_email.delay(
                        to=[user.email], message=Messages.admin_message(user=user), title='Admin Details'
                    )
                    # success
                    response = ApiResponse(True, Utils.get_messages().success)
                    return JsonResponse(status=status.HTTP_201_CREATED, data=response.__dict__)
                else:
                    # numeric password
                    response = ApiResponse(False, {'error': Utils.get_messages().numeric_password})
                    return JsonResponse(status=status.HTTP_406_NOT_ACCEPTABLE, data=response.__dict__)
            else:
                # username exists
                response = ApiResponse(False, {'error': Utils.get_messages().username_exists})
                return JsonResponse(status=status.HTTP_406_NOT_ACCEPTABLE, data=response.__dict__)
        else:
            # email exists
            response = ApiResponse(False, {'error': Utils.get_messages().email_exists})
            return JsonResponse(status=status.HTTP_406_NOT_ACCEPTABLE, data=response.__dict__)
