"""
  @author Takudzwa Sharara
  Email shararagarnet@gmail.com
  Created on 30/1/2022
"""
from rest_framework import status
from wsgiref import validate
from billers.models import Biller
from dto.responses.api_response import ApiResponse
from services.clients.Nyaradzo import NyaradzoClient
from services.clients.utils.telone import TeloneCustomerVerification
from services.clients.utils.zb import ZbCustomerVerification
from django.http.response import JsonResponse
import requests
import functools
from django.conf import settings
from django.core.exceptions import ValidationError
from serializers.users import UserVerificationSerializer
from services.clients.ZB import ZBClient
from services.clients.TelOne import TelOne


class Call(object):
    def __init__(self, serializer=UserVerificationSerializer,
                 headers=None, method='POST', success_code=200,
                 processor=None, dataType='json'
                 ):
        if headers is None:
            headers = {}
        self.method = method
        self.headers = headers
        self.processor = processor
        self.serializer = serializer
        self.success_code = success_code
        self.dataType = dataType
        self.response_template = lambda status_code, payload=None, error_message=None: JsonResponse(status=status_code,
                                                                                                    data={
                                                                                                        "success": True if status_code == 200 else False,
                                                                                                        "data": payload if payload else {},
                                                                                                        "info": {
                                                                                                            "errors": error_message if error_message else {}
                                                                                                        }
                                                                                                    })

    def __call__(self, fn):
        @functools.wraps(fn)
        def decorated(*args, **kwargs):
            request = fn(*args, **kwargs)
            serializer = self.serializer(data=request.data)
            if serializer.is_valid():
                print(serializer.validated_data.get("biller_code"))
                if serializer.validated_data.get("biller_code") in [biller.biller_code for biller in Biller.objects.filter(provider__name='ZB')]:
                    response = ZBClient(serializer.validated_data)
                    response = response.verify()
                    print(response)
                    return response
                elif serializer.validated_data.get("biller_code").upper() == 'RELOADLY':
                    if serializer.validated_data.get("provider", None) == None:
                        response = ApiResponse(False, {'provider': 'This is a required field'})
                        return JsonResponse(status=status.HTTP_403_FORBIDDEN, data=response.__dict__)
                elif serializer.validated_data.get("biller_code").upper() == 'NYARADZO':
                    print("HERE HERE")
                    nyaradzo = NyaradzoClient(serializer.validated_data)
                    response = nyaradzo.verify()
                    print("Done")
                    return response
                # elif serializer.validated_data.get("biller_code").upper() == 'TELONE_ADSL':
                #     print("HERE HERE")
                #     telone = TelOne(serializer.validated_data)
                #     response = telone.verify()
                #     print("Done")
                #     return self.response_template(status_code=200, payload=response)
                else:
                    
                    validated_payload = self.getService(dict(serializer.validated_data))
                    # print(validated_payload)
                    if validated_payload:
                        self.url = validated_payload.pop('url')
                        print(validated_payload)
                        try:
                            if self.dataType == 'data':
                                response = requests.post(
                                    url=self.url,
                                    data=validated_payload,
                                    headers=self.headers
                                )
                            else:
                                response = requests.post(
                                    url=self.url,
                                    json=validated_payload,
                                    headers=self.headers
                                )
                            print(response.content)

                            if response.status_code == self.success_code:
                                if self.processor:
                                    return self.processor(request, response, serializer.validated_data)
                                else:
                                    return self.response_template(status_code=response.status_code, payload=response.json())
                            else:
                                return self.response_template(status_code=response.status_code, error_message=response.json())
                        except Exception as e:
                            return self.response_template(status_code=500, error_message={"error": str(e)})
                    else:
                        return self.response_template(status_code=404, error_message={"error": "Biller Not Found"})
            else:
                return self.response_template(status_code=400, error_message=serializer.errors)
        return decorated

    @staticmethod
    def getService(payload: dict) -> dict:
        if payload.get('biller_code') not in Biller.objects.find_all_names():
            return {}
        print(payload.get('biller_code'))
        # TODO: REGISTER VERIFICATION CLASS HERE
        SERVICES = {
            "TELONE_ADSL": TeloneCustomerVerification(payload).__dict__,
        }
        # print(SERVICES.get(payload.pop('biller_code')))
        return SERVICES.get(payload.pop('biller_code'))

    @staticmethod
    def fromZb(request, response, validated_data):
        payload = response.json()
        data = {
            "success": True if response.status_code == 200 else False,
            "data": payload['message']['message']['response'] if response.status_code == 200 else {},
            "info": {
                "errors": {}
            }
        }
        return JsonResponse(status=200, data=data)
