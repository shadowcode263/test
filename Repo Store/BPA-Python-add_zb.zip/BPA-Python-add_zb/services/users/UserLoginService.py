"""
  @author Marlvin Chihota
  Email marlvinchihota@gmail.com
  Created on 11/1/2022
"""
from django.contrib.auth import authenticate
from django.http import JsonResponse
from rest_framework import status
from rest_framework_simplejwt.tokens import RefreshToken

from dto.responses.api_response import ApiResponse
from dto.responses.login_response import LoginResponse
from services.utils.Utils import Utils
from vendors.models import Vendor


class UserLoginService:
    """
        USER LOGIN SERVICE
    """

    def __init__(self, payload: dict, user: object):
        self.payload = payload
        self.user = user
        self.vendor = Vendor.objects.find_by_user(self.user)

    def authenticate(self) -> JsonResponse:
        # authenticate user
        if authenticate(username=self.payload.get('username'),
                        password=self.payload.get('password')):
            token = RefreshToken.for_user(self.user)
            response = LoginResponse(user=self.user,
                                     vendor=self.vendor,
                                     refresh=str(token), access=str(token.access_token))
            return JsonResponse(status=status.HTTP_200_OK, data=response.__dict__)
        # failed to authenticate
        else:
            # todo : sort out password retry chances
            response = ApiResponse(False, {'errors': Utils.get_messages().invalid_password})
            return JsonResponse(status=status.HTTP_401_UNAUTHORIZED, data=response.__dict__)
