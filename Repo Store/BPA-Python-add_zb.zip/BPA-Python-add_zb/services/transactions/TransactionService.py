"""
    @author Marlvin Chihota
    Email marlvinchihota@gmail.com
    Created on 2021/12/12
"""
import itertools

from django.http import JsonResponse
from rest_framework import status

from billers.models import Biller
from dto.payload.BilerTypes import BillerTypes
from dto.payload.TransactionPayload import TransactionPayload
from dto.responses.api_response import ApiResponse
from dto.responses.clients.econet.topup_response import TopUpResponse
from dto.responses.transaction_response import TransactionResponse
from permissions.models import VendorPermission
from products.models import Product
from services.clients.Econet import Econet
from services.clients.NetOne import NetOne
from services.clients.Telecel import Telecel
from services.clients.TelOne import TelOne
from services.clients.Voucher import VoucherClient
from services.clients.ZB import ZBClient
from services.clients.utils.econet import EconetAPI
from services.transactions.constants import format_phone_number
from services.utils.Contants import currency_options
# from services.utils.Logger import Logger
from services.utils.Utils import Utils
from transactions.models import TransactionType, Transaction
from vendors.models import Vendor, VendorProfile


class TransactionService:

    def __init__(self, payload: TransactionPayload, vendor: Vendor):
        self.payload = payload
        self.vendor = vendor

    def process(self) -> JsonResponse:
        biller = Biller.objects.filter(biller_code=self.payload.biller_code.upper()).first()
        
        if not biller.is_active:
            #inactive billerCode
            response = ApiResponse(False, {'error': Utils.get_messages().inactive_biller})
            return JsonResponse(status=status.HTTP_403_FORBIDDEN, data=response.__dict__)   
        permissions = [x.strip() for x in self.vendor.permissions.split(',')]
    
        if not str(biller.transaction_type.code in permissions): 
            # invalid permissions
            response = ApiResponse(False, {'error': Utils.get_messages().__dict__.get('invalid_permissions')})
            return JsonResponse(status=status.HTTP_403_FORBIDDEN, data=response.__dict__)
        else:
            if not Transaction.objects.find_by_vendor_reference(self.payload.vendor_reference):
                if self.payload.currency_code.upper() in currency_options:             
                    if self.payload.amount > self.vendor.balance:
                        response = ApiResponse(False, {'error': Utils.get_messages().low_balance})
                        return JsonResponse(status=status.HTTP_403_FORBIDDEN, data=response.__dict__)
                    else:                  
                        transaction = Transaction.objects.pre_commit(payload=self.payload,
                                                                    transaction_type=biller,
                                                                    vendor=self.vendor)
                        response = None
                        transaction_status = 'FAILED'
                        is_successful = False
                        if biller.provider.name == 'ECONET':
                            self.payload.target_account = format_phone_number(self.payload.target_account)
                            if self.payload.biller_code == 'ECONET_DATA':
                                product = Product.objects.filter(code=self.payload.product_id).first()
                                if product is not None:
                                    self.payload.amount = product.price
                                    self.payload.product_id = product.code
                                else:
                                    response = ApiResponse(False, {'error': Utils.get_messages().invalid_product_code})
                                    return JsonResponse(status=status.HTTP_403_FORBIDDEN, data=response.__dict__)
                                
                            client = Econet(self.payload)
                            # from pprint import pprint
                            response = client.process()
                            print('Econet Response', response)
                            if self.payload.transaction_type.upper() == '010':
                                sorted_data = response
                                transaction_status = 'SUCCESSFUL'
                                is_successful = True
                            else:
                                transaction_status = 'SUCCESSFUL' if type(response) == dict else 'FAILED'
                                is_successful = True if int(response[0]['code']) == 1 and int(response[1]['code']) == 0  else False
                            
                        elif biller.provider.name == 'NETONE':                   
                            # netone client
                            client = NetOne(self.payload)
                            response = client.process().__dict__
                            # Logger.output('NetOne Response', response.__dict__)
                            print('NetOne Response', response)
                            # response sorting
                            if self.payload.transaction_type.upper() == '010':
                                sorted_data = response
                                transaction_status = 'SUCCESSFUL'
                                is_successful = True
                            else:
                                transaction_status = 'SUCCESSFUL' if int(response['reply_code']) == 2 else 'FAILED'
                                is_successful = True if int(response['reply_code']) == 2 else False
                                transaction.upstream_response = response['reply_msg']
                        elif biller.provider.name == 'TELECEL':
                            client = Telecel(self.payload)
                            response = client.process()
                            print('Telecel Response', response.__dict__)
                            # response sorting
                            transaction_status = 'SUCCESSFUL' if int(response.result_code) == 0 else 'FAILED'
                            is_successful = True if int(response.result_code) == 0 else False
                        elif biller.provider.name == 'ZB':
                            zb = ZBClient(self.payload)
                            response_dict = zb.process()
                            response = response_dict.__dict__
                            transaction_status = 'SUCCESSFUL' if response_dict.successful else 'FAILED'
                            is_successful = response_dict.successful                        
                        elif biller.provider.name == 'YOAPP':
                            voucher = VoucherClient(self.payload)
                            response_dict = voucher.process()
                            response = response_dict.__dict__
                            transaction_status = 'SUCCESSFUL' if response_dict.successful else 'FAILED'
                            is_successful = response_dict.successful  
                        transaction.status = transaction_status 
                        if is_successful: 
                            if  self.payload.transaction_type.upper() != '010':                          
                                Vendor.objects.deduct_balance(profile=self.vendor,
                                                                currency=self.payload.currency_code.upper(),
                                                                amount=self.payload.amount)
                                # update transaction
                            transaction.provider = biller.provider.name
                            Transaction.objects.post_commit(transaction=transaction,
                                                    response=response, status=transaction_status,
                                                    is_successful=is_successful, provider=biller.provider.name)

                            # response object
                            transaction_response = TransactionResponse(transaction=transaction)
                            return JsonResponse(status=status.HTTP_200_OK, data=transaction_response.__dict__)
                        else:
                            Transaction.objects.post_commit(transaction=transaction,
                                                    response=response, status=transaction_status,
                                                    is_successful=is_successful, provider=biller.provider.name)
                            transaction_response = TransactionResponse(transaction=transaction)
                            return JsonResponse(status=status.HTTP_200_OK, data=transaction_response.__dict__)              
            
            else:
                response = ApiResponse(False, {'error': Utils.get_messages().duplicate_vendor_reference})
                return JsonResponse(status=status.HTTP_403_FORBIDDEN, data=response.__dict__) 

#                         elif biller == BillerTypes.netone.value:
#                             # netone client
#                             client = NetOne(self.payload)
#                             response = client.process()
#                             Logger.output('NetOne Response', response.__dict__)
#                             # response sorting
#                             transaction_status = 'SUCCESSFUL' if int(response.reply_code) == 2 else 'FAILED'
#                             is_successful = True if int(response.reply_code) == 2 else False

#                         elif biller == BillerTypes.telecel.value:
#                             # telecel client
#                             client = Telecel(self.payload)
#                             response = client.process()
#                             Logger.output('Telecel Response', response.__dict__)
#                             # response sorting
#                             transaction_status = 'SUCCESSFUL' if int(response.result_code) == 0 else 'FAILED'
#                             is_successful = True if int(response.result_code) == 0 else False

#                             # todo : telone integrations
#                         elif biller == BillerTypes.telone.value:
#                             # Telone Client
#                             print('to telone client', self.payload.__dict__)
#                             client = TelOne(self.payload.__dict__)
#                             response = client.process()
#                             Logger.output('TelOne Response', response)
#                             Logger.output('TelOne Response Dictionary ', response.__dict__)
#                             # response sorting
#                             transaction_status = 'SUCCESSFUL' if int(response.reply_code) != 400 else 'FAILED'
#                             is_successful = True if transaction_status == 'SUCCESSFUL' else False
                                

#                         # balance deduction
#                         if is_successful:
#                             VendorProfile.objects.deduct_balance(profile=vendor_profile,
#                                                                 currency=self.payload.currencyCode.upper(),
#                                                                 amount=self.payload.amount)
#                         # update transaction
#                         Transaction.objects.post_commit(transaction=transaction,
#                                                         response=response, status=transaction_status,
#                                                         is_successful=is_successful)

#                         # response object
#                         transaction_response = TransactionResponse(transaction=transaction)
#                         return JsonResponse(status=status.HTTP_200_OK, data=transaction_response.__dict__)
#                     else:
#                         # top up balance
#                         response = ApiResponse(False, {'error': Utils.get_messages().low_balance})
#                         return JsonResponse(status=status.HTTP_403_FORBIDDEN, data=response.__dict__)
#                 else:
#                     # invalid currency
#                     response = ApiResponse(False,
#                                             {'error': Utils.get_messages().invalid_currency})
#                     return JsonResponse(status=status.HTTP_403_FORBIDDEN, data=response.__dict__)
            # else:
            #     # duplicate vendor reference
            #     response = ApiResponse(False,
            #                             {'error': Utils.get_messages().duplicate_vendor_reference})
            #     return JsonResponse(status=status.HTTP_403_FORBIDDEN, data=response.__dict__)
#         else:
#             # inactive billerCode
#             response = ApiResponse(False, {'error': Utils.get_messages().inactive_biller})
#             return JsonResponse(status=status.HTTP_403_FORBIDDEN, data=response.__dict__)
#     else:
#         # invalid permissions
#         response = ApiResponse(False, {'error': Utils.get_messages().__dict__.get('invalid_permissions')})
#         return JsonResponse(status=status.HTTP_403_FORBIDDEN, data=response.__dict__)
# else:
#     # invalid transaction transactionType response
#     response = ApiResponse(False, {'error': Utils.get_messages().invalid_transaction_type})
#     return JsonResponse(status=status.HTTP_406_NOT_ACCEPTABLE, data=response.__dict__)

