def format_phone_number(phone_number):
    phone_number = phone_number.replace(" ", "")
    phone_number = phone_number.replace("+", "")
    if phone_number[0] == '0':
        phone_number = '263' + phone_number[1:]
    elif phone_number[0] == '7':
        phone_number = '263' + phone_number
    elif phone_number[0:3] == '263':
        pass
    else:
        return False
    return phone_number