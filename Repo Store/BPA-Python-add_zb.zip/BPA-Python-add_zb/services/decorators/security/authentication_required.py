"""
    @author Marlvin Chihota
    Email marlvinchihota@gmail.com
    Created on 2021/12/03
"""

from django.http import JsonResponse
from rest_framework import status

from dto.responses.api_response import ApiResponse
from serializers.authentication import AuthSerializer
from services.decorators.security.auth_payload import AuthPayload
from services.utils.Utils import Utils
from vendors.models import Vendor

"""
    AUTHENTICATE 
    VENDORS
"""


def authentication_required(function):
    def wrap(request, *args, **kwargs):

        # fetch api headers
        auth = AuthPayload(request)
        serializer = AuthSerializer(data=auth.__dict__)

        # header validation
        if serializer.is_valid():
            vendor = Vendor.objects.authenticate(auth)
            # authenticated vendor
            if vendor:
                # active vendor
                if vendor.is_active:
                    return function(request, *args, *kwargs)
                else:
                    # inactive vendor
                    response = ApiResponse(False, Utils.get_messages().inactive_vendor)
                    return JsonResponse(status=status.HTTP_403_FORBIDDEN, data=response.__dict__)
            else:
                # invalid credentials
                response = ApiResponse(False, {'error': Utils.get_messages().unauthorized})
                return JsonResponse(status=status.HTTP_401_UNAUTHORIZED, data=response.__dict__)
        else:
            # error response
            response = ApiResponse(False, {'error': serializer.errors})
            return JsonResponse(status=status.HTTP_400_BAD_REQUEST, data=response.__dict__)

    wrap.__doc__ = function.__doc__
    wrap.__name__ = function.__name__
    return wrap


"""
    AUTHENTICATE 
    VENDORS FOR VIEWS WITH LISTAPIVIEW
"""


# todo : auth required should return status
# todo : return responses

def auth_required(request):
    # fetch api headers
    auth = AuthPayload(request)
    serializer = AuthSerializer(data=auth.__dict__)

    # header validation
    if serializer.is_valid():
        vendor = Vendor.objects.authenticate(auth)
        # authenticated vendor
        if vendor:
            # active vendor
            if not vendor.is_active:
                # inactive vendor
                response = ApiResponse(False, Utils.get_messages().get('inactive_vendor'))
                return JsonResponse(status=status.HTTP_403_FORBIDDEN, data=response.__dict__)
        else:
            # invalid credentials
            response = ApiResponse(False, {'error': Utils.get_messages().get('unauthorized')})
            return JsonResponse(status=status.HTTP_401_UNAUTHORIZED, data=response.__dict__)
    else:
        # error response
        response = ApiResponse(False, {'error': serializer.errors})
        return JsonResponse(status=status.HTTP_400_BAD_REQUEST, data=response.__dict__)
