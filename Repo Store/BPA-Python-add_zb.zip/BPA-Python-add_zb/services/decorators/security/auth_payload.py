"""
    @author Marlvin Chihota
    Email marlvinchihota@gmail.com
    Created on 2021/12/03
"""
from dataclasses import dataclass


@dataclass
class AuthPayload:
    """
        GET VENDOR HEADERS
    """

    def __init__(self, request: object):
        self.password = request.headers.get('api-password')
        self.username = request.headers.get('api-username')
        self.key = request.headers.get('key')
