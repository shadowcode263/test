| Application Name     | Models |
| :---        |    :----:   |
| billers     | Biller       |
| products   | Product       |
| providers     | Country <br> Currency <br> Provider <br> SystemProvider       |
| rates   | Rates        |
| transactions   | TransactionType <br> Transaction       |
| users     | User      |
| vendors   | Vendor <br> Vendor Profile       |