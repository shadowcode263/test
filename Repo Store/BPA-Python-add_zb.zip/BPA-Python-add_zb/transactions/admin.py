from django.contrib import admin
from .models import Transaction, TransactionType

"""
    REGISTERING MODELS TO THE ADMIN PANEL
"""


@admin.register(Transaction)
class TransactionAdmin(admin.ModelAdmin):
    list_display = [f.name for f in Transaction._meta.fields]


@admin.register(TransactionType)
class TransactionTypeAdmin(admin.ModelAdmin):
    list_display = [f.name for f in TransactionType._meta.fields]
