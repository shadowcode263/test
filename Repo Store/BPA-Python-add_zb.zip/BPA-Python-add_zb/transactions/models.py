import uuid
import datetime

from django.db import models

from services.utils.Contants import currencies, transaction_status, TRANSACTION_TYPES

"""
    TRANSACTION TYPES MODEL
"""


class TransactionType(models.Model):
    code = models.CharField(max_length=50, blank=False, unique=True)
    name = models.CharField(max_length=255, blank=False,unique=True, choices=TRANSACTION_TYPES)
    from .managers import TransactionTypeManager
    objects = TransactionTypeManager()

    class Meta:
        ordering = ['name', 'code']
        verbose_name = 'Transaction Type'
        verbose_name_plural = 'Transaction Types'

    def __str__(self):
        return self.name


"""
    TRANSACTIONS MODEL
"""


class Transaction(models.Model):
    transactionType = models.ForeignKey(TransactionType, on_delete=models.PROTECT)
    from vendors.models import Vendor
    vendor = models.ForeignKey(Vendor, on_delete=models.PROTECT)
    target_account = models.CharField(max_length=255, blank=False)

    vendor_reference = models.CharField(max_length=255, unique=True)
    debit_reference = models.CharField(max_length=255, unique=True, blank=True, null=True)

    amount = models.FloatField(default=0)
    quantity = models.IntegerField(default=1)
    currencyCode = models.CharField(max_length=255, choices=currencies)
    upstream_response = models.JSONField(blank=True, null=True)
    status = models.CharField(max_length=255, choices=transaction_status)

    # todo : pending migration
    payload = models.JSONField(blank=True, null=True)# raw vendor payload
    response = models.JSONField(blank=True, null=True)# raw upstream response
    reversal = models.JSONField(blank=True, null=True)# reversal payload

    is_successful = models.BooleanField(default=False)
    is_reversed = models.BooleanField(default=False)

    response_code = models.CharField(max_length=255)
    transaction_biller = models.CharField(max_length=255)
    target_account = models.CharField(max_length=255)
    response_description = models.JSONField(blank=True, null=True)

    date_created = models.DateTimeField(auto_now_add=True)
    date_modified = models.DateTimeField()

    from .managers import TransactionManager
    objects = TransactionManager()

    def save(self, *args, **kwargs):
        self.date_modified = datetime.datetime.today()
        super().save(*args, **kwargs)

    class Meta:
        ordering = ['-date_created']
        verbose_name = 'Transaction'
        verbose_name_plural = 'Transactions'

    def __str__(self):
        return f'{self.vendor.company_name} - {self.vendor_reference}'


