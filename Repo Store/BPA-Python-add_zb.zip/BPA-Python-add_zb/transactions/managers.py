"""
    @author Marlvin Chihota
    Email marlvinchihota@gmail.com
    Created on 2021/11/27
"""
import datetime
import json

from django.db import models
# from billers.models import Biller

from dto.payload.TransactionPayload import TransactionPayload
from dto.responses.clients.econet.topup_response import TopUpResponse
from services.clients.utils.econet import EconetAPI
from vendors.models import Vendor
from collections import ChainMap



"""
    TRANSACTION MANAGER
"""


class TransactionManager(models.Manager):

    def find_all_by_vendor(self, vendor: Vendor) -> object:
        return self.filter(vendor=vendor).order_by('-date_created')

    def find_by_vendor_reference(self, reference: str) -> object:
        return self.filter(vendor_reference=reference).first()

    def find_by_today(self) -> object:
        return self.filter(date_created__gte=datetime.date.today())

    def find_by_vendor_and_today(self, vendor: Vendor) -> object:
        return self.filter(date_created__gte=datetime.date.today(), vendor=vendor)

    # vendor filters

    def find_by_vendor(self,
                       vendor: Vendor) -> object:
        return self.filter(
            vendor=vendor
        )

    def find_by_vendor_and_transaction_type(self,
                                            start_date, end_date,
                                            transaction_filter,
                                            vendor: Vendor) -> object:
        return self.filter(date_created=datetime.date.today(),
                           vendor=vendor,
                           date_created__gte=start_date,
                           date_created__lte=end_date,
                           transactionType__name__icontains=transaction_filter
                           )

    def find_by_vendor_and_currency(self,
                                    start_date, end_date,
                                    transaction_filter,
                                    vendor: Vendor) -> object:
        return self.filter(date_created=datetime.date.today(),
                           vendor=vendor,
                           date_created__gte=start_date,
                           date_created__lte=end_date,
                           currencyCode__icontains=transaction_filter
                           )


    def find_by_vendor_and_status(self,
                                  start_date, end_date,
                                  transaction_filter,
                                  vendor: Vendor) -> object:
        return self.filter(date_created=datetime.date.today(),
                           vendor=vendor,
                           date_created__gte=start_date,
                           date_created__lte=end_date,
                           is_successful=transaction_filter
                           )

    # admin filters

    def find_by_transaction_type(self,
                                 start_date, end_date,
                                 transaction_filter,
                                 ) -> object:
        return self.filter(date_created=datetime.date.today(),
                           date_created__gte=start_date,
                           date_created__lte=end_date,
                           transactionType__name__icontains=transaction_filter
                           )

    def find_by_currency(self,
                         start_date, end_date,
                         transaction_filter) -> object:
        return self.filter(date_created=datetime.date.today(),
                           date_created__gte=start_date,
                           date_created__lte=end_date,
                           currencyCode__icontains=transaction_filter
                           )


    def find_by_status(self,
                       start_date, end_date,
                       transaction_filter) -> object:
        return self.filter(date_created=datetime.date.today(),
                           date_created__gte=start_date,
                           date_created__lte=end_date,
                           is_successful=transaction_filter
                           )

    def pre_commit(self, payload: TransactionPayload,
                   vendor: Vendor, transaction_type,) -> object:

        # per commit logic

        return self.create(
            transactionType=transaction_type.transaction_type,
            transaction_biller = transaction_type.biller_code,
            vendor=vendor, vendor_reference=payload.vendor_reference,
            amount=payload.amount, quantity='1',
            status='PENDING',
            target_account=payload.target_account,
            payload=payload.__dict__
        )

    def post_commit(self, transaction: object,
                    response: object, status: str,
                    is_successful: bool, provider: str):
        # update transaction entry
        transaction.is_successful = is_successful
        try:
            transaction.response = dict(ChainMap(*response))
        except:
            transaction.response = response
        transaction.status = status

        # upstream response
        if transaction.transaction_biller.upper() == 'ECONET_BALANCE_ENQUIRY':
            transaction.response_code = '0' if type(response) == dict else '1'
            transaction.upstream_response = 'SUCCESSFUL' if type(response) == dict else 'FAILED'
        elif transaction.transaction_biller.upper() == 'ECONET_AIRTIME' or transaction.transaction_biller.upper() == 'ECONET_DATA':
            sorted_data = TopUpResponse.sort(response)
            transaction.response_code = sorted_data.get('status_code')
            transaction.upstream_response = sorted_data.get('description') 
        elif transaction.transaction_biller.upper() == 'ECONET_BALANCE' or transaction.transaction_biller.upper() == 'NETONE_BALANCE':
            transaction.response_code = True
            transaction.upstream_response = 'Balance'
        
        elif transaction.transaction_biller.upper() == 'NETONE_AIRTIME' or transaction.transaction_biller.upper() == 'NETONE_DATA':
            transaction.response_code = response['reply_code']
            transaction.upstream_response = response['reply_msg']
       
        print(provider)
        if provider == 'ZB':
            transaction.response_code = response['successful']
            transaction.response_description = ''
        

        # commit transaction
        transaction.save()


"""
    TRANSACTION TYPE MANAGER
"""


class TransactionTypeManager(models.Manager):

    def find_by_name(self, name: str) -> object:
        return self.filter(name__icontains=name).first()

    def find_by_code(self, code: str) -> object:
        return self.filter(code=code).first()

    def find_all_codes(self) -> object:
        codes = self.find_all().values('code')
        if codes:
            return [item.get('code').upper() for item in codes]
        else:
            return []

    def find_all(self) -> object:
        return self.all()

    def find_all_names(self) -> list:
        names = self.find_all().values('name')
        if names:
            return [item.get('name').upper() for item in names]
        else:
            return []


