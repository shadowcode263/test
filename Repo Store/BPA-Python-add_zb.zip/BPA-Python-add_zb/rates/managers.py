"""
    @author Marlvin Chihota
    Email marlvinchihota@gmail.com
    Created on 2021/11/27
"""

from django.db import models

"""
    RATES MANAGER
"""


class RatesManager(models.Manager):

    def find_all(self):
        return self.all()

    def find_latest(self):
        return self.filter().order_by('-last_updated').first()

    def zwl_amount(self, currency: str, amount: float) -> float:
        rate = self.find_latest()
        # convert amount
        return (rate.zwl_to_zar * amount) if currency.upper() == 'ZAR' else amount if currency.upper() != 'USD' else (
                rate.zwl_to_usd * amount)

    def create_or_update(self, payload: dict):
        rate = self.find_latest()
        if rate:
            rate.zwl_to_usd = payload.get('usd')
            rate.zwl_to_zar = payload.get('zar')
            rate.save()
        else:
            self.create(
                zwl_to_usd=payload.get('usd'),
                zwl_to_zar=payload.get('zar')
            )
