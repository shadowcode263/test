import uuid

from django.db import models
import datetime

from rates.managers import RatesManager

"""
    RATES MODEL
"""


class Rates(models.Model):
    zwl_to_usd = models.FloatField(default=0)
    zwl_to_zar = models.FloatField(default=0)
    last_updated = models.DateTimeField()

    objects = RatesManager()

    class Meta:
        verbose_name = 'Exchange Rate'
        verbose_name_plural = 'Exchange Rates'

    def save(self, *args, **kwargs):
        self.last_updated = datetime.datetime.today()
        super().save(*args, **kwargs)

    def __str__(self):
        return self.last_updated.strftime('%d %b %Y')
