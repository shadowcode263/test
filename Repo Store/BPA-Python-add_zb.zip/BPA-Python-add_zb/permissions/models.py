from django.db import models
import uuid
from permissions.manager import PermissionsManager
from providers.models import Provider
from services.utils.Contants import TRANSACTION_TYPES

class VendorPermission(models.Model):
    permission = models.CharField(max_length=255, blank=False, choices=TRANSACTION_TYPES)

    objects = PermissionsManager()

    class Meta:
        ordering = ['permission']
        verbose_name = 'Vendor Permission'
        verbose_name_plural = 'Vendor Permissions'

    def __str__(self):
        return f'{self.permission}'

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
