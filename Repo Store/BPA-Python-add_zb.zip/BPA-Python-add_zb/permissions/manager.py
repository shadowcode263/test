from django.db import models

class PermissionsManager(models.Manager):

    def find_all(self):
        return self.all()

    def find_by_name(self, permission_name: str) -> object:
        return self.filter(permission=permission_name).first()