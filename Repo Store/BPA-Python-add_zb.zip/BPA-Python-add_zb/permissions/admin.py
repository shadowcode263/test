from django.contrib import admin

from permissions.models import VendorPermission

@admin.register(VendorPermission)
class VendorPermissionsAdmin(admin.ModelAdmin):
    pass

