INSERT INTO public.providers_systemprovider ("ID", name, email, phone_number) VALUES ('39577ecc-4f99-4db2-a7a8-35fdb5de1349', 'BPA', 'info@intelliafrica.solutions', '263775580596');
