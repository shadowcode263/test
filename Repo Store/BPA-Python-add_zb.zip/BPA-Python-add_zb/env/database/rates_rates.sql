INSERT INTO public.rates_rates ("ID", zwl_to_usd, zwl_to_zar, last_updated) VALUES ('6d40bc80-a7d2-40e5-99ca-a5bb913f763f', 200, 100, '2021-12-07 21:21:33.668498 +00:00');
