"""
    @author Marlvin Chihota
    Email marlvinchihota@gmail.com
    Created on 2021/11/27
"""

from django.db import models

"""
    BILLER MANAGER
"""


class BillerManager(models.Manager):

    def find_all(self) -> object:
        return self.all()

    def find_all_names(self) -> list:
        names = self.find_all().values('biller_code')
        print(names)
        if names:
            return [item.get('biller_code').upper() for item in names]
        else:
            return []

    def find_by_name(self, name: str) -> object:
        return self.filter(name__icontains=name).first()

    def find_by_code(self, code: str) -> object:
        return self.filter(code=code).first()

    def find_by_provider_name(self, name: str) -> object:
        return self.filter(provider__name=name)
