import uuid

from django.db import models

from billers.managers import BillerManager

"""
    BILLER MODEL
"""


class Biller(models.Model):
    name = models.CharField(max_length=255, unique=True)
    biller_code = models.CharField(max_length=100, blank=False, unique=True)

    from transactions.models import TransactionType
    transaction_type = models.ForeignKey(TransactionType, on_delete=models.PROTECT, blank=True, null=True)

    from providers.models import Provider
    provider = models.ForeignKey(Provider, on_delete=models.PROTECT, blank=True, null=True)
    is_active = models.BooleanField(default=True)

    objects = BillerManager()

    class Meta:
        ordering = ['name']
        verbose_name = 'Biller'
        verbose_name_plural = 'Billers'

    def __str__(self):
        return self.name
