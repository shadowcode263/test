from django.contrib import admin
from .models import Biller


"""
    REGISTER MODELS TO THE ADMIN
"""


@admin.register(Biller)
class BillerAdmin(admin.ModelAdmin):
    list_display = [f.name for f in Biller._meta.fields]
