from django.contrib import admin
from .models import Product

"""
    REGISTER PRODUCT MODEL
"""


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = [f.name for f in Product._meta.fields]
