import uuid

from django.db import models

from services.utils.Contants import currencies

"""
    PRODUCT MODEL
"""


class Product(models.Model):
    from transactions.models import TransactionType
    type = models.ForeignKey(TransactionType, on_delete=models.PROTECT)

    code = models.CharField(max_length=255, unique=True)
    name = models.CharField(max_length=255, unique=True)

    currency = models.CharField(max_length=255, choices=currencies)
    price = models.FloatField(default=0)
    is_active = models.BooleanField(default=True)

    from products.managers import ProductManager
    objects = ProductManager()

    class Meta:
        ordering = ['name', 'code']
        verbose_name = 'Product'
        verbose_name_plural = 'Products'

    def __str__(self):
        return f'{self.name}'

