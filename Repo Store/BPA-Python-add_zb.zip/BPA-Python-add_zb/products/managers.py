"""
    @author Marlvin Chihota
    Email marlvinchihota@gmail.com
    Created on 2021/11/27
"""

from django.db import models

"""
    PRODUCT MANAGER
"""


class ProductManager(models.Manager):

    def find_all(self) -> object:
        return self.all()

    def find_by_biller(self, biller_name: str) -> object:
        # case insensitive query
        return self.filter(type__biller__name__icontains=biller_name, is_active=True)

    def find_by_provider(self, provider_name : str) -> object:
        # case insensitive query
        return self.filter(type__biller__provider__name__icontains=provider_name)
