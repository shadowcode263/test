> 

    HOW TO INSTALL CELERY AND RELATED STUFF

>
  #### Windows
       <a href="https://www.rabbitmq.com/install-windows.html">Download Setup</a>
      
  #### Unix
      sudo apt-get install rabbitmq-server 

###### install requirements.txt

###### add start_flower.sh start_celery.sh to supervisor

###### <a href="http://127.0.0.1:5555/dashboard">Monitoring</a>
