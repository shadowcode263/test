import uuid

from django.contrib.auth.models import AbstractUser
from django.db import models

from services.utils.Contants import roles
from users.managers import CustomUserManager

"""
    USER MODEL
"""


class User(AbstractUser):
    username = models.CharField(max_length=255, unique=True)
    email = models.EmailField(unique=True)
    first_name = models.CharField(max_length=255)
    last_name = models.CharField(max_length=255)
    password_retry_chances = models.IntegerField(default=3)
    role = models.CharField(max_length=255, choices=roles)
    is_deleted = models.BooleanField(default=False)
    is_locked = models.BooleanField(default=False)
    has_reset_password = models.BooleanField(default=False)

    objects = CustomUserManager()

    class Meta:
        ordering = ['last_name', 'first_name']
        verbose_name = 'User'
        verbose_name_plural = 'Users'

    def __str__(self):
        return f'{self.username}'
